"""Exact rational population reference. No GPU, provider, or real data."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse,json

def run():
    rows=[]
    for r,h,l,d,c,p in product(map(F,['.6','.7','.8','.9']),map(F,['.7','.85','.95']),map(F,['.5','.6']),range(4),map(F,['.5','1']),map(F,['.65','.8'])):
        a=c*(4-d)/4
        def b(u):return p*p+(1-2*p)*u
        vals={'fixed':F(1,4),'no_extra':F(1,4)*(1-a)+a*b(r),'source_rr':F(1,4)*(1-a)+a*b((h+l)/2),'source_hash':F(1,4)*(1-a)+a*b((h+l)/2),'active':F(1,4)*(1-a)+a*b(h)}
        delta=vals['active']-min(v for k,v in vals.items() if k!='active')
        rows.append({'rho':str(r),'hi':str(h),'lo':str(l),'delay':d,'coverage':str(c),'confidence':str(p),'losses':{k:float(v) for k,v in vals.items()},'delta':float(delta),'sign':-1 if delta<0 else 1 if delta>0 else 0,'fixed_gain':float(vals['active']-vals['fixed'])})
    out={'scope':'INDEPENDENT_ANALYTIC_REFERENCE_NOT_GPU_RERUN','conditions':len(rows),'mean_active_minus_best':sum(x['delta'] for x in rows)/len(rows),'strict_wins':sum(x['sign']<0 for x in rows),'ties':sum(x['sign']==0 for x in rows),'strict_losses':sum(x['sign']>0 for x in rows),'rows':rows}
    assert len(rows)==384 and (out['strict_wins'],out['ties'],out['strict_losses'])==(256,32,96)
    assert abs(out['mean_active_minus_best']-(-.0113525390625))<1e-14
    return out
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();r=run();a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='rows'}))
