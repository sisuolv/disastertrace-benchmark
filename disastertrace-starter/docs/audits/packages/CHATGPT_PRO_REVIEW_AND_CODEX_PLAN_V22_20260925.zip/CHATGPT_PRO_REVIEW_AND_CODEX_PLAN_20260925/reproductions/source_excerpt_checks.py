"""Read-only synthetic checks of explicitly transcribed source expressions.
NOT a full checkout or repository pytest reproduction. No network or archives.
Reviewed head: 8a6e2162c86c46a139a7f438a6d63d8356e8917c.
"""
from __future__ import annotations
import json, math, hashlib, sys
from pathlib import Path
from copy import deepcopy
from dataclasses import dataclass
from typing import Mapping, Any

# NaturalAction and NaturalSource: executable validation statements transcribed
# from natural_track_v18.py; docstrings/comments omitted, behavior unchanged.
ACTION_KINDS={"RETRIEVE","WAIT","UPDATE","STOP"}
@dataclass(frozen=True)
class NaturalAction:
    kind: str
    at: int
    query_id: str|None=None
    wake_at: int|None=None
    probability: float|None=None
    def __post_init__(self):
        if not isinstance(self.kind,str) or self.kind not in ACTION_KINDS or isinstance(self.at,bool) or not isinstance(self.at,int):
            raise ValueError("Invalid natural action")
        if self.kind=="RETRIEVE":
            if not isinstance(self.query_id,str) or not self.query_id: raise ValueError("RETRIEVE needs query_id")
            if self.wake_at is not None or self.probability is not None: raise ValueError("RETRIEVE cannot carry wake_at or probability")
        elif self.kind=="WAIT":
            if self.query_id is not None or self.probability is not None: raise ValueError("WAIT cannot carry query_id or probability")
            if isinstance(self.wake_at,bool) or not isinstance(self.wake_at,int) or self.wake_at<=self.at: raise ValueError("WAIT needs a future wake_at")
        elif self.kind=="UPDATE":
            if self.query_id is not None or self.wake_at is not None: raise ValueError("UPDATE cannot carry query_id or wake_at")
            if self.probability is None or isinstance(self.probability,bool) or not isinstance(self.probability,(int,float)) or not math.isfinite(self.probability) or not 0<=self.probability<=1: raise ValueError("UPDATE needs a probability in [0,1]")
        else:
            fields=[n for n,v in (("query_id",self.query_id),("wake_at",self.wake_at),("probability",self.probability)) if v is not None]
            if fields: raise ValueError("STOP cannot carry "+", ".join(fields))
@dataclass(frozen=True)
class NaturalSource:
    query_id:str
    available_at:int
    content:Mapping[str,Any]
    public_schedule:bool=False
    def __post_init__(self):
        if not isinstance(self.query_id,str) or not self.query_id: raise ValueError("NaturalSource needs a query_id")
        if isinstance(self.available_at,bool) or not isinstance(self.available_at,int) or self.available_at<0: raise ValueError("NaturalSource available_at must be a non-negative integer")
        if not isinstance(self.content,Mapping): raise ValueError("NaturalSource content must be a mapping")
        if not isinstance(self.public_schedule,bool): raise ValueError("NaturalSource public_schedule must be a bool")

# Exact control-flow subset of NaturalKernel __init__/step/public view.
# _canonical_target is deliberately replaced by a prevalidated public target;
# no claim about target hash validation is made by these checks.
class KernelSubset:
    def __init__(self,sources,*,start,deadline,target):
        if isinstance(start,bool) or isinstance(deadline,bool) or not isinstance(start,int) or not isinstance(deadline,int) or start>=deadline: raise ValueError("Natural kernel clock and deadline must be increasing integers")
        if len({s.query_id for s in sources})!=len(sources): raise ValueError("Invalid natural source roster")
        self.sources={s.query_id:NaturalSource(s.query_id,s.available_at,deepcopy(dict(s.content)),s.public_schedule) for s in sources}
        self.clock=start;self.deadline=deadline;self.target=deepcopy(target)
        self.read={};self.stopped=False;self.expired=False;self.actions=[]
    def _visible_query_ids(self):
        if self.target is None:return set(self.sources)
        return {q for q,s in self.sources.items() if s.available_at<=self.clock or s.public_schedule}
    def _catalogue(self):
        rows=[]
        for q in sorted(self._visible_query_ids()):
            s=self.sources[q];r={"query_id":q}
            if s.public_schedule:r["available_at"]=s.available_at
            rows.append(r)
        return rows
    def step(self,a):
        if self.stopped:raise ValueError("No action is allowed after STOP")
        if self.expired:raise ValueError("No action is allowed after deadline; kernel is terminal")
        if a.at!=self.clock or a.at>self.deadline:raise ValueError("Action clock does not match environment")
        if self.clock>=self.deadline and a.kind!="STOP":raise ValueError("Deadline reached; only STOP is allowed")
        if a.kind=="RETRIEVE":
            s=self.sources.get(a.query_id)
            if s is None:raise ValueError("Unknown query" if self.target is None else "Query is not currently visible")
            if self.target is not None and a.query_id not in self._visible_query_ids():raise ValueError("Query is not currently visible")
            if s.available_at>self.clock:
                result={"status":"unavailable","query_id":a.query_id}
                if s.public_schedule:result["available_at"]=s.available_at
            else:
                content=deepcopy(dict(s.content));self.read[a.query_id]=deepcopy(content)
                result={"status":"available","query_id":a.query_id,"content":content}
        elif a.kind=="WAIT":
            self.clock=min(a.wake_at,self.deadline)
            if self.clock>=self.deadline:
                self.expired=True;result={"status":"expired","clock":self.clock,"deadline":self.deadline}
            else:result={"status":"advanced","clock":self.clock}
        elif a.kind=="UPDATE":result={"status":"updated","probability":a.probability,"read_query_ids":sorted(self.read)}
        else:self.stopped=True;result={"status":"stopped","clock":self.clock}
        self.actions.append(deepcopy({"action":a.kind,"at":a.at,"result":result}));return deepcopy(result)
    def public_state(self):
        state={"clock":self.clock,"deadline":self.deadline,"read_query_ids":sorted(self.read),"stopped":self.stopped,"expired":self.expired,"terminal":self.stopped or self.expired,"action_count":len(self.actions)}
        if self.target is not None:state.update({"schema":"disastertrace.v21.natural_public_state.v1","target":deepcopy(self.target),"catalogue":self._catalogue(),"read":deepcopy({k:dict(v) for k,v in self.read.items()})})
        return deepcopy(state)

# Exact executable body of current active policy, input validation included.
def visible_ids(state):
    rows=state.get("catalogue",[])
    if not isinstance(rows,list):raise ValueError("active policy requires a public catalogue")
    ids=[]
    for row in rows:
        if not isinstance(row,Mapping) or set(row)-{"query_id","available_at"}:raise ValueError("malformed public catalogue row")
        q=row.get("query_id")
        if not isinstance(q,str) or not q:raise ValueError("catalogue query_id must be nonempty")
        ids.append(q)
    return sorted(set(ids))
def active(state,threshold_m=5000.):
    state=deepcopy(dict(state));clock=state.get("clock")
    if isinstance(clock,bool) or not isinstance(clock,int):raise ValueError("active policy requires an integer clock")
    if state.get("terminal"):raise ValueError("policy cannot act on a terminal state")
    catalogue=visible_ids(state);read=state.get("read")
    if not isinstance(read,Mapping):raise ValueError("active policy requires the v21 read view")
    if not read:return NaturalAction("RETRIEVE",clock,query_id=catalogue[0]) if catalogue else NaturalAction("STOP",clock)
    observed=list(read.values())[-1]
    if not isinstance(observed,Mapping):raise ValueError("retrieved content must be a mapping")
    v=observed.get("visibility_m");remaining=[q for q in catalogue if q not in read]
    if remaining and len(read)<2:
        i=(0 if float(v)<threshold_m else min(1,len(remaining)-1)) if isinstance(v,(int,float)) and not isinstance(v,bool) else 0
        return NaturalAction("RETRIEVE",clock,query_id=remaining[i])
    if state.get("action_count",0)>len(read):return NaturalAction("STOP",clock)
    p=.8 if isinstance(v,(int,float)) and float(v)<threshold_m else .2
    return NaturalAction("UPDATE",clock,probability=p)

# _projection_probability: exact decision rule from run_v21_real_dev_deterministic_score.py.
def projection_probability(projection,target_start,target_end):
    periods=projection.get("periods")
    if not isinstance(periods,list):return .5
    lower_values=[]
    for period in periods:
        if not isinstance(period,Mapping):continue
        start,end=period.get("valid_start"),period.get("valid_end")
        if not isinstance(start,int) or not isinstance(end,int) or end<=target_start or start>=target_end:continue
        interval=period.get("visibility_m")
        if not isinstance(interval,Mapping):continue
        lower=interval.get("lower")
        if isinstance(lower,(int,float)) and not isinstance(lower,bool) and math.isfinite(float(lower)):lower_values.append(float(lower))
    if not lower_values:return .5
    return .8 if min(lower_values)<5000. else .2

# Comparison-eligibility predicate copied from grid_scoring_v18.py.
# No brier_report substitute is claimed here: this tests the gate alone.
def eligible(rows):
    from collections import defaultdict
    target_methods=defaultdict(lambda:defaultdict(set));target_weights=defaultdict(dict)
    for row in rows:
        t=str(row['target_id']);m=str(row['method'])
        target_methods[t][m].add((int(row['checkpoint_index']),str(row['checkpoint_id'])))
        target_weights[t].setdefault(m,{})[int(row['checkpoint_index'])]=float(row['score_weight'])
    ok=True
    for methods in target_methods.values():
        rosters=list(methods.values())
        if rosters and any(r!=rosters[0] for r in rosters[1:]):ok=False
    for methods in target_weights.values():
        weights=list(methods.values())
        if weights and any(r!=weights[0] for r in weights[1:]):ok=False
    return ok

# Same-time identity guard extracted from qualify_stream; qualify_evidence
# is intentionally not called. This observes only acceptance/rejection.
def chronology_guard(rows):
    last_a=None;last_i=None;by_a={}
    for c in rows:
        a=c['available_at'];i=c['issued_at'];identity=(c['source_id'],c['source_revision'],c['kind'])
        if a is not None:
            if last_a is not None and a<last_a:raise ValueError('not chronological by available_at')
            if last_a is not None and a==last_a and last_i is not None and i<last_i:raise ValueError('not chronological by issued_at at equal arrival time')
            s=by_a.get(a)
            if s:
                same_identity=(s['source_id'],s['source_revision'],s['kind'])==identity
                if c['source_id']==s['source_id'] and not same_identity and c['relation_status'] not in {'duplicate','revision','cancellation'}:raise ValueError('Conflicting evidence arrivals')
                if same_identity and json.dumps(c['content'],sort_keys=True)!=json.dumps(s['content'],sort_keys=True) and c['relation_status']!='conflict':raise ValueError('Conflicting content')
            last_a=a;last_i=i;by_a[a]=c
    return 'ACCEPTED'

observations=[]
def check(id,kind,fn,expected):
    try: actual=fn()
    except Exception as e: actual={'exception':type(e).__name__,'message':str(e)}
    met=expected(actual)
    observations.append({'id':id,'kind':kind,'actual':actual,'expected_observation_met':met})
    if not met:raise AssertionError((id,actual))

def main(out):
    t={'entity':'SYNTHETIC','variable':'visibility','threshold':5000.0,'unit':'m','comparison':'<','observation_rule':'synthetic observation in fixed window','target_start':100,'target_end':200,'contract_version':'audit.synthetic.v1'}
    t['contract_hash']=hashlib.sha256(json.dumps(t,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    check('K01','positive_control',lambda:NaturalAction('STOP',0,probability=.2),lambda a:isinstance(a,dict) and a.get('exception')=='ValueError')
    check('K02','positive_control',lambda:NaturalAction('UPDATE',0,probability=float('nan')),lambda a:isinstance(a,dict) and a.get('exception')=='ValueError')
    check('K03','positive_control',lambda:NaturalSource('q',True,{}),lambda a:isinstance(a,dict) and a.get('exception')=='ValueError')
    def hidden():
        k=KernelSubset([NaturalSource('q',20,{})],start=0,deadline=30,target=t);results=[]
        for name in ('q','absent'):
            try:k.step(NaturalAction('RETRIEVE',0,query_id=name))
            except ValueError as e:results.append(str(e))
        return results
    check('K04','positive_control',hidden,lambda a:a[0]==a[1])
    def detach():
        k=KernelSubset([NaturalSource('q',0,{'a':{'v':1}})],start=0,deadline=30,target=t)
        k.step(NaturalAction('RETRIEVE',0,query_id='q'));v=k.public_state();v['read']['q']['a']['v']=2
        return k.read['q']['a']['v']
    check('K05','positive_control',detach,lambda a:a==1)
    def expiry():
        k=KernelSubset([],start=0,deadline=30,target=t);k.step(NaturalAction('WAIT',0,wake_at=50));k.step(NaturalAction('UPDATE',30,probability=.1))
    check('K06','positive_control',expiry,lambda a:isinstance(a,dict) and a.get('exception')=='ValueError')
    def aftertarget():
        k=KernelSubset([],start=210,deadline=300,target=t);k.step(NaturalAction('UPDATE',210,probability=.1));return k.public_state()
    check('K07','counterexample',aftertarget,lambda a:a['clock']==210 and a['target']['target_end']==200)
    def freeclock():
        k=KernelSubset([NaturalSource('q',0,{})],start=0,deadline=30,target=t)
        for _ in range(100):k.step(NaturalAction('RETRIEVE',0,query_id='q'))
        k.step(NaturalAction('UPDATE',0,probability=.8));return {'clock':k.clock,'terminal':k.public_state()['terminal'],'public_prediction_present':any(s in k.public_state() for s in ['probability','prediction','forecast']),'actions':len(k.actions)}
    check('K08','scope_gap',freeclock,lambda a:a['clock']==0 and not a['terminal'] and not a['public_prediction_present'])
    def futureloop():
        k=KernelSubset([NaturalSource('a',20,{'visibility_m':100},True)],start=0,deadline=30,target=t);trace=[]
        for _ in range(5):a=active(k.public_state());trace.append(a.kind);k.step(a)
        return {'actions':trace,'clock':k.clock,'read':len(k.read),'terminal':k.stopped or k.expired}
    check('K09','counterexample',futureloop,lambda a:a=={'actions':['RETRIEVE']*5,'clock':0,'read':0,'terminal':False})
    def permuted():
        def once(roles):
            sources=[NaturalSource(q,0,{'visibility_m':v}) for q,v in roles]
            k=KernelSubset(sources,start=0,deadline=20,target=t);seq=[];p=None
            for _ in range(6):
                if k.stopped:break
                a=active(k.public_state());r=k.step(a)
                if a.kind=='RETRIEVE':seq.append(a.query_id)
                if a.kind=='UPDATE':p=a.probability
            return seq,p
        return {'original':once([('q0',4000),('q1',3000),('q2',9000)]),'same_roles_arbitrary_renaming':once([('a',4000),('z',3000),('b',9000)])}
    check('K10','counterexample',permuted,lambda a:a['original'][1]==.8 and a['same_roles_arbitrary_renaming'][1]==.2)
    check('P01','positive_control',lambda:projection_probability({'periods':[{'valid_start':0,'valid_end':10,'visibility_m':{'lower':6437.376}}]},0,10),lambda a:a==.2)
    check('P02','counterexample',lambda:projection_probability({'periods':[{'valid_start':0,'valid_end':10,'operator':'PROB30','conditional':True,'native_probability':.3,'visibility_m':{'lower':1000}}]},0,10),lambda a:a==.8)
    def projection_cross():
        return [projection_probability({'periods':[{'valid_start':0,'valid_end':10,'visibility_m':{'lower':4000,'upper':upper,'lower_closed':True}}]},0,10) for upper in (4000,9000)]
    check('P03','scope_gap',projection_cross,lambda a:a==[.8,.8])
    def grid_missing():
        return eligible([{'target_id':'A','method':'m1','checkpoint_index':0,'checkpoint_id':'k','score_weight':1},{'target_id':'B','method':'m2','checkpoint_index':0,'checkpoint_id':'k','score_weight':1}])
    check('G01','counterexample',grid_missing,lambda a:a is True)
    def grid_weights():
        return eligible([{'target_id':'A','method':m,'checkpoint_index':0,'checkpoint_id':'k','score_weight':w} for m,w in [('m1',1),('m2',.5)]])
    check('G02','positive_control',grid_weights,lambda a:a is False)
    def row(q,v,a=10,i=1):return {'source_id':q,'source_revision':'v1','kind':'taf','issued_at':i,'available_at':a,'content':{'v':v},'relation_status':'normal'}
    check('E01','positive_control',lambda:chronology_guard([row('A',1,20,1),row('B',2,10,2)]),lambda a:isinstance(a,dict) and a.get('exception')=='ValueError')
    check('E02','positive_control',lambda:chronology_guard([row('A',1,10,5),row('B',2,20,1)]),lambda a:a=='ACCEPTED')
    check('E03','positive_control',lambda:chronology_guard([row('A',1),row('A',2)]),lambda a:isinstance(a,dict) and a.get('exception')=='ValueError')
    check('E04','counterexample',lambda:chronology_guard([row('A',1),row('B',5),row('A',2)]),lambda a:a=='ACCEPTED')
    # Exact stable sorted-first selection pattern in binder, using synthetic
    # candidate tuples only; no ASOS reader or production run is invoked.
    def y_order():
        def pick(rows):
            candidates=sorted(rows,key=lambda x:x['valid'])
            return int(candidates[0]['vsby']*1609.344<5000)
        low={'valid':120,'vsby':1.};high={'valid':120,'vsby':10.}
        return [pick([low,high]),pick([high,low])]
    check('Y01','counterexample',y_order,lambda a:a==[1,0])
    def wrong_reproduce_input():
        source={'schema':'disastertrace.v21.real_dev_source_bridge.v1','outcomes_accessed':False,'model_calls':0,'rows':[]}
        outcomes={'actor_received_outcomes':False,'unbound_count':0,'rows':[]}
        if source.get('outcomes_accessed') is not False or source.get('model_calls')!=0:raise ValueError('source input must remain source-only')
        if outcomes.get('actor_received_outcomes') is not False or outcomes.get('unbound_count')!=0:raise ValueError('outcome input is not a complete evaluator-only dev binding')
        y_by_episode={row['episode_id']:int(row['outcome_y']) for row in outcomes['rows']}
        return source['episodes']
    check('R01','counterexample',wrong_reproduce_input,lambda a:isinstance(a,dict) and a.get('exception')=='KeyError')
    payload={'schema':'disastertrace.v21.audit_scoped_observations.v1','head':'8a6e2162c86c46a139a7f438a6d63d8356e8917c','scope':'source-transcribed executable function/predicate subsets; NOT full repository execution or byte-matched module hydration','repository_tests_run':0,'network_calls':0,'gpu_jobs':0,'raw_archive_reads':0,'observations':observations,'counts':{'total':len(observations),'expected_observations_met':sum(o['expected_observation_met'] for o in observations),'counterexamples':sum(o['kind']=='counterexample' for o in observations),'positive_controls':sum(o['kind']=='positive_control' for o in observations),'scope_gaps':sum(o['kind']=='scope_gap' for o in observations)}}
    Path(out).write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n');print(json.dumps(payload['counts']))
if __name__=='__main__':main(sys.argv[1])
