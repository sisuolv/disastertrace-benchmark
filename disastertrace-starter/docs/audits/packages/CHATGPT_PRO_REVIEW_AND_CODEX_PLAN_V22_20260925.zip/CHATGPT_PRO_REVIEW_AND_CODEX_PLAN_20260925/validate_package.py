"""Validate this handoff package only. No network, archive, model, or GPU access."""
from pathlib import Path
import argparse, hashlib, json, re, sys

REQUIRED = ['README.md','REVIEW_REPORT.md','CODE_AUDIT.md','EXPERIMENT_AUDIT.md',
            'PLAN_TRACEABILITY_MATRIX.md','CLAIM_EVIDENCE_MATRIX.md','FOLLOWUP_PLAN.md',
            'CODEX_HANDOFF.md','EXECUTION_MANIFEST.json','TASKS.json','SOURCE_INVENTORY.json']

def validate(root: Path, check_hashes: bool = True) -> dict:
    root=root.resolve()
    for name in REQUIRED:
        if not (root/name).is_file(): raise ValueError('Missing required file: '+name)
    for path in root.rglob('*'):
        if path.is_symlink(): raise ValueError('No symlinks permitted: '+str(path))
    payload=[p for p in root.rglob('*') if p.is_file()]
    for p in payload:
        if p.suffix=='.json': json.loads(p.read_text(encoding='utf-8'))
    tasks=json.loads((root/'TASKS.json').read_text())
    items=tasks['tasks']; by={r['id']:r for r in items}
    if len(by)!=len(items): raise ValueError('Duplicate task ids')
    seen=set(); active=set()
    def visit(key):
        if key in active:raise ValueError('Cyclic dependency: '+key)
        if key in seen:return
        if key not in by:raise ValueError('Unknown dependency: '+key)
        active.add(key)
        for dep in by[key]['dependencies']:visit(dep)
        active.remove(key);seen.add(key)
    for row in items:
        visit(row['id'])
        if row['status']!='PROPOSED_NOT_EXECUTED':raise ValueError('Unexpected executed task')
        for field in ['files','inputs','commands','outputs','acceptance','stop_condition','risks']:
            if not row.get(field):raise ValueError(row['id']+' missing '+field)
    if any(v!='BLOCKED_EXPLICIT_AUTHORIZATION' for v in tasks['default_authorizations'].values()):
        raise ValueError('Unexpected default authorization')
    manifest=json.loads((root/'EXECUTION_MANIFEST.json').read_text())
    if manifest['actual_head_at_start']!=manifest['actual_head_at_final_recheck']:
        raise ValueError('Head mismatch not reconciled')
    if manifest['repository_pytest_nodes_executed']!=0:
        raise ValueError('Incorrect full-repository test execution claim')
    boundary=manifest['boundary']
    for key in ['real_provider_api_calls','new_gpu_jobs','training_runs','weather_downloads',
                'raw_weather_archive_reads','raw_outcome_archive_reads','holdout_reads','quarantine_reads','protected_window_reads']:
        if boundary[key]!=0:raise ValueError('Unexpected restricted action '+key)
    if boundary['published_development_outcome_artifact_read'] is not True:
        raise ValueError('Published-outcome artifact read must be disclosed')
    matched=0
    if check_hashes:
        checks=root/'SHA256SUMS.txt'
        if not checks.is_file():raise ValueError('Missing SHA256SUMS.txt')
        listed={}
        for line in checks.read_text().splitlines():
            if not line.strip():continue
            digest,rel=line.split('  ',1)
            if not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('Bad checksum')
            p=(root/rel).resolve()
            if not p.is_relative_to(root):raise ValueError('Checksum path escaped root')
            if rel in listed:raise ValueError('Duplicate checksum path')
            listed[rel]=digest
            if hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise ValueError('Hash mismatch '+rel)
            matched+=1
        expected={p.relative_to(root).as_posix() for p in payload if p.name!='SHA256SUMS.txt'}
        if set(listed)!=expected:raise ValueError('Checksum payload coverage mismatch')
    return {'status':'PASS','scope':'handoff-package-only; not benchmark validation',
            'task_count':len(items),'source_files_with_declared_read_scope':manifest['files_with_read_scope_listed'],
            'payload_files':len(payload),'sha256_payloads_verified':matched,
            'json_valid':True,'dag_acyclic':True,'default_external_permissions_blocked':True}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('directory',type=Path,nargs='?',default=Path(__file__).parent)
    parser.add_argument('--no-checksums',action='store_true',help='Build-time structural check only')
    args=parser.parse_args()
    try:print(json.dumps(validate(args.directory,not args.no_checksums),ensure_ascii=False,indent=2))
    except Exception as exc:print(str(exc),file=sys.stderr);raise SystemExit(1)
