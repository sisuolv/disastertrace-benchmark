# 计划追溯矩阵

完整 `plan/plans_v21_0925` 与 `plan/plan_v18_0922` 目录未取得。本表对照的是实际可读v18原计划副本、早期v21审计文档、当前发布与Notion；不是伪造缺失计划的逐任务验收。

|计划要求|当前实现/实验|证据|状态|缺口|下一步|
|---|---|---|---|---|---|
|V18-1 固定未来目标/多提前量|3个前置checkpoint已构造；多提前量后端未资格|builder/_checkpoint_cutoffs；G1|VERIFIED|原目标routine/terminal/first-valid未统一；长lead未完成|P0-02|
|V18-2 专业信息、F与真实Y分离|sourcebridge和Y binder分开，但score另行重选|source bridge/binder/score|VERIFIED|组件分离不等于同一实验完整绑定|P0-01/02/03|
|V18-3 来源/内容/信息效用分层|comparison hash已剥离行政字段|evidence_qualification_v18|VERIFIED|CNL/BECMG/支持/冲突和概率后端仍需资格|P0-04|
|V18-4 Endpoint vs Trajectory|synthetic score把最终p填给各点|natural_synthetic_score_v21|CONTRADICTED|不能验证动态有效轨迹差异|P0-03/05|
|V18-5 Adaptation vs Stability|synthetic low/high及renameprefix|active_policy/tests|VERIFIED|任意重命名失败；不是实际LLM适应能力|P1-01|
|V18-6 Repair→forecast loss|cache repair有trace差异|repair_trial_v21|VERIFIED|未证明实际Y损失改善，隔离和绑定不足|P0-06/P1-03|
|V18-7 四类强基线|age/earliest/hash/.5诊断；程序selector适配|real deterministic score|VERIFIED|没有当前同目标专业概率、强统计或provider端到端|P1-02/P2-01|
|V18-8 完整Natural active track|read/catalogue/target及4action实现|natural_track/active_policy|VERIFIED|无有效预测时间链与延迟失败处理；公开future可原地重试|P0-05|
|V18-9 Prospective Living|未见本次未来封存/成熟结算实际运行|release/claim table|INCONCLUSIVE|历史代码/模拟不等于前瞻|P3-01，L1/L2另授权|
|V18-10 多模态/第二域|旧资产非本次主要实验|v18原计划/旧模块地图|INCONCLUSIVE|没有当前协议的跨域实证|P3-01延后|
|V18-11 shared F/equal cost|cost surface的3臂2次抽象查询、相同F和N×4|cost script/result headers|VERIFIED|不是Natural实际token/wall成本；F丢初始信息|P1-00/01|
|V18-12 配对、过程分组、校准与确认|3GPU独立seed；开发24目标|aggregate/outcomes|VERIFIED|replica/cell/checkpoint不是独立天气过程；无校准/holdout支持|P1-02/P3-00|
|V21 本次13个指定run脚本及6模块存在|源码按命名范围读取|SOURCE_INVENTORY.json|VERIFIED|存在不等于所有分支/任务执行|P0-00|
|V21 226项测试与全manifest通过|报告和日志声明|TEST_STATUS/SNAPSHOT|REPORTED_ONLY|本轮没有完整checkout复跑226或重算65项|P0-00/01|
|V21 完整 plans_v21_0925 每项|未取得完整目录正文；有早期audit副本|docs/plans/PLAN_V21_AUDIT_20260925_CN.md|BLOCKED|不能替缺失完整计划计算完成率或关闭所有A-G任务|取得原包hash/文本，再追加矩阵|
|V18 原始 plan_v18_0922 整目录|有PLAN_V18_ORIGINAL_CN.md副本|docs/plans/PLAN_V18_ORIGINAL_CN.md|INCONCLUSIVE|可对照正文目标，不能认证目录中其他文件/授权|补原目录文档清单，不读数据|
|Notion C1|主动系统增量与同F获取是不同结果|当前Notion01/03/04/10|VERIFIED|当前新结果还只是程序选源/模拟，不是完整LLM Natural|P2-01|
|Notion C2|错误→修复→后续损失|Notion04/07/09/10|VERIFIED|trace差异替代损失的风险尚在|P1-03|
|Notion C3|独立target/backend/weather过程复验|Notion07/10|INCONCLUSIVE|未完成对应泛化实证|P3-01|

**完成率：不出具完整原计划完成百分比。** 当前真实Y派生诊断比旧v20进了一步，不能再写“从未结算Y”；也不能把GPU Monte Carlo或public view代码存在计作Natural/论文目标全部完成。缺失原包属于无法验证，不是实现错误。
