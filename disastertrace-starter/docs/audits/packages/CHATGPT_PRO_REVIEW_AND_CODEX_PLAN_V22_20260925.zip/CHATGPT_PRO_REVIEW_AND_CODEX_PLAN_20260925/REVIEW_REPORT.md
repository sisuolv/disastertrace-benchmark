# DisasterTrace v21：独立研究／代码／实验审核

**审查日期：2026-09-25。实际HEAD与指定8a6e2162c86c46a139a7f438a6d63d8356e8917c一致。**

## 简短结论

工程有真实进展，且现在确实存在带ASOS标签的development诊断；不能沿用旧“完全没有Y”的状态。六个GPU成功有保存调度凭证。但当前主科学问题没有因此关闭：真实score与Natural轨迹脱节、结果政策不统一、共同分母和arrival冲突仍有反例；synthetic adaptive优势主要是生成器公开给策略的路由先验。**当前NO-GO于协议冻结、立即provider运行和天气增益摘要；CONDITIONAL GO于最小修复和低成本反证。**

## 证据纪律

VERIFIED表示本报告限定范围内的源码、保存日志、算术或复现支持；REPORTED_ONLY表示未独立复算的自报/汇总；INCONCLUSIVE表示证据不足；BLOCKED表示缺文件/环境/权限；CONTRADICTED表示具体实现或来源冲突。不是所有发现都能归咎代码bug：baseline弱、样本少、generator先验是实验解释问题。

本轮通过GitHub连接器直接读取代码，Notion全文读回；无完整checkout、无原测试226项重跑。实际执行21个源函数/判定式子集观察：11正控制、8反例、2范围缺口；另有理数枚举384个参数条件。转录子集明确省略无关docstring/comments，并在需要处明确替代target已验证输入；不能叫Git blob一致的全模块执行。详见EXECUTION_MANIFEST和reproductions。

## 进展与计划

read/catalogue、target hash、hidden-handle拒绝、content-aware合成policy、同target冲突Y隔离、arrival主顺序已经改善。原始计划可读副本与最新完整plan目录不是同一材料；完整 `plans_v21_0925` 未取得，所以不出具全计划完成率。早期v21文档写无Y、后来_04有Y，是阶段更新，不自动构成自相矛盾。run记录9dffe dirty、release8a6是后续发布身份，应依源码哈希映射，不把两个SHA强行等同。

Notion仍在较早快照上解释C1/C2/C3，其方向是完整Agent增量与同F获取/同父干预分开；v21开发规则表和GPU模拟不能替代其承诺的Natural主结果。Notion“当前无Y”的进度应该追加更新，但不能把新first-valid诊断包装成原routine研究目标已通过。

## 八项Go/No-go

| 问题 | 判断 | 依据与失败风险 | 解除条件 |
|---|---|---|---|
| 工程是否进入下一轮 | CONDITIONAL GO | 代码/正向控制已有进展，但P0反例可破坏实验意义 | 先离线修对应入口；不重构全部旧系统 |
| Natural协议冻结 | NO-GO | 公共未来源重试、无effective forecast、deadline未绑目标、失败cap无评分 | P0-02/03/05与实际三时点端到端验收 |
| 立即provider pilot | BLOCKED/NO-GO | 既无新权限/模型决定，又有raw capture/输入协议缺口 | P0-07、P2-00和独立P1授权 |
| 最小provider设计 | CONDITIONAL GO（设计） | 同F内容依赖selector+强程序，所有目标/点失败保留 | 新run/model身份/完整roster/预算/no retry；详FOLLOWUP_PLAN |
| 是否先修scoring/identity/deadline/chronology | GO | G01/E04/K07/09与目标政策冲突为具体例子 | 先红后绿、独立review、旧结果不改 |
| active方向是否继续 | CONDITIONAL GO | 一般能力有意义，但当前oracle路由和age规则不能作新效果证据 | 可辨合法来源、强F、同成本、非oracle、噪声/逆转/跨过程反证 |
| 应停止什么 | NO-GO于当前扩算叙事 | 更多相同DGP的MC、弱prior胜利、trace不同、日期/阈值后改不能补科学缺口 | 保存旧结果、按限定机制归档，转向判别力实验 |
| 是否paper-ready | NO-GO于结果性摘要；GO于方法草稿 | 无provider天气收益/校准/独立确认；目标结算仍待资格 | 强真实对照、可靠Y/时间/失败分母、预注册与适用边界 |

## 六层最终判断

1. 工程：VERIFIED局部实现，仍有P0/P1错误；见CODE_AUDIT。
2. 测试：REPORTED_ONLY全226；已读17个v21测试，存在窄fixture与不充分断言。
3. 执行：VERIFIED保存的6个成功scheduler receipts；raw cells/全hash重建未完成。
4. 设计：CONTRADICTED复现schema、target policy和跨method gate；其他局部有效。
5. 方法：INCONCLUSIVE天气value；VERIFIED解析显示该DGP内优势预设条件。
6. novelty：INCONCLUSIVE整体研究贡献；不支持algorithm首创。不要因component已有先例就删除完整研究对象。

## 最重要的替代解释

- 真实表的改善来自弱.5 prior，而非selector；常零/常数.2的事后检查已显示这一风险。
- 三个selector相等可能因为source选择空间弱或预测映射相同；不等于所有内容依赖获取都无用。
- synthetic active知道生成器路由；优势是规定的信息结构，不是未知环境下的学习或可靠匹配。
- last-signal F忽略已有证据，校准错误可能使某些“更可靠”信号仍输给prior/initial。
- 816wins混合重复配置和总体平局的MC符号；不是816独立显著条件。
- 真实结果选择规则、未解冲突、稀疏正例与source-derived target选择，均可能改变天气解释。

最优下一步不是取消active，而是把它放到能失败的强对照中：固定同F/预算/时间，加入路由逆转、无可靠提示、合法ID置换和后端敏感性；然后在独立获准的真实目标上检验。

完整细节：CODE_AUDIT.md、EXPERIMENT_AUDIT.md、PLAN_TRACEABILITY_MATRIX.md、CLAIM_EVIDENCE_MATRIX.md、FOLLOWUP_PLAN.md。相关原论文的完整引用、链接与具体支持范围见LITERATURE_REFERENCES.md。
