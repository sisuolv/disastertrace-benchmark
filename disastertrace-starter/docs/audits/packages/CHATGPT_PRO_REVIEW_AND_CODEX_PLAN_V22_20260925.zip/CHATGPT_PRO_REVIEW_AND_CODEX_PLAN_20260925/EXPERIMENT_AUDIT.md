# 实验与结果审计

## 证据分层与读取范围

本轮读取了用户明确指定的已发布development派生结果，包括ASOS标签JSON及deterministic评分JSON；这属于审查输入，**不能填写“outcome artifact reads=0”**。未读原始TAF/METAR/ASOS body、未调用真实provider、未提交GPU、未列举或读取holdout/quarantine。

`VERIFIED` 的数值限定为本文写明的算术/已发布记录；不自动证明原生标签正确。`REPORTED_ONLY` 不等于虚构。原始文件与完整运行环境不可访问，相关全量复算为 `BLOCKED`。

## 当前数字

| 项目 | 数值 | 状态及证据上限 |
|---|---:|---|
| Development target/episode | 24 | VERIFIED：ASOS发布列表逐项读回；四站×1月1–6日，不是24独立过程 |
| checkpoint | 72 | VERIFIED：登记结构3点/目标与评分记录；72个source-bridge trace另为24×3 selector，不能混同 |
| ASOS target binding | 24/24 BOUND | VERIFIED：已发布记录及窗口算术；INCONCLUSIVE：不是原始观测/routine/QC/成熟政策认证 |
| Y分布 | 22为0、2为1 | VERIFIED：发布标签计数；不是自然机场风险率 |
| fixed | Q=.25，72cells，query0 | VERIFIED 算术；完整逐方法输入身份复算未做 |
| earliest/hash/active_age | 各Q=.11041666666666668，sum7.95，72cells，query65 | REPORTED_ONLY（完整逐方法重建）；源码、逐行样例、汇总与loss频数算术一致 |
| active−fixed | −.13958333333333334 | VERIFIED：以上报告值的独立相减；不是相对专业概率或强基线增益 |
| active−best nonactive | 0 | REPORTED_ONLY 全体逐行等价；源码和已读样例支持无独立selector证据 |
| shared-delay | 144配置×3=432行，active-best +.006160525294641654；wins31/ties158/loss243 | 配置数VERIFIED；全量结果REPORTED_ONLY，未重算432行 |
| cost-matched | 384配置×3=1152行；active-best −.011311323556583375；wins816/loss336 | 配置数VERIFIED；实测全量aggregate REPORTED_ONLY；解析期望独立重建见下 |
| v21 provider/model calls | 报告0 | REPORTED_ONLY历史总量；所读实验脚本无provider路径VERIFIED；编码AI不计被测模型 |
| 本轮新增真实provider/GPU | 0/0 | VERIFIED，本轮工具记录 |
| 历史actor无Y/holdout无访问 | flags=false | 静态数据流与声明支持；无法从布尔常量独立认证历史所有文件访问，INCONCLUSIVE |

### Loss频数核对与弱参照

已返回完整评分文本的工具检索计数：0.6400000000000001 共18行；0.04000000000000001共162行；0.03999999999999998共15行；0.25共93个数据行（另一个0.25是summary）。三source方法合计195个非fallback损失、21个fallback损失。其总和/3为7.95；7.95/72=.1104166667。此为频数/算术复核，不替代按episode/method完整join和源档案复算。

由已公布的22/2 Y分布，纯事后检查可得：常零Q=2/24=.0833333333；常数p=.2的Q=.09，均低于.1104166667。它们是审计参照，不是用测试集重新训练/预注册气候态，也不证明这些规则能泛化。结果说明“超过.5”不能承担天气增量的主要论据。

## 真实score与Natural不是同一条运行链

`run_v21_real_dev_source_bridge.py`实际让program selector通过kernel查询，但从首checkpoint启动、一般短序列即STOP。它产生 `rows/trace_count`，没有score所需的 `episodes/checkpoints/qualifications`。

`run_v21_real_dev_deterministic_score.py`独立从G1每checkpoint重选一条，`active_age`是age排序，不是内容依赖follow-up；它不读取bridge中实际执行的trace。因此REPRODUCE把bridge传给它会失败；不能把这个开发score称作前者Natural actor的评价。

## GPU收据

以下六个已保存 `describe.json` 均直接读取，state=SUCCEEDED，startup_script一致指向对应脚本/seed/n/cuda，lme.current_retries=0：

| 系列 | 保存job名 | seed | n/cell | 声明设备 |
|---|---|---:|---:|---|
| shared | om-9ztw5ypm | 310925 | 1000000 | 5090 |
| shared | om-qolmuk6c | 320925 | 1000000 | 5090 |
| shared | om-elhqpnle | 330925 | 1000000 | H100-share |
| cost | om-2i6w8d3y | 350925 | 500000 | 5090 |
| cost | om-hkd7uz7t | 360925 | 500000 | 5090 |
| cost | om-bdekxc0e | 370925 | 500000 | H100-share |

`VERIFIED`：保存的调度成功凭证和命令字段。没有实时查询调度器，也没有重新运行这些job。cost 5090/H100 result头及早期cell已抽查：每方法n×4分母、相同n、对应seed和设备。全部1152+432 cell、request/command文件、script SHA、manifest65项的字节级独立校验尚未完成，不能写“全部manifest已过”。

5090使用PyTorch2.8.0a0/Python3.12，H100使用2.3.0a0/Python3.10；可作为同DGP的不同Monte Carlo replica条件性合并，不能当字节一致的硬件复现，更不能把设备与环境变化造成的差异独立归因于硬件。应按replica保留估计和不确定性，禁止重复cell造成伪样本量。

## 独立解析重建：cost-matched surface

设初始信号正确率r，较可靠后续h，较差后续l，输出高概率p，coverage=c，delay=d，4个checkpoint。定义

\[
a=c(4-d)/4,\quad B(u,p)=p^2+(1-2p)u.
\]

生成器让initial=1时q1可靠、initial=0时q2可靠；active知道这个路由，因此总取h。固定后续的边际正确率为(h+l)/2。共同后端仅消费最后一个signal：

\[
Q_0=.25,
\quad Q_{no}=.25(1-a)+aB(r,p),
\quad Q_{rr}=Q_{hash}=.25(1-a)+aB((h+l)/2,p),
\quad Q_{active}=.25(1-a)+aB(h,p).
\]

对代码全部384参数组合用有理数独立枚举：
- 平均 active−best_nonactive = **−0.0113525390625**。
- 平均 active−fixed = **−0.0439453125**。
- 每replica总体严格赢256、平32、输96；三replica为768／96／288。
- 768 + 96/2 = 816，与报告的严格符号计数相同是值得核查的解释：总体平局可能被有限MC正负号各分一半。**这不证明实际报告的全部96行都发生了该原因，也不认证816原始计数。**

报告−.0113113与解析值相近。它支持实现符合指定生成机制的检查方向，而不是新算法学到了天气结构。无需更多同类型GPU样本即可知道其理论优势条件；保留为正控制即可。

### “best non-active”不是只含等成本对照

报告的best还包括0次查询的fixed与1次查询的no_extra。因此816/1152是与**混合成本参照中事后取最小分数**的比较，不能直接说成“在816个等成本条件赢”。应额外报告严格2次查询的active vs RR/hash。

本DGP的解析结果为：

\[
Q_{active}-\min(Q_{rr},Q_{hash})=-a(2p-1)(h-l)/2<0.
\]

全部384条件严格为负，均值−0.0298828125。这更直接表明优选路由规则的优势已经写入生成条件。它仍是合法的正控制；没有预先学得/可观测的路由质量时不能直接外推。

## Shared-delay与其他surface

Shared-delay的RR各时点重新抽噪声，active复用信号；hash固定p=.65而active可.8。因此其−.026375相对.5改善与active-best为正可以同时成立。纯查询成本与置信度未隔离，不能当equal-cost negative replication。

`signal_reliability_mc`和`calibration_sensitivity`原代码本就包含解析式，审稿不应把简单重推包装成新研究成果。`budgeted_miscalibration`对q_true的正比例中心缩放通常保留uncertainty排序，主要改变校准，不足以检验选择质量估计错误。应新增噪声排名/角色逆转/无信息条件，并用同一个正确posterior后端对照。

## 事后 best 选择与解析对象的边界

报告逐cell取同一评价样本中非active方法的最小经验损失；本文解析值则取各方法总体期望损失的最小值。二者有限样本下不严格相同：E[min_j Qhat_j] <= min_j E[Qhat_j]。尤其在总体平局附近，噪声和事后挑最小会影响符号计数与差值。因此−.01135254不是对原GPU输出的逐位复算，816也不是显著优势次数。新报告需同时列各预登记pair、独立开发期选定的best baseline，以及明确标注的hindsight-best诊断。

## 本轮只核验了一个日志payload的字节身份

`v17_v21_regression_final.log` 的320字节可从返回文本精确重建；Git blob和SHA-256均匹配，包含226个点。`regression.log`与`_final.log`在manifest中使用同一hash，不算两份独立测试证明。这个核验不重跑测试、不认证nodeid，也不认证其余64项。结果见 `reproductions/LOG_HASH_CHECK.json`。
