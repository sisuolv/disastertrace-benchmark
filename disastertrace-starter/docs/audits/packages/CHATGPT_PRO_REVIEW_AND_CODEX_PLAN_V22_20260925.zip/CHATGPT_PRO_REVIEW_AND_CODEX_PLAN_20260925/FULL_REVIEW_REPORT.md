# DisasterTrace V21 完整独立复核报告与后续计划

审查日期2026-09-25；固定HEAD `8a6e2162c86c46a139a7f438a6d63d8356e8917c`。各章节原文件同时保留。


---

<!-- Source section: REVIEW_REPORT.md -->

# DisasterTrace v21：独立研究／代码／实验审核

**审查日期：2026-09-25。实际HEAD与指定8a6e2162c86c46a139a7f438a6d63d8356e8917c一致。**

## 简短结论

工程有真实进展，且现在确实存在带ASOS标签的development诊断；不能沿用旧“完全没有Y”的状态。六个GPU成功有保存调度凭证。但当前主科学问题没有因此关闭：真实score与Natural轨迹脱节、结果政策不统一、共同分母和arrival冲突仍有反例；synthetic adaptive优势主要是生成器公开给策略的路由先验。**当前NO-GO于协议冻结、立即provider运行和天气增益摘要；CONDITIONAL GO于最小修复和低成本反证。**

## 证据纪律

VERIFIED表示本报告限定范围内的源码、保存日志、算术或复现支持；REPORTED_ONLY表示未独立复算的自报/汇总；INCONCLUSIVE表示证据不足；BLOCKED表示缺文件/环境/权限；CONTRADICTED表示具体实现或来源冲突。不是所有发现都能归咎代码bug：baseline弱、样本少、generator先验是实验解释问题。

本轮通过GitHub连接器直接读取代码，Notion全文读回；无完整checkout、无原测试226项重跑。实际执行21个源函数/判定式子集观察：11正控制、8反例、2范围缺口；另有理数枚举384个参数条件。转录子集明确省略无关docstring/comments，并在需要处明确替代target已验证输入；不能叫Git blob一致的全模块执行。详见EXECUTION_MANIFEST和reproductions。

## 进展与计划

read/catalogue、target hash、hidden-handle拒绝、content-aware合成policy、同target冲突Y隔离、arrival主顺序已经改善。原始计划可读副本与最新完整plan目录不是同一材料；完整 `plans_v21_0925` 未取得，所以不出具全计划完成率。早期v21文档写无Y、后来_04有Y，是阶段更新，不自动构成自相矛盾。run记录9dffe dirty、release8a6是后续发布身份，应依源码哈希映射，不把两个SHA强行等同。

Notion仍在较早快照上解释C1/C2/C3，其方向是完整Agent增量与同F获取/同父干预分开；v21开发规则表和GPU模拟不能替代其承诺的Natural主结果。Notion“当前无Y”的进度应该追加更新，但不能把新first-valid诊断包装成原routine研究目标已通过。

## 八项Go/No-go

| 问题 | 判断 | 依据与失败风险 | 解除条件 |
|---|---|---|---|
| 工程是否进入下一轮 | CONDITIONAL GO | 代码/正向控制已有进展，但P0反例可破坏实验意义 | 先离线修对应入口；不重构全部旧系统 |
| Natural协议冻结 | NO-GO | 公共未来源重试、无effective forecast、deadline未绑目标、失败cap无评分 | P0-02/03/05与实际三时点端到端验收 |
| 立即provider pilot | BLOCKED/NO-GO | 既无新权限/模型决定，又有raw capture/输入协议缺口 | P0-07、P2-00和独立P1授权 |
| 最小provider设计 | CONDITIONAL GO（设计） | 同F内容依赖selector+强程序，所有目标/点失败保留 | 新run/model身份/完整roster/预算/no retry；详FOLLOWUP_PLAN |
| 是否先修scoring/identity/deadline/chronology | GO | G01/E04/K07/09与目标政策冲突为具体例子 | 先红后绿、独立review、旧结果不改 |
| active方向是否继续 | CONDITIONAL GO | 一般能力有意义，但当前oracle路由和age规则不能作新效果证据 | 可辨合法来源、强F、同成本、非oracle、噪声/逆转/跨过程反证 |
| 应停止什么 | NO-GO于当前扩算叙事 | 更多相同DGP的MC、弱prior胜利、trace不同、日期/阈值后改不能补科学缺口 | 保存旧结果、按限定机制归档，转向判别力实验 |
| 是否paper-ready | NO-GO于结果性摘要；GO于方法草稿 | 无provider天气收益/校准/独立确认；目标结算仍待资格 | 强真实对照、可靠Y/时间/失败分母、预注册与适用边界 |

## 六层最终判断

1. 工程：VERIFIED局部实现，仍有P0/P1错误；见CODE_AUDIT。
2. 测试：REPORTED_ONLY全226；已读17个v21测试，存在窄fixture与不充分断言。
3. 执行：VERIFIED保存的6个成功scheduler receipts；raw cells/全hash重建未完成。
4. 设计：CONTRADICTED复现schema、target policy和跨method gate；其他局部有效。
5. 方法：INCONCLUSIVE天气value；VERIFIED解析显示该DGP内优势预设条件。
6. novelty：INCONCLUSIVE整体研究贡献；不支持algorithm首创。不要因component已有先例就删除完整研究对象。

## 最重要的替代解释

- 真实表的改善来自弱.5 prior，而非selector；常零/常数.2的事后检查已显示这一风险。
- 三个selector相等可能因为source选择空间弱或预测映射相同；不等于所有内容依赖获取都无用。
- synthetic active知道生成器路由；优势是规定的信息结构，不是未知环境下的学习或可靠匹配。
- last-signal F忽略已有证据，校准错误可能使某些“更可靠”信号仍输给prior/initial。
- 816wins混合重复配置和总体平局的MC符号；不是816独立显著条件。
- 真实结果选择规则、未解冲突、稀疏正例与source-derived target选择，均可能改变天气解释。

最优下一步不是取消active，而是把它放到能失败的强对照中：固定同F/预算/时间，加入路由逆转、无可靠提示、合法ID置换和后端敏感性；然后在独立获准的真实目标上检验。

完整细节：CODE_AUDIT.md、EXPERIMENT_AUDIT.md、PLAN_TRACEABILITY_MATRIX.md、CLAIM_EVIDENCE_MATRIX.md、FOLLOWUP_PLAN.md。相关原论文的完整引用、链接与具体支持范围见LITERATURE_REFERENCES.md。


---

<!-- Source section: CODE_AUDIT.md -->

# 代码与测试审计

固定 HEAD：`8a6e2162c86c46a139a7f438a6d63d8356e8917c`。路径相对 `disastertrace-starter/`。发现严重性是使用路径的门槛，不是认定所有旧结果被破坏。

## F01｜P0｜`CONTRADICTED`｜复现指南把错误 schema 输入交给评分脚本

**位置：** `artifacts/v21_execution_20260925_04/REPRODUCE.md / scripts/run_v21_real_dev_deterministic_score.py::run`

**证据：** 指南传 REAL_DEV_SOURCE_BRIDGE.json；该文件根键是 rows/trace_count，评分函数却访问 source["episodes"]。这是发布文档与实际入口的确定性不一致。

**复现／范围：** 用只含 rows/outcomes_accessed=false/model_calls=0 的合成 bridge，加完整空 evaluator 元数据，运行到 source["episodes"] 即 KeyError。未执行真实资料命令。

**修复建议：** 修复指南和 schema/type guard；若评分 G1，则准确称 checkpoint source-selection diagnostic；若评分 Natural，则必须读取其实际动作与生效预测，不能借桥接名字替换输入。

## F02｜P0｜`CONTRADICTED`｜目标结果政策没有跨层统一

**位置：** `scripts/bind_v21_dev_asos_outcomes.py::run/_read_station_month; scripts/run_v21_real_dev_source_bridge.py::target card`

**证据：** Y binder 取窗口中第一条有效 vsby；bridge 的目标描述为 terminal observation；原研究目标是按指定 routine-report 政策。binder 不核 report type/COR/QC/成熟度，源端 station 字段也没有验证。

**复现／范围：** 合成相同观测时刻的 1SM 与 10SM，交换稳定排序前顺序后 Y 为 [1,0]（Y01）。未证明当前两个正例实际错标。

**修复建议：** 冻结一个完整 Target/OutcomePolicy；同时间冲突保留 unresolved；独立校验 station、单位、report type、质量、订正权威与成熟版本。旧 first-valid 结果仅按旧诊断政策保留。

## F03｜P0｜`VERIFIED`｜完整共同分母 gate 漏掉整方法缺席

**位置：** `src/disastertrace/monitoring_v1/grid_scoring_v18.py::score_complete_grid`

**证据：** comparison_eligible 只比较各 target 实际出现的方法；target A 只有 m1，target B 只有 m2，仍会通过。函数主 report 还将方法合并为一个分数。

**复现／范围：** G01 精确 predicate 子集复现：两组不相交目标仍 True；G02 不同已出现权重正确返回 False。

**修复建议：** 显式全局 method×target×checkpoint roster；缺方法保留登记 cell；每方法分开 Q；统一 outcome mask 和有效时间准入。

## F04｜P0｜`VERIFIED`｜Natural 时钟/预测状态尚不能支撑外部 agent 协议冻结

**位置：** `src/disastertrace/monitoring_v1/natural_track_v18.py::NaturalKernel.__init__/step/public_state/replay_suffix`

**证据：** 只有 WAIT 推进 clock；UPDATE 只写日志不保存 effective forecast；target 已有 hash 但 start/deadline 不与目标未来性绑定；max_actions 超限抛错并没有完成 score/fallback 记录。

**复现／范围：** K07：target 100–200，start210/deadline300 的 UPDATE 可执行。K08：100次查询+UPDATE 后clock仍0，无公共预测状态。这是协议缺口，不是承诺所有任务都必须等待真实 wall time。

**修复建议：** 区分逻辑回放时钟/实际耗时；冻结预测截止；候选经统一 admission 进入有效事件；STOP/timeout/invalid 后继续完整网格评分。

## F05｜P0｜`VERIFIED`｜有公开排班的未来来源可使当前 active policy 原地重试

**位置：** `src/disastertrace/monitoring_v1/active_policy_v21.py::__call__; natural_selector_policy_v21.py::__call__`

**证据：** 目录允许 public_schedule 来源提前出现；未读任何内容时 policy 总选第一个 handle；unavailable 不改变 read 和 clock，没有 WAIT。

**复现／范围：** K09：唯一 q 在20可用、start0，连续5次 RETRIEVE@0，未终止。该反例实际运行的是源码转录子集；正式 checkout 回归列为待执行。

**修复建议：** 可查询/可发现分开；处理 unavailable 并合法 WAIT/STOP；限制重试且纳入预算、失败和终态。

## F06｜P0｜`VERIFIED`｜同到达时间冲突只记最后一条，A-B-A 可绕过检查

**位置：** `src/disastertrace/monitoring_v1/evidence_qualification_v18.py::qualify_stream`

**证据：** latest_by_available[time] 只存一条；同 source identity 内容冲突在相邻 A-A 时拒绝，在 A-B-A 时不再和第一个 A 比较。

**复现／范围：** E03：相邻A(v=1),A(v=2)拒绝；E04：A(v=1),B(v=5),A(v=2)，相同 issue/arrival，接受。

**修复建议：** 以 (arrival, source identity) 保存整组证据或先分组；明确定义等时 revision/cancel/重复/冲突，测试全部排列或明确拒绝。

## F07｜P0｜`VERIFIED`｜provider 原始捕获与关闭生命周期仍需最后验收

**位置：** `scripts/run_v18_controlled_api.py::call/parse_output/main`

**证据：** HTTP、返回模型和request ID检查有进展；但完整 raw/envelope 在逐次 journal 中未持久保存，正文仍依赖最终 attempts 文件；finish_reason被记录但length未被统一拒绝。缺新Natural actor adapter。

**复现／范围：** 本轮为源码路径核对，不声称复现真实网络故障。应 fake transport 注入响应后崩溃、截断、HTTP429/500、model mismatch、closed ID换输出路径。

**修复建议：** raw-first写捕获（不写凭据），记录长度/完整性；解析后终态；最后dispatch permit；不重发已关闭或unknown请求；P1权限另批。

## F08｜P1｜`VERIFIED`｜概率后端忽略条件组和区间不确定性，不能冒充专业概率

**位置：** `scripts/run_v21_real_dev_deterministic_score.py::_projection_probability; scripts/run_v21_real_dev_source_bridge.py`

**证据：** 把所有重叠period的visibility下界取min并映射0.8/0.2，忽略TEMPO/PROB和上界；bridge另取首period下界，两个路径的后端不是同一个。

**复现／范围：** P02：只含PROB30低能见度也给0.8；P03：exact4000与区间[4000,9000]同给0.8。这可作为明确的规则F，不是native probability或calibrated F。

**修复建议：** 基线卡明确该规则；采用一致输入/处理；对单位、删失、条件支持给明确定义；校准/统计后端需独立开发资料和授权。

## F09｜P1｜`VERIFIED`｜TAF 全语义资格仍有已披露缺口

**位置：** `scripts/build_v18_dev_episodes.py::_load_products/_classify_relation_status/build_roster`

**证据：** TEMPO不截断主导条件、PROBxx_TEMPO、元数据比较剥离已有修复；仍有末尾凭空+1h、BECMG仅作转换区间、全无period CNL跳过、先cover再cap8等路径。

**复现／范围：** 源码分支可构造最后一个prevailing无end、BECMG后目标、periodless CNL、第9个最新修订。未在本轮重跑真实TAF，不能给受影响比例。

**修复建议：** 原生parser/validity为准；unsupported而不补造；authority先于target投影；合成原文gold案例和真实允许readset资格分阶段。

## F10｜P1｜`CONTRADICTED`｜任意 handle 重命名不会影响策略的文档断言过强

**位置：** `src/disastertrace/monitoring_v1/active_policy_v21.py::_visible_ids/__call__; tests/test_v21_natural_active.py`

**证据：** 首source及后续角色依赖按query_id排序；原test只把q前缀改z，保留排序，不是任意重命名。

**复现／范围：** K10：q0低/q1低/q2高→.8；相同角色映射为a低/z低/b高→.2。无真实天气数据。

**修复建议：** 定义合法public role metadata或登记为generator-aware规则；增加随机ID置换、角色逆转和无提示对照。

## F11｜P1｜`VERIFIED`｜开发真实比较没有测试内容依赖 follow-up selection

**位置：** `scripts/run_v21_real_dev_deterministic_score.py::_choose/run; artifacts/.../REAL_DEV_DETERMINISTIC_SCORE.json`

**证据：** active_age=按可用时间优先的公开规则；每checkpoint独立选一条，未消费Natural行为轨迹；earliest/hash/age在汇总中相等。fixed=.5不是强气候态。

**复现／范围：** 已读逐行样例+完整summary；对整个输出的loss值频数重建汇总算术。没有重新跑source archive或完整逐臂JSON校验。

**修复建议：** 明确诊断对象；增加真正基于首条内容改变第二条查询的实际actor，对照同F同预算。先检查合法选择空间，不因三臂相等就宣称所有active无效。

## F12｜P1｜`VERIFIED`｜cost-matched GPU差异大部分由生成器结构直接决定

**位置：** `scripts/run_v21_cost_matched_adaptive_surface.py::_one/run`

**证据：** 规则知道initial=1时q1可靠、initial=0时q2可靠；固定F丢弃initial、只用最后signal。其胜负有解析期望，不是学出来的天气策略。aggregate的best还包含0/1查询参照，816不是纯2-query比较的计数。

**复现／范围：** 独立有理数枚举384组合：mean active-best=-0.0113525390625；256严格赢/32总体平局/96输。三轮768赢+96平局中的一半=816只是可解释参照，不证明实际96行均如此。

**修复建议：** 停止同生成器更大MC当novelty；保留正控制，增加逆转/无提示、ID置换、Bayes posterior F、learned而非知晓路由策略及冻结环境转移。

## F13｜P1｜`VERIFIED`｜shared-delay 比较同时变化重采样成本和概率映射

**位置：** `scripts/run_v21_shared_delay_surface.py::_one/run`

**证据：** RR在各checkpoint得到新噪声观测；active重用同一信号；hash固定0.65而active可0.65/0.8。不是纯获取策略的单因素实验，也不是跨target共享来源的实证。

**复现／范围：** 源码和聚合记录已经披露不等成本；报告31win不等于等成本active优势。未独立重算全部432行。

**修复建议：** 保留旧结果按原协议；新实验分cost×F×reuse因素；不重命名为cost-matched复验。

## F14｜P1｜`VERIFIED`｜历史kernel恢复不自动恢复delivery mask，repair trial不是Y-side attribution

**位置：** `src/disastertrace/monitoring_v1/delivery_intervention_v21.py; repair_trial_v21.py; interventions_v18.py`

**证据：** delivery mask位于wrapper而不在parent快照；固定probe UPDATE=.8不读delivered内容。repair证明cache驱逐/重新获取和trace变化，不等于概率改善。

**复现／范围：** 本轮静态检查；新增restore和无内容敏感policy反例列为待执行。不能沿用上轮缺正文错误：v21 public read已存在。

**修复建议：** 干预位置/单位/parent/未来mask版本完整登记；未来交付改变后重跑真实策略；repair独立分支，不作所有非repair实验共同前置。

## F15｜P1｜`INCONCLUSIVE`｜完整原计划与全量hash/逐cell复算仍缺独立证据

**位置：** `plan/plans_v21_0925; plan/plan_v18_0922; artifacts/.../SNAPSHOT_MANIFEST_V4.json`

**证据：** 原目录未取得；已读仓库v18原计划副本及早期v21审计文档，不能据此逐项认证未提供的完整方案。65项manifest未全量字节重算，GPU原cell仅抽样。

**复现／范围：** Git目录/Files检索未定位完整原包。六个已保存scheduler describe均读到SUCCEEDED；不能把这一项扩成所有hash通过。

**修复建议：** 补精确plan文本/hash、受限published artifact allowlist，运行只读核验器；不要求读取原始档案/保护目录或重跑关闭job。

## 已修复、不可继续照搬旧审计的问题

`VERIFIED`：v21公开视图已经包含防御性拷贝read、target和catalogue；隐藏与不存在handle在v21路径共用拒绝文字；TAF comparison剥离is_amendment等字段；arrival chronology以available_at为主；当前Brier在所有target中检查已结算Y冲突并把冲突组从主分数排除，legacy仅审计；provider解析列表类型错误已有严检；source copies/STOP/WAIT deadline与action互斥有具体实现。这些局部进步不等于完整Natural、TAF、数据政策或共同分母通过。

## 测试覆盖

已读六个 `test_v21*.py` 文件，17个测试定义：natural_active 5、selector_policy 3、natural_score 4、delivery 2、real_dev_evaluators 2、repair 1。没有在完整checkout执行这17项或报告的226项；本轮实际执行21项源逻辑子集观察（包含8个反例、11个正对照、2个范围缺口），不是原仓库pytest。

关键盲点：q→z前缀测试不等于任意ID置换；successful retrieval不等于三checkpoint持续forecast；frozen共享F不等于合格天气概率；trace different不等于repair改善；两个方法在不同目标上各自有完整网格不等于共同分母。


---

<!-- Source section: EXPERIMENT_AUDIT.md -->

# 实验与结果审计

## 证据分层与读取范围

本轮读取了用户明确指定的已发布development派生结果，包括ASOS标签JSON及deterministic评分JSON；这属于审查输入，**不能填写“outcome artifact reads=0”**。未读原始TAF/METAR/ASOS body、未调用真实provider、未提交GPU、未列举或读取holdout/quarantine。

`VERIFIED` 的数值限定为本文写明的算术/已发布记录；不自动证明原生标签正确。`REPORTED_ONLY` 不等于虚构。原始文件与完整运行环境不可访问，相关全量复算为 `BLOCKED`。

## 当前数字

| 项目 | 数值 | 状态及证据上限 |
|---|---:|---|
| Development target/episode | 24 | VERIFIED：ASOS发布列表逐项读回；四站×1月1–6日，不是24独立过程 |
| checkpoint | 72 | VERIFIED：登记结构3点/目标与评分记录；72个source-bridge trace另为24×3 selector，不能混同 |
| ASOS target binding | 24/24 BOUND | VERIFIED：已发布记录及窗口算术；INCONCLUSIVE：不是原始观测/routine/QC/成熟政策认证 |
| Y分布 | 22为0、2为1 | VERIFIED：发布标签计数；不是自然机场风险率 |
| fixed | Q=.25，72cells，query0 | VERIFIED 算术；完整逐方法输入身份复算未做 |
| earliest/hash/active_age | 各Q=.11041666666666668，sum7.95，72cells，query65 | REPORTED_ONLY（完整逐方法重建）；源码、逐行样例、汇总与loss频数算术一致 |
| active−fixed | −.13958333333333334 | VERIFIED：以上报告值的独立相减；不是相对专业概率或强基线增益 |
| active−best nonactive | 0 | REPORTED_ONLY 全体逐行等价；源码和已读样例支持无独立selector证据 |
| shared-delay | 144配置×3=432行，active-best +.006160525294641654；wins31/ties158/loss243 | 配置数VERIFIED；全量结果REPORTED_ONLY，未重算432行 |
| cost-matched | 384配置×3=1152行；active-best −.011311323556583375；wins816/loss336 | 配置数VERIFIED；实测全量aggregate REPORTED_ONLY；解析期望独立重建见下 |
| v21 provider/model calls | 报告0 | REPORTED_ONLY历史总量；所读实验脚本无provider路径VERIFIED；编码AI不计被测模型 |
| 本轮新增真实provider/GPU | 0/0 | VERIFIED，本轮工具记录 |
| 历史actor无Y/holdout无访问 | flags=false | 静态数据流与声明支持；无法从布尔常量独立认证历史所有文件访问，INCONCLUSIVE |

### Loss频数核对与弱参照

已返回完整评分文本的工具检索计数：0.6400000000000001 共18行；0.04000000000000001共162行；0.03999999999999998共15行；0.25共93个数据行（另一个0.25是summary）。三source方法合计195个非fallback损失、21个fallback损失。其总和/3为7.95；7.95/72=.1104166667。此为频数/算术复核，不替代按episode/method完整join和源档案复算。

由已公布的22/2 Y分布，纯事后检查可得：常零Q=2/24=.0833333333；常数p=.2的Q=.09，均低于.1104166667。它们是审计参照，不是用测试集重新训练/预注册气候态，也不证明这些规则能泛化。结果说明“超过.5”不能承担天气增量的主要论据。

## 真实score与Natural不是同一条运行链

`run_v21_real_dev_source_bridge.py`实际让program selector通过kernel查询，但从首checkpoint启动、一般短序列即STOP。它产生 `rows/trace_count`，没有score所需的 `episodes/checkpoints/qualifications`。

`run_v21_real_dev_deterministic_score.py`独立从G1每checkpoint重选一条，`active_age`是age排序，不是内容依赖follow-up；它不读取bridge中实际执行的trace。因此REPRODUCE把bridge传给它会失败；不能把这个开发score称作前者Natural actor的评价。

## GPU收据

以下六个已保存 `describe.json` 均直接读取，state=SUCCEEDED，startup_script一致指向对应脚本/seed/n/cuda，lme.current_retries=0：

| 系列 | 保存job名 | seed | n/cell | 声明设备 |
|---|---|---:|---:|---|
| shared | om-9ztw5ypm | 310925 | 1000000 | 5090 |
| shared | om-qolmuk6c | 320925 | 1000000 | 5090 |
| shared | om-elhqpnle | 330925 | 1000000 | H100-share |
| cost | om-2i6w8d3y | 350925 | 500000 | 5090 |
| cost | om-hkd7uz7t | 360925 | 500000 | 5090 |
| cost | om-bdekxc0e | 370925 | 500000 | H100-share |

`VERIFIED`：保存的调度成功凭证和命令字段。没有实时查询调度器，也没有重新运行这些job。cost 5090/H100 result头及早期cell已抽查：每方法n×4分母、相同n、对应seed和设备。全部1152+432 cell、request/command文件、script SHA、manifest65项的字节级独立校验尚未完成，不能写“全部manifest已过”。

5090使用PyTorch2.8.0a0/Python3.12，H100使用2.3.0a0/Python3.10；可作为同DGP的不同Monte Carlo replica条件性合并，不能当字节一致的硬件复现，更不能把设备与环境变化造成的差异独立归因于硬件。应按replica保留估计和不确定性，禁止重复cell造成伪样本量。

## 独立解析重建：cost-matched surface

设初始信号正确率r，较可靠后续h，较差后续l，输出高概率p，coverage=c，delay=d，4个checkpoint。定义

\[
a=c(4-d)/4,\quad B(u,p)=p^2+(1-2p)u.
\]

生成器让initial=1时q1可靠、initial=0时q2可靠；active知道这个路由，因此总取h。固定后续的边际正确率为(h+l)/2。共同后端仅消费最后一个signal：

\[
Q_0=.25,
\quad Q_{no}=.25(1-a)+aB(r,p),
\quad Q_{rr}=Q_{hash}=.25(1-a)+aB((h+l)/2,p),
\quad Q_{active}=.25(1-a)+aB(h,p).
\]

对代码全部384参数组合用有理数独立枚举：
- 平均 active−best_nonactive = **−0.0113525390625**。
- 平均 active−fixed = **−0.0439453125**。
- 每replica总体严格赢256、平32、输96；三replica为768／96／288。
- 768 + 96/2 = 816，与报告的严格符号计数相同是值得核查的解释：总体平局可能被有限MC正负号各分一半。**这不证明实际报告的全部96行都发生了该原因，也不认证816原始计数。**

报告−.0113113与解析值相近。它支持实现符合指定生成机制的检查方向，而不是新算法学到了天气结构。无需更多同类型GPU样本即可知道其理论优势条件；保留为正控制即可。

### “best non-active”不是只含等成本对照

报告的best还包括0次查询的fixed与1次查询的no_extra。因此816/1152是与**混合成本参照中事后取最小分数**的比较，不能直接说成“在816个等成本条件赢”。应额外报告严格2次查询的active vs RR/hash。

本DGP的解析结果为：

\[
Q_{active}-\min(Q_{rr},Q_{hash})=-a(2p-1)(h-l)/2<0.
\]

全部384条件严格为负，均值−0.0298828125。这更直接表明优选路由规则的优势已经写入生成条件。它仍是合法的正控制；没有预先学得/可观测的路由质量时不能直接外推。

## Shared-delay与其他surface

Shared-delay的RR各时点重新抽噪声，active复用信号；hash固定p=.65而active可.8。因此其−.026375相对.5改善与active-best为正可以同时成立。纯查询成本与置信度未隔离，不能当equal-cost negative replication。

`signal_reliability_mc`和`calibration_sensitivity`原代码本就包含解析式，审稿不应把简单重推包装成新研究成果。`budgeted_miscalibration`对q_true的正比例中心缩放通常保留uncertainty排序，主要改变校准，不足以检验选择质量估计错误。应新增噪声排名/角色逆转/无信息条件，并用同一个正确posterior后端对照。

## 事后 best 选择与解析对象的边界

报告逐cell取同一评价样本中非active方法的最小经验损失；本文解析值则取各方法总体期望损失的最小值。二者有限样本下不严格相同：E[min_j Qhat_j] <= min_j E[Qhat_j]。尤其在总体平局附近，噪声和事后挑最小会影响符号计数与差值。因此−.01135254不是对原GPU输出的逐位复算，816也不是显著优势次数。新报告需同时列各预登记pair、独立开发期选定的best baseline，以及明确标注的hindsight-best诊断。

## 本轮只核验了一个日志payload的字节身份

`v17_v21_regression_final.log` 的320字节可从返回文本精确重建；Git blob和SHA-256均匹配，包含226个点。`regression.log`与`_final.log`在manifest中使用同一hash，不算两份独立测试证明。这个核验不重跑测试、不认证nodeid，也不认证其余64项。结果见 `reproductions/LOG_HASH_CHECK.json`。


---

<!-- Source section: PLAN_TRACEABILITY_MATRIX.md -->

# 计划追溯矩阵

完整 `plan/plans_v21_0925` 与 `plan/plan_v18_0922` 目录未取得。本表对照的是实际可读v18原计划副本、早期v21审计文档、当前发布与Notion；不是伪造缺失计划的逐任务验收。

|计划要求|当前实现/实验|证据|状态|缺口|下一步|
|---|---|---|---|---|---|
|V18-1 固定未来目标/多提前量|3个前置checkpoint已构造；多提前量后端未资格|builder/_checkpoint_cutoffs；G1|VERIFIED|原目标routine/terminal/first-valid未统一；长lead未完成|P0-02|
|V18-2 专业信息、F与真实Y分离|sourcebridge和Y binder分开，但score另行重选|source bridge/binder/score|VERIFIED|组件分离不等于同一实验完整绑定|P0-01/02/03|
|V18-3 来源/内容/信息效用分层|comparison hash已剥离行政字段|evidence_qualification_v18|VERIFIED|CNL/BECMG/支持/冲突和概率后端仍需资格|P0-04|
|V18-4 Endpoint vs Trajectory|synthetic score把最终p填给各点|natural_synthetic_score_v21|CONTRADICTED|不能验证动态有效轨迹差异|P0-03/05|
|V18-5 Adaptation vs Stability|synthetic low/high及renameprefix|active_policy/tests|VERIFIED|任意重命名失败；不是实际LLM适应能力|P1-01|
|V18-6 Repair→forecast loss|cache repair有trace差异|repair_trial_v21|VERIFIED|未证明实际Y损失改善，隔离和绑定不足|P0-06/P1-03|
|V18-7 四类强基线|age/earliest/hash/.5诊断；程序selector适配|real deterministic score|VERIFIED|没有当前同目标专业概率、强统计或provider端到端|P1-02/P2-01|
|V18-8 完整Natural active track|read/catalogue/target及4action实现|natural_track/active_policy|VERIFIED|无有效预测时间链与延迟失败处理；公开future可原地重试|P0-05|
|V18-9 Prospective Living|未见本次未来封存/成熟结算实际运行|release/claim table|INCONCLUSIVE|历史代码/模拟不等于前瞻|P3-01，L1/L2另授权|
|V18-10 多模态/第二域|旧资产非本次主要实验|v18原计划/旧模块地图|INCONCLUSIVE|没有当前协议的跨域实证|P3-01延后|
|V18-11 shared F/equal cost|cost surface的3臂2次抽象查询、相同F和N×4|cost script/result headers|VERIFIED|不是Natural实际token/wall成本；F丢初始信息|P1-00/01|
|V18-12 配对、过程分组、校准与确认|3GPU独立seed；开发24目标|aggregate/outcomes|VERIFIED|replica/cell/checkpoint不是独立天气过程；无校准/holdout支持|P1-02/P3-00|
|V21 本次13个指定run脚本及6模块存在|源码按命名范围读取|SOURCE_INVENTORY.json|VERIFIED|存在不等于所有分支/任务执行|P0-00|
|V21 226项测试与全manifest通过|报告和日志声明|TEST_STATUS/SNAPSHOT|REPORTED_ONLY|本轮没有完整checkout复跑226或重算65项|P0-00/01|
|V21 完整 plans_v21_0925 每项|未取得完整目录正文；有早期audit副本|docs/plans/PLAN_V21_AUDIT_20260925_CN.md|BLOCKED|不能替缺失完整计划计算完成率或关闭所有A-G任务|取得原包hash/文本，再追加矩阵|
|V18 原始 plan_v18_0922 整目录|有PLAN_V18_ORIGINAL_CN.md副本|docs/plans/PLAN_V18_ORIGINAL_CN.md|INCONCLUSIVE|可对照正文目标，不能认证目录中其他文件/授权|补原目录文档清单，不读数据|
|Notion C1|主动系统增量与同F获取是不同结果|当前Notion01/03/04/10|VERIFIED|当前新结果还只是程序选源/模拟，不是完整LLM Natural|P2-01|
|Notion C2|错误→修复→后续损失|Notion04/07/09/10|VERIFIED|trace差异替代损失的风险尚在|P1-03|
|Notion C3|独立target/backend/weather过程复验|Notion07/10|INCONCLUSIVE|未完成对应泛化实证|P3-01|

**完成率：不出具完整原计划完成百分比。** 当前真实Y派生诊断比旧v20进了一步，不能再写“从未结算Y”；也不能把GPU Monte Carlo或public view代码存在计作Natural/论文目标全部完成。缺失原包属于无法验证，不是实现错误。


---

<!-- Source section: CLAIM_EVIDENCE_MATRIX.md -->

# Claim证据矩阵

|Claim|状态|现有证据|缺口|允许结论|
|---|---|---|---|---|
|真实dev已自动绑定24个标签|VERIFIED|发布ASOS行可对账|原始QC/报告类型/冲突政策未认证|仅first-valid开发诊断|
|当前selector带来天气独立gain|INCONCLUSIVE|age与earliest/hash相等|不测试内容follow-up且弱固定.5|不支持天气增量|
|当前Natural协议可冻结|CONTRADICTED|K07/08/09及无effective forecast|需正式时钟/预算/终态/评分桥接|NO-GO|
|六GPU已完成|VERIFIED|六保存describe state=SUCCEEDED|未实时查询/全字节核验|调度与输出存在性，不是方法效果|
|cost matched成立|VERIFIED|RR/hash/active抽象预算2，F和N×4相同|实际model/latency成本不存在|限定合成比较|
|816行证明active普遍更强|CONTRADICTED|解析总体tie与DGP路由先验|finite-MC符号/选择最小参照|仅指定DGP|
|algorithm novelty|INCONCLUSIVE|固定路由/已知Bayes式选择|无新的算法或理论证明|不作新算法声明|
|benchmark-object/value novelty|INCONCLUSIVE|目标、版本、时间、获取与损失联合方向|真实连通结果与强对照缺失|条件继续|
|provider/model身份混乱已发生|INCONCLUSIVE|v21记录零provider；默认模型不等于actual|无新响应可比较Luna/DeepSeek/GLM/Qwen|不得凭编码模型或历史名称推断|
|holdout从未读过|REPORTED_ONLY|flags=false和已读受限路径|不能审计过去所有访问|本轮确实未访问保护目录|


---

<!-- Source section: FOLLOWUP_PLAN.md -->

# 后续计划：P0 → 最有判别力的P1 → 条件P2 → P3决策

## 优先级与避免过度阻塞

P0-00/01先固定证据与可重现入口；P0-02/03固定target/Y/共同grid；P0-04处理来源语义；P0-05把Natural行动接到持续生效预测；P0-07单独关闭provider路径缺口。P0-06只阻塞使用paired repair/delivery的实验，不阻塞合格的非repair Controlled或Natural主表。纯解析P1-00可以并行，不需真实数据/模型/GPU。

不要为当前不使用的第二领域、LAMP原生概率或通用Python隔离等任务建立全局门槛；也不能为了尽快调用模型，跳过目标一致、公共信息、失败分母或raw capture。

## P1 最值得做的实验

### P1-A：解析一致性与反证（CPU）
研究问题：目前优势是否只是“已知生成路由+最后信号F”？

固定：同Y、初始观测、可见source universe、same F、同budget2、同四点权重、同coverage/delay随机掩码。比较固定q1、固定q2、合法随机/哈希、按已学公开提示active，以及单列的generator-aware oracle。后端另做last-signal F与正确利用全部已得信息的Bayes/posterior基线，不混在同一acquisition对比。

条件：原路由、路由逆转、无可辨提示、噪声提示；任选3个预注册可靠性关系（h>r、h=r、h<r），共12个核心条件。建议5个预注册seed（410925至410929），每条件20000个合成target用于初次仪器确认；这是预算提案，不是功效证明。正式运行前冻结配置。

报告：配对target-level Q差、MC标准误、总体解析期望、preregistered regret、query/unique-source/cached counts，confidence/accuracy不同维度。示例实际效果界δ=0.005 Brier仅作为researcher待批准值；不得称天气业务阈值。

支持：非oracle active 在已登记、非泄漏提示条件下优于固定control，区间完全小于−δ；否定某优势：区间落入[−δ,δ]且精度足够；反向效果保留；其余INCONCLUSIVE。构造h=r的仪器测试采用解析预期和MC容差，不靠观察是否significant调seed。

### P1-B：真实开发记录的可判别性
先仅在已批准published派生范围做选择空间检查；需要原源再读另D1。逐target/checkpoint记录合法候选数、unique origin、当前authority、内容差异、不同查询是否改变同一F输入。没有可区分动作不必做付费selector比较。原24目标已暴露，只能开发；不得挑active会赢的Y/日期。

保留正常/无变化时段、强规则、常零与合法开发期climatology、observation persistence、TAF规则和已资格强统计F。常数.2的本轮事后算术不是冻结climatology。重新拟合或校准须另立训练/开发/测试角色。

### P1-C：小型paired机制
仅在已验证policy/parent/delivery/admission上做expose/withhold/delay；repair separate Original/Repair/Sham。从暴露前parent出发，干预消息或语义来源组须预登记；重新获得同一信息必须记录。真实错误不存在时NOT_APPLICABLE，不主动伪造后称自然故障。两个分支不复用旧回答，使用同政策新后缀。

## P2 provider-backed最小完整设计（仍未授权）

**provider/model**：不得从编写代码的ChatGPT/Codex/Claude或历史Luna/Qwen等名称推断。RUN_SPEC必须填真实endpoint标识、exact request model、允许返回模型/固定revision、requestID字段、routing记录。当前runner的默认DeepSeek字符串不是本轮已评模型。未批准模型时BLOCKED，不填一个看似完整的假modelID。

**pilot**：建议以同一个冻结F、一个provider actor做有限selector pilot；完整LLM direct probability作为独立研究arm，避免第一批同时变后端。先独立run的少量合成-shaped compatibility calls，再另一个新run的12个development targets×3checkpoints×最多2个查询决策×2个draw，最多144个决策请求槽。每method/draw仍只有36个预测评分cell；主动STOP后剩余request slots登记NOT_DISPATCHED，已有效预测继续评分。若研究者决定用现24目标全体，则预算按公式重新批准，不能默认翻倍。

**equal-cost**：所有有查询程序/actor共享source-query上限和sameF、相同初始信息/公开目录/服务规则；程序不需要虚拟消耗LLM tokens。另报实际模型费用、latency和调用数，而不是伪称总成本相同。预算上限与实际消耗并列。

**output schema**：版本、target/contract/parent、可信决策时点、action enum及互斥字段、query handle、target_state（变量/单位/有限区间/置信标签/引用范围）、候选概率有限[0,1]。结构合法不是事实正确。模型不得提供可信completion time或最终Y。

**captures**：dispatch intent→最后permit→一次HTTP→原始响应去凭据落盘→解析→model/requestID/finish/status验证→tokens/费用→terminal。HTTP非200、invalid JSON/schema、timeout、length、model mismatch都保留原capture和fallback。默认不重试；不确定是否发送或收费时UNKNOWN，不再请求。

**outcome**：预测先封存、Y1后独立结算。后见修正另版本，不能改预测。全体已注册目标/方法/点/无效与未结算报告齐全。小开发pilot足以检验运行和大结构错误，不足以正面或反面证明天气增量、稀有风险校准或排行榜稳定性。

## P3研究决策

继续：真实版本/时间/目标约束下主动获取及状态维护的条件性作用，Natural主任务+Controlled解释。
修改：把“active是否存在优势”改为“在可公开辨别的条件、合理F、同成本和同时间下，何时存在优势/损害”。把generator-aware规则降为oracle参考，把.5降为弱prior。
停止：同一个已知解析生成器无限加GPU/seed；将trace不同叫原因已定位；将源侧规则分数叫LLM成果；把first-valid标签当原routine合同而不版本化；以816符号wins替代效应和区间。

可写论文的方法/工程草稿，但摘要不能声称已提升天气预测、已证泛化、已完成Natural真实agent或新算法理论。候选paper narrative：一个业务版本化天气证据与固定未来目标的可审计协议，在强基线和干预下刻画额外取证的适用边界；只有补齐真实非平凡结果才成为benchmark研究贡献。

## 时间安排（计划，不是后台承诺）

| 时间 | 有限目标 | 硬出口 |
|---|---|---|
| 0–9小时 | P0-00/01、关键target/Y/grid回归；P1-00解析并行；provider fake capture核查 | 已复现问题、最小patch+独立review、缺失材料/权限；不自动启动外部 |
| 9–24小时 | 完成使用路径P0；有限CPU反证矩阵和Natural→effective→score合成闭环；已有published结果重建 | 共同时钟/分母/身份；real-readset和P2 spec待审；未过则停对应路径 |
| 1–2周 | 获授权后源资格→有界新provider→封存→Y；前瞻baseline计划并行；决定一项扩展 | development结论/精度范围和GO/NO-GO；未授权保持BLOCKED，不把等待时间算实验进度 |

所有阶段不读取holdout/quarantine。H2必须独立批准；不因拿到本包或原报告“曾获授权”默认解锁。

## Provider pilot预算与判定的补充约束

建议另立compatibility run，最多4个纯合成shape请求（也需P1授权），输出上限1024 tokens/请求、单请求总超时60秒只是待研究者批准的起始参数。正式controlled acquisition pilot的144个actor决策槽与查询预算不同：每checkpoint最多2次新资料查询，episode最多6次；缓存命中与新版本读取分别计数，不免费重新取同一版本。WAIT/STOP也消耗actor决策槽；槽用尽则按登记cap终态结束该段，不能偷偷增发。F按固定评分网格消费已合法取得的输入，不需要另一个actor请求才能保留分母。

两个draw不等于两个独立天气过程；provider不支持seed时记录draw ID、请求参数和交错随机运行顺序，不声称seed控制。该首批明确是Controlled获取pilot，不将其命名为完整Natural运行。后续Natural/direct-probability轨需独立冻结允许动作和资源合同。接口/运行完整性可以在小pilot判定；12个已暴露development目标不提供天气有效性/无效性的一般结论。

P3-01含可分开的baseline-only prospective、agent prospective和holdout子路径。它们不是三个权限必须同时具备：baseline-only只申请其L1及相关读取权限，agent需要L2，holdout只有明确H2后才可能执行。未批准子路径不阻塞其他已批准路径，也绝不自动解锁。


---

<!-- Source section: LITERATURE_REFERENCES.md -->

# 文献和原始来源（检索2026-09-25）

这是一轮针对核心定位的有界文献核查，不宣称穷尽2025–2026所有研究。以下只使用论文/作者机构/官方文档。源文献不是DisasterTrace当前实验的证据。

1. **Valter Schütz, Han Wu, Reza Rezvan, Linus Aronsson, Morteza Haghir Chehreghani.** *AFABench: A Generic Framework for Benchmarking Active Feature Acquisition.* arXiv:2508.14734, v3, 22 Feb 2026（初版2025）。https://arxiv.org/html/2508.14734v3 。实读§2–4，尤其§3.2：共享外部预测器分离获取/内部预测收益；§4含静态、myopic和非myopic对照。支持“内容依赖查询及相同F并不是新的通用研究问题”。复用候选：https://github.com/Linusaronsson/AFA-Benchmark ，复制代码前仍须在选定commit核许可与依赖，本轮未做该repo逐文件许可审计。
2. **Daniel Golovin, Andreas Krause.** *Adaptive Submodularity: Theory and Applications in Active Learning and Stochastic Optimization.* JAIR 42 (2011):427–486. DOI:10.1613/jair.3278. https://arxiv.org/abs/1003.3967 ; 作者机构记录 https://authors.library.caltech.edu/records/dn297-7wr20 。本轮读摘要/作者机构记录。支持自适应观测决策有理论先例；**不**证明本项目具有adaptive submodularity，不能直接继承最优性界。
3. **Ran El-Yaniv, Yair Wiener.** *On the Foundations of Noise-free Selective Classification.* JMLR11(53)(2010):1605–1641. https://www.jmlr.org/papers/v11/el-yaniv10a.html 。本轮读摘要。支持拒绝选项下risk–coverage含义；本任务HOLD后仍carry-forward评分，不能混作删样本abstention。
4. **Shashwat Goel, Nikhil Chandak, Arvindh Arun, Ameya Prabhu, Steffen Staab, Moritz Hardt, Maksym Andriushchenko, Jonas Geiping.** *FutureSim: Replaying World Events to Evaluate Adaptive Agents.* arXiv:2605.15188v1 (2026). https://arxiv.org/html/2605.15188v1 。本轮打开完整HTML并核持续预测/时间信息协议；不将Live或多轮预测当本项目首创。
5. **Michael Chen.** *AgentCaster: Reasoning-Guided Tornado Forecasting.* arXiv:2510.03349v1 (2025). https://arxiv.org/html/2510.03349v1 。本轮读任务/评价段落。支持天气Agent查询与概率预测已有直接先例；不能证明当前H15策略有效或无效。
6. **PyTorch contributors.** *Reproducibility*, PyTorch2.8 official documentation. https://docs.pytorch.org/docs/2.8/notes/randomness.html 。跨版本/平台不能保证逐位相同；本项目5090/H100混合应按replica与环境报告。
7. **NOAA/NWS Aviation Weather Center.** *Product Info — METAR and TAF.* https://aviationweather.gov/help/data/ 。本轮读单位、SPECI/COR和TAF产品说明。SM含分数，M/P是边界，COR可保持同一观测时间；程序需要显式版本/冲突政策。产品说明不是当前原始档案完整性证明。

## 研究定位

当前陈述“有限成本/延迟/不可靠证据下，依内容选择后续查询是否改善预测”属于active sensing/active feature acquisition/序贯决策的一般问题。VOI是给定当时信息的期望风险降低；已实现的单个Y损失差是realized contrast，不能直接拿来当上线停止oracle。Forecast monitoring/版本修订提供有价值的领域结构，但应通过真实时间、来源权威、匹配、状态错误与损失的联合对照来证明其额外测量价值。

候选贡献可落在**任务/数据合同＋诊断评测＋实证适用边界**，不是目前硬编码selector的新算法。不要因先例存在而删去所需组件；也不要用“没有论文把我们所有模块同时实现”证明novelty。

