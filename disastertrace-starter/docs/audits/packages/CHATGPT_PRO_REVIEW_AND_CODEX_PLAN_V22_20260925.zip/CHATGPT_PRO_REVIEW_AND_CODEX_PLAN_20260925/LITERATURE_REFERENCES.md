# 文献和原始来源（检索2026-09-25）

这是一轮针对核心定位的有界文献核查，不宣称穷尽2025–2026所有研究。以下只使用论文/作者机构/官方文档。源文献不是DisasterTrace当前实验的证据。

1. **Valter Schütz, Han Wu, Reza Rezvan, Linus Aronsson, Morteza Haghir Chehreghani.** *AFABench: A Generic Framework for Benchmarking Active Feature Acquisition.* arXiv:2508.14734, v3, 22 Feb 2026（初版2025）。https://arxiv.org/html/2508.14734v3 。实读§2–4，尤其§3.2：共享外部预测器分离获取/内部预测收益；§4含静态、myopic和非myopic对照。支持“内容依赖查询及相同F并不是新的通用研究问题”。复用候选：https://github.com/Linusaronsson/AFA-Benchmark ，复制代码前仍须在选定commit核许可与依赖，本轮未做该repo逐文件许可审计。
2. **Daniel Golovin, Andreas Krause.** *Adaptive Submodularity: Theory and Applications in Active Learning and Stochastic Optimization.* JAIR 42 (2011):427–486. DOI:10.1613/jair.3278. https://arxiv.org/abs/1003.3967 ; 作者机构记录 https://authors.library.caltech.edu/records/dn297-7wr20 。本轮读摘要/作者机构记录。支持自适应观测决策有理论先例；**不**证明本项目具有adaptive submodularity，不能直接继承最优性界。
3. **Ran El-Yaniv, Yair Wiener.** *On the Foundations of Noise-free Selective Classification.* JMLR11(53)(2010):1605–1641. https://www.jmlr.org/papers/v11/el-yaniv10a.html 。本轮读摘要。支持拒绝选项下risk–coverage含义；本任务HOLD后仍carry-forward评分，不能混作删样本abstention。
4. **Shashwat Goel, Nikhil Chandak, Arvindh Arun, Ameya Prabhu, Steffen Staab, Moritz Hardt, Maksym Andriushchenko, Jonas Geiping.** *FutureSim: Replaying World Events to Evaluate Adaptive Agents.* arXiv:2605.15188v1 (2026). https://arxiv.org/html/2605.15188v1 。本轮打开完整HTML并核持续预测/时间信息协议；不将Live或多轮预测当本项目首创。
5. **Michael Chen.** *AgentCaster: Reasoning-Guided Tornado Forecasting.* arXiv:2510.03349v1 (2025). https://arxiv.org/html/2510.03349v1 。本轮读任务/评价段落。支持天气Agent查询与概率预测已有直接先例；不能证明当前H15策略有效或无效。
6. **PyTorch contributors.** *Reproducibility*, PyTorch2.8 official documentation. https://docs.pytorch.org/docs/2.8/notes/randomness.html 。跨版本/平台不能保证逐位相同；本项目5090/H100混合应按replica与环境报告。
7. **NOAA/NWS Aviation Weather Center.** *Product Info — METAR and TAF.* https://aviationweather.gov/help/data/ 。本轮读单位、SPECI/COR和TAF产品说明。SM含分数，M/P是边界，COR可保持同一观测时间；程序需要显式版本/冲突政策。产品说明不是当前原始档案完整性证明。

## 研究定位

当前陈述“有限成本/延迟/不可靠证据下，依内容选择后续查询是否改善预测”属于active sensing/active feature acquisition/序贯决策的一般问题。VOI是给定当时信息的期望风险降低；已实现的单个Y损失差是realized contrast，不能直接拿来当上线停止oracle。Forecast monitoring/版本修订提供有价值的领域结构，但应通过真实时间、来源权威、匹配、状态错误与损失的联合对照来证明其额外测量价值。

候选贡献可落在**任务/数据合同＋诊断评测＋实证适用边界**，不是目前硬编码selector的新算法。不要因先例存在而删去所需组件；也不要用“没有论文把我们所有模块同时实现”证明novelty。
