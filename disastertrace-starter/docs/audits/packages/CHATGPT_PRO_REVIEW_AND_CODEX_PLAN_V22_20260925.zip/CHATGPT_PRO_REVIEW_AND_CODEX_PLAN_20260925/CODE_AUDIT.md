# 代码与测试审计

固定 HEAD：`8a6e2162c86c46a139a7f438a6d63d8356e8917c`。路径相对 `disastertrace-starter/`。发现严重性是使用路径的门槛，不是认定所有旧结果被破坏。

## F01｜P0｜`CONTRADICTED`｜复现指南把错误 schema 输入交给评分脚本

**位置：** `artifacts/v21_execution_20260925_04/REPRODUCE.md / scripts/run_v21_real_dev_deterministic_score.py::run`

**证据：** 指南传 REAL_DEV_SOURCE_BRIDGE.json；该文件根键是 rows/trace_count，评分函数却访问 source["episodes"]。这是发布文档与实际入口的确定性不一致。

**复现／范围：** 用只含 rows/outcomes_accessed=false/model_calls=0 的合成 bridge，加完整空 evaluator 元数据，运行到 source["episodes"] 即 KeyError。未执行真实资料命令。

**修复建议：** 修复指南和 schema/type guard；若评分 G1，则准确称 checkpoint source-selection diagnostic；若评分 Natural，则必须读取其实际动作与生效预测，不能借桥接名字替换输入。

## F02｜P0｜`CONTRADICTED`｜目标结果政策没有跨层统一

**位置：** `scripts/bind_v21_dev_asos_outcomes.py::run/_read_station_month; scripts/run_v21_real_dev_source_bridge.py::target card`

**证据：** Y binder 取窗口中第一条有效 vsby；bridge 的目标描述为 terminal observation；原研究目标是按指定 routine-report 政策。binder 不核 report type/COR/QC/成熟度，源端 station 字段也没有验证。

**复现／范围：** 合成相同观测时刻的 1SM 与 10SM，交换稳定排序前顺序后 Y 为 [1,0]（Y01）。未证明当前两个正例实际错标。

**修复建议：** 冻结一个完整 Target/OutcomePolicy；同时间冲突保留 unresolved；独立校验 station、单位、report type、质量、订正权威与成熟版本。旧 first-valid 结果仅按旧诊断政策保留。

## F03｜P0｜`VERIFIED`｜完整共同分母 gate 漏掉整方法缺席

**位置：** `src/disastertrace/monitoring_v1/grid_scoring_v18.py::score_complete_grid`

**证据：** comparison_eligible 只比较各 target 实际出现的方法；target A 只有 m1，target B 只有 m2，仍会通过。函数主 report 还将方法合并为一个分数。

**复现／范围：** G01 精确 predicate 子集复现：两组不相交目标仍 True；G02 不同已出现权重正确返回 False。

**修复建议：** 显式全局 method×target×checkpoint roster；缺方法保留登记 cell；每方法分开 Q；统一 outcome mask 和有效时间准入。

## F04｜P0｜`VERIFIED`｜Natural 时钟/预测状态尚不能支撑外部 agent 协议冻结

**位置：** `src/disastertrace/monitoring_v1/natural_track_v18.py::NaturalKernel.__init__/step/public_state/replay_suffix`

**证据：** 只有 WAIT 推进 clock；UPDATE 只写日志不保存 effective forecast；target 已有 hash 但 start/deadline 不与目标未来性绑定；max_actions 超限抛错并没有完成 score/fallback 记录。

**复现／范围：** K07：target 100–200，start210/deadline300 的 UPDATE 可执行。K08：100次查询+UPDATE 后clock仍0，无公共预测状态。这是协议缺口，不是承诺所有任务都必须等待真实 wall time。

**修复建议：** 区分逻辑回放时钟/实际耗时；冻结预测截止；候选经统一 admission 进入有效事件；STOP/timeout/invalid 后继续完整网格评分。

## F05｜P0｜`VERIFIED`｜有公开排班的未来来源可使当前 active policy 原地重试

**位置：** `src/disastertrace/monitoring_v1/active_policy_v21.py::__call__; natural_selector_policy_v21.py::__call__`

**证据：** 目录允许 public_schedule 来源提前出现；未读任何内容时 policy 总选第一个 handle；unavailable 不改变 read 和 clock，没有 WAIT。

**复现／范围：** K09：唯一 q 在20可用、start0，连续5次 RETRIEVE@0，未终止。该反例实际运行的是源码转录子集；正式 checkout 回归列为待执行。

**修复建议：** 可查询/可发现分开；处理 unavailable 并合法 WAIT/STOP；限制重试且纳入预算、失败和终态。

## F06｜P0｜`VERIFIED`｜同到达时间冲突只记最后一条，A-B-A 可绕过检查

**位置：** `src/disastertrace/monitoring_v1/evidence_qualification_v18.py::qualify_stream`

**证据：** latest_by_available[time] 只存一条；同 source identity 内容冲突在相邻 A-A 时拒绝，在 A-B-A 时不再和第一个 A 比较。

**复现／范围：** E03：相邻A(v=1),A(v=2)拒绝；E04：A(v=1),B(v=5),A(v=2)，相同 issue/arrival，接受。

**修复建议：** 以 (arrival, source identity) 保存整组证据或先分组；明确定义等时 revision/cancel/重复/冲突，测试全部排列或明确拒绝。

## F07｜P0｜`VERIFIED`｜provider 原始捕获与关闭生命周期仍需最后验收

**位置：** `scripts/run_v18_controlled_api.py::call/parse_output/main`

**证据：** HTTP、返回模型和request ID检查有进展；但完整 raw/envelope 在逐次 journal 中未持久保存，正文仍依赖最终 attempts 文件；finish_reason被记录但length未被统一拒绝。缺新Natural actor adapter。

**复现／范围：** 本轮为源码路径核对，不声称复现真实网络故障。应 fake transport 注入响应后崩溃、截断、HTTP429/500、model mismatch、closed ID换输出路径。

**修复建议：** raw-first写捕获（不写凭据），记录长度/完整性；解析后终态；最后dispatch permit；不重发已关闭或unknown请求；P1权限另批。

## F08｜P1｜`VERIFIED`｜概率后端忽略条件组和区间不确定性，不能冒充专业概率

**位置：** `scripts/run_v21_real_dev_deterministic_score.py::_projection_probability; scripts/run_v21_real_dev_source_bridge.py`

**证据：** 把所有重叠period的visibility下界取min并映射0.8/0.2，忽略TEMPO/PROB和上界；bridge另取首period下界，两个路径的后端不是同一个。

**复现／范围：** P02：只含PROB30低能见度也给0.8；P03：exact4000与区间[4000,9000]同给0.8。这可作为明确的规则F，不是native probability或calibrated F。

**修复建议：** 基线卡明确该规则；采用一致输入/处理；对单位、删失、条件支持给明确定义；校准/统计后端需独立开发资料和授权。

## F09｜P1｜`VERIFIED`｜TAF 全语义资格仍有已披露缺口

**位置：** `scripts/build_v18_dev_episodes.py::_load_products/_classify_relation_status/build_roster`

**证据：** TEMPO不截断主导条件、PROBxx_TEMPO、元数据比较剥离已有修复；仍有末尾凭空+1h、BECMG仅作转换区间、全无period CNL跳过、先cover再cap8等路径。

**复现／范围：** 源码分支可构造最后一个prevailing无end、BECMG后目标、periodless CNL、第9个最新修订。未在本轮重跑真实TAF，不能给受影响比例。

**修复建议：** 原生parser/validity为准；unsupported而不补造；authority先于target投影；合成原文gold案例和真实允许readset资格分阶段。

## F10｜P1｜`CONTRADICTED`｜任意 handle 重命名不会影响策略的文档断言过强

**位置：** `src/disastertrace/monitoring_v1/active_policy_v21.py::_visible_ids/__call__; tests/test_v21_natural_active.py`

**证据：** 首source及后续角色依赖按query_id排序；原test只把q前缀改z，保留排序，不是任意重命名。

**复现／范围：** K10：q0低/q1低/q2高→.8；相同角色映射为a低/z低/b高→.2。无真实天气数据。

**修复建议：** 定义合法public role metadata或登记为generator-aware规则；增加随机ID置换、角色逆转和无提示对照。

## F11｜P1｜`VERIFIED`｜开发真实比较没有测试内容依赖 follow-up selection

**位置：** `scripts/run_v21_real_dev_deterministic_score.py::_choose/run; artifacts/.../REAL_DEV_DETERMINISTIC_SCORE.json`

**证据：** active_age=按可用时间优先的公开规则；每checkpoint独立选一条，未消费Natural行为轨迹；earliest/hash/age在汇总中相等。fixed=.5不是强气候态。

**复现／范围：** 已读逐行样例+完整summary；对整个输出的loss值频数重建汇总算术。没有重新跑source archive或完整逐臂JSON校验。

**修复建议：** 明确诊断对象；增加真正基于首条内容改变第二条查询的实际actor，对照同F同预算。先检查合法选择空间，不因三臂相等就宣称所有active无效。

## F12｜P1｜`VERIFIED`｜cost-matched GPU差异大部分由生成器结构直接决定

**位置：** `scripts/run_v21_cost_matched_adaptive_surface.py::_one/run`

**证据：** 规则知道initial=1时q1可靠、initial=0时q2可靠；固定F丢弃initial、只用最后signal。其胜负有解析期望，不是学出来的天气策略。aggregate的best还包含0/1查询参照，816不是纯2-query比较的计数。

**复现／范围：** 独立有理数枚举384组合：mean active-best=-0.0113525390625；256严格赢/32总体平局/96输。三轮768赢+96平局中的一半=816只是可解释参照，不证明实际96行均如此。

**修复建议：** 停止同生成器更大MC当novelty；保留正控制，增加逆转/无提示、ID置换、Bayes posterior F、learned而非知晓路由策略及冻结环境转移。

## F13｜P1｜`VERIFIED`｜shared-delay 比较同时变化重采样成本和概率映射

**位置：** `scripts/run_v21_shared_delay_surface.py::_one/run`

**证据：** RR在各checkpoint得到新噪声观测；active重用同一信号；hash固定0.65而active可0.65/0.8。不是纯获取策略的单因素实验，也不是跨target共享来源的实证。

**复现／范围：** 源码和聚合记录已经披露不等成本；报告31win不等于等成本active优势。未独立重算全部432行。

**修复建议：** 保留旧结果按原协议；新实验分cost×F×reuse因素；不重命名为cost-matched复验。

## F14｜P1｜`VERIFIED`｜历史kernel恢复不自动恢复delivery mask，repair trial不是Y-side attribution

**位置：** `src/disastertrace/monitoring_v1/delivery_intervention_v21.py; repair_trial_v21.py; interventions_v18.py`

**证据：** delivery mask位于wrapper而不在parent快照；固定probe UPDATE=.8不读delivered内容。repair证明cache驱逐/重新获取和trace变化，不等于概率改善。

**复现／范围：** 本轮静态检查；新增restore和无内容敏感policy反例列为待执行。不能沿用上轮缺正文错误：v21 public read已存在。

**修复建议：** 干预位置/单位/parent/未来mask版本完整登记；未来交付改变后重跑真实策略；repair独立分支，不作所有非repair实验共同前置。

## F15｜P1｜`INCONCLUSIVE`｜完整原计划与全量hash/逐cell复算仍缺独立证据

**位置：** `plan/plans_v21_0925; plan/plan_v18_0922; artifacts/.../SNAPSHOT_MANIFEST_V4.json`

**证据：** 原目录未取得；已读仓库v18原计划副本及早期v21审计文档，不能据此逐项认证未提供的完整方案。65项manifest未全量字节重算，GPU原cell仅抽样。

**复现／范围：** Git目录/Files检索未定位完整原包。六个已保存scheduler describe均读到SUCCEEDED；不能把这一项扩成所有hash通过。

**修复建议：** 补精确plan文本/hash、受限published artifact allowlist，运行只读核验器；不要求读取原始档案/保护目录或重跑关闭job。

## 已修复、不可继续照搬旧审计的问题

`VERIFIED`：v21公开视图已经包含防御性拷贝read、target和catalogue；隐藏与不存在handle在v21路径共用拒绝文字；TAF comparison剥离is_amendment等字段；arrival chronology以available_at为主；当前Brier在所有target中检查已结算Y冲突并把冲突组从主分数排除，legacy仅审计；provider解析列表类型错误已有严检；source copies/STOP/WAIT deadline与action互斥有具体实现。这些局部进步不等于完整Natural、TAF、数据政策或共同分母通过。

## 测试覆盖

已读六个 `test_v21*.py` 文件，17个测试定义：natural_active 5、selector_policy 3、natural_score 4、delivery 2、real_dev_evaluators 2、repair 1。没有在完整checkout执行这17项或报告的226项；本轮实际执行21项源逻辑子集观察（包含8个反例、11个正对照、2个范围缺口），不是原仓库pytest。

关键盲点：q→z前缀测试不等于任意ID置换；successful retrieval不等于三checkpoint持续forecast；frozen共享F不等于合格天气概率；trace different不等于repair改善；两个方法在不同目标上各自有完整网格不等于共同分母。
