# 后续计划：P0 → 最有判别力的P1 → 条件P2 → P3决策

## 优先级与避免过度阻塞

P0-00/01先固定证据与可重现入口；P0-02/03固定target/Y/共同grid；P0-04处理来源语义；P0-05把Natural行动接到持续生效预测；P0-07单独关闭provider路径缺口。P0-06只阻塞使用paired repair/delivery的实验，不阻塞合格的非repair Controlled或Natural主表。纯解析P1-00可以并行，不需真实数据/模型/GPU。

不要为当前不使用的第二领域、LAMP原生概率或通用Python隔离等任务建立全局门槛；也不能为了尽快调用模型，跳过目标一致、公共信息、失败分母或raw capture。

## P1 最值得做的实验

### P1-A：解析一致性与反证（CPU）
研究问题：目前优势是否只是“已知生成路由+最后信号F”？

固定：同Y、初始观测、可见source universe、same F、同budget2、同四点权重、同coverage/delay随机掩码。比较固定q1、固定q2、合法随机/哈希、按已学公开提示active，以及单列的generator-aware oracle。后端另做last-signal F与正确利用全部已得信息的Bayes/posterior基线，不混在同一acquisition对比。

条件：原路由、路由逆转、无可辨提示、噪声提示；任选3个预注册可靠性关系（h>r、h=r、h<r），共12个核心条件。建议5个预注册seed（410925至410929），每条件20000个合成target用于初次仪器确认；这是预算提案，不是功效证明。正式运行前冻结配置。

报告：配对target-level Q差、MC标准误、总体解析期望、preregistered regret、query/unique-source/cached counts，confidence/accuracy不同维度。示例实际效果界δ=0.005 Brier仅作为researcher待批准值；不得称天气业务阈值。

支持：非oracle active 在已登记、非泄漏提示条件下优于固定control，区间完全小于−δ；否定某优势：区间落入[−δ,δ]且精度足够；反向效果保留；其余INCONCLUSIVE。构造h=r的仪器测试采用解析预期和MC容差，不靠观察是否significant调seed。

### P1-B：真实开发记录的可判别性
先仅在已批准published派生范围做选择空间检查；需要原源再读另D1。逐target/checkpoint记录合法候选数、unique origin、当前authority、内容差异、不同查询是否改变同一F输入。没有可区分动作不必做付费selector比较。原24目标已暴露，只能开发；不得挑active会赢的Y/日期。

保留正常/无变化时段、强规则、常零与合法开发期climatology、observation persistence、TAF规则和已资格强统计F。常数.2的本轮事后算术不是冻结climatology。重新拟合或校准须另立训练/开发/测试角色。

### P1-C：小型paired机制
仅在已验证policy/parent/delivery/admission上做expose/withhold/delay；repair separate Original/Repair/Sham。从暴露前parent出发，干预消息或语义来源组须预登记；重新获得同一信息必须记录。真实错误不存在时NOT_APPLICABLE，不主动伪造后称自然故障。两个分支不复用旧回答，使用同政策新后缀。

## P2 provider-backed最小完整设计（仍未授权）

**provider/model**：不得从编写代码的ChatGPT/Codex/Claude或历史Luna/Qwen等名称推断。RUN_SPEC必须填真实endpoint标识、exact request model、允许返回模型/固定revision、requestID字段、routing记录。当前runner的默认DeepSeek字符串不是本轮已评模型。未批准模型时BLOCKED，不填一个看似完整的假modelID。

**pilot**：建议以同一个冻结F、一个provider actor做有限selector pilot；完整LLM direct probability作为独立研究arm，避免第一批同时变后端。先独立run的少量合成-shaped compatibility calls，再另一个新run的12个development targets×3checkpoints×最多2个查询决策×2个draw，最多144个决策请求槽。每method/draw仍只有36个预测评分cell；主动STOP后剩余request slots登记NOT_DISPATCHED，已有效预测继续评分。若研究者决定用现24目标全体，则预算按公式重新批准，不能默认翻倍。

**equal-cost**：所有有查询程序/actor共享source-query上限和sameF、相同初始信息/公开目录/服务规则；程序不需要虚拟消耗LLM tokens。另报实际模型费用、latency和调用数，而不是伪称总成本相同。预算上限与实际消耗并列。

**output schema**：版本、target/contract/parent、可信决策时点、action enum及互斥字段、query handle、target_state（变量/单位/有限区间/置信标签/引用范围）、候选概率有限[0,1]。结构合法不是事实正确。模型不得提供可信completion time或最终Y。

**captures**：dispatch intent→最后permit→一次HTTP→原始响应去凭据落盘→解析→model/requestID/finish/status验证→tokens/费用→terminal。HTTP非200、invalid JSON/schema、timeout、length、model mismatch都保留原capture和fallback。默认不重试；不确定是否发送或收费时UNKNOWN，不再请求。

**outcome**：预测先封存、Y1后独立结算。后见修正另版本，不能改预测。全体已注册目标/方法/点/无效与未结算报告齐全。小开发pilot足以检验运行和大结构错误，不足以正面或反面证明天气增量、稀有风险校准或排行榜稳定性。

## P3研究决策

继续：真实版本/时间/目标约束下主动获取及状态维护的条件性作用，Natural主任务+Controlled解释。
修改：把“active是否存在优势”改为“在可公开辨别的条件、合理F、同成本和同时间下，何时存在优势/损害”。把generator-aware规则降为oracle参考，把.5降为弱prior。
停止：同一个已知解析生成器无限加GPU/seed；将trace不同叫原因已定位；将源侧规则分数叫LLM成果；把first-valid标签当原routine合同而不版本化；以816符号wins替代效应和区间。

可写论文的方法/工程草稿，但摘要不能声称已提升天气预测、已证泛化、已完成Natural真实agent或新算法理论。候选paper narrative：一个业务版本化天气证据与固定未来目标的可审计协议，在强基线和干预下刻画额外取证的适用边界；只有补齐真实非平凡结果才成为benchmark研究贡献。

## 时间安排（计划，不是后台承诺）

| 时间 | 有限目标 | 硬出口 |
|---|---|---|
| 0–9小时 | P0-00/01、关键target/Y/grid回归；P1-00解析并行；provider fake capture核查 | 已复现问题、最小patch+独立review、缺失材料/权限；不自动启动外部 |
| 9–24小时 | 完成使用路径P0；有限CPU反证矩阵和Natural→effective→score合成闭环；已有published结果重建 | 共同时钟/分母/身份；real-readset和P2 spec待审；未过则停对应路径 |
| 1–2周 | 获授权后源资格→有界新provider→封存→Y；前瞻baseline计划并行；决定一项扩展 | development结论/精度范围和GO/NO-GO；未授权保持BLOCKED，不把等待时间算实验进度 |

所有阶段不读取holdout/quarantine。H2必须独立批准；不因拿到本包或原报告“曾获授权”默认解锁。

## Provider pilot预算与判定的补充约束

建议另立compatibility run，最多4个纯合成shape请求（也需P1授权），输出上限1024 tokens/请求、单请求总超时60秒只是待研究者批准的起始参数。正式controlled acquisition pilot的144个actor决策槽与查询预算不同：每checkpoint最多2次新资料查询，episode最多6次；缓存命中与新版本读取分别计数，不免费重新取同一版本。WAIT/STOP也消耗actor决策槽；槽用尽则按登记cap终态结束该段，不能偷偷增发。F按固定评分网格消费已合法取得的输入，不需要另一个actor请求才能保留分母。

两个draw不等于两个独立天气过程；provider不支持seed时记录draw ID、请求参数和交错随机运行顺序，不声称seed控制。该首批明确是Controlled获取pilot，不将其命名为完整Natural运行。后续Natural/direct-probability轨需独立冻结允许动作和资源合同。接口/运行完整性可以在小pilot判定；12个已暴露development目标不提供天气有效性/无效性的一般结论。

P3-01含可分开的baseline-only prospective、agent prospective和holdout子路径。它们不是三个权限必须同时具备：baseline-only只申请其L1及相关读取权限，agent需要L2，holdout只有明确H2后才可能执行。未批准子路径不阻塞其他已批准路径，也绝不自动解锁。
