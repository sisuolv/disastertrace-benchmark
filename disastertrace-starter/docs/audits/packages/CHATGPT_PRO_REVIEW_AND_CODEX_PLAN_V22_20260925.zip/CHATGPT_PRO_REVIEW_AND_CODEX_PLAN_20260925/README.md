# ChatGPT Pro review & Codex plan — 2026-09-25

仓库 `sisuolv/disastertrace-benchmark`，分支 `codex/v18-repaired-release-20260923`，审查HEAD `8a6e2162c86c46a139a7f438a6d63d8356e8917c`。

本包是独立审查和下一轮提案，**不是代码修复结果或新实验授权**。新会话顺序：REVIEW_REPORT.md → CODE_AUDIT.md → EXPERIMENT_AUDIT.md → PLAN_TRACEABILITY_MATRIX.md → FOLLOWUP_PLAN.md → CODEX_HANDOFF.md/TASKS.json。先做P0-00；不得盲跑历史REPRODUCE中的真实命令。

```bash
unzip CHATGPT_PRO_REVIEW_AND_CODEX_PLAN_20260925.zip -d review_v21
cd review_v21/CHATGPT_PRO_REVIEW_AND_CODEX_PLAN_20260925
python validate_package.py .
python reproductions/analytic_reference.py --out /tmp/v21_review_analytic.json
python reproductions/source_excerpt_checks.py /tmp/v21_review_subset_checks.json
```

上述两个复现只计算人工合成例子/解析公式，不访问真实来源或网络。source_excerpt_checks是明确转录的函数/条件子集，不是repo pytest；真实checkout验收见任务要求。

所有D1/P1/Y1/L1/L2/H2仍须单独明确授权。当前用户允许审查指定published development artifacts，这不等于开放raw archives、holdout或新provider/GPU。不要将REPORTED_ONLY升级为VERIFIED；不得复发关闭run、覆盖历史或写凭据。

SHA256SUMS.txt覆盖所有payload文件，按标准不包含自身；ZIP另提供外部.sha256。检查文件不是benchmark测试结果。缺完整plans_v21_0925和原plan_v18_0922目录，已用可读原计划副本作限定追溯。

完整可连续阅读报告：`FULL_REVIEW_REPORT.md`。实际读取范围和命令：`SOURCE_INVENTORY.json`、`EXECUTION_MANIFEST.json`。本包只有研究报告、去敏统计、任务与纯合成复现脚本，不携带原始天气或outcome行。
