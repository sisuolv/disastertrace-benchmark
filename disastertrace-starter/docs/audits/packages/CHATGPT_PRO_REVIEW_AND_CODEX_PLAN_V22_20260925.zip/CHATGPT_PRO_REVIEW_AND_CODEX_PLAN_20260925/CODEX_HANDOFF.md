# Codex交接：先审计，后按使用路径修复

固定审查HEAD `8a6e2162c86c46a139a7f438a6d63d8356e8917c`；分支 `codex/v18-repaired-release-20260923`。全部任务为 PROPOSED_NOT_EXECUTED。本包不是外部动作批准，也不授权直接修改原历史产物。

## 从零上下文开始

读 README → REVIEW_REPORT → CODE_AUDIT → EXPERIMENT_AUDIT → PLAN_TRACEABILITY_MATRIX → TASKS.json。若当前HEAD变化，只核相关diff并记录；禁止git reset/clean、全树git add、后台执行旧launcher。优先确认AGENTS.md等实际仓库约束，但历史报告中的run命令不是当前授权。

只对 src/scripts/tests/docs/configs 的明确路径工作。先审查测试及conftest，避免自动读取真实档案或连接provider。`DISASTERTRACE_OFFLINE=1` 只是约定，不是网络沙箱；使用fake transport、进程级禁网和明确temporary input allowlist。不要默认安装依赖或提交GPU。

本轮允许代码与人工synthetic/mock；本包审查曾读用户指定的published dev结果，不向新执行者扩展成raw数据授权。任何再读原TAF/METAR/ASOS、下载、provider、未来collect、holdout各走单独权限。

实现和独立复核为不同调用。每次固定base/head/diff；review读取代码、失败反例和实际stdout/JUnit，不只读实现者总结。没有独立review可用时标NEEDS_INDEPENDENT_REVIEW。

## 每项工作命令、输入、输出、验收与停止条件

下面所有新测试/新脚本是任务交付物，**在其实现、审查通过之前命令不可直接运行**。每项执行保存原命令/退出码/环境/nodeid/哈希，不把历史226与本轮测试数相加。

### P0-00｜绑定当前版本、完整计划与审查读取清单

依赖：无。权限：离线代码/合成限定。

**文件：** `docs/`；`指定published artifacts/manifest`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 核HEAD、限制worktree检查；补完整原计划的去敏文本及hash；不扫描真实归档

```text
git rev-parse HEAD
git diff --name-status -- disastertrace-starter/src disastertrace-starter/scripts disastertrace-starter/tests disastertrace-starter/docs
python <PACKAGE>/validate_package.py <PACKAGE>
```

**输出：** 新审查目录/P0-00/IMPLEMENTATION.md；新审查目录/P0-00/TEST_RESULTS.json；新审查目录/P0-00/INDEPENDENT_REVIEW.md

**验收：** 新旧状态逐项映射；权限关闭；缺失材料如实登记

**停止：** HEAD变化先出差异；不reset；缺完整plan不阻塞已确证的离线修复

### P0-01｜修复复现入口并重建已发布结果

依赖：P0-00。权限：离线代码/合成限定。

**文件：** `artifacts/.../REPRODUCE.md`；`scripts/run_v21_real_dev_deterministic_score.py`；`tests/test_v21_review_regressions.py (new)`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 声明schema并接正确输入；输出分组算术及manifest whitelist核验，不重跑关闭API/GPU

```text
python scripts/review_v21_published_artifacts.py --allowlist <APPROVED_PUBLISHED_ALLOWLIST> --out <NEW_OUT>  # 需先实现/审查，禁止递归扫描
python -m pytest -q tests/test_v21_review_regressions.py -k schema
```

**输出：** 新审查目录/P0-01/IMPLEMENTATION.md；新审查目录/P0-01/TEST_RESULTS.json；新审查目录/P0-01/INDEPENDENT_REVIEW.md

**验收：** bridge错误输入清楚拒绝；正确G1评分与旧数值可对账；差异追加不覆盖

**停止：** 未获发布derived文件读取范围时停；不能跟随manifest绝对路径进入原档案

### P0-02｜固定目标、ASOS政策与结果身份

依赖：P0-00。权限：离线代码/合成限定。

**文件：** `scripts/bind_v21_dev_asos_outcomes.py`；`src/disastertrace/revision_v1/outcome_wiring.py`；`scripts/run_v21_real_dev_source_bridge.py`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** researcher决定routine/first/terminal；复用纯resolver薄适配，检查同target唯一Y、冲突、station、单位、成熟与readset

```text
python -m pytest -q tests/test_v21_review_regressions.py -k "outcome or target"  # 新测试先实现且确认纯合成
```

**输出：** 新审查目录/P0-02/IMPLEMENTATION.md；新审查目录/P0-02/TEST_RESULTS.json；新审查目录/P0-02/INDEPENDENT_REVIEW.md

**验收：** 输入置换不翻Y；first/terminal不能同hash；missing/conflict不填0；outcome仅evaluator

**停止：** 政策未冻结停止新标签；本批不读真实ASOS；数据执行另需Y1

### P0-03｜共同网格与实际生效轨迹

依赖：P0-00, P0-02。权限：离线代码/合成限定。

**文件：** `src/disastertrace/monitoring_v1/grid_scoring_v18.py`；`scoring.py`；`natural_synthetic_score_v21.py`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 全局method×target×checkpoint登记，effective-event时点、carry/fallback、目标归一化；每方法Q及共同mask

```text
python -m pytest -q tests/test_v21_review_regressions.py -k "grid or carry or outcome_conflict"
```

**输出：** 新审查目录/P0-03/IMPLEMENTATION.md；新审查目录/P0-03/TEST_RESULTS.json；新审查目录/P0-03/INDEPENDENT_REVIEW.md

**验收：** 整方法缺席不能eligible；跨时间提交不回填；STOP/invalid留分母；shared missing-Y bounds与CI分开

**停止：** 任何权重/target/Y冲突阻断比较，不删行后自动发表排名

### P0-04｜天气与evidence语义剩余边界

依赖：P0-00。权限：离线代码/合成限定。

**文件：** `scripts/build_v18_dev_episodes.py`；`src/disastertrace/monitoring_v1/evidence_qualification_v18.py`；`providers/aviation.py`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 修A-B-A同时间冲突；CNL/源权威/尾窗/BECMG不补造；保留已正确SM转换和comparison剥离

```text
python -m pytest -q tests/test_v21_review_regressions.py -k "chronology or taf or visibility"
```

**输出：** 新审查目录/P0-04/IMPLEMENTATION.md；新审查目录/P0-04/TEST_RESULTS.json；新审查目录/P0-04/INDEPENDENT_REVIEW.md

**验收：** P6SM开区间、4SM6437.376、分数/缺失手算；TEMPO覆盖不截断prevailing；所有等时排列拒绝或同结果

**停止：** 无原生支持则UNSUPPORTED；真实比例复算另需D1

### P0-05｜Natural持续观察、预算、deadline和policy推进

依赖：P0-00, P0-03。权限：离线代码/合成限定。

**文件：** `src/disastertrace/monitoring_v1/natural_track_v18.py`；`active_policy_v21.py`；`natural_selector_policy_v21.py`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 定义时钟基准/成本；公开future来源合法WAIT/STOP；有真实effective forecast；cap失败可结算；角色不从opaque顺序偷取

```text
python -m pytest -q tests/test_v21_review_regressions.py -k "natural or deadline or catalogue or permutation"
```

**输出：** 新审查目录/P0-05/IMPLEMENTATION.md；新审查目录/P0-05/TEST_RESULTS.json；新审查目录/P0-05/INDEPENDENT_REVIEW.md

**验收：** K07/08/09/10对应新合同被正确处理；不同source正文有positive control；等价信息有negative control

**停止：** 仍原地重试/背填概率/源身份不可核就不接真实provider

### P0-06｜干预与parent绑定（专属路径）

依赖：P0-04, P0-05。权限：离线代码/合成限定。

**文件：** `delivery_intervention_v21.py`；`repair_trial_v21.py`；`interventions_v18.py`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 保存未来delivery-mask及完整parent；repair与资料干预分离；真正identity与sham；只先做确定性已隔离policy

```text
python -m pytest -q tests/test_v21_review_regressions.py -k "delivery or repair or identity"
```

**输出：** 新审查目录/P0-06/IMPLEMENTATION.md；新审查目录/P0-06/TEST_RESULTS.json；新审查目录/P0-06/INDEPENDENT_REVIEW.md

**验收：** restore保留mask；已读证据不被withhold抹掉；实际内容影响后续；所有branch共享合法后续grid

**停止：** 未知共享state则repair NOT_COMPARABLE；不阻塞不使用repair的其他路径

### P0-07｜provider transport和模型身份最后gate

依赖：P0-00。权限：离线代码/合成限定。

**文件：** `scripts/run_v18_controlled_api.py`；`configs/closed_run_ids.json`；`tests/test_v21_provider_faults.py (new)`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** fake transport原始响应先落盘、schema/finish/model/requestID/timeout终态；最终permit与关闭ID跨路径拒绝

```text
python -m pytest -q tests/test_v21_provider_faults.py  # mock-only，无网络
```

**输出：** 新审查目录/P0-07/IMPLEMENTATION.md；新审查目录/P0-07/TEST_RESULTS.json；新审查目录/P0-07/INDEPENDENT_REVIEW.md

**验收：** 崩溃后已有capture可重建；HTTP非200/length/model不符保持失败；无凭据入log；unknown不重试

**停止：** 任何真实连接尝试直接停止；此项未过不运行P2

### P1-00｜解析基准与有限CPU机制核验

依赖：P0-00。权限：离线代码/合成限定。

**文件：** `scripts/run_v21_cost_matched_adaptive_surface.py`；`scripts/run_v21_shared_delay_surface.py`；`新解析reference tests`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 用本包解析式核结果；独立按row regroup比较报告；不扩大同生成器GPU

```text
python <PACKAGE>/reproductions/analytic_reference.py --out <NEW_OUT>/analytic.json
python -m pytest -q tests/test_v21_analytic_reference.py  # 待实现
```

**输出：** 新审查目录/P1-00/IMPLEMENTATION.md；新审查目录/P1-00/TEST_RESULTS.json；新审查目录/P1-00/INDEPENDENT_REVIEW.md

**验收：** 384期望、ties、分母一致；抽样偏差在已定MC容差内；不把符号wins当显著结果

**停止：** 解析与实测不符先查实现，不以更多随机样本掩盖

### P1-01｜最小反证矩阵：路由先验×后端×成本

依赖：P0-03, P0-05, P1-00。权限：离线代码/合成限定。

**文件：** `新synthetic counterfactual experiment`；`测试与预注册配置`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 注册原路由、逆转、无提示、噪声提示；同F比较固定/学习/路由oracle；另比较Bayes融合与last-signal F

```text
python scripts/run_v21_falsification_cpu.py --config <FROZEN_CONFIG> --out <NEW_OUT>  # 新脚本通过审查后；CPU/fake only
```

**输出：** 新审查目录/P1-01/IMPLEMENTATION.md；新审查目录/P1-01/TEST_RESULTS.json；新审查目录/P1-01/INDEPENDENT_REVIEW.md

**验收：** 完整12个预登记核心条件×5seed×20000合成target示例设计；每cell同Y同预算同grid；按构造期望/δ分类，负结果保留

**停止：** 样本和δ未研究者冻结不能开跑；例示规模非功效证明

### P1-02｜真实开发选择空间与强基线资格

依赖：P0-01, P0-02, P0-03, P0-04。权限：D1_IF_RAW_SOURCE, Y1_IF_RAW_OUTCOME。

**文件：** `target/forecast/baseline cards`；`已批准published result或精确readset adapter`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 优先从现有派生记录确认0/1/多合法来源、内容差异与state/F消费；另按授权重建新目标，不按Y或winner选例

```text
python scripts/audit_v21_choice_support.py --allowlist <APPROVED_READSET> --out <NEW_OUT>  # 先实现；访问级别逐项批准
```

**输出：** 新审查目录/P1-02/IMPLEMENTATION.md；新审查目录/P1-02/TEST_RESULTS.json；新审查目录/P1-02/INDEPENDENT_REVIEW.md

**验收：** 包括zero、合法climatology、observation persistence、TAF规则、冻结强统计与latest/earliest/hash；官方概率仅有资格才使用

**停止：** 没有动作可区分性则不花provider查询；真实raw需D1，真实Y需Y1

### P1-03｜小型机制效应（不强求正收益）

依赖：P0-06, P1-01。权限：离线代码/合成限定。

**文件：** `干预记录`；`score adapter`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** expose/withhold/delay与Original/Repair/Sham分别测；重复信息组与消息单位分开

```text
python scripts/run_v21_paired_instrument.py --config <FROZEN_SYNTHETIC> --out <NEW_OUT>  # proposed
```

**输出：** 新审查目录/P1-03/IMPLEMENTATION.md；新审查目录/P1-03/TEST_RESULTS.json；新审查目录/P1-03/INDEPENDENT_REVIEW.md

**验收：** same parent/pre-exposure；fresh continuation；facts、candidate、effective、loss、cost齐全；NOT_APPLICABLE和不确定保留

**停止：** 已知共享状态或错误delivery缺口时停止该干预，不伪造自然错误

### P2-00｜冻结provider pilot协议与授权

依赖：P0-02, P0-03, P0-04, P0-05, P0-07, P1-02。权限：离线代码/合成限定。

**文件：** `新RUN_SPEC.json`；`model/target/baseline cards`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 冻结新run ID、provider exact requested+acceptable returned model、roster/callslots/tokens/cost/deadline、数据角色、no retry

```text
python scripts/validate_v21_pilot_spec.py --spec <PROPOSED_RUN_SPEC> --offline  # proposed/no dispatch
```

**输出：** 新审查目录/P2-00/IMPLEMENTATION.md；新审查目录/P2-00/TEST_RESULTS.json；新审查目录/P2-00/INDEPENDENT_REVIEW.md

**验收：** 全部必填；六权限不自动继承；接口失败按预算留分母；拒绝默认旧closed run

**停止：** 型号/预算/数据范围未批准即BLOCKED；默认P1=false

### P2-01｜有界新的provider-backed pilot

依赖：P2-00。权限：P1。

**文件：** `已冻结RUN_SPEC`；`provider capture`；`actual Natural traces`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 先资格smoke（合成天气形状），再完整已获准开发roster；不同phase新ID；不重启旧run

```text
python scripts/run_v21_provider_pilot.py --spec <APPROVED_SPEC> --out <FRESH_OUTPUT>  # 待实现，仅显式P1授权后
```

**输出：** 新审查目录/P2-01/IMPLEMENTATION.md；新审查目录/P2-01/TEST_RESULTS.json；新审查目录/P2-01/INDEPENDENT_REVIEW.md

**验收：** 例示12目标×3点×最多2query决策×2draw=144注册决策槽；未发送尾部亦登记；prediction36格/方法/draw，不以call数冒充target数

**停止：** 未知传输状态、不一致model、schema、deadline、raw捕获丢失先闭run；禁止自动retry；144是上限提案非授权

### P2-02｜独立结果结算与development结论

依赖：P2-01, P0-02, P0-03。权限：Y1。

**文件：** `冻结预测与roster`；`授权mature observations`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 独立evaluator结算Y；同一目标全部方法/点共享；raw/calibrated输出分开；不在同批结果上拟合

```text
python scripts/settle_v21_pilot.py --predictions <SEALED> --outcome-policy <APPROVED_POLICY> --readset <APPROVED_Y_READSET> --out <NEW_OUT>  # proposed
```

**输出：** 新审查目录/P2-02/IMPLEMENTATION.md；新审查目录/P2-02/TEST_RESULTS.json；新审查目录/P2-02/INDEPENDENT_REVIEW.md

**验收：** 完整Nregistered/Nsettled/Npositive/失败；基线匹配；pair/block CI与missing bounds分开；小样本只描述

**停止：** Y1未授权停止；冲突不填0；当前24已暴露，不改名confirmation

### P3-00｜研究go/no-go与论文主张

依赖：P1-01, P1-02。权限：离线代码/合成限定。

**文件：** `CLAIM_EVIDENCE_MATRIX`；`已合法取得的实验结果`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 预先区分正效果、实际等价、精度不足、测量失败；保留Natural主问题而非永久query-selector

```text
python scripts/validate_claim_evidence.py --claims <NEW_CLAIMS> --manifest <AUDITED_MANIFEST>  # proposed/offline
```

**输出：** 新审查目录/P3-00/IMPLEMENTATION.md；新审查目录/P3-00/TEST_RESULTS.json；新审查目录/P3-00/INDEPENDENT_REVIEW.md

**验收：** 缺provider/Y不得摘要声称weathergain；算法与benchmark/data/diagnostic贡献分名；强替代解释逐项回应

**停止：** 不以“negative也有价值”免除真实测量与新认识

### P3-01｜前瞻与独立确认（不属默认执行批次）

依赖：P0-02, P0-03, P0-05, P3-00。权限：L1, L2, H2。

**文件：** `冻结方法/目标/评估/统计与权限`

**输入：** 固定HEAD源码/本报告的对应finding；只限源码或人工合成fixture；外部动作须另行批准

**动作：** 先baseline shadow再agent；新过程confirm；一项有根据的第二backend/过程，不堆16灾种

```text
仅编写prospective/confirmation spec；无批准时不得执行任何reader或collector
```

**输出：** 新审查目录/P3-01/IMPLEMENTATION.md；新审查目录/P3-01/TEST_RESULTS.json；新审查目录/P3-01/INDEPENDENT_REVIEW.md

**验收：** L1/L2/H2分别授权；事前封存、成熟结算、版本桥接；没有正收益也可做有价值限定复验

**停止：** 未授权/方法未冻结/过程不足时BLOCKED

## 最终必须交回

新的版本化output目录：HEAD/工作区差异身份、每任务receipt、独立review标识、精确测试集合与环境、source/config/script hash、注册分母和每个terminal、P0反例处理表、研究主张状态、权限与文件访问摘要。已关闭/中断API和旧GPU不重跑；不要修改旧G1/G3/G4、REAL_DEV_*、aggregate、RUN_MANIFEST。新结果按correction/supersedes链接旧结果，旧字节保留。
