Read batch/IMPLEMENTATION_STATUS.md and batch/REVIEW_GUIDE_CN.md.
V2: structural parse 12/12; complete query sets 10/12; strict task correctness 0/12.
CPU replay: python cpu_review/review_cpu.py --bundle cpu_review --receipt /tmp/mm3-v2-review-new.json
