Read mm3_20260909/REVIEW_GUIDE_CN.md.
MM-3: 12 real replies; 12 invalid state-array outputs.
V2: offline prepared only; zero generations.
CPU replay: python cpu_review/review_cpu.py --bundle cpu_review --receipt /tmp/mm3-review-new.json
