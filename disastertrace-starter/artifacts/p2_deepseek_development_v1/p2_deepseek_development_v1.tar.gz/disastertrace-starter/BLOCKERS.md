# Blockers

## Current: common P2 format screen fails before heldout readiness

The first P2 DeepSeek comparison completes 270/270 responses with a passing
independent audit and seven passing offline finalization commands. There is no
remaining collection, report-generation or P2 unknown-charge blocker. The launch
is consumed. Entry: `README_P2_DEEPSEEK_V1.md`; outcome:
`artifacts/p2_deepseek_development_v1/FINAL_STATUS.json`.

U2 snapshot and answer_history each have 28/30 schema-valid responses, below the
fixed 29/30 threshold. Four failures concern valid-JSON structure; two are
length/empty responses at 8192. This blocks claiming common format readiness and
advancing to final heldout inference under the current design. Preserve the run
and prepare a new common output-contract revision offline. Do not selectively
retry, lower thresholds or infer authorization for another paid matrix.

Three citation errors occur with correct values; no value/status mismatch is
observed among valid answers. This limited conditional result and the dependent
source/case design do not establish broad weather or internal-memory competence.
Second-model choice, heldout freeze and original P1 attempt 79 remain separate.

## Previous launch: prerequisites resolved

The complete frozen diagnostic passes; the real detached worker starts at
2026-09-07 12:29:08 UTC. Actual coverage, empirical format screening and the final
independent report are pending. This launch is consumed; inspect its existing
runtime instead of submitting another worker.

The user has now authorized the proposed first P2 matrix. Fresh official price
and settings documents match the frozen snapshots; actual authorization and
attestation are bound to the unchanged execution in
`artifacts/p2_deepseek_development_v1/`. A new detached runner passes eight tests;
the final frozen diagnostic is in progress before model dispatch. Complete actual
coverage, empirical format reliability and independent scoring remain pending.
The P1 unknown charge, second-model selection and heldout inference remain separate.

## Current P2 execution status and launch prerequisites

The P2 collection, independent capture/provenance/budget audit and direct scoring
engineering gap is resolved. Final offline acceptance passes 999 tests and all
13 pipeline steps, including 270 diagnostic responses and report recomputation.
Entry: `README_P2_EXECUTION_V1.md`; evidence: `artifacts/p2_execution_v1/validation/`.
No per-item human annotation, LLM judge or paid API is needed for these deliverables.

Actual P2 model reliability and scores remain unmeasured. The new execution is
frozen with a proposed 270-attempt / 8192-token / USD 3 conditional scope, but its
authorization template is false. Before model dispatch, record actual P2 approval
and confirm that the saved pricing/context assumptions still apply. Different
rates/settings require a new execution identity; a copied output or old T6/P1
claim cannot authorize it. This is a launch prerequisite, not missing offline code.

The first full-suite attempt was intentionally stopped for a reproduced original-
machine pricing-path dependency. That defect and excessive JSON nesting handling
are fixed and included in the passing final suite. Historical runtime directories
can now be verified through saved archives without extraction. There are no
unresolved failures in the final local acceptance. Remote CI and Git publication
are not executed in this stage.

The task still uses controlled records with source-inherited initial values;
physical realism, cross-hazard generalization and statistical significance are
not established by the software tests. The original P1 unknown charge, a second
model and heldout inference remain separate. T6 remains complete and unchanged.

## Previous T6 completion and P2 dependencies

T6 completes all 270 attempts/responses with independent audit on 2026-09-07 at
09:36:28 UTC. Its common cap is 8192. The final audit/coverage/cap-selection
dependencies listed in the earlier launch section are resolved. No T6 pending
reservation remains, and this initial scope is consumed. Entry:
`README_T6_CALIBRATION_V1.md`; analysis: `artifacts/t6_deepseek_calibration_v1/FINDINGS.md`.

The remaining engineering task is P2-specific live collection, captured-response
provenance audit and scorer integration. Its current four-field adapter only
prepares unsent requests; diagnostic-only scoring cannot accept real answers by
changing a label. P2 uses its own task/implementation identity and budget; the
8192 recommendation is an initial setting, not proof of P2 reliability or a new
model-call authorization. No credential or pricing blocker remains for the
completed T6 batch. Any future P2 launch must establish its own current conditions.

NHC citation verification still has a declared restricted grammar/locator policy.
Nine selected-cap known-field failures are evaluator_unverifiable citations with
correct values; two others are longitude-sign value errors. Preserve this distinction
and the frozen scores. These do not mandate human item review or a silent scorer fix.
The old P1 unknown charge, second-model selection and heldout freeze remain separate.

## Previous T6 launch status

The user has approved the proposed 270-attempt / USD 3 T6 scope. Current official
pricing/settings are verified and actual authorization is recorded; the frozen
worker starts on 2026-09-07 at 08:43:29 UTC. These launch prerequisites are now
resolved for this execution. Current entry: `README_T6_CALIBRATION_V1.md`.
The final independent audit, completion coverage and cap recommendation remain
pending until the worker finishes or stops. A stopped unknown dispatch must not be
automatically retried. P2-specific live collection/audit and its separate scope,
second-model selection and heldout evaluation remain subsequent work.

## Previous next-phase completion and remaining dependencies

T0-T3 calibration execution and T4-T5 controlled tasks are offline-complete.
Entry: [README_NEXT_PHASE_V1.md](README_NEXT_PHASE_V1.md). Full offline regression
passes 949 tests; complete diagnostic collection, audit/report and both preparation
pipelines pass. No model calls or new per-item human review are required to use
these completed offline deliverables. The old missing collector/ledger/auditor
engineering blockers listed in the historical section below are resolved.

T6 real output calibration remains unexecuted. Before a new live run, bind an
actual scope to its execution identity and confirm current service availability,
pricing and limits. The saved 2026-09-06 rates and proposed USD 3 / 270 attempts
are not a fresh price observation or a live launch authorization. This is separate
from the consumed P1 continuation. The current offline work does not inspect or
reuse the old credential. No empirical common output cap has yet been selected.

P2 `live_ready=false` is an implementation boundary: it currently has task
generation, dual Gold validation, offline runtime/scoring and unsent provider
request preparation. P2-specific durable live collection, independent response
provenance audit and actual model-result scoring still need implementation using
frozen P2 settings. The current scorer intentionally accepts diagnostic origins
only. A second provider/model and its own budget/configuration also remain open.

The cohort, source grounding and controlled semantics support a limited evidence
update benchmark. They do not establish physical weather-process realism, broad
hazard coverage, model pretraining decontamination or independent samples at each
checkpoint. No heldout inference, new background P1 run or training occurs.
Original P1 attempt 79 remains an unknown charge; it is not resolved by new ledger
code. Conditional estimates remain distinct from invoices and unknown expense.

The new GitHub Actions workflow is present locally; no remote execution or push
is claimed for this development milestone.

## Previous output-contract calibration scope (historical)

The offline next-step package is implemented, with a new explicit public output
contract, complete development schedule, unsent initial requests, diagnostic
rehearsals, frozen scoring projections and budget screening rules. Current entry:
`README_CALIBRATION_V1.md`. All 684 offline tests pass; no API calls are made.

Model calibration itself is not yet measured. The prepared 270-call experiment
and USD 3 conditional allowance are proposals. Existing live collection and audit
still reconstruct legacy requests; contract-aware collection, durable scheduling,
an independently tested budget guard and actual launch authorization remain before
paid execution. This does not block the completed offline preparation.

Offline diagnostics cannot establish whether 4096 or 8192 is sufficient, estimate
new model performance, or resolve the earlier formatting-effect hypothesis. Do
not pass their generated answers into any live method history. All seven heldout
storms remain outside inference, and no per-item human review is required.

The old P1 unknown request charge remains unresolved in its historical ledger.
No price refresh or provider charge lookup is performed by this offline package.

## Current P1 continuation status

The user approved the USD 1.5 cumulative allowance and one explicit retry of
the unresolved request. The frozen detached worker completed all 12 new calls
and exited 0 on 2026-09-06. All three methods now have 30 received responses,
within 91 cumulative request attempts. No credential, budget or worker-execution
blocker remains for this completed batch. The one-use continuation is consumed;
do not repeat it. Current entry: `README_P1_DEEPSEEK.md`.

The original interrupted experiment, all 78 old received responses, its unknown
request and its partial report remain intact. The amended cumulative ledger
retains USD 0.46678016 for original attempt 79. Its actual response and usage are
still unavailable, so total incurred expense remains unknown. The 90 received
responses have a captured-price subtotal of USD 0.146989544; the 12 new responses
contribute USD 0.023630952. These are usage-based estimates, not invoices.

Observed method differences are descriptive for three development storms, one
model and one repeat, with fixed method order and a restart. Snapshot has 14
truncated and two structurally invalid answers; answer_history has six truncated
answers. These failures are retained, not repaired or selectively retried.
All schema-valid answers have correct field values, with one snapshot citation
not verified. Public output typing, budget sufficiency and possible format-example
effects need a new controlled calibration before broad method claims.

No new per-item human annotation or LLM judge is required for that next package.
The existing seven heldout storms remain unused for live inference. Changing
the public contract or output budget needs a separately versioned experiment;
the completed batch does not authorize further model calls.

## Previous P0 completion and persistent research limitations

P0 equivalent-citation scoring and immutable offline migration are complete.
The full suite passes 611 tests, zero skips; archived replay, collection audit
and derived-package verification pass. Current entry: README_SCORING_V2.md.
The earlier authorized DeepSeek trial remains one SDK probe plus ten Ida
development requests; P0 makes zero additional model requests.
Records: artifacts/deepseek_probe_v1/ and work/deepseek-ida-state-v1/. Prior
pre-API artifacts and their original implementation sources are preserved.

There is no missing credential/model configuration blocker for the completed
bounded trial. The secret was held only in the calling process and not persisted
in project files. Larger comparisons still need model/method scope and budget
fixed; this trial did not execute the full two-model or heldout matrix.

The strict-citation finding is resolved under a separately versioned restricted
evidence policy: the same ten saved responses score 50/50 overall and 32/32
known-only grounding in v2. Original v1 stays 49/50 and is exactly reproduced.
One field changes because a supported body citation is now accepted. Results:
work/deepseek-ida-rescore-v2/. This is not a model improvement. Arbitrary prose,
new languages/source genres and contradictory cross-paragraph text remain
outside the declared support grammar; evaluator_unverifiable is reported
separately from demonstrated false model claims.

The collector enforces attempts, request-body bytes and aggregate requested output
token reservations, with independently audited safe-prefix resume. These are not
total-token or currency caps. Exact DeepSeek model/high-effort/thinking options
were documented and successfully exercised; full context limits and other
providers remain untested. The USD 0.015092568 usage-based estimate is not a
billing receipt. Docs and price snapshots are retained with the trial artifacts.

The 12-event source catalogue yields 10 complete events (3 development, 7
heldout). Four parser rejections are retained: three older Matthew publisher
headers and a Harvey remnants advisory. This version does not broaden the frozen
parser or replace rejected events. These are documented coverage limits, not
blockers or reasons to require per-item human review.

The cohort uses controlled release times and shared task templates. Exact and
fixed-threshold lexical near-duplicate screening now passes; historical public
availability, pretraining decontamination, representative event coverage and broad
extreme-weather generalization remain unestablished. The heldout
last-arrival control gets all coarse actions right despite only 84% grounded
field accuracy, so action accuracy is not sufficient as a standalone metric.

The legacy starter has previously documented defects. Its original tests will be retained, but passing them is not certification of the new protocol or of real model behavior.
