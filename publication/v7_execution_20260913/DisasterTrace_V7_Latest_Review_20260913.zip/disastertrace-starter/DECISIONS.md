# Decisions

## Integrated v7 final execution decisions, 2026-09-13

- Keep original and local statistical maps as separately frozen controls. Local
  calibration improves 2024 but worsens 2026; do not select years, banks or source
  windows after inspecting gains. Fewer pooled fallbacks is not a quality proof.
- Record 720 new actual calls separately from 31,104 audited historical calls.
  Preserve all filled-example copies and failures; E-only contributes no F score.
  New independent heads are CPU-ready, not additional F-only model evidence.
- Reject common-baseline adoption at or beyond the target's legal update upper
  boundary; retain the rejection journal. A partial-window task may keep an earlier
  issued baseline. Derived availability must not precede its parent's availability.
- Keep current code fixes and future head interfaces distinct from the source
  copies frozen into GPU batches and CPU replay. Do not rewrite historical results.
- Treat scalar MAE as numerical engineering until lawful submission times, provider
  support semantics and same-session joint budget graphs are bound explicitly.
- Use the final report and next plan in `../plans/v7_execution_20260913/` as the
  current execution handoff; no new scientific admission follows from file counts.

## Integrated v7 execution decisions, 2026-09-13

- Keep v7/C1/C2/C3 and the original sixteen-hazard roadmap. Execute W0--W3 through
  `../plans/v7_execution_20260913/`; do not replace historical freezes or results.
- Separate an actual predictor call, selector call, candidate value, chosen action
  and deadline-effective value. Forcing saved candidates to override is an offline
  diagnostic, with mixed gains, not a newly executed adaptive policy.
- Add an immutable fixed-evidence lane before changing the adaptive engine. A
  scalar temperature target uses its native point support and units; no artificial
  time interval or probability encoding is introduced.
- Keep filled-output-example sensitivity and the ensuing explicit-truth head
  probes as exposed development diagnostics. Never silently replace constant or
  incorrect outputs, or count E-only calls as submitted F forecasts.
- Use historical native LAMP bulletin minutes, not normalized IEM runtime, for
  chronology checks. Native thresholds and 15-minute minimum support stay separate
  from old 1km/5km hourly-report targets.
- Admit EUPPBench/DWD to numerical integration only. Keep SEEPS daily-window/QC and
  CNRFC regulated/unregulated/hourly-support questions explicit; exact timestamps
  and successful downloads do not prove the physical targets are equivalent.

## Final v7 development decisions, 2026-09-13

- Keep v7/C1/C2/C3 and all 16 hazards; publish the verified engineering and
  regional development result with conditional scientific acceptance.
- Retain all zero/negative model gains. Separate native complete TAF input from
  the Bay-trained research probability mapping transferred to Front Range;
  distinguish probability loss, ranking and operational warning claims.
- Use one source-query path for joint E references, with all opportunities in
  the denominator. Source-only E headroom is not a per-target failure penalty
  or the objective an F policy must maximize.
- Preserve unchanged-message E order repeats as post-hoc development probes.
  All 768 raw answers match their originals; this does not create independent
  weather evidence or identify a general representation effect.
- Report actual binding call caps, unused token/compute quotas and cheap bulk
  transport separately. Account for selector calls in the same model budget.
- Preserve the original QINE/CFS hydrology chain. Current native Stage/ft
  samples and official stage thresholds support the next provider preflight;
  secondary NWPS flow is kcfs. Shared observations are not independent truth,
  and deterministic stage forecasts are not native exceedance probabilities.
- Keep source/model archives, local HEAD/index and historical failures intact.
  Final GitHub publication and readback use separate repositories/indexes and
  receipts; archive replay does not count as new inference.

## v7 verification decisions, 2026-09-12 21:50 UTC

- Preserve all2024/2026 opportunities, strict-parser failures and original request
  errors. New source retries have separate receipts; old results are not replaced.
- Use one unknown binary outcome per target when bounding paired loss across its
  repeated lead times. Calendar block resampling is a sensitivity assumption,
  not independent-storm confirmation.
- Preserve both independent TAF decoder results. Normalize external PROB syntax,
  but retain native FM minutes where the external implementation truncates them.
- Compare the two E models on byte-identical96-case inputs. Assisted fact tables
  and rule examples remain diagnostic conditions, not evidence of active F gain.
- Offline relocation replays recorded ACP receipts rather than claiming fresh
  infrastructure checks. No model weights, network or new calls are needed.
- The bounded four-batch queue owns its one-use launches and validators. Helper
  hashes are frozen; do not edit them or submit duplicate batches during execution.

## v7 review execution, 2026-09-12

- Keep v7 and C1/C2/C3 fixed. Apply the review through the separate governing
  amendment at `../plans/v7_review_execution_20260912/PLAN_AMENDMENT_CN.md`.
- Separate public product/measurement support from model estimates and hidden
  evaluation labels. Use a nonempty support test, legal revision replacement,
  unbounded missing intervals and unique weighted spatial coverage.
- Evaluate jointly reachable target sets using one legal resource/time witness;
  individual reachability is only a relaxation. Fixed acquisition quotas charge
  the initiating target in full. First X01 varies request/byte allocation only.
- Use complete TAF with a separately fitted research probability map. Neither
  TEMPO nor a task-name match supplies an official event probability. Retain all
  routine slots, corrections with unknown input chronology, and unresolved results.
- Preserve negative F gains and E errors. Use fixed calendar expansion to inspect
  positive-event coverage; do not remove quiet days or select winning tasks.
- Freeze each GPU batch separately, reconcile actual tokens/costs/entitlements,
  and keep original failures. User permission covers up to4 H100s concurrently;
  old consumed GPU and paid API launch scopes remain consumed.

## v7 additional execution decisions, 2026-09-12 20:20 UTC

- Keep strict native TAF projection errors. A verified but unparsed new envelope
  has its full raw text and a separately identified frozen fallback, preserving
  target validity and preventing stale old mapping reuse. Windowless NIL/CNL
  produces a same-station withdrawal until a later legal product arrives.
- Treat the observed three-station hourly bulk service as a strong cost audit.
  Preserve original logical prices and separately label physical batch sensitivity;
  do not infer deployed C1 value from artificial source-slot scarcity.
- Charge selector and forecaster calls together, show current legal target state
  and remaining hard resources, and distinguish cheap program updates from model
  inference. Current-state/action v2 runs remain separate from prior v1 results.
- Use complete fixed2024 calendars and a separately registered2026 replication,
  with prior-December calibration. Retain missingness, fallback and all failures;
  never count multiple leads or neighboring hours as independent weather events.

## Expanded dataset use and publication, 2026-09-12

- Keep all97 entries and16 hazards, assigning each source to professional forecast,
  reference/proxy, perception diagnostic, event index or conditional extension.
  A decoded sample is not a formally admitted prediction task.
- Admit nine recovered sample entries while preserving all partial downloads,
  failed requests, empty geometries and negative examples. Preserve original
  registry snapshots and record the new inventory in a separate bundle.
- Record GWIS/EFFIS as shared-backend delivery entries. Keep the same distinction
  for USGS/CAMELSH, METAR/IEM, MRMS subproducts and benchmark-derived labels.
- Exclude unknown SenForFlood label semantics from binary flood scoring. Use the
  selected Urban positive tile only for exposed development feasibility. Record
  CEMS EMSR842 as wildfire rather than claiming the planned flood AOI is validated.
- Publish selected code/reports on the existing private GitHub branch, based on
  its current remote tip and with an isolated publication index. Preserve the
  dirty local worktree/index; omit raw large assets, environments and credentials.
- Continue with historical matched-task qualification and falsifiable N1/N2/N3
  comparisons; data breadth alone does not establish novelty or acquisition gain.

## Real task-chain feasibility and candidate priority, 2026-09-12

- Use the advisor proposal's priority families for a bounded real-download pilot.
  Preserve the97-entry access registry and all16 hazard definitions; matching
  these initial chains does not qualify every source or hazard for formal release.
- Prefer temperature and US TAF/METAR for the next development qualification.
  Retain HEFS/USGS as a continuous-flow chain and conditional warning flagship:
  actual short historical versions are verified, but flood thresholds and multiple
  independently sampled extremes are not. Keep strict rainfall and UK TAF pending.
- Retain all34 fixed targets, including suspect-temperature and accumulation
  failures. The additional Phoenix daytime target belongs to the original heat
  process. Do not replace exact-time results with7/10-minute near-time diagnostics.
- Decode native METAR threshold values; do not reconstruct strict metric labels
  from rounded mile columns. Record19 UK sub-1km reports and11 exact1000m reports,
  correcting the preserved initial30 count. Keep censoring and conditional TAF
  segments explicit; prevailing-only extraction is an incomplete projection.
- Separate asset identity (query URL and bytes) from independent information.
  Different endpoints, representations and updated products are not automatically
  independent evidence. Common professional forecast updates remain the primary
  baseline for later extra-evidence acquisition experiments.
- Use source-bound public checkpoint/private outcome files for CPU qualification.
  Controlled release delays do not prove historical availability; file separation
  does not certify a secure live model runtime. No new model batch is needed for
  this acquisition task, and no positive novelty follows from successful decoding.

## Advisor-stage research and candidate selection, 2026-09-12

- Prioritize the user's latest request for an advisor discussion packet over
  continuing exhaustive acquisition or launching another model matrix. Keep the
  original16-hazard scope with explicit source/target/QC requirements per family.
- Treat acquisition value, source dependence/representation, and deadline/failure
  interventions as testable hypotheses. A decoded sample does not prove a full
  task chain, useful additional information or a novel empirical result.
- Qualify hydro, station temperature/precipitation and TAF/METAR historical chains
  before choosing two main families. Hydro is a conditional flagship because its
  historical business versions, thresholds and extra-evidence utility remain
  limiting. Keep NHC as an engineering and natural-version control.
- Propose common latest-legal-professional-forecast updates to every method for
  the primary extra-evidence comparison. Separately study acquisition of forecast
  updates themselves. Preserve cheap all-read and strong numerical baselines.
- GEE access is now verified for the recorded products. Keep it as an acquisition
  and processing channel with frozen asset identities, never an extra independent
  source or proof of historical ingestion. Preserve all old failures and QA gaps.
- Document the97-entry registry snapshot and the retained late undecoded prefixes
  without upgrading their states. Keep authorization, target completeness,
  scientific semantics and redistribution conditions distinct.
- Use historical replay as the main research route, with separate verified-time
  and prospective conditions. Advisor review of the research design does not add
  per-item human Gold review. Preserve old experiments and report negative results.

## Hydro data admission and prospective shadow, 2026-09-12

- Advance the already completed ActiveWarning minimum loop with a separate water
  namespace and fresh prospective registration. Preserve all historical runs;
  distinguish a working real-data LLM replay from the currently pending online trial.
- Select nine input-risk-stratified candidates from six regional catalogs; admit
  seven, run six with two ordinary controls and one coastal context. Do not count
  gauges/timestamps as independent extreme events or infer population incidence.
- Bind water-level reference and current minor threshold. Use DNLF1's documented
  minus0.8ft NAVD88 transform; retain CHLA2's datum mismatch and the empty62614
  query. Use strict CO-OPS QC and separate provisional from approved observations.
- Keep HEFS QINE/CFS flow diagnostics separate where official CFS thresholds are
  missing. Tide Height/MLLW is a distinct variable contract and is not automatically
  weather-attributed storm surge. Source retransmission is not sensor independence.
- Freeze18 future targets,72 method opportunities,15 polls/360 logical downloads,
  four CPU fetch children and no retries. Require actual disk receipts before each
  target's two-hour deadline. Preserve every poll's outcome version and failures.
- Run four simple numerical policies first. No new LLM/GPU batch is needed to wait
  for genuine future observations. Existing up-to-four-H100 permission persists;
  a later model comparison needs a fresh bounded experiment and useful data.

## ActiveWarning minimum loop, 2026-09-12

- Use NHC/HURDAT2 as the fixed-future-target bridge and HEFS/USGS as a continuous
  flow pilot. Exclude GEE under the current user instruction. Other authorized
  source samples enter only after target/time/support/outcome pairing.
- Select model targets by input-time coverage, not error or result availability.
  Preserve unresolved targets; distinguish HURDAT2 retrospective analysis from
  USGS provisional observations and from any future independent sensor claim.
- Keep controlled release times explicit and separate from captured timestamps;
  do not imply prospective online performance. No flow warning score without a
  compatible flow threshold; point-threshold probabilities remain diagnostic.
- Freeze the same forecasting backend for acquisition comparisons. Treat the
  canonical view as a combined representation/state diagnostic and budget4
  all-read as an additional-resource reference. Do not force active policies to win.
- After17 long-ID copy failures, preserve the entire first matrix and perform
  one fresh full matrix with short public target handles and an alias registry.
  Keep both experiments separate; do not repair individual historical answers.
- Report the negative acquisition result and strong persistence baseline. Further
  research prioritizes independent extreme processes and useful additional data.
  Current same-chain canonical reduction is not a general multi-provider lineage
  model, a full LEAP reproduction or a standalone novelty proof.

## P6 first offline milestone and supplemental fourth plan

- Choose one2-condition/2-repeat E1,2160 opportunities, from the convergent plans.
  The fourth plan confirms this option. New source-binding probes and examples
  remain separate; do not silently change a frozen matrix or launch all budgets.
- Keep field value, literal support, current authority, locator and action errors
  separate. Preserve all P5 counts and disclose that109 of230 citation errors use
  superseded same-value sources. Do not infer internal model causes from matching
  earlier carrier references.
- Derive exposure from actual evidence, preserving six revision no-op episodes.
  Report both directions of change; paired conditions share sampling seeds while
  methods/repeats/conditions have independent run identities and carriers.
- Persist all returned raw items before parsing, stop on unknowns/partial batches,
  and reconstruct without regeneration. Reject diagnostic origins as model scores.
- Admit latest-issued sufficiency in the current legal single-chain domain.
  Same-content carrier representation, length controls, independent sources and
  real forecast versions are separate future studies, not score repairs.
- Use existing CPU dependencies and installed-runtime CPU tests; no downloads or
  environment upgrades. Preserve first environment failures and deduplicate node
  coverage across subsequent verification. No P6 publication occurs this phase.
- Keep GPU permission persistent, but this phase remains offline. A new live
  backend/launcher, actual hardware preflight and bounded live freeze are still
  required; the offline candidate cannot be toggled into production authorization.

## P5 ACP completion and repeatability priority

- Use the user's CPU-CCI/ACP instruction for three independent one-H100 factor
  jobs, within the four-card cap, preserving the frozen single-GPU model settings.
  Complete exactly 1,620 actual replies without model/platform retries.
- Retain all 320 field errors across 260 checkpoints. All 29 action errors overlap
  wind-field failures. Output-contract success does not establish semantic success.
- Describe the observed factor-specific scores without a universal method ranking.
  The zero-effect chain controls also vary (snapshot 27 to 30, structured_state
  28 to 25, answer_history 29 to 30), motivating same-hardware independent repeats.
- Preserve existing P4/P5 source, data and captures. Bind the new launcher separately
  and reconstruct all four reports plus postprocessing in an isolated CPU copy.
  The completed phase does not authorize reuse of its one-use launch artifacts.
- Keep the next 6,480-response, four-condition/three-repeat design as an unlaunched
  proposal requiring a new repeat-aware execution version and offline acceptance.

## P5 scope and authorized GitHub publication

- Apply current upload authorization to the existing private repository and
  `next-phase-v1` branch. Use the existing gh credentials through a repository-local
  Git helper; do not store credentials in tracked code or change visibility.
- Preserve the completed P4 bundle and its archive. Add separate stress data,
  execution and capture identities; retain all selected level-4 candidates.
- Continue automatic Gold and deterministic scoring. Check factor equivalence,
  public-oracle agreement, all metric denominators and program controls before any
  new local inference. Keep the six zero-effect chain controls.
- Existing GPU authorization persists across steps. Freeze experiment budgets and
  provenance for reproducibility; these records are not renewed permission prompts.

## P4 completed: retain semantic errors and separate output-track interpretation

- Complete the fixed 540-response constrained matrix. All outputs pass the original
  contract, but 50 checkpoints have semantic/action failures. Preserve every error
  and all fixed opportunities; constraints do not substitute for scored reasoning.
- Report the observed structured_state 178/180, snapshot 167/180, answer_history
  145/180 results descriptively. Method order differs from the free-output run;
  three source groups, one repeat and model-derived carrier differences preclude
  causal memory or broad weather-competence claims.
- Verify 540 actual token sequences, including 142,272 constrained final/EOS tokens,
  without inference. Reconstruct audit, analysis and comparison after relocation
  with original paths/network blocked and Torch/vLLM absent. Preserve original
  canonical provenance paths while allowing explicit copied-run paths for review.
- Advance difficulty through separately versioned level-4 profiles. All three pass
  the full output reservation under ten program carrier types; level 16 does not.
  Keep six zero-effect chain controls and do not select variants by observed errors.
- Consume the current local scope at 540 actual responses. No stress inference,
  paid API, heldout, training or publication follows from the completed P4 launch.


## Separate constrained track and automatic GPU extension, 2026-09-08

- Treat the user's explicit automatic-GPU instruction as authority for one new
  bounded 540-response constrained local development matrix after offline checks.
  Use fresh scope, execution, run and deadline; retain the consumed P3 launch.
- Preserve all task semantics and prompts; add a static structure-only schema.
  Do not encode Gold, numeric ranges/precision, current record IDs/lines, unknown
  consistency or wind-to-action logic into decoding. Retain the original strict
  parser and fixed metric denominators; report three validity layers explicitly.
- Pin vLLM 0.10.2 V1/XGrammar 0.1.23, no fallback, thinking enabled, unconstrained
  until the generated closing delimiter, and unchanged P3 sampling/context caps.
  Reject prompts that already contain the special closing token without silently
  editing carriers. Disclose schema property-order and EOS constraints.
- Keep the new collector/auditor in separate versioned modules because historical
  execution identities bind the prior implementation. CPU review requires no
  Torch/vLLM/weights. Program token traces remain diagnostic with zero model calls.
- Preserve negative/offline failures and distinguish grammar reachability, GPU
  load/config checks and actual model reliability. No paid API, heldout, training,
  publication, item-level human review or LLM judge is added.


## Balanced local matrix completed; separate format and semantic interpretation

- Complete the fixed 540-response Qwen3-8B matrix despite format failures. All
  responses arrive without retry or length termination; preserve 340 invalid
  answers and every field/action opportunity. All nine format screens fail.
- Treat 332 JSON syntax failures and eight root-structure failures as measured
  interface behavior. The additional two value/status, five citation and one
  action errors remain visible. Valid-only 193/200 all-correct checkpoints do
  not replace the full 193/540 primary score.
- Report snapshot's observed higher score descriptively. Cumulative evidence,
  output-example exposure, input length, few source groups and one sample prevent
  a causal internal-memory or broad weather-competence conclusion.
- Compare only the exact old 18-episode overlap as a labeled historical subset,
  with identical tasks/Gold/scoring and separately observed model configurations.
  Do not combine full 270/540 scores into a model ranking.
- Verify a relocated report in an independent CPU-only environment while denying
  original data/weight/network access. Keep the first missing-Jinja2 failure and
  successful correction; no model generation or primary-source change occurs.
- Prefer a separately frozen structure-constrained track next, without Gold-based
  values/citation/action constraints. Keep the current free-output baseline. No
  new local/paid matrix follows automatically from consumed launch artifacts.

## Balanced local GPU development scope, 2026-09-07

- Apply current autonomous/GPU authorization to one new local second-family
  development matrix, at most 540 responses, no retries or additional probes.
- Fully cross source and primary/secondary case using a new selector; retain the
  legacy 18 episodes and all controlled semantics byte-for-byte. New results have
  a separate identity and cannot be ranked against historical 270-version scores.
- Use official full-BF16 Qwen3-8B weights with per-file ModelScope revisions and
  digests, vLLM in a separate environment, model-recommended thinking sampling,
  and a resource-bounded 8192 cap. The cap is below Qwen's general recommendation;
  report any truncation rather than claiming an unrestricted Qwen capability score.
- Predeclare all nine 58/60 and at-most-two-length format thresholds. Preserve
  missing/invalid responses and method-isolated carriers. Use independent token,
  prompt and score reconstruction; local origin stays distinct from paid HTTP
  responses and diagnostic fixtures. Three sources still limit generalization.

## Common output-contract v2 development completed, 2026-09-07

- End the scope at 270 actual responses with no retries or extra probes. All nine
  frozen format cells pass at 30/30 with zero length finishes. Independent audit
  and reconstruction pass; all field, citation, unknown and action outputs are
  correct on the complete matrix. Retain every response and fixed denominator.
- Treat the all-method perfect scores as a development ceiling, not general
  reliability or superiority. Preserve historical v1 failures. The separately
  verified historical contrast checks 321 denominators and 270 opportunities,
  but different collection times and one sample prevent causal attribution.
- Distinguish the lower captured-price estimate USD 0.267236704 from the slightly
  higher conservative settlement USD 0.64265696. Prompt/total tokens increase while
  completion tokens decrease. Report observed costs/latencies without a general
  savings claim. Original P1 unknown expense remains separate.
- Preserve the first finalizer's nine passed subcommands and missing footer/unknown
  outer exit. In a new directory, verify existing outputs through five commands
  and finish the 3,116-entry historical check, all successful, observer exit 0.
  No model collection is restarted, and no successful core suite is rerun.
- Recommend offline second-family interface preparation and a deliberate choice
  between the current and source-by-case balanced task versions before new calls.
  Future difficulty extensions require predeclared factors and automatic Gold
  checks, rather than model-error-based item selection or a changed current score.

## Common output-contract v2 model authorization, 2026-09-07

- Apply the current "可以" to the preceding exact 270-attempt v2 development
  proposal and separate USD 3 conditional allowance. Preserve the old unapproved
  proposal/template and bind actual authorization in a fresh live bundle.
- Fresh official pricing/settings bytes match the frozen documents. Keep the
  accepted v2 execution and canonical registry, common 8192/high/thinking settings,
  fixed nine-cell thresholds and all original task/Gold/scoring semantics.
- Use a dedicated detached launcher with explicit v2 contract checks. Test it
  offline and rehearse in a separate diagnostic registry before one real launch.
  No repeated full core suite is needed for unchanged, verified frozen source.
- Audit all actual captures and report any stopped prefix with fixed denominators.
  Historical v1 comparisons are descriptive; collection times differ and each
  configuration has one sample. No selective repair, extra probe or silent retry.

## Common output-contract v2 offline acceptance, 2026-09-07

- Accept v2 as an offline-ready candidate, with 1,074 core test passes, nine
  supplemental passes, complete diagnostics and frozen report reconstruction.
  Do not equate program reliability/usage with model reliability/cost.
- Compare six task/Gold/source file classes and seven semantic modules by bytes;
  compare all 30 program score objects by canonical JSON content, matching the
  existing acceptance policy. Keep both raw file hashes because COUNT_KEYS set
  iteration can change serialized key order. Preserve all 30 exact program traces.
- Compare paired-list metrics as well as ordinary metrics: 321 denominators and
  270 checkpoint opportunity rows match. Preserve the reproduced comparator
  failures and corrected checks; no scorer/runtime semantics are modified.
- Reuse the completed 13-step pipeline through explicit log/source/environment
  and report revalidation when finishing the corrected comparison. Preserve the
  first failed outer finalization instead of overwriting it or rerunning a passed
  17-minute core suite without a runtime/source change.
- Keep the independent production registry unconsumed. The future 270-call / USD 3
  proposal is a conditional guard, not guaranteed completion at worst-case usage.
  No new paid calls, second model, two-arm comparison or heldout inference occur.

## Common output-contract v2 offline scope, 2026-09-07

- Retain the exact legacy preparation as v1 and select v2 explicitly. Bind the
  common system text and version into prepared requests and the frozen execution;
  audit and report the selected contract. No per-method instruction adaptation.
- Keep the public user message, strict answer parser, factual Gold and metric
  opportunities unchanged. Explain structure and citations without filled answers,
  private fields, future evidence or failure-specific correct values.
- Retain 8192, high reasoning, thinking enabled, no temperature, no retry and
  the current deadline/budget guards. The two observed length failures remain
  unresolved empirically until a separately scoped model screen.
- Preserve historical artifacts and prepare a fresh 270-call single-contract
  development proposal only. No live calls are authorized by offline acceptance.

## First P2 development comparison completed, 2026-09-07

- Consume the authorized scope at 270 captured responses without retries or extra
  probes. Keep all failures, fixed denominators and original pricing/authorization
  records. Independent audit, direct scores and offline reconstructions pass.
- Record a failed common format screen: U2 snapshot and answer_history each have
  28/30 valid answers. Seven passing cells do not replace the all-cell requirement.
  Structured-state success alone does not authorize final heldout inference.
- Separate four valid-JSON structural errors from two length/empty responses.
  Three further snapshot field errors are citation bindings (two delivery IDs used
  as record IDs and one wrong ASSERT line), with correct numeric values. Preserve
  them; do not repair IDs, remove extra fields or flatten output for rescoring.
- Treat 1,056/1,056 valid-answer field values/statuses as conditional diagnosis,
  not an alternative denominator or proof of general semantic/memory ability.
  The primary/secondary case allocation also limits source-group interpretations.
- Report USD 0.298880548 captured-price estimate separately from USD 0.63745748
  conservative settlement and the unresolved original P1 charge. P2 pending and
  unknown reserves are zero; no provider invoice is observed.
- Recommend a common output-contract v2 offline package first, retaining 8192 as
  an initial controlled setting while tracking both length failures. Any later cap
  change, live matrix, second model or heldout scope needs its own frozen proposal.

## First P2 development model authorization, 2026-09-07

- Treat the current approval of the preceding 270-request / 8192-cap / USD 3
  proposal as authorization for that exact P2 matrix. Record its own evidence;
  leave the historical preparation templates and T6/P1 authorizations unchanged.
- Re-fetch all four official documents. Their bytes match the previous verified
  pricing/settings, so retain the frozen execution identity and add a current
  price attestation. Do not make an extra paid probe.
- Copy the frozen execution into a separately tested launch bundle while retaining
  its canonical production registry. Use a fresh run, no diagnostic history,
  a detached worker, and independent audit, direct scoring and report verification.
- Keep the 9 family-by-method format screens and every scoring denominator fixed.
  Schema failures, factual errors and wrong current citations remain observable;
  no per-item human correction, LLM judge, selective retry or parameter adjustment.

## P2 captured execution integration, 2026-09-07

- Complete the user-approved offline collection/audit/scoring stage without new
  model calls. Keep the old P2 semantic artifacts and T6 result bundle immutable;
  new recursive implementation/content IDs bind the added execution dependency.
- Reuse private byte-transport primitives behind separate strict NHC and P2
  wrappers. Keep bidirectional protocol rejection before dispatch. Do not add a
  generic public validator bypass or route P2 through the NHC task scorer.
- Admit captured results through an independent journal/provenance audit and
  direct P2 scoring entry. Share metric arithmetic while retaining the existing
  diagnostic scorer's origin restriction. Preserve full opportunity denominators
  and distinguish unsent, unknown dispatch, unfinalized capture and invalid answer.
- Preserve schema-invalid responses and previous valid carriers; propagate
  schema-valid factual mistakes unchanged. Catch excessive nesting as an invalid
  answer at collector, auditor and scorer boundaries. Never repair from Gold.
- Use a separate canonical production registry and explicit authorization/rate
  attestation, with diagnostic and loopback origins kept outside the scoreboard.
  Unknown dispatch is not retried, even after a machine restart or released lock.
- Propose 270 P2 attempts, common 8192 cap and a separate USD 3 conditional
  allowance, with 2,211,840 aggregate requested output tokens. Preserve the
  family-by-method 29/30 schema and at-most-one length screen from the integrated
  plan. Program passes cannot establish measured P2 model reliability.
- Resolve captured price documents by local bytes and recorded hash; retain old
  absolute source paths only as provenance. Verify archived history without
  extraction when ignored work directories are missing from a Git checkout.
- Final acceptance passes 999 tests and all 13 pipeline steps. Compare all six
  historical semantic artifact classes byte-for-byte and all 30 program score
  configurations by canonical content. Preserve the interrupted first acceptance
  and both reproduced regression failures instead of hiding them.

## T6 completion and P2 handoff, 2026-09-07

- End T6 at its full 270 audited responses; no retries, extra probes or replacement
  calls occur. The authorized initial scope is consumed. Preserve all raw responses,
  23 schema failures, 21 length finishes and 20 empty contents with overlapping counts.
- Select 8192 using the previously frozen all-method schema/length thresholds.
  Explicit 4096 fails for snapshot and answer_history; explicit 8192 passes all
  three methods. Do not use best factual scores to redefine this selection rule.
- Report selected-cap known-value correctness separately from grounding: 286/288
  values and 277/288 value/source pairs. Two longitude-sign errors differ from nine
  evaluator_unverifiable citation failures; keep the all-citations-valid policy and
  original scores, including cases with a valid plus an unverified extra citation.
- Record observed usage and USD 0.628557504 cache/window estimate separately from
  USD 0.97628256 conservative settlement and any account invoice. T6 has no unknown
  reserve; it does not resolve original P1 attempt 79.
- Hand off 8192 as a P2 starting cap without changing its frozen offline manifest.
  P2 needs independent protocol-aware collection/audit/scoring integration and its
  own 270-call scope; 270 times 8192 means 2,211,840 requested output tokens, not
  T6's mixed-cap reservation limit. Complete that engineering before P2 model work.

## T6 authorized launch, 2026-09-07

- Treat the user's approval of the immediately preceding T6 proposal as actual
  authorization for its stated three arms, three methods, three development storms,
  maximum 270 requests and USD 3 conditional allowance. No repeated permission
  question is needed for that already specified scope.
- Fetch current official pricing, thinking, completion and rate-limit documents.
  The pricing document matches the bound snapshot byte-for-byte, so retain the
  original execution rates and identity with a new dated price attestation.
- Freeze a separate source copy and tested detached runner before using the
  user-provided credential via a non-echoing prompt. Preserve the same canonical
  experiment registry; the new output path does not create extra call allowance.
- Use the frozen core collector without automatic retries or restart. Generate an
  independent audit and full-denominator report after either completion or stop;
  monitoring counts are provisional and do not select parameters while running.
- Keep P1 and its unknown charge, all P2 model work and seven heldout storms outside
  this experiment. Any further model matrix requires its own explicit scope.

## T0-T5 integrated implementation, 2026-09-07

- Follow `../plans/INTEGRATED_NEXT_PHASE_PLAN_V1.md` in a separate worktree and
  `next-phase-v1` branch. Preserve the original project, review baseline and 1,616
  historical source/test/artifact/reference files. No new model launch is included.
- Derive a new execution v1.1 from the old calibration preparation. Inherit its
  three arms, methods, development data, schedule and common-cap thresholds. Use
  180-second socket timeout and separately enforced total network deadline for all
  arms. Never edit the frozen 60-second parent preparation to change its identity.
- Send saved prepared bytes once; capture bounded safe response material before
  parsing. Finalize valid usage even when task schema fails; preserve earlier valid
  carrier on schema failure, and propagate schema-valid factual mistakes unchanged.
- Use one registry claim and single-writer hash-chain journal for the whole
  experiment. Bind the canonical registry path into execution identity. Unknown
  dispatch and damaged journals stop network work; local lock expiry does not
  establish whether the provider processed a request. Offline recovery may finish
  already captured responses without credentials or new sends.
- Keep the immutable authorization scope separate from refreshable matching price
  attestations. Conditional USD 3 reservation arithmetic uses peak/cache-miss rates;
  cache/window-aware descriptive cost requires verified usage and an unambiguous
  UTC interval at the saved price snapshot. Neither equals an account invoice.
- Audit actual views first, then materialize instruction-only compatibility
  projections for unchanged V1/V2 scorers. Record attempted unresolved and genuinely
  unsubmitted slots separately; include both in fixed denominators. Only a complete,
  independently audited real run may select a common cap; simulated passes cannot.
- Keep P2 under `disastertrace/controlled`, with four-field full-state output and
  opaque public identifiers. Use explicit legal single-chain supersession, scoped
  roots for alternate windows, and missing evidence only before first exposure.
  No retraction, ambiguous conflicts or hidden parent versions are introduced.
- Bind actual initial source values, raw hashes and locators; label all subsequent
  controlled transformations as generated. Eighteen development trajectories and
  twelve separate micro fixtures are fixed independently of model performance.
  Independent public-only oracle validation and directional program controls replace
  per-item subjective annotation. Accept per-key-latest-issued success where the
  restricted semantics make it a legitimate baseline.
- Freeze recursive implementation/resource identity and reject modified packages.
  P2 content identity is path-independent; live execution/registry identity is not.
  P2 live capture provenance is deferred explicitly: offline adapter/scorer success
  is not readiness to report LLM results. Keep seven heldout storms out of inference.

## Offline common output contract and calibration preparation

- Execute the user's next-step approval as the proposed offline contract and
  calibration-design package. No new model calls, credential access, annotation,
  LLM judge, heldout inference or historical answer replacement occurs.
- Add standalone output_contract.py and calibration.py. The explicit contract
  changes only the instruction string and shares exact wording across methods;
  preserve the legacy renderer, answer parser, source parser and both scorers.
  Provide declarative shape/types without a filled task answer example.
- Keep structural acceptance separate from evidence correctness. Known slots
  with empty evidence remain parser-valid and fail grounding; no score inflation
  or stricter parser is hidden inside the new output instructions.
- Freeze a proposed three-arm development comparison: legacy/4096,
  explicit/4096, explicit/8192, all three methods and all three development
  storms with complete branches. Plan 270 fresh opportunities, rotate method and
  arm order across storms, and isolate every configuration/episode carrier.
- Predeclare a common-budget screening rule: complete audited matrix, schema
  success at least 29/30 and at most one length-finish response in each method.
  Choose the smallest qualifying common cap or no selection. Aggregate-count
  screening is explicitly unauthenticated and not a live recommendation.
- Treat USD 3 as a proposed conditional stopping allowance, not authorization,
  invoice estimate, completion guarantee, or reuse of P1's remaining allowance.
  Preserve the unknown original charge and revalidate prices before later live work.
- Prepare only authentic unsent c0 requests. Later wire requests depend on future
  accepted model answers. Full offline rehearsals are deterministic program
  controls, never reusable model predictions or evidence of LLM improvement.
- Verify each actual diagnostic trace before creating a separate instruction-only
  legacy projection for frozen scorer compatibility. Save actual/projection hashes
  and full v1/v2 scores; never relabel a projection as an actual provider exposure.
- Use a fresh build for the added implementation modules. Preserve the existing
  P1 build and all histories, and archive root documentation before updating it.

## Authorized background continuation completed

- The user explicitly accepts the USD 1.5 cumulative allowance, one reissue of
  unresolved original attempt 79, and at most 12 new / 91 cumulative attempts.
  Record the actual approval against amendment ecd9840f5e679a8f789192b904d231c2eaef990bd1e40c197932d1c2bf672456.
- Execute the frozen detached worker once. It completes all 12 new requests
  and exits 0; 90 benchmark responses are now available across the three methods.
  Retain all 78 original received responses, including their 20 invalid answers.
- Keep all 79 original ledger rows unchanged. Cumulative attempt 80 is the
  explicitly authorized reissue; old attempt 79 still has no response or usage.
  There are 91 physical request attempts but 90 scoring opportunities. No
  automatic retry or reissue of received invalid answers is performed.
- Retain the old USD 0.46678016 reservation even after its reissue completes.
  Report USD 0.146989544 as the received-response cost subtotal and
  USD 0.023630952 as the new-response subtotal. Total incurred cost is unknown.
- Produce a separate amended report with explicit prefix/suffix/ledger
  reconciliation. The original 90-request no-retry partial report and its
  247-entry archive stay unchanged; do not feed the 91-attempt ledger into the
  original reporter's 90-attempt accounting assumptions.
- Keep the frozen scorer and all failed answers. Completed method differences
  describe this one-model, three-event run with fixed order and a restart;
  they do not isolate memory effects or establish broad model superiority.

## P1 live development comparison and restart recovery

- Execute the user-authorized 90-request development comparison using the frozen
  DeepSeek settings, three methods, three development storms, one fresh repeat,
  USD 1 conditional guard and no retries; retain the prior trial separately.
- Keep model inputs, source parser, task schema and v1/v2 scorers fixed throughout
  the batch. Preserve output truncation and structural failures instead of
  repairing answers or silently increasing max_tokens after observing failures.
- A machine restart leaves 79 admitted requests, 78 responses, one uncertain
  attempt and 11 unattempted checkpoints. Preserve the original running/pending
  records and report the absence of a known exit code. Do not infer provider
  failure, free execution or successful completion from missing local output.
- Finalize the original partial experiment offline into a new directory. An
  explicit local administrative error disposition closes the legacy collection
  schema without inventing a provider error or response. Keep original journals
  and pending reservation intact and score all 90 planned opportunities.
- Report received-response USD 0.123358592 as a subtotal; full incurred cost is
  unknown. The conservative USD 0.30435328 settlement plus USD 0.46678016 pending
  reserve leaves insufficient allowance for a new full-context reservation.
- The user's request to resubmit a background process motivates a separate
  proposed USD 1.5, maximum 91-attempt amendment with one explicit uncertain
  retry. Obtain that scope/budget answer before live continuation; keep all
  78 received answers, including invalid outputs, without selective repeats.
- Describe format-example effects as a hypothesis, since answer carriers supply
  prior JSON examples and the current prompt leaves action type implicit.
  Explicit common output typing and output-budget calibration precede broad
  method claims. The partial last method and fixed order further limit comparison.

## Original scope and first work package

- The user's v0.3 scope supersedes the historical packaged plan's requirements for new human annotation and port-policy expert approval.
- Extend the existing disastertrace package with an automated subpackage. Preserve legacy modules and tests; the new first work package must not rely on the known-defective legacy scorer or treat its results as verified v0.3 metrics.
- Separate public tasks and actual model requests from private labels and generated references.
- The first end-to-end run uses deterministic fixture/diagnostic backends or externally supplied predictions, never a fixture result presented as an LLM score.
- Inherited DisasterBench labels, parsed source facts, controlled release schedules, and any synthetic edits retain distinct provenance.
- No paid model calls, model weights, or operational tool execution are needed for this first work package.
- DisasterBench uses a strict derived protocol: admit 230 of 233 tasks, retain inherited plans, quarantine malformed source plans, and score missing/invalid responses over the full admitted denominator. This is not the upstream permissive parser or an extreme-weather-only subset.
- CyPortQA's 48 templates are inventoried by eligibility. The implementation does not claim to recover or evaluate the full CyPortQA QA dataset.
- The dynamic example retains three original official NHC Ida reports. The two release schedules are controlled; neither source issue time nor retrieval time proves historical public availability.
- Dynamic answers describe the latest available reported observations, not a correction for the same forecast valid time. Full visible evidence is supplied at every checkpoint, so the example does not establish causal dependence on the state carrier.
- Dynamic Gold is generated_by_spec, with fact_origin=derived_from_source and schedule_origin=controlled_release. Original source text is unchanged. The unsupported port-reopening field is an explicit insufficiency control.
- The public 100 mph threshold is a research rule used to exercise a transition between the selected 85 and 105 mph reports. It is not an operational port or emergency policy.
- Build artifacts bind source provenance, generated records, and implementation hashes. A copy of the automated Python sources is retained in each new build. Changed code requires a fresh build/run; prior artifacts are preserved.
- All current backends, including externally supplied files, are marked ineligible_for_llm_leaderboard. The submission importer cannot attest which prompts an external model actually saw.
- Conditional change/preservation denominators depend on the model's actual prior state. Report their counts and do not pool planning, field correctness, and action metrics into one score.

## Second work package

- Freeze a purposeful catalogue of 12 Atlantic storms and advisories 009/010/011 before acquisition or model results. Assign four development and eight heldout storms; previously inspected Ida remains development. Do not replace rejected events or tune the frozen NHC parser on the heldout data.
- Keep failed source admission distinct from missing model evidence. Thirty-two source records pass the unchanged parser; only complete three-record events enter dynamic tasks. Ten events remain (three development, seven heldout); two parsed Harvey records are retained in the source inventory but not used in task episodes.
- Catalogue storm-name case is compared case-insensitively; original parsed names and raw text are preserved. This fixes adapter identity matching without broadening the frozen source parser.
- Retain both branches within each storm split. Check exact source-byte duplicates across splits and report unresolved near-duplicate/template similarity and pretraining contamination separately.
- Report per-event scores, equal-weight event macro rates, pooled opportunity counts, and paired base/delay differences. No confidence intervals or representative-population claims for this selected small cohort.
- Keep provider collection separate from offline submission import. The collector saves exact wire requests and responses, keeps model-authored state, enforces a global request-attempt cap, and performs no automatic retries. An import makes zero provider calls even when importing a separately collected response file.
- Provider configuration requires an explicit endpoint/model and token-parameter convention; credentials come from environment variables. Preparation makes no network calls. Aggregate token and monetary caps are not implemented, and sample config is not authorization for paid calls.
- At the start of this package, no model endpoint, key environment variable, or model budget was configured. The user was asked for model/service and budget while independent data and adapter work continued.

## Pre-API pilot preparation

- Complete all independent first-pilot engineering before asking again for the unresolved model configuration. The user's request authorizes subsequent API testing; it does not identify a provider, credential or spending limit.
- Compare structured_state, snapshot and answer_history using the same cumulative delivered evidence and fresh messages. The carrier is actual schema-valid output, including factual errors; no Gold repair. This is not a causal memory-isolation experiment.
- Retain the original source parser, all 12 predeclared events, 36 acquisition rows, 32 parsed records and 10 admitted events. Run exact/normalized duplicates and fixed word-five-shingle Jaccard analysis without tuning the threshold or replacing heldout samples.
- Independent collection audit reconstructs actual wire requests, accepted history, raw completion envelopes and usage. Scored runs bind that audit and reject any imported completion lacking an audited response. Local consistency does not authenticate the provider.
- Resume only an independently verified prefix into a new directory, preserving old artifacts and cumulative caps. No reissue of received invalid JSON, uncertain in-flight attempts or provider errors. Copy verified in-memory rows to avoid a second unverified source read.
- Request-body byte guards and output-token reservations complement the attempt limit; they do not establish total token use or enforce a currency budget. Provider-specific context support, billing/prices and missing usage remain explicit.
- Freeze two unresolved model slots, three methods and one repeat. Ida-only smoke is 60 attempts; full development 180 and heldout 420. Smoke overlaps development and cannot be pooled as independent samples. Actual models and service constraints are frozen later, before model results.
- Preflight requires expected positive/negative diagnostic behavior, independent data checks and implementation-matching full-suite evidence for offline_ready. live_ready remains false while actual endpoint/model/credentials/budget are unresolved. Every diagnostic and injected transport rehearsal is labeled as non-LLM.
- The first API pilot preparation is distinct from completing the full research program: cross-hazard/multimodal expansion, richer correction/cancellation variants, adaptive Frontier search and broad generalization remain subsequent work.

## First authorized DeepSeek trial

- The user's provided model, endpoint, credential and request to try it authorize a bounded connectivity probe and small development sample. Execute 1 SDK probe plus 10 Ida/structured_state requests; do not infer authorization for the whole two-model matrix.
- Use the exact requested deepseek-v4-flash, high reasoning effort and enabled thinking mode. Add typed, hashed provider options; omit temperature because the official thinking-mode documentation says it is ineffective.
- Hold the provided key only in the calling process/environment, obtained via a non-echoing prompt. The example config stores only DEEPSEEK_API_KEY's variable name. No key file or inline credential is needed.
- Preserve all model responses and the existing scorer. The live trial's 49/50 strict grounded score includes an equivalent citation that the frozen reference rejects; report the restriction instead of presenting it as an unsupported weather claim or silently upgrading the score.
- Price calculations use captured official rates and returned cache/usage data; reasoning tokens are already part of completion tokens. The estimate is not an account debit or invoice. Budget limits for larger trials remain to be chosen.

## P0 versioned evidence scoring and offline migration

- The user's next-step instruction executes P0 plus metric definitions/implementation from OPTIMIZATION_ROADMAP.md. This package requires zero new model requests; a broader development matrix remains the next experiment.
- Keep dynamic.py, sources.py, workflow.py and model input/runtime contracts unchanged. Add standalone nhc_equivalent_support_v2 and dynamic_score_v2.0 modules; do not overwrite v1 scores or silently relabel them.
- Accept only restricted source-supported summary/body constructions, with latest delivered report, entity/time, exact canonical value/unit and locator checks. At least one citation is required for known answers and every supplied citation must pass. Unsupported grammar is evaluator_unverifiable, not automatically hallucination.
- Fixed Gold transition and preservation denominators include unsuccessful attempts and do not depend on model prior correctness. Known-only correctness, conditional self-error recovery and provenance refresh have separate definitions; zero opportunities produce null rates. V1 model-dependent metrics remain separately labeled.
- Historical migration verifies archived source/build/run/collection, executes the trusted saved implementation in a temporary private module namespace, and binds a new scorer/index/difference package. Verification recomputes from saved source; no historical manifest identity is rewritten.
- The original ten-response trial reproduces 49/50 strict grounding; derived v2 is 50/50 with one equivalent-citation difference. This changes evidence evaluation, not observed model behavior or heldout performance. New collection work needs a fresh build matching the new implementation.
