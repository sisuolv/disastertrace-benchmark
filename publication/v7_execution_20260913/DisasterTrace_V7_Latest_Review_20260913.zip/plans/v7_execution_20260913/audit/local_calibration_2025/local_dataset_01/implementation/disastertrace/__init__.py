"""Frozen data-builder package."""
