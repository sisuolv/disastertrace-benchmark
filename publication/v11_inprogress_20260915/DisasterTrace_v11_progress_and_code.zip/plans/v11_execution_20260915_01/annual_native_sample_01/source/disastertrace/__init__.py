"""Frozen monthly data qualification."""
