"""Frozen monitoring-only package."""
