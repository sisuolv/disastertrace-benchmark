# DisasterTrace v7 typed adaptive review

Read plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md.

Replay using the Python standard library, without network, weights or new inference:

```bash
python -I -B verify_portable.py . ../new-review-output
```

The output directory must be new. GPU launch directories are consumed; do not relaunch.
