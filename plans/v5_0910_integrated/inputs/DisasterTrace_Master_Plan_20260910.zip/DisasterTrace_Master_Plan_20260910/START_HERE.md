# 从这里开始

这是 DisasterTrace 的研究与执行总计划，不是已经运行的 benchmark。

## 文件用途

- `DisasterTrace_Master_Roadmap_CN.md`：完整研究、数据、代码、阶段、实验与验收计划。
- `dataset_registry_execution_v2.json`：保留上一轮43项原始来源登记，增加实施波次、候选角色与待验收状态。未修改原有报称规模；没有将任何来源变成“已下载”。
- `execution_backlog.json`：29个有依赖关系的本地工单、交付物和验收条件。不是已创建的GitHub issues。
- `planning_validation.json`：仅是本计划文件的自洽性检查结果，不是仓库测试报告。

先读总计划第0—5节，再按第8—9节与backlog执行。完整原始资源信息已保留在registry，无需依靠聊天上下文获取43项入口。

## 一句话方向

**广覆盖多灾种数据与严格主动预警子集并行，共享“证据—修订—固定未来目标—结果结算”契约。少数洪水测站是工程起点，不是全库上限。**

## 给 Codex 的首轮提示

```text
阅读本目录的master roadmap、registry和backlog。
在现有DisasterTrace工作区先完成DS-00至DS-04，
DS-05只在当前网络/下载预算明确时执行。

检查本地AGENTS、HEAD、改动、冻结清单和运行状态。
不重置旧SHA，不覆盖旧Gold/响应/失败/scorer/验收，不自动push。
实际写共享契约、registry、公开投影、计数和CPU测试，
不要只再返回一个方案，不创建43个未使用的空adapter。

范围必须包含多个天气家族：目录、气旋、强对流、洪水、
野火扩展、干旱/干热、极端温度；strict水文相机支路
不能阻塞其他大规模时序数据。每个来源分别记录资格。

没有真实数据时fixture仅为软件测试，不算真实验收。
不默认GPU、付费API、训练、权重、heldout、后台任务或外部发布。
报告实际改动、命令、测试、资源、真实覆盖和阻塞。
```

## 验收含义

PLANNED不等于IMPLEMENTED，入口可读不等于FETCHED，FETCHED不等于TASK_ELIGIBLE，程序通过不等于模型结果成立。任何科学规模必须以执行后的清单和收据重计。
