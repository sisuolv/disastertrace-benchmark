# DisasterTrace 后续总计划包

版本：2026-09-10 / master-v1.0。全部新增内容是计划，不是已经完成的数据或模型实验。

## 入口

- `DisasterTrace_Master_Plan_CN.md`：完整研究、数据、工程、实验及发布计划。
- `CODEX_START_HERE_CN.md`：首轮离线执行说明；优先交给编码代理。
- `backlog.json`：26项带依赖的实施任务，初始均为proposed。
- `source_plan.json`：完整继承59个来源，并加接入工作线、候选轨道和验收；eligible_tracks仍为空。
- `configs/hazard_taxonomy.yaml`：15家族、34个操作性子类草案。
- `configs/release_targets.yaml`：万级episode等规模目标，非实际数量。
- `configs/execution_policy.yaml`：执行权限默认关闭，预算未设时不得外部执行。
- `references/`：4份原始材料的原样副本；旧计划与新范围变更以主计划第0节为准。
- `package_validation.json`：仅本计划包文件/引用/计数/依赖/配置的本地检查结果，不是项目测试。
- `manifest.json`：文件SHA-256及大小。

这些JSON/YAML是实现规格和规划配置，不代表当前仓库的CLI能直接加载。没有克隆/修改仓库、运行项目测试、取得新灾害数据或启动模型/采集服务。
