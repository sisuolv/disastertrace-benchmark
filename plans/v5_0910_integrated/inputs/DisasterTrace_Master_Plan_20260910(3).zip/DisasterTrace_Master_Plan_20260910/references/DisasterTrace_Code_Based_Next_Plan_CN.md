# DisasterTrace｜基于现有代码的下一阶段实施计划

**版本：2026-09-10｜性质：代码审查 + 待实施研究规格。**

本次通过已连接的 GitHub 读取远端分支、源码与报告，并核查官方数据说明；没有修改仓库、下载完整实验数据、运行项目测试、调用模型或提交计算作业。下面所有新增文件、规模与实验都是建议，不是当前已有成果。

## 0. 执行结论

**不要推倒重写，也不要直接扩大旧提示/格式矩阵。先用已有 NHC 资产完成“合法图文证据 → 固定未来目标的预测提交 → 事后结果验证”的最小闭环，再接主动取证、等待和准备截止时间。**

研究终点：系统怎样在异步、多模态、预算和时限约束下，把可获得的信息转化为可靠且及时的预警。

工程顺序：

1. 当前资产/权限核对和离线 v2 契约；修复会破坏新实验解释的交付与记录机制。
2. NHC 文本 + 同产品 GIS/地图 + HURDAT2 的小型数据闭环。图文准入同步做，不把视觉留到最后。
3. 固定时点的概率/分布预测、结果结算与强基线。
4. 同一内核增加主动取证、等待、预算和研究决策截止时间。
5. 感知、证据到达、状态和停止策略的分层诊断。
6. 洪水站点任务通过档案门槛后接入；按事件和共享来源冻结独立验证。

Text Core 仍是基础诊断及回归集，不能改名为真实天气预测成绩。气旋最大风速预测用于首先验证协议，不等于已经证明沿岸地方预警价值。应用层主张需要后续站点级验证。

---

## 1. 本次核查的代码基线

### 1.1 远端版本，不代表用户 CCI 的全部本地工作

| 分支 | 本次读取的 HEAD | 使用方式 |
|---|---|---|
| `main` | `a23f73adadcbec077b9fcf2aecf8f45dfa4fe061` | 2026-09-07 的较早审查快照，不作为新开发起点 |
| `next-phase-v1` | `36082c42a93e11f67d274d8000c87cd1dc098d74` | 本次源码审查锚点 |

远端 `RESULTS_20260909.md` 内的状态时间仍为 2026-09-08 20:31 UTC，P11–P14 部分内容尚写为运行/等待。上传的总体材料标记为 2026-09-09 02:44 UTC，并包含更晚的结果。两者分别记录：**不把旧报告的“运行中”说成现在仍有作业，也不把附件数字说成已经重新从远端原始响应复算。**

先在实际工作机核对本地 HEAD、工作树、原始运行和终态报告；若比本规格新，优先输出差异，不回滚到本规格。不要自动 merge、checkout 或覆盖未提交工作。[C0–C2]

### 1.2 仓库中有两条不同的实现路径

**通用原型**：根层 `models.py / evidence.py / policies.py / interventions.py / runner.py / scoring.py / adapters.py`。已经有图像、增量状态、证据门控、动作字段和 Actual/Masked/Oracle/Edited 原型。

**已实测的原文任务**：`forecast_source/`、`forecast_task/`、`forecast_live/` 等。原文协议明确使用累计 `numbered_text`，按 latest-explicit 选源；输出不允许 actions，也不包含真正的预测概率与后验结算。

**存在原型 ≠ 已纳入原文主轨 ≠ 已有多模态真实实验。**过去计划中的“新增四臂”，应具体改为“复用已有原型并在新输入权限与真实样本上验收”。[C3–C10]

### 1.3 逐文件复用与修改边界

| 已读文件 | 可复用内容 | 新版本需要补齐的内容 |
|---|---|---|
| `models.py` | Artifact、TimeRange、Episode、StateLedger、EvidenceReference、动作与义务结构 | 版本/资产/locator 绑定、多对多来源关系、未知可用时间、Prediction/Outcome/Decision 分离 |
| `evidence.py` | 严格按可用时间上界门控、来源等级筛选 | 可用、已交付、实际已读三者区分；未知历史可用性与受控时间分开 |
| `policies.py` | new/all 两种历史访问、图像打包入口、结构状态 | 显式访问契约、类型化矢量/栅格处理、完整版本祖先和目标范围检查 |
| `interventions.py` | withholding、父版本替换、组合干预 | 有序 DeliveryEvent；真实“旧版本再次到达”与“隐藏新版”成为不同干预 |
| `runner.py` | 显式状态、新会话、状态干预、轨迹记录 | 每步原始记录持久化、工具动作执行、外部时钟、预算和截止；不复用整段结束才落盘的路径 |
| `adapters.py` | 实际 image_url/base64 图像输入、ScriptedAdapter | 原始响应先保存再解析；实际序列化请求哈希；重试/未知提交审计；预测协议独立 schema |
| `scoring.py` | 状态、来源、动作与配对指标结构 | locator 与资产绑定、值保持和支持刷新分开；概率/决策另评分；commit-used 仅配对诊断 |
| `forecast_source/pipeline.py` | 有限采集、来源封存、划分保护、双解析组织 | 原有选择范围保持冻结；新 adapter 用声明的配置，不能直接修改旧 `SELECTION` 扩题 |
| `forecast_task/protocol.py` | 固定槽位、确定性 ID、严格历史前缀检查 | 保留原任务；新轨加入有限访问、预测登记与动作，不静默改变旧协议 |
| `forecast_live/runtime.py` | intent → started → raw → parsed、失败前缀证据 | 把整 worker 停止的失败隔离改为新版本的逐轨迹处理 |
| `automated/run_store.py` | 单机写锁、fsync、hash-chain journal | 包装成新轨的耐久日志；不能直接声称已支持多机并发写入 |

`pyproject.toml` 已有 Pydantic、pytest/Hypothesis 等开发可选项以及 GeoPandas/Shapely/pyproj 地理可选项。不为这项工作升级共享环境或引入新的大框架；新依赖需单独声明并固定版本。[C11–C15]

---

## 2. 新实验前必须处理的六个具体问题

### 2.1 同名 snapshot 的语义不同

根层 `snapshot_policy()` 是 `history_mode="new", carry_state=False`；原文 `forecast_task` 的 snapshot 不带自己的历史答案，但仍读累计公告。

新运行清单至少记录：`evidence_access_mode`、`history_mode`、`carrier_type`、`retrieval_permission`、`version_filter`。不要只写 snapshot/ledger，也不要把不同信息权限混成同一个排行榜。[C5,C9]

### 2.2 集合式交付无法表示重复送达

当前 `newly_delivered_ids = delivered_ids - previous_delivered` 使用集合。已经出现过的旧图再次送达时，差集不能表达这一次新事件。当前 `StaleVersionReplay` 是替换可见版本，不等于在新版后重新送达旧图。

新增只追加的事件序列：

```text
DeliveryEvent(
  delivery_event_id, artifact_revision_id,
  sequence_no, delivered_at, delivery_kind
)
```

同一个 artifact revision 可有多条 delivery；同一 delivery 不得重复执行。模型实际读取记录另存 `ReadEvent`。旧图重放、重复无新信息、隐藏新版、延迟关键新版分别测试。[C6,C7]

### 2.3 保持数值与刷新支持不是同一操作

当前 `StateLedger.apply()` 对 KEEP 直接跳过；状态只持久化 artifact IDs，而非完整 span/region；`scoring.py` 的保持比较包含整个 SlotState，可能把合法来源/时间刷新算成“改变保持字段”。

新版本以显式字段或两个正交操作表达：

```text
value_operation: KEEP | SET | UNKNOWN | RETRACT
support_operation: KEEP | REPLACE | ADD | RETRACT
```

保持项根据预先定义的语义字段比较，不默认要求整个对象字节相同。新来源同值时允许值 KEEP、支持 REPLACE；原始合法错误状态不由评分器修好。[C3,C8]

### 2.4 region/span 必须绑定具体版本与资产

当前通用评分器分别聚合 artifact IDs、span IDs 和 region IDs。新任务不能只凭“引用集合里有某个来源，同时有某个 region 字符串”认定支持正确。

建议引用：`(artifact_revision_id, asset_id, locator_kind, locator, transform_id)`；用整组元组和目标语义校验。不同地图都出现 `region_1` 时，不能串图命中；整图框也不自动当成精确区域支持。[C3,C8]

### 2.5 原始捕获先于解析，按轨迹隔离故障

通用适配器先解析为 CheckpointCommit 才返回；通用 runner 只在整条 episode 结束后写 trajectory.json。不要用这条原型路径直接跑新主实验。

新轨复用成熟原文轨的 raw-first 设计与 RunStore：

```text
request_prepared → dispatch_started → raw_received
→ parse_result → state_applied → checkpoint_closed
```

每步耐久保存；请求摘要基于实际发给后端的完整提示/schema/图像清单与转换，而不是仅高层 prompt。区分未提交、已返回无效、已提交结果未知。结果未知不静默重发。单条轨迹超长或不可恢复时，其他独立轨迹继续；需要同批重新准备时，不重复已提交项。[C7,C10–C12]

### 2.6 当前动作字段不等于主动环境

已有 `REQUEST_EVIDENCE`、`latest_safe_time` 等结构，但已读通用 runner 没有把动作接为下一份证据选择、等待与预算变化；通用 timing 是根据当前 checkpoint 时刻做范围检查，不是观测验证的预警效用。[C3,C7,C8]

新增环境机制必须单独定义，而不是只在提示里写“请主动搜索”。

---

## 3. 统一的新契约：三种真值，四个信息集合，两个时钟

### 3.1 三种参考严格分开

| 层 | 含义 | 对应评分 |
|---|---|---|
| EvidenceGold（新评测对象） | 当轮合法输入明确支持的事实、版本、空间关系与未知 | 内容、引用、选择性修订 |
| OutcomeRecord | 目标时刻之后取得并按规则核验的观测或事后分析结果 | Brier、分布/数值误差、校准 |
| DecisionPolicy | 公开研究假设下的准备成本、损失与截止时间 | 限时决定的研究损失 |

真实概率预测不存在每轮唯一正确的概率。不能把最终 y 复制成每轮的正确置信度；也不能要求每次合理更新都更接近单次实际结果。

### 3.2 新的对象（建议，不是现有类名）

```text
TargetSpec:
  target_id, event_group_id, hazard, entity_id, variable,
  measurement_kind, unit, valid_from, valid_to,
  threshold(optional), outcome_rule_id, forecast_schedule

EvidenceRevision:
  revision_id, product_id, scope, observed_interval,
  issued_at, valid_interval,
  availability_lower, availability_upper, availability_basis,
  retrieved_at, content_sha256,
  supersedes_ids, derived_from_ids, dependence_group_id,
  origin, asset_ids, visibility_role

Asset:
  asset_id, revision_id, media_type, sha256, local_path,
  dimensions, crs, render_transform_id

DeliveryEvent / ReadEvent:
  event_id, revision_id, action_id, at, order, kind,
  bytes_read, image_pixels, token_usage, latency_provenance

PredictionCommit:
  prediction_id, target_id, opportunity_id,
  issued_sim_at, issued_wall_at, input_manifest_hash,
  value_or_probability_or_quantiles,
  supporting_refs, raw_output_digest, status

OutcomeRecord [evaluator-only]:
  target_id, observed_value, unit, observed_interval,
  quality_flags, settlement_status, settlement_revision,
  source_revision_id, resolved_at

DecisionCommit:
  target_id, decision_policy_id, action, committed_at,
  deadline, prediction_id, evidence_refs, terminal
```

`visibility_role=outcome_only` 的资产不能通过旧缓存、检索、工具元数据或默认 all-history 进入正常模型。历史已结算的结果如果被公开为过去观测，应产生另一个带合法时间边界的输入投影，而不是直接把 outcome store 挂载给模型。

### 3.3 四个集合

- available：此时在声明来源中可获得。
- catalog-visible：系统允许知道其存在和元数据；不得透露未来发布文件或内容。
- delivered/acquired：经允许动作已经交付本系统。
- read/retained：本方法真正读过或保留过的内容。

Full-evidence 自动开放所有当前允许证据；budgeted retrieval 需要显式查询；Streaming 只有新输入与预算内保留内容。各轨分别比较。

证据从未交付的事实题可以是 unknown；已经交付但策略丢失的信息仍构成保留失败。概率预测任务即使缺少一份证据也可能有合法先验预测，不照搬事实题的 unknown 标签。

### 3.4 外部时间与计算时间

- 外部时间：产品产生、发布、可用、目标发生、准备截止。
- 计算时间：序列化、模型生成、工具计算、网络传输等实际耗时。

离线主轨可用确定性的事件时钟/明确的延迟情景，另报实际壁钟成本；系统性能轨在相同硬件条件下测实际 wall-clock deadline。不能一会儿让外部时钟冻结、一会儿让它按某个模型的速度走，却仍称同一条件。

任务步进可概括为 `request_started=max(now, availability_boundary)`，然后根据声明的执行/传输模型确定完成时间；该模型不能把原本免费即时的信息人为设为长时间等待。真实、测得、模拟三种延迟分开。

---

## 4. 数据路线：一个立即复用主线，一个应用验证主线

### 4.1 必做 A：NHC 文本 + 匹配 GIS/图像 + HURDAT2

**作用：最快形成与当前代码连续的证据—预测—结果闭环。**

| 数据 | 角色 | 处理方式 |
|---|---|---|
| NHC Forecast/Advisory、必要时 Discussion | 可见预测证据和官方直接预测基线 | 复用已保存原文/双解析；新增来源另开带范围的采集版本 |
| NHC forecast wind radii 等匹配 GIS/地图 | 空间事实和多模态修订 | 官方原图与官方数据重渲染分开；固定目标、量、范围和精度 |
| HURDAT2 固定发布版本 | 事后气旋位置/最大持续风速核验 | evaluator-only；按 storm_id 和绝对时刻对齐，不填成早期观测 |

官方入口提供气旋公告及图形/GIS档案；HURDAT2 提供六小时尺度的位置、最大风速、中心气压等事后资料。[D1–D3]

**首个真实数据例：**先在既有开发集的 Francine 或 Ida 选一条通过数据审查的轨迹；不要默认所有公告都有可匹配图，也不使用已标记保护的风暴。当前 `forecast_source/pipeline.py` 明确把 Francine/Ida 用于 development，并有 heldout collision guard。[C13]

**预测首题：**固定未来绝对时刻 T 的气旋最大持续风速；先做数值/分位数预测，再增加预先声明阈值的超越概率。也可采用 `Vmax(T) ≥ 64 kt` 作为研究二元目标，但不把该气旋中心尺度目标说成某港口局地风速。

查询 T 来自预先登记的时间网格和入口时已知规则，不扫描全部后续公告或实际结果来挑“变化最大”题。前缀始终早于 T。时刻不匹配、状态不支持、结算数据缺失时依据冻结政策标 unresolved；不把消失记录赋成 0 kt。

**两层成绩不可混用：**

- 官方图中地点覆盖与新旧版本对齐，由当轮产品核对。
- 模型未来风速/位置，由事后最佳路径核验。

两者可来自同一事件，但不能声称“GIS 正确判分”就验证了未来真实风场。只有未来图像包含新增必要空间信息、且它影响预测或选择时，才支持多模态预测增量；否则仅称图文证据诊断。

若所取得的 HURDAT2 文件同时包含受保护事件，只允许隔离的机器过滤过程提取授权开发事件；不得把全库正文或保护事件结算标签暴露给编码代理、模型输入或开发选参过程。无法确认过滤隔离时，暂不接入该文件。

NHC 数值预报是确定性输入，不能假装它自带概率分布。二元概率基线可以用独立开发年份/事件中的预报残差进行固定校准；不得在测试事件的结算结果上拟合阈值或误差模型。持久性、官方原预报和校准后的官方基线均保留。

### 4.2 条件必做 B：水文站超阈值预警

**作用：将代理级的时限/信息管理能力连接到地点明确、观测可核验的预警问题。**

数据组合：[D4–D6]

- NWPS/HEFS：预报周期、集合成员/概率、测站和阈值信息。
- USGS Continuous Values 与站点/时间序列元数据：流量或水位、单位、质量标记及记录覆盖。
- 与目标具有明确流域关系的空间背景；GFS 降雨预报或可确认当时版本的 IMERG 可作为补充，不必首轮全接。

**首题只选一种量。**推荐优先选择预报和观测均能直接对齐的流量；使用固定的流量阈值。若选择水位及官方洪水等级，须核查站点映射、垂直基准、单位和阈值版本。不得直接将流量与水位比较，也不能用不明版本的评级曲线随意转换。

**时间口径只选一种：**固定时刻超阈值，或固定未来区间内至少一次超阈值。两者不同，HEFS 的逐步概率与 member-maximum 窗口概率也不能混用。

**档案门槛：**本次 NOAA 官方说明普通 NWPS API 不提供完整历史预报；实验性 HEFS API 当前约十天保留。先审查 3–5 个站点在指定窗口的真实历史周期与对应观测。历史不足时，保存前瞻采集任务但不虚构多年回放；可另查机构归档，其覆盖未经核实前不列为硬依赖。[D4]

用更晚质量控制的观测作结算可以，但把它倒灌为当时可见输入不可以。未来窗口有缺测时不默认阴性；应报告未结算覆盖和敏感性分析。

准备成本/截止时间首先是公开研究设定，不是当地官方应急规范。主论文若声称实际预警价值，需要通过此类应用任务验证；仅完成风暴最大风速试题时收缩主张。

### 4.3 补充来源，而不是起步硬依赖

| 来源 | 可以增加什么 | 不能替代什么 |
|---|---|---|
| GEE `NOAA/GFS0P25` | 有创建周期和目标时刻的格点预报、区域输入 | 不能只按有效日期选资料，也不能以全球格点风速代替港口局地观测 |
| GEE `NASA/GPM_L3/IMERG_V07` | 降雨估计与空间背景 | provisional 后续会更新；今天的最终估计不能冒充历史近实时输入 |
| SpaceNet 8 | 洪水设施空间理解/已有标签迁移 | 不是逐发布时刻的连续预测档案 |
| GEOID-Flood | 已配准灾前/灾后 S1、灾前 S2 与 DEM 的迁移 | 不能把双时相编成多轮真实过程，也不是水文站预测真值 |

GFS 查询显式固定 `creation_time` 与 `forecast_time`；降水波段有累积窗口规则，转换时必须防重复累加。IMERG 30 分钟表示数据时间分辨率，不等于交付时延。[D6–D9]

首篇不要求野火、地震、滑坡、社交媒体和训练遥感模型全部完成。洪水影像迁移只从 SpaceNet 8/GEOID-Flood 选一个小切片，不下载全库、不默认开启训练。

---

## 5. 在线使用方案：采集器与模型评测分离

```text
机构 API / GEE
    → 有范围与预算的只追加采集
    → 内容寻址快照 + 版本/可用性/转换清单
    → 冻结 EpisodeManifest
    → 无外网的主评测
    → 独立结果结算
```

GEE 用于发现、筛选、裁剪、渲染和地理计算，不作为各模型任意访问的 `latest` 真值来源。

候选接口（本次只设计、后续实现）：

```text
SourceAdapter.discover(query)       # 不暴露未来资产
SourceAdapter.fetch(asset_ref)      # 有范围、次数、字节上限
SourceAdapter.normalize(raw)        # 无模型/无 Gold
ArtifactStore.put_immutable(bytes)  # 相同 URL 新内容也保留新 revision
EpisodeBuilder.freeze(manifest)
```

首次观察到资料并不证明全球首次公开时间。已确认不可用到首次确认可用之间可构成区间；没有可靠反面检查时不伪造下界。只知道 issued_at 的历史样本走 controlled replay，不把它填入严格历史 availability。

`source_object_id`、内容哈希、来源版本、GEE asset ID、渲染/区域/尺度等均登记。原始产物和渲染产物不能只保留会过期的临时 URL。相同来源在图、文、表中表达的内容加入 dependence group；不把同源复制当作独立信息。

本轮 ONLINE-01 的范围是 mock adapter、缓存与manifest单元测试，不读取凭据、不访问用户 GEE、不创建导出任务。真正联网采集按新阶段的明确范围执行。此计划不自动重新激活旧 P5/P6/ACP 任务或已过期自主窗口。

---

## 6. 新代码组织：一个稳定包，不再复制一套套阶段内核

建议在现有项目中增加 `src/disastertrace/active_warning/`。若本地已有 `mm_trace/`、`revision_task/` 或 data-v2 工作，则先复用并确定唯一共享内核；不得照本清单再复制第三套。

```text
active_warning/
  contracts.py          # Target / Revision / Prediction / Outcome / Decision
  artifacts.py          # 资产、locator、内容寻址、依赖/版本
  delivery.py           # 有序交付事件；delay/withhold/stale/null
  access.py             # 合法/交付/已读/保留权限与预算
  state.py              # 值/支持正交更新、未知、模型自有状态
  multimodal.py         # 类型化图像输入、公开渲染与私有几何隔离
  environment.py        # 获取、等待、外部时钟、截止与终止
  forecasting.py        # 不可覆盖的预测登记与公开基线
  outcomes.py           # evaluator-only 结果对齐、质量与结算版本
  decisions.py          # 公开研究成本模型、决定时限
  scoring.py            # 证据 / 预测 / 决策 / 成本分别报告
  runtime.py            # 复用 raw-first、日志、逐轨迹故障隔离
  policies.py           # 强预测/检索/获取/停止基线
  sources/
    nhc.py              # 旧原文 wrapper + 新地图 manifest
    hurdat2.py          # 按需解析授权开发事件，输出结果投影
    hydro.py            # NWPS/HEFS/USGS 对齐与覆盖审查
    gee.py              # 可选；首轮mock，不是启动外网导出
```

这是目标结构，不要求首个 PR 创建所有空文件。首个 PR 只落 contracts、artifact adapter、ordered delivery、mock source、迁移说明和相关测试。数据驱动条件放配置，旧 `forecast_task` 与历史源快照不变。

依赖方向：模型可访问模块不能依赖 `outcomes.py` 的私有结果读取器。序列化白名单和文件挂载隔离都要测试，不只依赖 prompt 中“不要看答案”的文字。

---

## 7. 主动环境的最小动作与决定规则

### 7.1 最小动作

```text
READ(source_ref or catalog_query)
RETRIEVE_PAST(target, filters)
WAIT(until)
SUBMIT_FORECAST(target_id, distribution)
COMMIT_DECISION(target_id, action)
STOP
```

目录只能包含当时允许知道的来源；不能给出未来文件名、最终灾害类别或私有“最相关来源”标签。READ 不等于允许任意互联网访问。动作计次、预算、超时与非法请求都记录。

首版可以串行工具操作，明确限制；并行/全读作为另外可解释基线，不能宣称已测全部部署策略。WAIT 不能跳过强制预测检查点或准备截止，越界要先结算这些事件。

### 7.2 固定的预测承诺与决定

每个固定 target / checkpoint / run 都有预登记机会；即使系统只等待，也不能消失一个预测分母。缺失与无效预测保留为失败，另报告冻结默认专业基线回退后的系统预测分数；不要把 p=null 当合法概率直接塞进 Brier。结算资料缺失与模型没交付是不同问题，分别报告。

事件内部的权重预先固定，事件间等权或按明确目标人群/时间抽样权重汇总。不能用 checkpoint 数更多的风暴主导总榜。

研究决定首版可使用二元准备模型：及时行动付 rho，不行动且事件发生付 1；动作影响所定义的研究损失，不影响天气结局。该理想化假设与 rho、准备时间均公开。截止后的决定按预先规定的未及时完成处理；不随意给迟到系统额外的完全保护收益。

“自报 ready 但从未执行”的现实问题不在本版范围内，不能宣称实际救灾收益。

**不能凭空奖励早停。**若等待没有费用、不会失去资料或准备机会，且截止前动作效用相同，提前提交不应额外得分；需要将这种情形作为正确的负对照。只有声明的成本、真实/公开情景时延、不可逆动作或准备条件，才能形成取证与等待的取舍。先允许一次不可逆终态研究决定；撤销、分级预警和多阶段行动后续独立定义。

---

## 8. 工作包与进入条件

| 包 | 立即交付 | 验收条件 | 模型/采集状态 |
|---|---|---|---|
| WP0 / DATA-00 | baseline_snapshot、current_vs_proposed、保护清单、文档/产物差异 | 本地/远端/附件三个状态分开，旧结果未改；旧运行授权范围核清 | 只读与离线 |
| WP1 / DATA-01 + ONLINE-01 | v2契约、旧开发样例投影、有序DeliveryEvent、mock缓存与测试 | 通过下一节关键不变量；无未来数据和私有locator泄漏 | mock；0模型0GPU |
| WP2 / DATA-02 | 先1条、再3–5个开发事件候选的 NHC 图文/结果manifest | 同目标对齐，图可读，来源可核对；模态性质明确，结果隔离 | 按新采集范围取得小样本 |
| WP3 / FORECAST-01 | 固定时点预测、结算、持久性/官方/校准基线 | 从真实已保存输出可重算；真实输出与参考/Scripted严格区分 | 先离线基线，后单模型小预检 |
| WP4 / ACTIVE-01 | READ/WAIT/STOP、预算、准备截止、decisions | 同证据下只改变声明的权限/时间；全读与简单策略能运行 | 小规模开发对照 |
| WP5 / AUDIT-01 | 感知、到达、四臂状态、固定预测的停止策略对照 | 特权诊断单列；配对来源一致；不能加总干预收益为归因百分比 | 受限新运行 |
| WP6 / HYDRO-01 + EVAL-01 | 水文站档案审查通过后的迁移、独立事件/共享源测试 | 任务/协议/模型/预算冻结后评测；含阴性和近阈值样本 | 不自动打开受保护heldout |

### 最小规模：明确用途，不给虚假的统计保证

先1条完整任务验证数据和评分，再3–5个事件验证跨来源结构。工程试点可组织约12个episode，但真正独立组按共享storm/流域/原始产品计算，不把12当统计充分。

一次开发矩阵的算例：12 episode × 4固定预测点 × 4策略 × 2后端 × 2重复 = 768个最终预测机会。实际长短不同则逐manifest求和；主动工具、模型内调用、图像读取和特权诊断另计。此数不是GPU时长、不是许可上限、不是已批准运行计划。

正式测试规模由独立事件覆盖、错误类型稳定性及分组不确定性决定。至少按时间、强度/生命周期与来源依赖分层；不以“必须让三种模型显著失败”为通过条件。

---

## 9. 第一批必须写的测试

以下是待实现测试规格，本次没有执行。

| ID | 测试 | 应满足 |
|---|---|---|
| T01 | availability区间跨越checkpoint | 严格轨不提前开放；历史未知不自动填发行时间 |
| T02 | 同一revision重复交付 | 两个DeliveryEvent均保留，内容只需一份；顺序可重建 |
| T03 | 新版后送旧图 | 不自动撤回新版；真正重放与隐藏新版是不同条件 |
| T04 | 同值新来源 | value保持、support刷新合法；值保持分数不被时间戳变化误伤 |
| T05 | 两图都含region_1 | 跨artifact串用locator失败 |
| T06 | UPDATE与KEEP未知 | 仅机械执行模型操作，无Gold补齐；缺证不是数值0 |
| T07 | 非image的二进制GIS/GeoTIFF | 不用read_text替换乱码；只走声明的typed adapter |
| T08 | outcome-only资产 | READ、全历史、缓存、metadata均不可泄漏 |
| T09 | 固定T多轮预测 | 每轮target不变，晚于T的输入不得污染早期commit |
| T10 | 预测记录覆盖 | 相同机会不得重写；重试/替代形成另行登记状态 |
| T11 | 无效JSON或错误schema | raw先存在；解析失败不删除计划槽位 |
| T12 | 已提交后连接中断 | 标unknown，不静默重发重复计费/采样 |
| T13 | 一轨上下文超限 | 其他独立轨仍完成；本轨失败/恢复遵循冻结规则 |
| T14 | WAIT越过检查点/截止 | 强制预测与决定机会不会跳过或被追溯修改 |
| T15 | 掩掉从未交付信息 vs 已交付后遗忘 | 事实参考分别处理；概率预测先验不被强制null |
| T16 | GFS降水累积窗口 | 使用声明的时间窗口，不能重复累加；目标时间与init分开 |
| T17 | 水文流量/水位/单位基准 | 不同量拒绝匹配；缺测不判阴性 |
| T18 | 同源图文和派生产品 | dependence group正确，去重不抹掉真实新增观测 |
| T19 | shared storm/洪水/影像组 | 派生地区、同源图片与twins不跨dev/test |
| T20 | 正确/错误/缺失Scripted策略 | evaluator按设计通过/失败；不能把脚本得分称VLM成绩 |
| T21 | 无成本等待且截止前效用相同 | 不虚构早停收益；截止后的信息不能追溯改善已提交决定 |

首个 PR 以 T01–T08/T11–T13 的离线版本为主。后续功能的测试不应提前写“已通过”。旧任务回归要在隔离输出目录运行，先确认测试不会触发网络、模型加载或写冻结目录。

---

## 10. 基线与论文所需证据

### 10.1 可部署基线

- 持久性/统计基线；当前可用的专业预测；固定开发集校准的专业预测。
- 同后端全合法证据重算。
- 时间/产品/版本过滤检索。
- 结构状态和来源去重，配简单固定获取/停止规则。
- 固定专业预报后端 + 预算/时限感知证据选择。

版本过滤、状态结构化、信息价值本身不是首创；自己的轻量实现应写为 style/reference implementation，不声称复现外部作者完整系统。图像缓存须和充分的结构化几何及有预算历史检索比较，不只和弱摘要比较。

### 10.2 特权诊断，不进入主排行榜

Oracle视觉事实、Oracle状态、离线事后最佳证据选择。实际提取的视觉事实保留错误，不能由Gold修复。固定同一保存前缀的单步对照和闭环轨迹分别报告。

### 10.3 三组核心结果

1. 同一系统的预测质量—截止前研究价值—信息成本曲线。没有排名反转也报告。
2. 新证据的配对收益及旧版/同源重复造成的错误：不要求每事件每次更新都更准。
3. 固定后端下，感知、版本、记忆或停止策略变化能改善什么；干预互有作用，不作简单相加归因。

更新为末位正确不等于曾经按时提交。提前量只在固定误报约束和明确漏报分母下比较。只采最终灾害事件不足以评估实用误报率；诊断集可富集异常，总体性能集应使用预先定义的监测窗口/非事件及说明的抽样权重。

---

## 11. 交给 Codex 的首轮指令

> 你要在现有 DisasterTrace 代码上完成一个离线 v2 基础增量，不运行模型，不恢复旧作业，也不把已完成的 Text Core 重做一遍。
>
> 1. 先检查本地/远端 HEAD、工作树和现有 data-v2/mm_trace/revision_task 等实现。读取当前任务适用的仓库说明，区分历史阶段授权与此次计划范围。不要覆盖未提交工作或自动切分支。
> 2. 以本规格核查的 `36082c42...` 为比较锚点，不强制回滚。输出远端、附件后续汇总、本地原始终态证据的差异及可追溯链接/哈希。
> 3. 只完成 WP0/DATA-00、WP1/DATA-01、ONLINE-01(mock)。先复用既有纯函数和数据，不更改 `forecast_task_v1`、旧评分器、旧运行目录和受保护数据。
> 4. 定义 EvidenceRevision/AssetLocator/DeliveryEvent/ReadEvent/Target/Prediction/Outcome 的最小接口；明确 outcome-only、未知availability、版本与派生关系。
> 5. 解决集合重放、值/支持分离、locator绑定和raw-first风险。已有通用四臂只作为原型复用；不要宣称新增真实四臂实验已完成。
> 6. 用人工合成并显式标记的fixture和既有允许开发输入测试；参考/结果fixture不能传入正常请求。保留全部失败；不使用模型来生成或评价Gold。
> 7. 输出 `baseline_snapshot.md`、`implementation_delta.md`、`schema_v2.md`、`source_registry.yaml`、`test_report.md`、`next_data_acquisition_plan.md`。新增目录名先检查本地已有结构，避免再建重复内核。
> 8. 测试报告逐项写执行命令、环境、通过/失败/未执行及原因。不能把静态检查写成集成测试通过。
> 9. 不读取凭据、不调用机构/GEE网络、不创建GEE导出、不下载新权重、不提交GPU/付费API/训练任务、不打开heldout答案、不推送GitHub。真实采集和模型运行留到范围与预算明确的新阶段。
> 10. 达到离线验收后，给出下一步一条NHC真实图文与HURDAT2对齐任务的获取/核验清单，然后结束本轮，不自动扩成大规模实验。

## 12. 来源索引及核查范围

### 已通过连接读取的用户仓库（固定提交）

仓库：https://github.com/sisuolv/disastertrace-benchmark

固定根：https://github.com/sisuolv/disastertrace-benchmark/tree/36082c42a93e11f67d274d8000c87cd1dc098d74

- C0：`branches` 与 `main` 提交元数据。
- C1：`RESULTS_20260909.md`，完整读取。
- C2：用户上传 `DisasterTrace_Overall_Pre_CN.md` 的更晚结果快照；不是远端复算。
- C3：`disastertrace-starter/src/disastertrace/models.py`，完整读取。
- C4：`disastertrace-starter/src/disastertrace/evidence.py`，完整读取。
- C5：`disastertrace-starter/src/disastertrace/policies.py`，完整读取。
- C6：`disastertrace-starter/src/disastertrace/interventions.py`，完整读取。
- C7：`disastertrace-starter/src/disastertrace/runner.py`，完整读取。
- C8：`disastertrace-starter/src/disastertrace/scoring.py`，完整读取。
- C9：`disastertrace-starter/src/disastertrace/forecast_task/protocol.py` 与 `contract.py`，完整读取。
- C10：`disastertrace-starter/src/disastertrace/adapters.py`，完整读取。
- C11：`disastertrace-starter/src/disastertrace/forecast_live/runtime.py` 与 `worker.py`，完整读取。
- C12：`disastertrace-starter/src/disastertrace/automated/run_store.py`，完整读取。
- C13：`disastertrace-starter/src/disastertrace/forecast_source/pipeline.py`，本次读取前170行；不宣称全量读取该文件后半或重跑双解析。
- C14：`disastertrace-starter/AGENTS.md`，本次读取前115行；包含历史阶段记录，不将其中旧时间窗自动视为本轮授权。
- C15：`disastertrace-starter/pyproject.toml`，完整读取。

此外读取了根目录与源码目录树；这不是对所有科学文件、所有依赖和全部二进制归档的全量审计。

### 官方数据与作者资料（2026-09-10 核查）

- D1 NHC Data Archive：https://www.nhc.noaa.gov/data/index.php 。官方搜索索引可读，直接页面读取本次返回403；不据此判断数据不存在，也不声称已下载HURDAT2。
- D2 NHC GIS：https://www.nhc.noaa.gov/gis/ ；本次可读官方镜像：https://prod-east-nhc.woc.noaa.gov/gis/ 。存在入口不保证每个目标图文可匹配。
- D3 官方图层语义：https://mapservices.weather.noaa.gov/tropical/rest/services/tropical/NHC_tropical_weather/MapServer 。实时服务不是不变历史版本仓库。
- D4 NWPS/HEFS API说明：https://api.water.noaa.gov/about/api 。普通API无完整历史；HEFS当前十天保留；正式实现再次核对最新限制。
- D5 USGS Water Data API：https://api.waterdata.usgs.gov/ 。使用连续值、监测位置及时间序列元数据；具体站点历史覆盖仍需审查。
- D6 GFS/GEE：https://developers.google.com/earth-engine/datasets/catalog/NOAA_GFS0P25 。需按创建/预报时间及波段窗口处理。
- D7 IMERG/GEE：https://developers.google.com/earth-engine/datasets/catalog/NASA_GPM_L3_IMERG_V07 。临时数据会更新，保存具体版本；不把最新目录当历史首次版本。
- D8 SpaceNet8作者项目：https://github.com/SpaceNetChallenge/SpaceNet8 。只建议小型辅助迁移，不在本次运行训练。
- D9 GEOID-Flood作者项目：https://github.com/links-ads/geoid-flood ；数据卡：https://huggingface.co/datasets/links-ads/geoid-flood 。代码/数据许可分别保存，上游归属与标签生成层次进一步核查。
- 可选 ATCF guidance 档案入口：https://ftp.nhc.noaa.gov/atcf/archive/ 。本次仅目录可读，不据此宣称所有年份/周期的业务可用时间和集合成员完整；不作为首轮硬依赖。

**最终验收标准：一个模型无关的可检查任务闭环，而不是更多阶段名、更多问题数，或事先要求模型一定低分。**
