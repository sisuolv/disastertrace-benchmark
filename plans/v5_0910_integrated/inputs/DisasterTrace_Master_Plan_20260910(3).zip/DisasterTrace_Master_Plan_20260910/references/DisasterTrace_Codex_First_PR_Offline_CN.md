# DisasterTrace｜交给 Codex 的第一轮离线任务

配套完整规格：`DisasterTrace_Code_Based_Next_Plan_CN.md`。本轮不授权执行后续模型或采集工作包。


你要在现有 DisasterTrace 代码上完成一个离线 v2 基础增量，不运行模型，不恢复旧作业，也不把已完成的 Text Core 重做一遍。
>
1. 先检查本地/远端 HEAD、工作树和现有 data-v2/mm_trace/revision_task 等实现。读取当前任务适用的仓库说明，区分历史阶段授权与此次计划范围。不要覆盖未提交工作或自动切分支。
2. 以本规格核查的 `36082c42...` 为比较锚点，不强制回滚。输出远端、附件后续汇总、本地原始终态证据的差异及可追溯链接/哈希。
3. 只完成 WP0/DATA-00、WP1/DATA-01、ONLINE-01(mock)。先复用既有纯函数和数据，不更改 `forecast_task_v1`、旧评分器、旧运行目录和受保护数据。
4. 定义 EvidenceRevision/AssetLocator/DeliveryEvent/ReadEvent/Target/Prediction/Outcome 的最小接口；明确 outcome-only、未知availability、版本与派生关系。
5. 解决集合重放、值/支持分离、locator绑定和raw-first风险。已有通用四臂只作为原型复用；不要宣称新增真实四臂实验已完成。
6. 用人工合成并显式标记的fixture和既有允许开发输入测试；参考/结果fixture不能传入正常请求。保留全部失败；不使用模型来生成或评价Gold。
7. 输出 `baseline_snapshot.md`、`implementation_delta.md`、`schema_v2.md`、`source_registry.yaml`、`test_report.md`、`next_data_acquisition_plan.md`。新增目录名先检查本地已有结构，避免再建重复内核。
8. 测试报告逐项写执行命令、环境、通过/失败/未执行及原因。不能把静态检查写成集成测试通过。
9. 不读取凭据、不调用机构/GEE网络、不创建GEE导出、不下载新权重、不提交GPU/付费API/训练任务、不打开heldout答案、不推送GitHub。真实采集和模型运行留到范围与预算明确的新阶段。
10. 达到离线验收后，给出下一步一条NHC真实图文与HURDAT2对齐任务的获取/核验清单，然后结束本轮，不自动扩成大规模实验。
