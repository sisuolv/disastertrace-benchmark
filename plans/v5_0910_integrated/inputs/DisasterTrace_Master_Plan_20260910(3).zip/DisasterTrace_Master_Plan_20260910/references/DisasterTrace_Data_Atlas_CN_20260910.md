# DisasterTrace 多灾种与在线数据资源清单

核查日期：2026-09-10。共 **59 个候选条目**，包括数据集、历史档案、实时业务服务，不代表 59 个互相独立的语料库。

## 如何读这份清单

**R**：业务/近实时获取；**U**：持续但延迟更新；**A**：固定历史版本，可以在线访问，不等于实时数据流。数量按发布版本引用，未进行全库下载或逐文件清点。理论时间层数量不等于影像文件数，更不等于极端事件数。

## 建议的范围

将项目数据层扩为约15个极端天气及相关水文气候灾害家族，约25–35个操作性子类。范围可包括气旋、强降水、洪水、强对流、非气旋大风、热浪、寒潮、暴雪、冻雨、干旱、野火天气及烟羽、沙尘、低能见度、沿海高水位/海浪、海洋热浪；降雨触发滑坡作为关联扩展。此为研究组织建议，不是官方统一分类。地震、火山与海啸不能计入极端天气数量。

## 数据如何成为benchmark

优先建立事件索引/持续观测底座，按事件和区域按需读取图像；不要全量下载所有栅格。分为事件库、时序证据库、可评测任务库。来源能支持静态感知就纳入感知子集，具有版本链才纳入修订，具有真实未来核验且输入先于目标才纳入预测。不要要求所有源都满足最严格的预警任务后才入库。

规模分开统计：独立event_group、episode、artifact_version、delivery_event、checkpoint_query、模型调用。相同事件跨数据集、国家、瓦片和灾种记录应关联，而不是相加。预警不等于发生事实，缺测不等于阴性，风险图不等于灾害确认图。

## 事件与公告

### E01｜NOAA Storm Events

**灾种：**强对流、龙卷风、冰雹、雷暴大风、洪水、热浪、寒潮、暴雪、冻雨、沙尘、雾。

**规模与单位：**官方完整记录制度含48类；本次未清点总行数；计数单位为事件记录（并非独立天气系统）。

**覆盖与在线：**1950起；1996起覆盖完整类型体系；U；年度CSV.gz/网页查询。

**建议用途：**事件索引；灾后标签；文字证据。

**边界：**早期仅部分类型；通常延迟90–120天，不是实时预警；同一过程可能跨县、多行。

**官方/作者依据与入口：**

- https://www.ncdc.noaa.gov/stormevents/details.jsp
- https://www.ncei.noaa.gov/pub/data/swdi/stormevents/csvfiles/

### E02｜EM-DAT

**灾种：**洪水、风暴、干旱、极端温度、野火、滑坡。

**规模与单位：**>27000条全部灾害记录；首页分类下界：洪水>5750、风暴>4580、干旱>790、极端温度>600、野火>450；计数单位为事件—国家记录。

**覆盖与在线：**1900起；U；注册后表格下载；公共库按周更新。

**建议用途：**全球事件索引；影响标签。

**边界：**全部记录包含技术事故和地质灾害；同一灾害跨国家可重复；不是逐轮预报档案。

**官方/作者依据与入口：**

- https://www.emdat.be/
- https://doc.emdat.be/docs/data-accessibility/
- https://doc.emdat.be/docs/data-structure-and-content/emdat-public-table/

### E03｜GDIS v1

**灾种：**洪水、风暴、干旱、极端温度、滑坡。

**规模与单位：**9924个灾害，39953个地理位置；计数单位为灾害 / 行政区位置。

**覆盖与在线：**1960–2018；A；CSV/GIS下载。

**建议用途：**全球事件定位；跨源链接。

**边界：**EM-DAT派生，不能与EM-DAT相加；含地震火山；行政区几何不是实际灾害淹没范围。

**官方/作者依据与入口：**

- https://www.nature.com/articles/s41597-021-00846-6
- https://www.prio.org/publications/12638

### E04｜IBTrACS v4r01

**灾种：**热带气旋。

**规模与单位：**全球多机构轨迹；总风暴数须由固定CSV按SID去重清点；计数单位为风暴 / 轨迹时刻。

**覆盖与在线：**历史至近实时；现代1980起更适合跨机构比较；U；CSV/NetCDF/Shapefile；通常每周更新三次。

**建议用途：**事件索引；轨迹核验。

**边界：**最佳路径和provisional不是全部历史业务预报；不能按机构轨迹重复计数。

**官方/作者依据与入口：**

- https://www.ncei.noaa.gov/products/international-best-track-archive

### E05｜NHC 公告与GIS档案

**灾种：**热带气旋、气旋大风、风暴潮。

**规模与单位：**按风暴×公告周期×产品计；本次未清点全档案；计数单位为公告 / 产品版本。

**覆盖与在线：**多年档案与业务发布；R；官方HTTPS文本、地图与GIS。

**建议用途：**时间回放；已发布预测基线；多模态证据。

**边界：**预报风圈、路径锥和风概率不同；同一相对时效不等于同一绝对有效时刻。

**官方/作者依据与入口：**

- https://www.nhc.noaa.gov/data/
- https://www.nhc.noaa.gov/gis/

### E06｜NWS API Alerts/Forecasts

**灾种：**强对流、暴雨、洪水、热浪、寒潮、冰雪、大风、海岸灾害、火险。

**规模与单位：**多灾种持续生成；alerts接口仅最近7天；计数单位为公告 / 预警生命周期。

**覆盖与在线：**当前与滚动短档案；R；免费JSON-LD/GeoJSON/CAP；需要User-Agent。

**建议用途：**在线预警；版本更新；预测证据。

**边界：**短滚动档案不是多年历史；资料总量需本地持续采集；遵守限流。

**官方/作者依据与入口：**

- https://www.weather.gov/documentation/services-web-api

### E07｜IEM NWS WWA/VTEC 与文字档案

**灾种：**强对流、洪水、热浪、寒潮、冰雪、大风。

**规模与单位：**预生成档案列表可追溯1986；早期类型覆盖须另查；计数单位为预警事件 / 更新消息 / 多边形。

**覆盖与在线：**长期档案与当前更新；R；脚本接口、年度ZIP、Shapefile/CSV、实时服务。

**建议用途：**历史预警修订；空间范围变化。

**边界：**IEM为处理归档；默认下载可能仅初始多边形，需明确请求后续更新；不是灾害发生真值。

**官方/作者依据与入口：**

- https://mesonet.agron.iastate.edu/request/gis/watchwarn.phtml

### E08｜NASA EONET v3

**灾种：**风暴、野火、洪水、干旱、冰雪、沙尘。

**规模与单位：**滚动事件目录；按时间和类别查询计数；计数单位为事件及几何更新。

**覆盖与在线：**持续维护；R；公开JSON API。

**建议用途：**在线发现；原始来源链接。

**边界：**目录非穷尽；缺记录不能推断无灾害；含非天气自然事件。

**官方/作者依据与入口：**

- https://eonet.gsfc.nasa.gov/docs/v3

### E09｜GDACS API

**灾种：**气旋、洪水、干旱、野火。

**规模与单位：**按查询范围计数；本次未清点；计数单位为告警 / 事件记录。

**覆盖与在线：**持续更新；R；官方API规范与事件服务。

**建议用途：**事件发现；跨灾种关联。

**边界：**告警筛选及估计影响不等于完整实测；具体产品和权限需预检。

**官方/作者依据与入口：**

- https://www.gdacs.org/gdacsapi/swagger/index.html

### E10｜NOAA Billion-Dollar Disasters 固定档案

**灾种：**干旱、洪水、冻害、强风暴、气旋、野火、冬季风暴。

**规模与单位：**403场：32/45/9/203/67/23/24；计数单位为高损失灾害事件。

**覆盖与在线：**1980–2024；A；官方统计表与事件档案。

**建议用途：**高影响事件分层。

**边界：**固定历史范围；强损失门槛，不能估计所有天气事件发生率。

**官方/作者依据与入口：**

- https://www.ncei.noaa.gov/access/billions/state-summary/US

## 已整理研究数据

### D01｜SEVIR

**灾种：**强对流、强降水、雷电、龙卷风/冰雹关联事件。

**规模与单位：**>10000条，4小时、约384×384km、5种图像/雷电模态；计数单位为天气序列窗口。

**覆盖与在线：**原始发布历史样本；A；公开S3 sevir。

**建议用途：**多模态时序；降水临近预报；事件关联。

**边界：**含常规/随机天气窗口；不等于>10000场严重灾害；静态云端档案不等于实时。

**官方/作者依据与入口：**

- https://neurips.cc/virtual/2020/public/poster_fa78a16157fed00d7a80515818432169.html
- https://registry.opendata.aws/sevir/

### D02｜TC PRIMED 原始发布

**灾种：**热带气旋。

**规模与单位：**2101场气旋，>176000次微波卫星过境；计数单位为气旋 / 卫星过境。

**覆盖与在线：**1998–2019；A；NCEI NetCDF档案。

**建议用途：**气旋多模态；强度与降水；时序任务。

**边界：**包含事后最佳路径与ERA5；作为历史输入须防止倒灌未来核验信息。

**官方/作者依据与入口：**

- https://journals.ametsoc.org/view/journals/bams/104/11/BAMS-D-21-0052.1.xml

### D03｜ADT-HURSAT

**灾种：**热带气旋。

**规模与单位：**1978–2024的长期卫星强度估计档案；本次未清点总风暴/图像数；计数单位为卫星估计 / 风暴时刻。

**覆盖与在线：**1978-05-30–2024-12-31（核查版本）；A；NCEI/NODD NetCDF。

**建议用途：**气旋长历史核验与影像关联。

**边界：**ADT估计与原始HURSAT图像层须区分；不是局地站点风速实测。

**官方/作者依据与入口：**

- https://www.ncei.noaa.gov/products/advanced-dvorak-technique-hurricane-satellite

### D04｜MeteoNet

**灾种：**强降水、强对流、风、高低温。

**规模与单位：**3年，两个约550×550km区域，约500站及雷达/卫星/NWP；计数单位为区域时序 / 站点。

**覆盖与在线：**2016–2018；A；Météo-France公开下载。

**建议用途：**图像+站点+预报对齐。

**边界：**连续天气而非全为极端；不将站点数乘时次数称独立事件。

**官方/作者依据与入口：**

- https://meteonet.umr-cnrm.fr/

### D05｜HKO-7

**灾种：**降水、强降水。

**规模与单位：**七年香港雷达数据；具体有效帧数由许可后的清单确认；计数单位为雷达帧 / 降雨序列。

**覆盖与在线：**历史七年基准；A；作者项目入口；具体下载权限需确认。

**建议用途：**降水临近预报；区域外推。

**边界：**不是无需审批的实时API；代码的online模式是评测协议，不代表连接当前雷达流。

**官方/作者依据与入口：**

- https://github.com/sxjscience/HKO-7
- https://arxiv.org/abs/1706.03458

### D06｜RainNet

**灾种：**强降水、飓风相关降水、飑线。

**规模与单位：**>62400对低/高分辨率降水图；17年；计数单位为降水图对。

**覆盖与在线：**17年历史资料（原始发布）；A；作者网盘/HDF5；压缩下载约13.6GB。

**建议用途：**降水空间理解；降尺度；历史序列。

**边界：**不是62400场灾害；原任务是降尺度，不能直接当未来预测标签。

**官方/作者依据与入口：**

- https://neuralchen.github.io/RainNet/
- https://github.com/neuralchen/RainNet

### D07｜Global Flood Database v1

**灾种：**洪水。

**规模与单位：**913场已制图洪水；计数单位为洪水事件。

**覆盖与在线：**2000–2018；A；GEE公开ImageCollection。

**建议用途：**洪水范围/持续；事件索引。

**边界：**固定历史MODIS产品；不是实时更新；质量/云掩膜须保留。

**GEE ID：**`GLOBAL_FLOOD_DB/MODIS_EVENTS/V1`

**官方/作者依据与入口：**

- https://developers.google.com/earth-engine/datasets/catalog/GLOBAL_FLOOD_DB_MODIS_EVENTS_V1

### D08｜WorldFloods extended 1.0

**灾种：**洪水。

**规模与单位：**144场事件，509份洪水范围地图；计数单位为事件 / 地图。

**覆盖与在线：**扩展发布至2023；A；作者Zenodo下载。

**建议用途：**光学洪水范围；多事件空间评测。

**边界：**509张图不是509场洪水；与CEMS/GEOID等来源可能重叠。

**官方/作者依据与入口：**

- https://zenodo.org/records/8153514

### D09｜Sen1Floods11

**灾种：**洪水。

**规模与单位：**11场洪水，4831个512×512切片；446个人工标注切片，其余弱标签；计数单位为事件 / 图像切片。

**覆盖与在线：**固定研究发布；A；GCS/作者STAC及清单。

**建议用途：**SAR洪水识别；模态对照。

**边界：**标签可信度分层；不可称全部切片人工标注。

**官方/作者依据与入口：**

- https://github.com/cloudtostreet/Sen1Floods11

### D10｜GEOID-Flood

**灾种：**洪水。

**规模与单位：**219次CEMS启动、65国、14282瓦片、165329栅格、584GB/319分片；计数单位为启动记录 / 瓦片 / 栅格文件。

**覆盖与在线：**2016–2026（当前作者数据卡）；A；Hugging Face tar分片中的COG。

**建议用途：**多传感器洪水；空间迁移。

**边界：**启动数不等于去重物理事件数；不是14282场洪水；S1灾前后、S2灾前、DEM角色分开；不保证HF自动streaming加载成功。

**官方/作者依据与入口：**

- https://huggingface.co/datasets/links-ads/geoid-flood

### D11｜SpaceNet8

**灾种：**洪水、气旋诱发洪水。

**规模与单位：**作者公开影像、建筑与道路标签；本次未核验统一样本总数；计数单位为影像 / 建筑 / 道路。

**覆盖与在线：**固定挑战数据；A；作者项目/数据入口。

**建议用途：**设施级淹水；道路建筑空间任务。

**边界：**淹水不直接代表不可通行；挑战代码许可不等于影像再分发许可。

**官方/作者依据与入口：**

- https://github.com/SpaceNetChallenge/SpaceNet8

### D12｜FPA-FOD 第六版

**灾种：**野火。

**规模与单位：**约230万条火灾记录；计数单位为火灾发生记录。

**覆盖与在线：**1992–2020；A；USDA归档、GIS服务/下载。

**建议用途：**野火事件索引；大规模发生记录。

**边界：**包括大量小火，不全是极端火灾；需按事件ID与重复报告规则去重。

**官方/作者依据与入口：**

- https://catalog.data.gov/dataset/national-interagency-fire-occurrence-sixth-edition-1992-2020-feature-layer

### D13｜TS-SatFire

**灾种：**野火、火场扩展。

**规模与单位：**179场野火，3552幅影像，约71GB；计数单位为事件 / 影像。

**覆盖与在线：**2017-01–2021-10美国；A；作者项目/数据下载。

**建议用途：**火点检测；烧毁范围；次日火场演化。

**边界：**3552幅影像不是3552场火；缺测和填充值不能当作无火。

**官方/作者依据与入口：**

- https://www.nature.com/articles/s41597-025-06271-3
- https://github.com/zhaoyutim/TS-SatFire

### D14｜Sen2Fire

**灾种：**野火、烟羽。

**规模与单位：**2466个512×512多模态切片；计数单位为切片。

**覆盖与在线：**固定研究发布；A；Zenodo。

**建议用途：**S2+S5P火灾/烟羽感知。

**边界：**切片不等于独立火灾；气溶胶并非全部来自火灾。

**官方/作者依据与入口：**

- https://zenodo.org/records/10881058

### D15｜MTBS v12

**灾种：**野火、燃烧范围。

**规模与单位：**1984–2024多年代大火档案；本次未清点总事件数；计数单位为火场 / 燃烧严重度产品。

**覆盖与在线：**1984–2024（2025年4月版本）；U；USGS/MTBS空间数据下载。

**建议用途：**大火范围；事后严重度核验。

**边界：**包含规定燃烧；西部1000英亩、东部500英亩等准入阈值，不是全部火点。

**官方/作者依据与入口：**

- https://www.usgs.gov/data/monitoring-trends-burn-severity-ver-120-april-2025

### D16｜Landslide4Sense

**灾种：**滑坡（需筛选降雨触发）。

**规模与单位：**4844切片：3799训练/245验证/800测试；14波段；计数单位为图像切片。

**覆盖与在线：**固定研究发布；A；Zenodo/作者清单。

**建议用途：**S2+地形的滑坡空间识别。

**边界：**滑坡触发可能包括地震；天气主轨必须筛触发类型。

**官方/作者依据与入口：**

- https://zenodo.org/records/10463239
- https://github.com/iarai/Landslide4Sense-2022

### D17｜xBD

**灾种：**气旋、洪水、野火、其他灾害。

**规模与单位：**850736个建筑标注；45362平方千米影像覆盖（原论文）；计数单位为建筑标注 / 影像覆盖。

**覆盖与在线：**固定研究发布；A；xView2/作者数据入口。

**建议用途：**灾前灾后损伤；影响空间任务。

**边界：**包含非天气事件；建筑数不是灾害数；需单独核查影像使用与再发布条款。

**官方/作者依据与入口：**

- https://arxiv.org/abs/1911.09296

### D18｜CLLMate

**灾种：**天气气候多类。

**规模与单位：**26156篇与ERA5对齐的环境新闻；计数单位为新闻文章。

**覆盖与在线：**EMNLP2025正式版本；A；作者数据与项目。

**建议用途：**文字+气象场；事件描述。

**边界：**文章不是独立事件；ERA5是再分析；新闻可能泄漏后来结果。

**官方/作者依据与入口：**

- https://aclanthology.org/2025.emnlp-main.886/

### D19｜CrisisMMD v2

**灾种：**洪水、气旋、野火、其他灾害。

**规模与单位：**16058条文本、18082张图，7次灾害；计数单位为文本 / 图像 / 灾害。

**覆盖与在线：**2017事件、v2发布；A；作者下载。

**建议用途：**人道影响图文；补充证据。

**边界：**包含非天气事件；用户内容可靠性与平台再分发限制须核查，不作主物理真值。

**官方/作者依据与入口：**

- https://crisisnlp.qcri.org/crisismmd

### D20｜Incidents1M

**灾种：**自然灾害图像、其他事故。

**规模与单位：**约100万图，43事故类和49场景类；计数单位为网络图像。

**覆盖与在线：**固定研究发布；A；作者项目导航。

**建议用途：**感知预训练/鲁棒性辅助。

**边界：**不是100万极端天气事件；大量非天气类，缺完整时间/位置链。

**官方/作者依据与入口：**

- https://crisisnlp.qcri.org/

### D21｜ClimateNet

**灾种：**热带气旋、大气河。

**规模与单位：**219个唯一模拟时刻，459份专家标注映射；计数单位为模拟时刻 / 标注。

**覆盖与在线：**CAM5.1历史时期模拟；A；作者数据发布。

**建议用途：**天气形态分割；模拟诊断。

**边界：**这是气候模型模拟，不是观测或再分析；专家多次标注不增加独立时刻。

**官方/作者依据与入口：**

- https://gmd.copernicus.org/articles/14/107/2021/

## 连续在线与区域资料

### O01｜GHCN-Daily

**灾种：**热浪、寒潮、暴雨、降雪、积雪、冻害。

**规模与单位：**>10万历史站点；约2万站在任一30天窗口更新；>2.5万站有日极温；计数单位为历史站点 / 活跃站点。

**覆盖与在线：**各站跨度不同，部分超过175年；U；HTTPS、CDO、清单及日版本。

**建议用途：**站点核验；极端窗口构造；阴性样本。

**边界：**多数站非持续活跃；约半数仅降水；质量标记、日界线和后续修订须保留。

**官方/作者依据与入口：**

- https://www.ncei.noaa.gov/products/land-based-station/global-historical-climatology-network-daily

### O02｜GHCN-Hourly

**灾种：**强风、雾、沙尘、高低温、降水相态、冰雪。

**规模与单位：**全球多来源小时/天气代码；本次未清点站点总量；计数单位为站点—时刻记录。

**覆盖与在线：**长期历史至更新资料；U；NCEI、PSV/Parquet等批量资料。

**建议用途：**小时阈值任务；低能见度；天气现象。

**边界：**应替代已停止更新的ISD；实际字段、有效覆盖和当时可用性逐站核查。

**官方/作者依据与入口：**

- https://www.ncei.noaa.gov/products/global-historical-climatology-network-hourly
- https://www.ncei.noaa.gov/metadata/geoportal/rest/metadata/item/gov.noaa.ncdc%3AC01688/html

### O03｜ERA5-Land HOURLY

**灾种：**高低温、降水、风、土壤干旱、雪。

**规模与单位：**1950起全球陆面小时场；每非闰年理论8760时刻/变量；计数单位为全球时间层。

**覆盖与在线：**1950起；GEE核查到2026-09-04；U；CDS/GEE。

**建议用途：**阈值派生；背景场；事后核验辅助。

**边界：**小时分辨率不是实时延迟；再分析不是业务预测，也不是无误差的站点真值。

**GEE ID：**`ECMWF/ERA5_LAND/HOURLY`

**官方/作者依据与入口：**

- https://developers.google.com/earth-engine/datasets/catalog/ECMWF_ERA5_LAND_HOURLY

### O04｜GFS 0.25°

**灾种：**热浪、寒潮、强降水、风、天气条件。

**规模与单位：**4预报周期/日，非闰年理论1460周期；每周期多预报时效；计数单位为预报初始化周期 / 有效时间层。

**覆盖与在线：**GEE2015-07起；核查到2026-09-10；R；NOAA开放资料/GEE。

**建议用途：**滚动预测；版本修订；专业基线。

**边界：**creation_time与forecast_time分开；降水累积窗口不可乱加。

**GEE ID：**`NOAA/GFS0P25`

**官方/作者依据与入口：**

- https://developers.google.com/earth-engine/datasets/catalog/NOAA_GFS0P25

### O05｜GPM IMERG V07

**灾种：**强降水、暴雨、洪水、降雨滑坡。

**规模与单位：**半小时场；非闰年理论17520时间层；计数单位为全球降水时间层。

**覆盖与在线：**GEE1998起；核查到2026-09-09；U；NASA/GEE。

**建议用途：**降雨观测估计；时序输入；结果辅助。

**边界：**Early/Late/Final及provisional/permanent分开；后处理会替换历史估计。

**GEE ID：**`NASA/GPM_L3/IMERG_V07`

**官方/作者依据与入口：**

- https://developers.google.com/earth-engine/datasets/catalog/NASA_GPM_L3_IMERG_V07

### O06｜CHIRPS v3

**灾种：**干旱、极端降水。

**规模与单位：**1981起0.05°陆地降水；日/候/月产品；计数单位为栅格时间层。

**覆盖与在线：**1981起；60°N–60°S；U；UCSB HTTPS；GEE已列v3 DAILY_RNL。

**建议用途：**长期降水异常；干旱窗口。

**边界：**preliminary/final与日尺度分解方法分开；DAILY_RNL不是即时降雨；GEE入库时间可能晚于源站。

**GEE ID：**`UCSB-CHC/CHIRPS/V3/DAILY_RNL`

**官方/作者依据与入口：**

- https://www.chc.ucsb.edu/data/chirps3
- https://developers.google.com/earth-engine/datasets/catalog/UCSB-CHC_CHIRPS_V3_DAILY_RNL

### O07｜Sentinel-1 GRD

**灾种：**洪水、野火变化、降雨滑坡。

**规模与单位：**持续全球SAR场景；按AOI和日期查询；计数单位为轨道场景 / 切片。

**覆盖与在线：**2014起；U；GEE/ESA云目录。

**建议用途：**洪水空间证据；多时相变化。

**边界：**不是所有地点每天都有影像；上游可用与GEE入库有延迟；GRD处理/显示方式冻结。

**GEE ID：**`COPERNICUS/S1_GRD`

**官方/作者依据与入口：**

- https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S1_GRD

### O08｜Sentinel-2 SR Harmonized

**灾种：**洪水、野火、积雪、旱情、滑坡。

**规模与单位：**持续全球光学场景；按AOI和云/有效像素筛选；计数单位为场景 / 切片。

**覆盖与在线：**GEE L2A 2017起；U；GEE/ESA云目录。

**建议用途：**灾害空间证据；多时相观察。

**边界：**云、阴影、重访与处理延迟限制可见性；不能把无有效影像当无灾害。

**GEE ID：**`COPERNICUS/S2_SR_HARMONIZED`

**官方/作者依据与入口：**

- https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2_SR_HARMONIZED

### O09｜GOES ABI/GLM

**灾种：**强对流、雷电、气旋、降水、野火。

**规模与单位：**多卫星、多波段连续观测；按产品扫描模式计；计数单位为扫描时刻 / 波段 / 闪电事件。

**覆盖与在线：**GOES-R历代业务与档案；R；公开S3，例如noaa-goes19/noaa-goes18。

**建议用途：**新增事件采集；SEVIR类型在线扩充。

**边界：**卫星业务交接后旧桶未必更新；重处理产品与当时业务产品分开；不是每个扫描一场灾害。

**官方/作者依据与入口：**

- https://registry.opendata.aws/noaa-goes/

### O10｜NEXRAD Level II/III

**灾种：**强对流、冰雹、龙卷风、雷暴风、强降水。

**规模与单位：**持续雷达体扫和历史档案；本次未统计总扫描数；计数单位为雷达站—扫描。

**覆盖与在线：**历史与近实时；R；S3 unidata-nexrad-level2等。

**建议用途：**雷达时序；临近预报；与事件/预警对齐。

**边界：**旧noaa-nexrad-level2入口已被替换；Level II与实时chunks不同；反射率不能直接当龙卷风真值。

**官方/作者依据与入口：**

- https://registry.opendata.aws/noaa-nexrad/

### O11｜NASA FIRMS API

**灾种：**野火、火险相关观测。

**规模与单位：**持续MODIS/VIIRS等热异常；按区域和日期计；计数单位为热点探测。

**覆盖与在线：**历史与近实时；R；NASA API，申请MAP_KEY。

**建议用途：**火点变化；在线事件发现。

**边界：**同一火场可出现许多探测；热点不等于独立火灾或最终烧毁面积。

**官方/作者依据与入口：**

- https://firms.modaps.eosdis.nasa.gov/api/

### O12｜USGS Water Data APIs

**灾种：**河流洪水、干旱低流量。

**规模与单位：**全国站点网络；按监测点、变量、时间覆盖清点；计数单位为测站—时刻。

**覆盖与在线：**站点特定历史至当前；R；公开水文API。

**建议用途：**预测核验；水位流量序列。

**边界：**水位/流量不混同；基准面、质量标记、缺测、批准状态与修订版本保留。

**官方/作者依据与入口：**

- https://api.waterdata.usgs.gov/

### O13｜NWPS HEFS

**灾种：**河流洪水。

**规模与单位：**HEFS实施于>3000地点；当前API约10天滚动数据；计数单位为预测地点 / 初始化周期。

**覆盖与在线：**实时与短期滚动；R；实验性API。

**建议用途：**集合预报；预测修订。

**边界：**地点不是同等可用测站；普通NWPS不含完整历史；接口非24/7承诺，不假设多年预报档案。

**官方/作者依据与入口：**

- https://api.water.noaa.gov/about/api

### O14｜NWPS National Water Model

**灾种：**河流洪水、低流量、沿岸总水位。

**规模与单位：**约320万河段；多数配置3天滚动，long_range约1天；计数单位为模型河段 / 预报周期。

**覆盖与在线：**当前与短期滚动；R；实验性API及NODD历史入口。

**建议用途：**大规模河网背景；专业模型指导。

**边界：**320万不是观测站或洪水事件；属于模型guidance，不是官方逐点实测真值。

**官方/作者依据与入口：**

- https://api.water.noaa.gov/about/api

### O15｜GloFAS/EFAS EWDS

**灾种：**河流洪水、低流量、水文干旱。

**规模与单位：**GloFAS 1979起全球每日0.05°场；预报/再预报另列；计数单位为河流格点—日 / 预测周期。

**覆盖与在线：**1979起至近实时；U；EWDS API、GRIB/NetCDF。

**建议用途：**跨国水文；预测基线；历史模拟。

**边界：**historical为LISFLOOD+ERA5驱动模拟，不是全球真实测站；2026-07发布v5，版本固定。

**官方/作者依据与入口：**

- https://ewds.climate.copernicus.eu/datasets/cems-glofas-historical?tab=overview

### O16｜U.S. Drought Monitor

**灾种：**干旱、快速旱情加重。

**规模与单位：**1999起每周；按27年×52估算约1400期量级，非实际清点；计数单位为周地图 / 空间区。

**覆盖与在线：**1999起；U；GIS、表格、Web services。

**建议用途：**慢变量状态更新；文字地图证据。

**边界：**周四发布评估前周二以前情况；不是预测；一张周图不是一场独立干旱。

**官方/作者依据与入口：**

- https://droughtmonitor.unl.edu/About/WhatistheUSDM.aspx
- https://droughtmonitor.unl.edu/Data.aspx

### O17｜MODIS MOD10A1.061

**灾种：**积雪、冰雪背景。

**规模与单位：**2000起日尺度500m瓦片；计数单位为日—空间瓦片。

**覆盖与在线：**2000-02起；GEE核查到2026-09-07；U；NASA/GEE。

**建议用途：**积雪范围变化；融雪洪水背景。

**边界：**积雪覆盖不是暴雪发生、降雪率或冻雨真值；云掩膜不能判无雪。

**GEE ID：**`MODIS/061/MOD10A1`

**官方/作者依据与入口：**

- https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MOD10A1

### O18｜MERRA-2 M2T1NXAER

**灾种：**沙尘、烟霾相关大气条件。

**规模与单位：**1980起小时气溶胶场；每非闰年理论8760时刻；计数单位为全球时间层。

**覆盖与在线：**1980起；GEE核查到2026-08-01；U；NASA/GEE。

**建议用途：**沙尘历史；大气背景。

**边界：**气溶胶再分析不是实时沙尘实测，也不能将全部AOD高值归为沙尘。

**GEE ID：**`NASA/GSFC/MERRA/aer/2`

**官方/作者依据与入口：**

- https://developers.google.com/earth-engine/datasets/catalog/NASA_GSFC_MERRA_aer_2

### O19｜CAMS atmospheric composition forecasts

**灾种：**沙尘、野火烟羽、相关空气质量。

**规模与单位：**每天2次、每次5天；非闰年理论730初始化周期；计数单位为预测周期 / 时效。

**覆盖与在线：**2015-07起业务产品；R；ADS/ECMWF API。

**建议用途：**沙尘和烟羽预测修订。

**边界：**aerosol类型、垂直层和变量固定；空气污染与极端天气分类需分开。

**官方/作者依据与入口：**

- https://www.ecmwf.int/en/forecasts/datasets/cams-global-atmospheric-composition-forecasts
- https://atmosphere.copernicus.eu/global-products

### O20｜NOAA OISST v2.1

**灾种：**海洋热浪、海温异常。

**规模与单位：**1981-09起全球每日0.25°海温场；每年365/366时间层；计数单位为全球海温时间层。

**覆盖与在线：**1981起；GEE核查到2026-09-07；U；NOAA/GEE。

**建议用途：**海洋热浪派生；气旋环境背景。

**边界：**插值分析非单点实测；初版约1天、终版约14天延迟并替换；需事先定义热浪阈值和持续时长。

**GEE ID：**`NOAA/CDR/OISST/V2_1`

**官方/作者依据与入口：**

- https://developers.google.com/earth-engine/datasets/catalog/NOAA_CDR_OISST_V2_1

### O21｜NOAA CO-OPS

**灾种：**风暴潮、沿海洪水、异常高水位。

**规模与单位：**站点水位/潮汐/气象时间序列；站点有效覆盖另查；计数单位为潮位站—时刻。

**覆盖与在线：**各站历史与当前；R；CO-OPS API。

**建议用途：**沿海水位预测核验；潮汐与风暴信号。

**边界：**水位datum、时区、预报潮和观测潮分开；高水位不全由气旋导致。

**官方/作者依据与入口：**

- https://api.tidesandcurrents.noaa.gov/api/prod/

### O22｜NASA LHASA/GLC

**灾种：**降雨触发滑坡。

**规模与单位：**GLC自2007编集；LHASA风险/暴露地图逐日产品；计数单位为事件记录 / 风险栅格。

**覆盖与在线：**事件目录与模型业务产品；U；NASA风险图/下载与目录。

**建议用途：**降雨滑坡扩展；预测与事件确认分离。

**边界：**LHASA是风险/nowcast；16年平均曝光档案不是每日在线流；不可把风险值当已发生滑坡标签。

**官方/作者依据与入口：**

- https://earth.gsfc.nasa.gov/hydro/data/landslide-hazard-assessment
- https://svs.gsfc.nasa.gov/5584/

### O23｜CMA 热带气旋最佳路径

**灾种：**西北太平洋台风。

**规模与单位：**1949起；通常6小时，部分登陆阶段3小时；计数单位为台风 / 轨迹时刻。

**覆盖与在线：**1949起；按年更新；U；按年文本文件。

**建议用途：**亚洲台风事件；结果核验。

**边界：**与IBTrACS有共享上游；年度最佳路径不是实时业务预报。

**官方/作者依据与入口：**

- https://tcdata.typhoon.org.cn/zjljsjj.html

### O24｜风云卫星数据服务

**灾种：**台风、强对流、降雨、沙尘、火灾相关、冰雪。

**规模与单位：**FY-2/3/4等多星多产品；按仪器/AOI/时间查询；计数单位为扫描 / 产品 / 场景。

**覆盖与在线：**历史与业务更新；R；国家卫星气象中心；注册实名审核及数据访问规则。

**建议用途：**亚洲区域高频影像；多源补充。

**边界：**门户可见不等于全部产品免审核无限下载；扫描频率按实际仪器/模式确认。

**官方/作者依据与入口：**

- https://satellite.nsmc.org.cn/

### O25｜香港天文台开放数据

**灾种：**暴雨、台风、雷暴、高温、寒冷、火险、潮汐。

**规模与单位：**官方2025-09介绍48组开放数据；非48种灾害；计数单位为数据产品 / 公告 / 站点记录。

**覆盖与在线：**当前预警、预报、观测与部分历史；R；免费JSON/XML/CSV，繁简英。

**建议用途：**中文在线公告；多灾种发布变更。

**边界：**warnings接口是当前状态，历史版本需合法采集；HKO-7不等于此开放API。

**官方/作者依据与入口：**

- https://www.weather.gov.hk/en/education/weather/data-and-technology/00740-Open-Data-of-Hong-Kong-Observatory.html
- https://data.gov.hk/en-data/dataset/hk-hko-rss-weather-warning-information

### O26｜中国气象数据网 地面小时/CLDAS-V2.0

**灾种：**热浪、寒潮、降水、风、旱情。

**规模与单位：**官方目录列有地面小时与CLDAS实时产品；本次未核验账号可获数量；计数单位为站点 / 分析网格。

**覆盖与在线：**产品各自声明范围；U；官方服务，注册与产品权限逐项核查。

**建议用途：**中国区域观测分析；跨区扩展。

**边界：**不承诺所有资料公开无门槛或实时API；CLDAS为融合分析，非独立观测真值。

**官方/作者依据与入口：**

- https://k.data.cma.cn/

### O27｜WeatherBench2 数据归档

**灾种：**多类天气、阈值派生极端。

**规模与单位：**示例ERA5归档93544个6小时时刻，62变量/13层（特定文件）；计数单位为全球时间点 / 变量。

**覆盖与在线：**示例1959-01-01至2023-01-10T18:00；A；GCS Zarr远程读取。

**建议用途：**标准天气场；基线与数据组织。

**边界：**静态研究归档不等于实时预测服务；不能将结束日期写成覆盖整个2023年。

**官方/作者依据与入口：**

- https://weatherbench2.readthedocs.io/en/latest/data-guide.html

### O28｜NOAA NDBC 浮标与海浪

**灾种：**大浪、海上强风、沿海风暴。

**规模与单位：**各站多年历史；实时滚动窗口通常45天；本次未清点活跃站数；计数单位为浮标/站点时序。

**覆盖与在线：**逐站历史与实时；R；HTTP文本、gzip历史、OPeNDAP/netCDF。

**建议用途：**海浪和海风核验；极端海况阈值任务。

**边界：**实时值未完成最终归档质量处理；非NDBC站的实时窗口可能仅至少24小时；不是全部浮标都测所有变量。

**官方/作者依据与入口：**

- https://www.ndbc.noaa.gov/faq/realtime.shtml
- https://www.ndbc.noaa.gov/historical_data.shtml
- https://dods.ndbc.noaa.gov/

## 接入策略

第一批优先接入能一次覆盖多个灾种的Storm Events、EM-DAT/GDIS、NWS/IEM、GHCNd/GHCNh、GFS/ERA5-Land、IMERG/CHIRPS。第二批用SEVIR、TC PRIMED、GEOID-Flood/WorldFloods、TS-SatFire等补充已整理的多模态时序。第三批增加GOES/NEXRAD/FIRMS/USGS/NWPS/HKO/CAMS等持续采集，为前瞻轨提供版本证据。各批不是只允许少数灾种入库，而是减少重复开发。

## 保存字段

建议至少登记 `source_id, provider, hazard_tags, event_id, parent_event_group, modality, semantic_role, observed_at, issued_at, valid_from, valid_to, available_lower, available_upper, retrieved_at, delivered_at, version_id, parent_version_ids, source_lineage, quality_flags, content_hash, license, artifact_url, render_transform_id`。历史可用时间无证据时为空或区间，不能用观测时刻/今天下载时刻替代。

## 在线服务的特别提醒

NWS alerts只留最近7天；HEFS接口当前约10天；NWM多数模式约3天。NEXRAD的旧桶已被新的Unidata桶替换。GHCNh应替代已停止更新的ISD。IMERG、OISST等产品的后续版本可能替换临时估计，因此必须保存不可覆盖的快照，不能让不同模型在不同日期直接各取latest比较。

## 条款与执行边界

本清单没有触发大规模下载、模型运行或付费作业。数据条款独立于代码许可证；转载图文还受原发布者条件约束。GEE、云计算、存储、网络导出和API使用的权限与成本应在执行前核查。HF/S3/HTTP入口存在不保证所有自动加载器可直接流式读；先用少量合法样本进行范围请求、解码与质量检查。
