# DisasterTrace｜Codex 首轮启动任务：统一内核与多灾种扩容骨架

配套：`DisasterTrace_Master_Plan_CN.md`、`backlog.json`、`source_plan.json`、`configs/`。
**当前只执行离线实施范围。扩大设计范围不代表批准联网下载、持续服务、模型/GPU调用、训练、测试答案访问或GitHub推送。**

## 1. 本轮目标

在已有仓库上交付“可扩容、不会混淆时间/来源/真值的v2骨架”，同时纳入15家族34操作子类、59条候选来源。NHC是第一条兼容性样例，不是新任务的唯一允许灾种；其他来源先以元数据与mock进入。

不重新做一遍Text Core，不把所有来源一律标成可实时预测，不把保存过一个状态等同于已证明状态使用。原始规模文字照实继承；无实测inventory时，实际计数用null或未统计，而不是填发布数据总量。

## 2. 先读与先查

1. 读取本地适用的AGENTS/README与当前结果入口，确认当前工作树、HEAD、已有v2/mm_trace/revision_task/active_warning修改、原运行路径和protected清单。
2. 将历史审查锚点`36082c42a93e11f67d274d8000c87cd1dc098d74`作为比较基线，而不是自动回滚目标。若当前本地更新，以差异报告说明，不reset、clean、覆盖未提交工作或擅自切分支。
3. 将“源码原型存在”“已接入主轨”“真实模型验收”分开。通用Artifact/图像/四臂与原文累计输入任务不混为一个配置。
4. 已有结果保持原样；文件名日期、报告内部时间、远端HEAD与本地作业状态分别登记。不要重新启动已过期的自主窗口。
5. 开始测试前确认测试范围不会触发网络、读取凭据、加载模型、修改旧run、访问heldout。可能有副作用的测试先标记未执行并说明原因。

## 3. 本轮允许的实现范围

对应backlog：P00、P01、P02、P03、P04；P05的离线存储/故障fixture可做。P06只做数据接入计划与mock，不执行真实预检。后续任务不自动串行执行。

### 3.1 分类和源配置

将taxonomy及59条source-plan加载成类型化对象，保留原source_id及原hazard labels。操作子类可能重叠，不伪装官方互斥taxonomy。新增source_status、licence_status、probe_status、candidate_tracks、eligible_tracks、availability_basis与count_unit。

加入检查：59条ID唯一；所有source refs能解析；原metadata/hash不被重写；eligible_tracks为空直到真实样本验收；每个家族有候选source但不能因此显示“已有任务覆盖”。

### 3.2 唯一共享内核

优先复用本地已有v2位置；不存在时可新建`src/disastertrace/active_warning/`。先做必要模块，不建立几十个空文件。旧`forecast_task`及冻结评分不变。

定义最小对象：SourceRecord、TargetSpec、EvidenceRevision、AssetLocator、DeliveryEvent、ReadEvent、StateCommit、EpisodeManifest；PredictionCommit/OutcomeRecord只需明确独立类型和隔离接口，不提前实现全部预测策略。

三个private/public边界必须可测试：公开证据、模型自己的状态、评测侧参考/未来结果。公开schema约束格式，不能锁入该题正确值、正确来源或正确区域。

### 3.3 时间、重复交付和支持刷新

历史可用性未知不得填issued_at/retrieved_at。严格准入用可信区间上界；受控交付另写schedule_origin。

以有序DeliveryEvent表示重放：同一个revision可再次交付而不生成假新原始信息。合法可得、目录可见、已交付、实际已读和保留的集合分开。

状态更新分value_operation与support_operation。新版本同值允许KEEP value＋REPLACE support。locator按revision+asset+位置+transform成组校验，不允许跨图同名region串用。

### 3.4 原始捕获与故障隔离

复用成熟raw-first设计，不使用“整段最后才落盘”的原型跑新轨。每步先保存实际序列化请求，再记录dispatch，先存raw再解析。失败/未知返回保留；一个轨迹超长不得牵连其他可运行轨迹。

本轮用可注入Scripted/mock模拟，不调用任何真实模型。不要给通用adapter悄悄增加基于语义的重试；未确认提交结果不当成未提交重发。

### 3.5 三种源mock和旧样例投影

- 事件/站点表：包含同一灾害多行、日期/单位/质量标记、未知字段与部分覆盖。
- 预警JSON/GeoJSON：包含初次、更新、取消、相同URL内容变化、延迟和分页fixture。
- 图像/栅格序列：小型人工fixture，显式generated_fixture；有尺寸、CRS/渲染、nodata、两个相同region名字的不同图。

同时用已有允许开发NHC资料验证兼容投影；不能读取受保护事件答案，也不能用合成fixture冒充新真实多模态数据。

### 3.6 采集准备但不启动

输出NHC第一条图文/结果匹配清单、Storm Events/GHCN等跨类别预检清单及NWS/HEFS短保留接口保存方案。任务清单须含地区/时期/变量、允许请求数/字节、许可状态、期望格式、失败终态和停机条件；未确认的预算留null并使执行器拒绝运行。

SourceAdapter建议接口：discover、plan_fetch、fetch、normalize、audit_coverage、freeze。当前fetch仅Mock；不读取用户GEE/云端key，不在代码里放token，不设置cron/定时任务。

## 4. 本轮测试与验收

至少实现：可用时间边界；重复交付；旧版重放vs隐藏新版；值保持支持刷新；locator串图拒绝；unknown不等零；未来结果/私有掩膜隔离；binary不read_text；原始响应先于解析；未知提交不重发；单轨故障隔离；sourceID映射/计数；同源重复不增加独立事件；分页不完整不判空库。

每个测试写：命令、环境、fixture来源、预期、实际、passed/failed/not_run、产物路径。用脚本正确/错误控制检查评分边界，但只标程序测试。测试数量不是科学效度证明。

## 5. 必须交付的文件

- `baseline_snapshot.md`：本地/历史锚点/报告范围，实际改动与不改动范围。
- `implementation_delta.md`：复用、已实现、缺失、需后续验证。
- `schema_v2.md`：对象、时间、可见性、locator、状态语义及兼容路径。
- `source_registry_v2.json`与`hazard_taxonomy.yaml`：原59条来源/15家族/34子类完整保留。
- `source_probe_plan.json`：跨家族有限预检＋短保留源采集计划；全部execution_enabled=false。
- `test_report.md`：真实执行的离线测试和未执行项，不借用旧测试数量。
- `next_actions.md`：下一次进入真实数据阶段的具体范围、依赖与预算，不能笼统写“继续加数据”。

## 6. 本轮退出条件

工作树中只存在说明过的增量；旧文本/运行/heldout没有改写；59来源状态未冒充接入；核心不变量有可审查离线测试；跨灾种接口可扩展；下一阶段联网/模型权限仍关闭。

本轮不执行外部下载、部署常驻采集、付费/GPU推理、训练、正式heldout、GitHub push或Notion修改。达到离线交付后停在本轮边界，报告实际完成、失败和未做项。阻塞不通过伪造样本、放宽旧分数或自动加调用预算处理。
