# DisasterTrace：多灾种、多模态、在线证据更新评测总计划

**版本：master-plan-v1 / 2026-09-10。性质：待执行研究与工程方案。**

**最终方向：构建广覆盖的极端天气及关联灾害证据体系，评测模型能否区分灾情演化、同目标估计修订和证据可见性变化，正确获取所缺资料，并仅修订受到影响的结论。**

本计划整合而非替换已经验收的研究资产。它承接《DisasterTrace 广覆盖数据源目录》的52项候选来源、《数据契约、在线能力与论文升级审查》的源码问题，以及既有下一阶段实施计划。较早计划中的 NHC＋OPERA 小型样例，调整为工程通路验证，不再限定最终数据覆盖。

实际核对到的远程分支仍为 `next-phase-v1@36082c42a93e11f67d274d8000c87cd1dc098d74`；默认 `main` 为 `a23f73adadcbec077b9fcf2aecf8f45dfa4fe061`。执行前重新检查实际 HEAD、未提交修改与 AGENTS.md；参考提交不是回退指令。阶段文档保存的是2026-09-08运行快照，不是实时调度平台状态。旧自主运行授权窗口已经过去。

## 0. 先执行什么，最终交付什么

### 0.1 总体策略：广覆盖与科学验证并行

不采用“先只做两个灾种，全部做完后才考虑其他来源”的串行路线，也不采用“把52项数据全部下载后再想题目”的路线。

**同时推进四条工作线：**

| 工作线 | 第一周起的职责 | 最终交付 |
|---|---|---|
| A．代码与数据契约 | 接通已有通用接口与可靠采集；修正交付、来源绑定和状态语义 | 可复用的多源任务编译、回放、工具与评分框架 |
| B．广覆盖数据 | 登记全部52项来源；分批取得目录和已批准的样例 | 候选索引、去重事件集、多模态证据快照、辅助数据集 |
| C．任务与实验 | 先证明一个真实样例可解，再在更多家族中验证相同能力 | 动态修订主任务、感知诊断、主动补证实验与分组结果 |
| D．在线归档与论文 | 先完成有限快照；获准后尽早开始前瞻采集；同步写协议 | 版本冻结批次、事前提交记录、数据卡与论文 |

一个人可以轮流承担四条线；它们是工作分解，不是已经有四个团队。多 Codex 会话并行时必须分支/工作区隔离，不能同时改动同一冻结运行源码。

### 0.2 最终产品与规模目标

以下全部是**建议建设目标**，不是已取得数据或保证数目。

| 资产 | 目标 | 计数规则 |
|---|---|---|
| 候选来源注册表 | 52项全部登记与分层，后续可追加 | 数据集、产品族与目录，不称52个独立数据集已经集成 |
| 事件候选索引 | 尽可能覆盖10个家族、25–30个细类，争取万级候选记录 | 原始目录行与去重事件分开 |
| 动态主集 v1 | 目标约3,000个去重事件或规则定义的天气过程 | 原生事件、规则提取过程、独立来源组分别计数 |
| 动态任务规模 | 以每事件平均3个目标 episode、每 episode平均6检查点估算，约54,000基础检查点 | 实际允许变长；不通过分支、模型和重复增加“事件数” |
| 感知/静态辅助层 | 目标100,000–500,000条去重、允许使用的图文/图像样本 | 不冒充相同数量的动态事件；实际规模取决于许可和筛选 |
| 深度主动监测子集 | 从主集挑选约100–300个具备足够证据选项的任务情境 | 嵌套子集，不能再加到3,000事件上 |
| 前瞻归档批次 | 初期观察30–60天，事件数按实际自然发生与准入报告 | 不保证期间出现特定数量或全部灾种 |

**目标宽，准入严格；样例小，只是门槛。**达不到某个数字时，报告原因和实际数量，不降低时间、支持或许可标准凑样本。

### 0.3 第一轮交给 Codex 的范围

本次用户请求是制定计划，不构成新的执行授权。未来把本文件交给 Codex 后，默认第一轮只做：本地源码审查、52项本地目录转换、类型契约、针对旧探针的新回归测试、synthetic软件闭环、下载 dry-run、已有合法开发数据的真实闭环。

额外网络获取、权重下载、模型生成、GPU、付费API、后台轮询、heldout执行和发布，均通过新的独立范围与预算许可。不能从旧 CURRENT_PHASE.md 继承授权。不能把合成fixture或程序代理答题称作新增真实模型结果。

---

## 1. 研究主线与必须保留的边界

### 1.1 一个核心问题，三个逐步递进的研究目标

**中心问题：当多源证据持续变化时，模型是否能在当时信息条件下形成合理判断，并正确管理后续修订？**

- **内容与依据：**读对对象、变量、有效时间、数值或类别，给出适用的支持。
- **变化与保持：**区分新物理时刻、同目标估计更新、覆盖/到达变化；应改的改，不应改的保留，不能确定的继续未知。
- **主动补证：**在给定时间和成本内选择下一项证据，提高正确覆盖，避免重复查询已知信息。

内容、当前来源与连续可靠性来自原研究骨架；跨模态覆盖、主动补证和大规模多灾种属于本方案扩展，不写成已有实证。[S1,S2]

### 1.2 四个研究问题

| RQ | 必须回答什么 | 所需证据 |
|---|---|---|
| RQ1 | 高单次内容分数是否代表可靠的跨版本/跨模态更新？ | 内容、来源、局部修订、轨迹分层，同分母比较 |
| RQ2 | 模型能否区分灾情演化与证据变化，并保护无关结论？ | 同资料到达干预、有效期错配、覆盖变化与稳定目标对照 |
| RQ3 | 显式状态和主动取证是否改善预算下的持续判断？ | 同权限强基线、F/S轨、成本曲线和状态使用诊断 |
| RQ4 | 这种能力能否跨事件、地区、来源和灾种迁移？ | 关联组划分、冻结策略、未用于开发的家族/事件与前瞻批次 |

不能根据两张时间不一致、质量不一致的图，强迫模型回答唯一的物理变化成因；“现有证据无法区分”应是允许结果。

### 1.3 不应成为本期主张

不宣称“首个多模态极端天气benchmark”；不把所有近邻描述为静态QA；不把读取官方预报当成独立预测；不把阈值研究标记当成真实关港/撤离最优行动；不把自动程序一致当成无标签噪声；不把代码已有接口当成完成实测。

EarthVerse已经包含多源灾害调查、可执行参考和过程评价。新方案应通过逐检查点知识边界、局部修订义务、补证成本与跨灾种实验争取差异，而不是只增加灾种名字。[W8]

---

## 2. 数据与评测分层：大规模不要求每条资料都伪装成在线时间线

### 2.1 三层数据资产

**L0 / Candidate Index：**保留允许取得的元数据和来源链接；时空不明、许可待确认、标签仅事后可得的资料仍可登记，但不能默认进入模型输入。

**L1 / Dynamic Core：**有真实观测序列、明确已发布资料或合法受控交付安排，能确定检查点的可支持答案；这是动态论文主分母。

**L2 / Auxiliary：**已有感知/静态标签但缺少可靠时间链的图文、建筑损伤、无人机和社交图片，作为感知控制或允许的独立训练/适配数据。不存在序列就不任意排列成“灾害演化”。

一个上游数据集可以贡献多个层次的不同样本。层次分配应是样本级属性，而不是预先认定整库全部合格。

### 2.2 四种时间配置，不混成一个榜单

| 配置 | 资料条件 | 可以声称什么 |
|---|---|---|
| R0 静态/感知 | 单次或灾前灾后，时间链不足 | 单次理解或有限变化对照 |
| R1 观测顺序回放 | 有观测时刻，历史真实发布可用性不足 | 明确声明的观测序列任务；不等于历史实时环境 |
| R2 发行/版本回放 | 有产品版本与发布时间，交付由研究协议安排 | 已发布陈述及受控信息到达；未知available_at保持未知 |
| R3 前瞻端点记录 | 自己记录到的版本、first_seen、完整响应与交付 | 指定采集端点/频率下的可见性评估，不声称全网首次公开时间 |

同一条原始资料可以派生受控延迟分支，但这只增加实验条件，不增加真实事件。R1/R2都可进入动态主集；严格online主张仅限有相应证据的R3子集。

### 2.3 不因追求多模态而歧视有效的单模态任务

逐样本标记 `text_required / visual_required / cross_modal_required / multimodal_redundant`。文字问题加一张图只表明有视觉输入，不天然是“图文缺一不可”。

原生数据量、感知样本量、真正跨模态检查点、真实版本修订次数、主动任务次数各自报告。不能用总图片数证明跨模态推理覆盖。

---

## 3. 覆盖目标与数量口径

### 3.1 延续已提出的3,000事件规划，不静默改配额

| 主家族 | 目标 | 主要候选来源ID |
|---|---:|---|
| 气旋/大风 | 400 | D08,D09,D10,D11,D12,D52 |
| 强对流 | 700 | D03,D13,D14,D15,D43 |
| 极端降雨/洪水 | 500 | D06,D13,D16–D21,D50,D51 |
| 热浪/寒潮 | 400 | D01,D03,D04,D26–D28,D52 |
| 干旱 | 200 | D01,D29–D32,D38 |
| 野火/烟相关事件 | 400 | D06,D22–D25,D35,D50 |
| 冰雪 | 200 | D03,D26–D28,D33,D34 |
| 沙尘/大雾 | 100 | D03,D27,D35 |
| 沿海/海洋极端 | 100 | D03,D12,D36,D37；极端波浪仍需补专用数据 |
| 合计 | 3,000 | 均为期望值，不是已取得量 |

原目录的第10家族“天气相关滑坡/泥石流/雪崩”保留在扩展准入队列D39–D41，不纳入上表九家族配额中悄悄再加事件。通过真实数据门槛后，在新release明确增加独立配额或调整表格。长尾类别支持不足时公开显示缺口。[S3]

这些配额是覆盖设计，不反映自然界发生频率。可以同时报告家族平衡表与实际准入池分布，不能将有意过采样的困难事件描述为自然部署分布。

### 3.2 三种事件身份

- `native_catalog_event`：上游明确登记的事件，仍需跨国家/县区/数据库去重。
- `derived_extreme_episode`：按事先公开的阈值、基准期、持续时间和连通规则从连续场识别的天气过程。
- `context_or_control`：普通天气、非极端波动或视觉背景。控制样本单列，不能充数到极端事件总量。

多危险标签可属于同一父事件。一次台风及其引发的洪水/风暴潮不能无条件计为三个互不相关的独立灾害。

### 3.3 每个来源至少记录七个计数

`published_count`（带单位与版本）、`discovered_count`、`downloaded_count`、`admitted_count`、`unique_event_count`、`independent_source_groups`、`base_checkpoint_count`。

实际尚未清点使用null及明确状态，不填0冒充已经查明为空。局地序列、图片、像元、模型回答和来源组分别计数。52项注册条目也不代表52个已经完成适配的数据集。

---

## 4. 数据接入波次：广覆盖从第一周开始

每项来源均保留原D01–D52编号。附件 `source_registry.plan.json` 包含52项原始目录记录与新增的实施映射；原公布规模和限制不被覆盖。

### W0．目录与身份：优先把“有什么”搞清楚

**来源：D01–D07、D10–D11。**

先做NOAA Storm Events、IBTrACS、已有NHC开发身份、EONET、CEMS；EM-DAT/GDIS和需要许可的入口并行处理；EWB/ExEBench当作研究资源索引与事件种子，不把其全部任务自动当新来源。

**交付：**来源表、变量/家族映射、事件链接候选、许可状态、原生split与禁止访问列表。先拿轻量目录，不下载所有TB影像。

### W1．高产出的动态来源：快速建立多模态主集

**来源：D08,D09,D12,D13,D16–D21,D50。**

| 子线 | 先复用什么 | 第一批适合的任务 | 暂不能声称什么 |
|---|---|---|---|
| 气旋 | NHC桥梁、Digital Typhoon V2、TCIR、IBTrACS身份 | 同目标预报修订、图像时间过程、强度/空间信息读取 | best-track标签与裁剪中心全部当时已知 |
| 对流 | SEVIR目录、时空对齐通道和局地报告映射 | 雷达/卫星/闪电的时间、覆盖和局地条件 | 每个SEVIR片段都是独立极端灾难 |
| 洪水 | Global Flood DB、WorldFloods、SEN12、OPERA | 产品范围、质量掩码、缺证恢复和时空兼容 | 地表水分类就是无误洪水真值 |

**优先读取既有reader与数据说明。**SEVIR官方入口是公开S3；Digital Typhoon已有作者数据组织和pyphoon2入口；OPERA有官方发现和展示教程。[W1–W3]

第一条NHC/OPERA真实闭环只用于检查新框架；SEVIR、Digital Typhoon等规模来源同时登记和适配，不等小闭环全部模型实验结束才启动它们。

### W2．补齐火、温度、干旱、冰雪和连续产品

**来源：D14,D22–D34,D38,D51,D52。**

火灾先从FPA FOD/MTBS确定候选及范围，Global Fire Atlas补全球历史过程，FIRMS负责前瞻火点。热冷用GHCN/ISD和已有目录，ERA5作回顾性参照；干旱用CHIRPS/TerraClimate/SPEI/USDM/SMAP；冰雪用SNODAS/MOD10A1。MeteoNet补非美国多源天气，GFS提供明确初始化与lead的预报版本。

公开连续场并非已经定义好的极端事件，需在本波实现可冻结的event builder；不能给每个格点日/站点日一个独立灾害ID。

### W3．地区与长尾，外加独立的静态辅助层

**来源：D15,D35–D37,D39–D49。**

HKO-7按机构协议推进；MERRA-2/OISST/GESLA补能见度和沿海海洋；COOLR/高山亚洲目录筛天气触发案例；Landslide4Sense、CLLMate、WeatherQA、CrisisMMD、MEDIC、Incidents1M、xBD、FloodNet、RescueNet分别进入允许的辅助任务。

社交/灾后图像先审查时空身份、个人信息、许可和原生split。没有时间链不人为排列；没有标签权限不绕过下载；含NC/ND的来源保留许可阻塞，不作通用法律许可推断。

### 4.1 52项来源全部登记，不等于全部作为关键依赖

核心发布不能被HKO-7、某一DataPort入口或单个账号审批卡住。阻塞来源在同一清单中保留 `blocked_access/blocked_license/blocked_alignment`，用已声明的候选替代，而不是临时找一个模型做得更差的数据源替换。

### 4.2 每个新adapter必须完成同样的纵向验收

**目录解析 → 白名单样例 → 版本/质量/时间字段 → 公开表示 → 私有参考 → 一个episode → 程序代理回放 → 评分与独立检查。**

合成fixture用于单元测试。真实样例失败时，报告真实失败，不用synthetic数量顶替真实准入数量。

---

## 5. 从资料池到可信事件集

### 5.1 来源准入

逐项冻结：原URL/DOI/目录版本、下载方式和授权、文件清单与SHA-256、观测/发行/处理时间、产品范围、变量与单位、质量flag、数据依赖、标签来源、解析器/渲染器版本、原生划分。

归档文件安全解压，拒绝路径越界、异常内容类型和解压炸弹。签名URL与密钥单独保存，不进入公开输入/发布包。大体量下载、对共享存储的写入均有明确上限、断点恢复和失败回执。

### 5.2 极端性准入与控制样本

`extreme_basis`至少区分：官方事件类别/严重度、事先指定的物理阈值、固定气候基准分位数、研究者规则识别、尚未确定。

对于热浪、干旱、暴雨等rule-derived事件，event builder配置必须包含：变量、时区/日界、基准期、阈值算法、最低有效观测比例、持续时间、最小空间范围、相邻事件合并规则，以及缺失资料政策。

这些阈值由产品说明和研究设计决定，本文不替所有地区指定唯一热浪或快速干旱定义。先在开发/校准数据上冻结，不用测试期间的数据拟合基准或为了制造失败反复改阈值。

普通天气可作为负对照；未报道不能作无事件标签；小火、农烧与算法火场对象不自动等于极端野火。水体与洪水、积雪覆盖与暴雪、AOD与能见度、极端海平面与风暴潮分别定义。

### 5.3 跨库去重：两张图而不是一个简单并查集

**事件身份图：**officialID、跨机构映射、时空区间、父风暴与子影响、重复国家/县区记录。已知对应关系优先，模糊匹配保留可信度；不确定联系可保守隔离，不强行合并。

**信息泄漏关系图：**同一实际目标标签、同一源影像的重叠裁剪/改写/渲染、同一事件的干预、同一影响调查。用于split分组。

不能因为两个样本都引用“ERA5”或同一大范围全球文件就把全世界并为一个组。共享背景数据、同一publisher、同一collection是弱上下文关系；实际参与答案的重叠时空数据、共同事件和标签依赖才是强隔离关系。必要时用spatiotemporal source block作为分组单位，并对巨型连通分量作人工规则级审查。

保留原始图文感知数据中的上游test限制：任何辅助训练、few-shot、校准都不得与新动态测试事件或相同内容相撞。

### 5.4 区域与生命周期平衡

分层统计家族、洲/海盆、年份、数据供应者、语言、强度、生命周期、观测覆盖和产品质量。避免全是美国、早期气旋或有清晰可见变化的样本。地域缺口和罕见类别不足公开报告，不能以低质量资料填满表格。

总样本表同时显示自然变化分布和人为平衡的stress子集。技术可解性/许可等准入条件事先确定，不看被测模型得分挑选正式案例。

---

## 6. 任务生成：用共同能力组织不同灾种

### 6.1 任务类型

| 类型 | 问题 | 可适配来源 |
|---|---|---|
| T1 目标/当前支持 | 哪个产品的哪个时刻、地点和变量支持当前答案？ | 所有时间清楚的来源，NHC/GFS尤适合 |
| T2 局部空间/时间条件 | 哪些地点、时间窗口满足一个公开条件？依据是什么？ | 雷达、概率图、地表水、温度/干旱图 |
| T3 选择性修订 | 新资料使哪些值/来源应改，哪些必须保持？ | 原生序列、版本链与声明的受控交付 |
| T4 缺证/冲突管理 | 无观测、未到达、过期、跨产品不兼容如何区分？ | 多传感器、质量层、站点、异步公告 |
| T5 变化性质判断 | 是新时刻的变化、同目标估计修订还是新增可见性？ | 有足够元数据且语义可判定的子集 |
| T6 预算主动补证 | 下一个值得查询的区域/产品是什么，何时提交或等待？ | 有真实候选证据选项的嵌套子集 |

T5若自然资料不足以确定唯一答案，允许“无法区分并列出缺失前提”；不强制真实世界变化成因三分类。确定性的标签可首先在固定同一原始资料、只变交付的控制样本中建立。

### 6.2 从连续传感器序列构造检查点

不要按固定帧数随意切为“新事件”。先识别父事件及时间范围，再固定目标/任务，按真实资料时间构建；R1轨可使用声明的观测顺序，不能装成历史as-of。

雷达/红外/微波/概率/指数等通道保存原始数值与单位，按固定物理范围渲染。逐帧自动min-max容易把数值不变变成视觉变化，或者把真实幅值变化抹掉，应禁止作为主轨默认做法。渲染要固定色阶、NoData显示、投影、坐标、图像尺寸与图例。

### 6.3 多模态必要性与信息泄漏

先定义合法的模态信息分工，再用反事实见证验证：保留文字而改变兼容图像会改变答案；保留图像而改变兼容文字条件会改变答案。补充text-only/vision-only实验，但低分不能单独证明信息不足。

不能用私有Gold生成准确caption、正确区域裁剪、答案化文件名、动态正确候选列表，再让模型“推理”。需要合成语言时，模板仅来自公开规则和合法元数据；涉及生成模型的任务写作单独审批，不拿生成文本当自然观测。

**新增检查：Digital Typhoon的作者流程用best-track位置进行气旋中心裁剪。[W2]**它能很好地用于回顾感知/演化任务，但不能自动用来证明模型在无先验情况下在线发现/定位气旋。需要此类主张时，改用基于当时可见信息确定的AOI，或明确将真实中心作为oracle输入。

### 6.4 样例：地表水范围与未知的逻辑边界

假设任务区域面积为A，产品在其中有效观测面积为V，已识别水体面积为W。在只讨论该产品类别、且无额外未知区域假设的情况下，整个区域水体比例的逻辑范围为：

`[W/A, (W + A - V)/A]`。

这不是实际洪水面积的统计置信区间，也不修正分类误差。它只防止把无数据面积从分母悄悄去掉。图片不提供精确面积时，可输出规定区间/格网关系而非隐藏小数。

迟到资料只改变可见范围时，更新知识边界；更晚采集的资料对应另一个物理时刻，不能反填成旧目标的确定事实。OPERA不同传感器未同化，不直接将跨传感器差异判成水体扩张。[W3]

---

## 7. 代码升级：以既有资产为基础，不重写全部工程

### 7.1 保留、复用、修正

| 现有位置 | 本计划处置 |
|---|---|
| `forecast_task/{contract,compiler,protocol,scoring}.py` | 保持冻结任务与旧成绩，新增兼容adapter，只映射可证明字段 |
| `models.py` / `policies.py` | 复用Artifact/状态/新增与累计访问思想，新契约版本化 |
| `adapters.py` | 复用实际图像输入，不继承解析先于原始落盘和不透明重试行为 |
| `runner.py` / `interventions.py` | 新路径采用有序DeliveryEvent和分支隔离，重放不使用set丢次数 |
| 已有实测/存储/独立审核 | 优先接入新图文路径，不退回整轨结束才写日志 |
| `forecast_source/pipeline.py` | 借鉴有界获取、headers/hash/receipt；不改写旧固定选择集变成无限轮询 |

旧通用snapshot和原生snapshot不等义；运行身份绑定 `task_version + access_contract + method_version + model_revision + branch + repeat`。[S1]

### 7.2 第一批强制回归测试

1. A/B都可获取，实际只释放A，请求不得出现B。
2. 新版B仍在时，再次交付旧A，顺序和次数可复算。
3. 值保持、来源刷新不互相误罚；先前错误被修正不算collateral edit。
4. 来源—资产—区域三元组绑定，区域挂错图片不能通过；状态保留完整定位。
5. 未知available_at可显式表达；valid区间逆序拒绝。
6. 二进制GIS交给类型化loader/render，不能read_text乱码入模。
7. 原始输出在解析之前逐步落盘；坏JSON、超时和uncertain send不消失。
8. 单轨overflow不停止无关轨迹；分支/方法/重复不覆盖彼此路径。

这是将上一轮固定提交探针转为新契约测试，并非要求改旧探针或追溯否定旧P7成绩。[S1]

### 7.3 统一数据对象

在六个评测核心对象外，补两个全局目录对象：

- `SourceSpec`：来源ID、版本、许可、provider、标签性质、访问权限与公布规模。
- `EventRecord`：原生/规则事件身份、hazard标签、时空范围、父事件与group split。
- `ArtifactRevision`：逻辑产品、字节/语义修订ID、媒体资产、观测/发行/处理时间、上游依赖。
- `AvailabilityObservation`：端点、完整响应、first_seen与可证明区间；未知允许null。
- `DeliveryEvent`：branch、sequence、revision、交付/访问时间、原因，允许重复。
- `QuerySpec`：实体/空间、有效窗口、变量/测量/统计类型、单位、产品选择政策。
- `BeliefCommit`：值、知识状态、unknown_reason、支持定位和更新操作，完全来自模型。
- `ReferenceRecord`：按分支编译的证据参考与单独的事后参考，私有。

`metadata`保留未知上游字段，但影响评分和时效的字段必须正式验证。

### 7.4 建议增量目录（待实现，不是现成功能）

```text
disastertrace-starter/src/disastertrace/mm_trace/
  contract.py, compatibility.py, delivery.py, state.py, grounding.py
  source_registry.py, event_registry.py, lineage.py, splits.py
  providers/         # 可用官方reader与传输层的窄adapter
  event_builders/    # station/grid/catalog，极端过程生成
  task_builders/     # T1–T6按数据适配，不复制完整运行器
  render.py, reference.py, reference_check.py
  passive_protocol.py, active_protocol.py
  capture.py, scoring.py, statistics.py, report.py, cli.py

tests/mm_trace/
configs/mm_trace/
docs/mm_trace/STATUS.md
```

先实现纵向流程所需模块，不创建一堆空壳后宣布完成。不在`artifacts/`或`work/`归档源码上直接开发。

---

## 8. 参考答案与任务效度

### 8.1 三类标签，不能假装一样可信

`inherited_human`：已有人工数据标签，保存来源与原生划分。

`inherited_algorithmic`：已有产品分类/算法派生标签，公开其质量和适用性。

`computed_by_public_spec`：从合法数据和公开规则计算的值、关系、状态与支持。

模型生成标签不是默认第四条主Gold路线。主评分继续不依赖新逐题人工标注或LLM judge，但需要研究者审查规则、样例可观察性、产品政策和系统性错误。[S0,S1]

### 8.2 两套参考分离

`SupportGold_t = resolve(本分支本轨道已可见/已访问的资料, query, policy)`。

`OutcomeReference_T = verify(事后目标兼容且质量合格的验证资料)`。

没有独立结果时Outcome为unresolved，而不是最后版本自动真值。隐性物理量不能因为存在best-track/算法标签就认定可从给定低清图精确推断。可以选择较粗分类、有不确定性的预测，或改为明确的已发布陈述读取；问题与参考类型必须对应。

### 8.3 独立核验与公开可解性

compiler与reference checker至少在目标选择、几何/数值计算等关键点有独立路径或可验证手算fixture；不只是同函数调用两遍。共享库与共同语义假设须披露。

对文本明确规则可建立公开求解器；对image-only但私有GIS生成参考的任务，私有几何程序属于oracle，不声称它与VLM使用相同输入。增加可观察性校验、图例/分辨率检查和感知分层，而不是偷给普通模型矢量答案。

---

## 9. 在线能力：从可追溯获取，到可重复的主动环境

### 9.1 三层架构

**O1 有界在线获取：**按授权AOI、日期、产品取得候选，保存内容与回执。

**O2 滚动归档、逐批冻结：**定期登记新修订，发布固定资料批次，旧成绩不随latest变化。

**O3 主动查询回放：**Agent可SEARCH/FETCH/WAIT/COMMIT，工具只返回该轨道时间下可获得的资料，带研究时间和预算。真正live访问单列，不能与离线固定响应混成同榜。

### 9.2 provider接口与现成软件

优先复用earthaccess/PO.DAAC处理NASA目录与认证、原始S3/HTTPS读取SEVIR、作者reader读取Digital Typhoon/TCIR/MeteoNet、CEMS公开API、NOAA站点目录；GEE是可选的空间检索与处理provider，不是所有数据必须经过的唯一入口。[W1,W2,W5,W9]

```text
discover(query, cursor, lookback) -> candidate refs + pagination status
fetch(ref, expected_revision) -> raw assets + receipt
normalize(raw, product_spec) -> typed metadata
commit_snapshot(raw, metadata) -> immutable revision
```

仅跟踪最大观测日期会漏掉回填和旧日期修订；应支持产品变更游标或有预算的重叠窗口。请求失败、分页未完、端点中断不是“该资料不存在”的证明。

### 9.3 GEE与其他产品的时间限制

GEE `filterDate`依据`system:time_start`，不是历史首次可取得时间。[W6] IMERG目录写明provisional后续替换为permanent，因此相同日期查询不保证返回历史同版本。[W7]

GHCN也存在实时数据被archive-quality来源替换、值/质量flag再处理，官方记录每日版本；因此它也需要版本记录，不能只对遥感产品做快照。[W4]

保存原始值/质量层、collection/image或granuleID、处理表达式、投影/分辨率、渲染和处理器身份。已记录first_seen只是采集系统在指定端点已看到的证据，上一次失败或未完整分页不能提供可靠不存在下界。

### 9.4 从第二周开始申请前瞻采集，不等论文末尾才开

在小范围成功完成“发现→不可变快照→断网回放”后，为明确的产品、AOI、轮询频率、截止时间和字节/计算预算申请新授权。可先NHC、一个OPERA区域或若干GHCN站点，再加入FIRMS。

前瞻主张需冻结模型身份与事件选入规则。若只在重大灾害发生之后挑中它、再回取之前资料，不能称全流程事前监测。模型可能预训练暴露问题会减弱，但不会因此被绝对排除。

---

## 10. 实验协议：信息权限、方法和干预分别变化

### 10.1 访问轨道

| 轨道 | 条件 | 使用 |
|---|---|---|
| F Full evidence | 累计已交付图文均可读，保存实际输入预算 | 标准动态主表与重算基线 |
| S Streaming | 新证据＋声明预算内的模型历史和保留图像，无隐藏回读 | 独立持续状态诊断 |
| A Active acquisition | 固定候选provider与动作预算，查询影响后续可见资料 | 嵌套子集上的补证效率 |

同轨方法共享证据访问规则。跨轨差异是环境条件，不称纯方法提升。表格记录底层多模态processor、分辨率、裁剪/tiles、文本与视觉tokens、生成与工具预算。

### 10.2 三个主基线与补充系统

主矩阵先固定：累计图文直接重算；时间/版本感知检索；显式状态及依赖重查。补充视觉证据保留方法作为S轨重点，加入固定轮询、随机查询、常规ReAct和覆盖感知重查作为A轨基线。

VersionRAG与CUPMem等可适配，需锁实际代码、说明改动和计算内部调用。未忠实复现只命名`version_filter`或`state_rechecker`，不能伪称作者官方成绩。专用确定性工具是诚实的强参照，不预设VLM应替代它。[S1]

四个被测模型是正式阶段的规模建议，至少来自两个独立语言骨干；模型名称在预检时用官方可用版本冻结，不用某个“latest”身份。试点先两个可用VLM，文本历史模型保持旧任务，不默认它能处理图像。

### 10.3 三层感知诊断

单次图像原子事实 → 正确感知事实但保留时空/版本选择的oracle → 原始图文动态任务。

oracle不得直接给当前最终状态或未来目标的答案。若差距全部来自感知，论文应明确说感知是瓶颈，而不是将低分全部归因于记忆失败。

### 10.4 配对干预

Delay/Withhold：保持真实内容和物理时间，改变研究交付，按各分支重算Gold。

Stale additive replay：新版仍在，旧原始资料再次出现；与移除新版的stale replacement独立命名。

Null/unrelated：额外材料不改变目标Gold值；如果来源刷新需要变化则单列，不强制所有字段全不变。

干预前输入应该一致；闭环后自有历史可以分歧。单步固定前缀和完整闭环成绩分开。缓存键包含输入/图像/模型/分支/前缀/采样身份，禁止跨分支误复用。

### 10.5 状态载体四臂审计

Actual真实状态，Masked相关信息移除加长度对照，Oracle正确前缀（特权），Edited相关/无关槽位编辑。

Masked排查服务端会话、缓存、自动摘要和旧图旁路。Edited要有本轮权威反证条件：能纠正错误状态是能力，盲从错误不算优点。`commit_used`通过组间干预诊断，不直接乘入每个普通检查点主分。

---

## 11. 主动补证的评价，避免“总答未知”和“只在成功时提交”

预先固定有限的合法查询空间、费用单位和时间推进规则。可多个正确查询路径，不以复刻研究者工具序列为唯一正确条件。

所有系统在共同检查时间和目标集上评价：到截止没有提交为missing；WAIT耗时；问题不可解时正确unknown获支持信用，但不获得“已解决”的覆盖信用。

拆开四类时间：观测周期/来源发布、平台获取、Agent未查询、已读到但未修订。用充分证据可合法获得/实际已读到的两个起点分别报告延迟，不把上游延迟全罚给模型。

评价至少同时报告：证据支持一致性、正确解决的目标比例、无依据确定断言、查询/字节/时间成本、重要未知区域消减、修订延迟。

预算本身不能取得全部证据时，给小规模可行或特权最优查询上限，单列而不当公平基线；使用多个预算点，避免人为将某个策略设计为唯一得分路径。

---

## 12. 评分、统计与测试划分

### 12.1 主指标分层

| 层次 | 指标示例 |
|---|---|
| 内容 | 状态/值/范围/目标时间正确；精度按公开信息 |
| 依据 | 可见性、时空兼容、版本、字面/区域定位、等价支持集合 |
| 修订 | 必要值更新、同值来源刷新、稳定正确率、collateral edit、错误恢复 |
| 不确定性 | unknown原因、未观测保护、无依据断言、risk–coverage |
| 流程 | 整轨成功、重复整轨成功、缺失/无效/未尝试与恢复延迟 |
| 主动 | 预算—正确覆盖、重复无效查询、时间与成本 |

值保持不要求时间戳和来源全不变；模型纠正旧错误不算不必要更改；零eligible样本返回null和count0而非100%。缺失、非法和工具故障均保留计划分母，并给系统错误/语义错误分解。

### 12.2 规模大，但只在固定测试集上做主要比较

建议3,000事件/source-group目标达成后，以家族和来源组分层的 **60% development / 20% validation / 20% test** 作规划模板。实际按组分配，数目不必恰好1800/600/600；既有protected heldout和上游split优先，不得为了凑比例泄漏。

跨灾种OOD测试另设任务配置：测试家族的事件、few-shot和标签不能参与方法调优。公开产品说明与任务规则可以提供。这里的跨灾种迁移不是要求模型先验不知道灾种定义。

新旧测试暴露历史登记；反复看同一测试结果属于开发信号，不能继续称未见测试。若规则需修复另发版本，旧成绩保留；评分器自测使用fixture或开发资料，不临时修正测试答案提高分数。

### 12.3 汇总统计

至少给每个家族、来源组、时间配置、任务类型和质量层结果，主表报告家族宏平均与机会加权结果。差值区间按事件/关联组聚类，不把每个像元或检查点视为独立。

600或3,000是规划目标，不意味着统计精度已足够。正式检验前根据pilot的组间变异与计划对比做样本量敏感性分析；家族只有少数事件时不声称普遍显著。

---

## 13. 可执行里程碑与工期

### 13.1 计划假设

以下以“研究者持续参与＋Codex实施辅助＋已明确数据/算力预算”为前提。小团队可按12–16周规划；如果研究、数据适配、审查和运维主要由你一人完成，按16–24周更稳妥。没有假定会议截稿日，也不保证某时间必须出现足够前瞻灾害。

### 13.2 里程碑

| 里程碑 | 建议时间 | 数据目标（均待验收） | 通过条件 |
|---|---|---|---|
| M0 工程与注册 | 第1周 | 52项本地计划登记；一个允许开发事件的真实闭环 | 旧结果不变，核心回归测试与下载dry-run完成 |
| M1 多家族pilot | 第2–3周 | 约100个事件候选准入目标、至少5个家族；约1,200基础检查点预算例 | 不是全部同源；有来源/时间/模态边界、程序对照及真实失败清单 |
| M2 Beta | 第4–6周 | 约600事件、6–8家族；1万级基础检查点目标 | 已有自动抽取、去重/划分、模态与支持验证、首次分层模型结果 |
| M3 扩展与主动 | 第7–10周 | 约1,000–1,500事件；主动子集先50再100个情境 | 强基线、公平访问与工具预算、跨来源描述统计 |
| M4 正式候选 | 第11–16周及必要延长 | 目标3,000事件、约54,000基础检查点；独立辅助集；前瞻批次 | 家族覆盖表、冻结split、模型主表、独立复算、许可与数据卡 |

100事件等是目标不是准入放宽条件。某项缺口只影响对应主张；例如HKO未获许可不能阻塞其他数据，online不足则保留回放主轨不假装具备真实在线证据。

### 13.3 每周固定交付，不以“阅读了很多资料”代替进度

一个真实可执行样例或批次；来源状态和准入/隔离计数；代码变更/测试/命令；实际资源使用；新增科学发现或仍不支持的结论；下一周最小任务。

至少每两周review一次研究主线，防止不断扩source、改格式却没有新的有效任务。

---

## 14. 预算与规模控制

### 14.1 不在所有样本上做完整笛卡尔积

数据建设可以3,000事件、辅助集几十万，模型主表只评冻结测试部分。大量程序Gold/数据准入检查不需要LLM。消融、重复与oracle用预先抽取的分层子集，不在发现哪个案例异常后才只测它。

一个按600测试事件、每事件3episode、每条6检查点计算的基础矩阵：

`600 × 3 × 6 × 4模型 × 3方法 = 129,600次最终回答`。

加入第二分支会翻倍；完整重复会再翻倍。主动轨的memory writer/verifier/retriever等额外模型调用另计。不能把逻辑最终回答数当总API调用量。

小型模型预检先用隔离校准fixture；一条12episode×5检查点×3系统×2模型×2重复的基础pilot为720最终回答，不代表全期只有这个量。

### 14.2 算力只用实测吞吐估计

`预计分配GPU小时 = Σ(该配置正式批次实测墙钟小时 × 使用GPU数)`，包括加载、等待和失败。对不同图像分辨率、上下文和方法分别测，不用纯文本token速度估计所有VLM。

仅作敏感性例：若129,600个机会的有效单GPU平均成本为20秒或60秒，对应约720或2,160 GPU小时。这里是条件算术，不是测得速度，也不是已获资源授权。模型并行度、batch与长历史会改变该成本。

不默认购买API、扩至8卡或继承旧4-H100窗口；先提交新版范围、上限和stop条件。

### 14.3 存储先审计后批准

原目录给出的例子：SEVIR约1TB，Digital Typhoon V2约77GB，MeteoNet约219GB；不等于本项目必须全量下载这些字节。[S3,W1,W2]

建议先批准一个50–200GB的样例/子集缓存范围（具体由用户选择），使用文件大小与选定AOI估算扩大后的原始、派生、索引、结果、双副本占用，再申请TB级存储。此处不将任意预算值写成当前可用空间。

内容寻址复用相同字节；不为每个模型/分支复制图像。禁止盲目对数百万火灾逐个拉全景；先按事件/区域/时间选取必要产品。日志图像引用哈希不重复base64写入多份结果。

---

## 15. 论文如何与工程同步完成

### 15.1 建议贡献只保留三个

**数据/任务：**广覆盖但语义明确的多灾种动态证据任务，特别区分物理时间、修订时间和可见性，不把所有原始资料强行当在线。

**测量：**内容、支持、选择性更新与未知保护分层，用分支参考和有序回放评价；主动子集加入成本和修订延迟。

**实证/方法：**强检索/状态/视觉保留基线、跨事件家族外推和前瞻批次；候选方法若无优势也报告，不把benchmark绑在必须赢榜的方法上。

### 15.2 必须准备的正文图表

总体事件—证据—状态流程；家族×来源×时间配置覆盖矩阵；三个典型变化类型案例；主结果分层表；配对与稳定目标表；感知/oracle/状态消融；预算—正确覆盖—延迟；跨家族/来源/时间外推。

所有图表区分已完成与计划，来源公布量与实际准入量，程序与真实模型。历史阶段编号留附录，不用P6/P7/P20叙述整篇论文。

### 15.3 近邻比较的交付

每项论文用明确协议页/代码入口比较：事件数量与单位、模态、时序/可见性、目标对齐、状态提交、证据定位、主动工具、干预、自动参考与可复现性。内容不明填unknown，不能把“没在摘要看到”写成“没有”。

重点复核EarthVerse、ExtremeWeatherBench、DORA/SIREN、StateMemBench/STALE、SpaMEM/VERA和相关异步Agent环境。主差异是待通过本项目实验支持的评价重点，不使用未经证明的“首个”。[S1,W8]

---

## 16. 发布、风险与停止条件

### 16.1 发布包

dataset/model/protocol cards；schema与任务规范；事件/来源清单和允许再分发的文件；不允许再分发的来源只提供合法获取脚本/指针；split、引用、许可与血缘；确定性评分和最小复算；失败记录及变更历史。

代码MIT之类不自动覆盖上游影像、社交个人数据或模型权重。申请型源不随总包分发。发布前检索密钥、认证回执、私有绝对路径和第三方限制。

### 16.2 常见风险的处置

| 风险 | 必须采取的行动 |
|---|---|
| 文件很多但独立事件少 | 公开group计数，改抽独立事件，不复制裁剪填配额 |
| 版本/时间无法还原 | 降为R1/R2或辅助层，缺失明确，不制造available_at |
| 参考和可见图像精度不一致 | 改输出为可读区间/关系，隔离不可观察样本 |
| 跨传感器不兼容 | 分开产品或输出兼容性/未知，不把冲突当灾情变化 |
| 主方法靠更多信息/调用赢 | 报系统成本，另做匹配对照，不归因结构机制 |
| 高分或负结果 | 诚实报告；不要删样本或改测试制造失败 |
| 真正灾害类别数据不足 | 留缺口或延后，不把所有相似背景都标灾害 |
| 子任务需主观现实行动判决 | 移出自动Gold主轨，或另建有独立领域依据的任务 |

Go的标准是任务有效、预算和支持可解释；不是“至少三个大模型必须失败”。

---

## 17. 第一周的逐日执行指令

**第1天：**读取适用AGENTS和实际HEAD；登记现有变更/冻结文件/heldout；导入52源原始目录并校验ID；创建本总计划对应的状态与任务清单。明确哪些需要账号，哪些可以已有本地数据验证。

**第2天：**落地SourceSpec/EventRecord与六个评测对象的最小契约；补时间/来源/操作测试；新路径分支日志身份不混用。

**第3天：**完成有序交付、来源刷新、region绑定和单轨故障隔离；旧任务回归不变；synthetic fixture离线跑通。

**第4天：**并行实现/适配目录级reader：SEVIR、Digital Typhoon/IBTrACS、Storm Events、OPERA。使用本地fixture时写明；远程查询只在当前允许范围内，有界下载先给manifest。

**第5天：**用已允许开发的NHC或其他真实资料形成闭环，至少一个非NHC来源达到可检查adapter；不要等全部模型成绩才继续数据目录。

**第6–7天：**输出第一批准入/隔离和覆盖表；确定100事件pilot抽样政策、任务类型及新增下载/前瞻/算力申请。完成实际测试与重建，反馈阻塞而不是只递交下一份计划。

若某一天真实数据受限，继续其余独立代码和fixture工作，但真实准入项保持blocked。

---

## 18. Codex使用方式与交付包说明

将本包放在仓库外或新的 `plans/master_v1/` 中，不覆盖旧计划和AGENTS。读取 `CODEX_START_HERE.md` 和 `workplan.yaml`；`source_registry.plan.json` 是包含52项原目录的计划记录，不是下载清单、可自动访问权限或已验收数据卡。

第一轮完成E01–E04与已有权限下的数据目录/fixture工作。达到需要真实网络、批量数据、GPU或背景服务的任务时，明确列出所需源ID、具体URL/查询范围、字节/时间/费用上限及为什么需要，等待新授权。任务pending不意味着工具不可用；有权限的独立工作仍继续。

本包没有运行实施计划，没有下载数据/权重，没有创建远程任务。YAML/JSON只完成本地结构、ID覆盖、依赖及预算算术检查；拟新增命令/API不是已安装功能。

---

## 19. 资料依据与本次核查边界

### 继承材料

[S0] 用户提供的论文式底稿与演示稿，研究骨架为内容、来源和连续可靠性；其2026-09-08模型状态仅是历史快照。

[S1] `DisasterTrace_Code_Online_Novelty_Audit_CN.md`：固定提交源码与八条局部探针审查。本计划复用结论，没有重新执行探针或全量模型。

[S2] `DisasterTrace_Next_Implementation_Plan_CN.md`：NHC/OPERA桥梁、online与主动补证计划。本计划扩展其最终来源与数量范围，保留有效性和执行边界。

[S3] `DisasterTrace_Broad_Coverage_Datasets_CN.md` 与 `DisasterTrace_Dataset_Catalogue_CN.json`：52项来源公布规模、单位、限制与官方入口；不是下载后的实际统计。

### 本轮重点核对的官方入口（2026-09-10）

- [W1] SEVIR公开数据入口与S3读取：<https://registry.opendata.aws/sevir/>。
- [W2] Digital Typhoon V2规模、best-track中心裁剪与reader：<https://github.com/kitamoto-lab/digital-typhoon>。
- [W3] OPERA产品定义、非跨传感器同化与教程：<https://www.jpl.nasa.gov/go/opera/products/dswx-product-suite/>。
- [W4] GHCN-Daily变量覆盖、实时/档案替换和日版本：<https://www.ncei.noaa.gov/products/land-based-station/global-historical-climatology-network-daily>。
- [W5] CEMS公开激活/产品API：<https://mapping.emergency.copernicus.eu/about/how-to-harvest-cems-mapping-data/emergency-response-data/>。
- [W6] GEE日期筛选：<https://developers.google.com/earth-engine/apidocs/ee-imagecollection-filterdate>。
- [W7] IMERG产品替换与版本说明：<https://developers.google.com/earth-engine/datasets/catalog/NASA_GPM_L3_IMERG_V07>。
- [W8] EarthVerse论文公开正文：<https://arxiv.org/html/2608.23525v1>，本轮用于限定近邻定位，不声称代码复现。
- [W9] earthaccess官方文档入口：<https://earthaccess.readthedocs.io/en/latest/>；代码复用建议继承S2，实施前锁版本。

其余52源的详细入口见附件注册表，本轮没有逐一重新下载核验。注册表保留上轮 `metadata_review_date` 和公布量，新增计划字段与之分开。本计划时间表、数量配额、抽样比例、任务ID、资源例子和代码结构均为新的建议规格，不代表来源论文已支持这些具体实现。

## 附录A．52项来源到实施波次的映射

下表只有第一个官方/作者入口；完整原公布数量、单位、限制和其余链接保留在注册表的 `catalogue_record` 中。所有能力仍需样本级准入。

| 来源ID | 来源 | 波次 | 建议adapter类型 | 首个官方/作者入口 |
|---|---|---|---|---|
| D01 | EM-DAT | W0 | catalogue | [入口](https://www.emdat.be/) |
| D02 | GDIS | W0 | catalogue | [入口](https://www.nature.com/articles/s41597-021-00846-6) |
| D03 | NOAA Storm Events | W0 | catalogue | [入口](https://www.ncei.noaa.gov/stormevents/) |
| D04 | ExtremeWeatherBench | W0 | catalogue | [入口](https://github.com/brightbandtech/ExtremeWeatherBench) |
| D05 | ExEBench / EarthExtreme-Bench | W0 | catalogue | [入口](https://arxiv.org/abs/2505.08529) |
| D06 | Copernicus EMS Rapid Mapping | W0 | activation_and_mapping_api | [入口](https://mapping.emergency.copernicus.eu/) |
| D07 | NASA EONET | W0 | catalogue | [入口](https://eonet.gsfc.nasa.gov/docs/v3) |
| D08 | Digital Typhoon V2 | W1 | prepackaged_multisensor_sequence | [入口](https://agora.ex.nii.ac.jp/digital-typhoon/dataset/V2/) |
| D09 | TCIR | W1 | prepackaged_multisensor_sequence | [入口](https://github.com/BoyoChen/TCIR) |
| D10 | IBTrACS v4r01 | W0 | catalogue | [入口](https://www.ncei.noaa.gov/products/international-best-track-archive) |
| D11 | CMA热带气旋最佳路径 | W0 | catalogue | [入口](https://tcdata.typhoon.org.cn/en/zjljsjj.html) |
| D12 | NHC Forecast/Advisory与GIS | W1 | nhc_text_and_gis | [入口](https://www.nhc.noaa.gov/archive/) |
| D13 | SEVIR | W1 | prepackaged_multisensor_sequence | [入口](https://proceedings.neurips.cc/paper/2020/hash/fa78a16157fed00d7a80515818432169-Abstract.html) |
| D14 | MeteoNet | W2 | prepackaged_multisensor_sequence | [入口](https://meteofrance.github.io/meteonet/english/data/summary/) |
| D15 | HKO-7 | W3 | prepackaged_multisensor_sequence | [入口](https://arxiv.org/html/1706.03458v2) |
| D16 | Global Flood Database v1 | W1 | event_geometry_product | [入口](https://developers.google.com/earth-engine/datasets/catalog/GLOBAL_FLOOD_DB_MODIS_EVENTS_V1) |
| D17 | WorldFloods v2 | W1 | catalogue | [入口](https://zenodo.org/records/8153514) |
| D18 | Sen1Floods11 | W1 | inherited_label_or_qa | [入口](https://openaccess.thecvf.com/content_CVPRW_2020/html/w11/Bonafilia_Sen1Floods11_A_Georeferenced_Dataset_to_Train_and_Test_Deep_Learning_CVPRW_2020_paper.html) |
| D19 | SEN12-FLOOD | W1 | prepackaged_multisensor_sequence | [入口](https://doi.org/10.21227/c1b8-aa12) |
| D20 | WorldFloodType | W1 | inherited_label_or_qa | [入口](https://zenodo.org/records/20225841) |
| D21 | OPERA DSWx-HLS/S1 | W1 | geospatial_time_product | [入口](https://developers.google.com/earth-engine/datasets/catalog/OPERA_DSWX_L3_V1_HLS) |
| D22 | FPA FOD第6版 | W2 | catalogue | [入口](https://apps.fs.usda.gov/arcx/rest/services/EDW/EDW_FireOccurrence6thEdition_01/MapServer) |
| D23 | Global Fire Atlas | W2 | prepackaged_multisensor_sequence | [入口](https://essd.copernicus.org/articles/11/529/2019/) |
| D24 | MTBS | W2 | catalogue | [入口](https://www.mtbs.gov/) |
| D25 | NASA FIRMS VIIRS/MODIS | W2 | detection_feed | [入口](https://firms.modaps.eosdis.nasa.gov/) |
| D26 | GHCN-Daily | W2 | station_series | [入口](https://www.ncei.noaa.gov/products/land-based-station/global-historical-climatology-network-daily) |
| D27 | NOAA ISD | W2 | station_series | [入口](https://www.ncei.noaa.gov/products/land-based-station/integrated-surface-database) |
| D28 | ERA5 | W2 | geospatial_time_product | [入口](https://cds.climate.copernicus.eu/datasets/reanalysis-era5-single-levels?tab=overview) |
| D29 | CHIRPS v2日降水 | W2 | geospatial_time_product | [入口](https://developers.google.com/earth-engine/datasets/catalog/UCSB-CHG_CHIRPS_DAILY) |
| D30 | TerraClimate | W2 | geospatial_time_product | [入口](https://developers.google.com/earth-engine/datasets/catalog/IDAHO_EPSCOR_TERRACLIMATE) |
| D31 | SPEIbase | W2 | geospatial_time_product | [入口](https://spei.csic.es/database.html) |
| D32 | US Drought Monitor | W2 | geospatial_time_product | [入口](https://droughtmonitor.unl.edu/DmData/DataDownload.aspx) |
| D33 | SNODAS | W2 | geospatial_time_product | [入口](https://www.nohrsc.noaa.gov/archived_data/) |
| D34 | MODIS MOD10A1 | W2 | geospatial_time_product | [入口](https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MOD10A1) |
| D35 | MERRA-2 aerosol | W3 | geospatial_time_product | [入口](https://developers.google.com/earth-engine/datasets/catalog/NASA_GSFC_MERRA_aer_2) |
| D36 | NOAA OISST v2.1 | W3 | geospatial_time_product | [入口](https://www.ncei.noaa.gov/products/optimum-interpolation-sst) |
| D37 | GESLA 4.x | W3 | station_series | [入口](https://os.copernicus.org/articles/22/1681/2026/) |
| D38 | SMAP土壤湿度 | W2 | geospatial_time_product | [入口](https://smap.jpl.nasa.gov/data/) |
| D39 | Landslide4Sense | W3 | inherited_label_or_qa | [入口](https://github.com/iarai/Landslide4Sense-2022) |
| D40 | NASA COOLR | W3 | catalogue | [入口](https://gpm.nasa.gov/applications/landslides/coolr) |
| D41 | High Mountain Asia Landslide Catalog v2 | W3 | catalogue | [入口](https://nsidc.org/data/hma_ls_cat/versions/2) |
| D42 | CLLMate | W3 | inherited_label_or_qa | [入口](https://aclanthology.org/2025.emnlp-main.886/) |
| D43 | WeatherQA（2024 Severe Weather） | W3 | inherited_label_or_qa | [入口](https://arxiv.org/abs/2406.11217) |
| D44 | CrisisMMD v2 | W3 | inherited_label_or_qa | [入口](https://crisisnlp.qcri.org/crisismmd) |
| D45 | MEDIC | W3 | inherited_label_or_qa | [入口](https://github.com/firojalam/medic) |
| D46 | Incidents1M | W3 | inherited_label_or_qa | [入口](https://arxiv.org/abs/2201.04236) |
| D47 | xBD | W3 | inherited_label_or_qa | [入口](https://arxiv.org/abs/1911.09296) |
| D48 | FloodNet | W3 | inherited_label_or_qa | [入口](https://github.com/BinaLab/FloodNet-Supervised_v1.0) |
| D49 | RescueNet | W3 | inherited_label_or_qa | [入口](https://www.nature.com/articles/s41597-023-02799-4) |
| D50 | Sentinel-1/2原始与标准处理产品 | W1 | geospatial_time_product | [入口](https://dataspace.copernicus.eu/) |
| D51 | GPM IMERG | W2 | geospatial_time_product | [入口](https://gpm.nasa.gov/data/imerg) |
| D52 | NOAA GFS | W2 | geospatial_time_product | [入口](https://developers.google.com/earth-engine/datasets/catalog/NOAA_GFS0P25) |
