# DisasterTrace 完整后续计划
## 多灾种数据底座、在线版本快照、证据充分性与主动取证评测

- 计划日期：2026-09-10。
- 文件性质：研究与工程实施规格；不是已经完成的实现、实验结果或资源授权。
- 实际核查的仓库：`sisuolv/disastertrace-benchmark`。
- 实际核查的开发分支：`next-phase-v1`。
- 实际核查的提交：`36082c42a93e11f67d274d8000c87cd1dc098d74`。
- 本轮重新确认 `main` 仍为 `a23f73adadcbec077b9fcf2aecf8f45dfa4fe061`。
- 核查方式：读取 GitHub 分支、阶段导航、选定正式接口；完整读取前期数据目录、数据格式计划和主动取证计划；针对关键接口与近邻研究复查官方资料。本轮未克隆并运行整仓、未重算全部 captures、未认证 GEE、未下载新数据、未启动模型或服务器任务。
- 使用对象：项目负责人、Codex 编码代理、数据与实验协作者。

> **最终方向不再改变：保留 DisasterTrace。广度由 17 类天气及天气相关灾害和 45 项候选来源保证；论文深度由可验证的证据支持、版本/覆盖理解和有限预算下的主动取证保证。数据池尽可能广，进入主评分的任务必须经过语义和标签认证。**

---

# 0. 执行摘要与本次整合决策

## 0.1 一句话研究定位

**DisasterTrace 在持续更新的跨灾种、多模态证据中，区分“信息尚不充分”与“模型未正确使用信息”，并检验模型能否以有限的信息成本形成有来源支持、时空可比、及时更新的判断。**

只有未来结果验证轨达到数据与实验标准后，才追加“改善预警提前量或代理决策收益”的主张。不把读取官方预报写成提升物理预测精度，不把研究阈值写成业务预警标准。

## 0.2 与前期三个文件的关系

本计划整合以下文件，不删除它们，不将前期提案当作已实现代码：

1. `DISASTERTRACE_DATA_FORMAT_AND_ONLINE_PLAN.md`：保留资产版本、采集时间、空间支持、任务专用协议和不可变快照设计。
2. `DISASTERTRACE_ACTIVE_EVIDENCE_NEXT_PLAN_2026-09-10.md`：保留 goal/visible/sufficiency 三层参考、READ/STOP/ABSTAIN、覆盖感知和独立结果验证边界。
3. `DISASTERTRACE_EXTREME_WEATHER_DATA_CATALOG_2026-09-10.md`：保留 17 类分类和 45 项候选来源，不把所有数量相加。

**本次明确调整的优先级：**前期主动取证计划中“先只做 NHC/洪水、其他灾种全部后置”的调度，不再作为整个项目的数据接入限制。按照用户最新要求，全部类别的目录、元数据、准入与可用任务清单立即并行建设；NHC/洪水仍用于率先验证最复杂的主动取证机制，而不是限制最终 benchmark 的灾种数。

不同时实现三个同义的来源层。统一命名为 `source_stream/`；如果工作区已有 `online_sources/`，先比较其职责和实际实现，再选定唯一入口，避免重复模块。

## 0.3 四个交付层，分别验收

| 层 | 交付内容 | 规模目标的性质 |
|---|---|---|
| 数据目录层 | 17 类、45 项候选来源的版本/许可/覆盖/接口注册，跨来源事件关联 | 全部登记是当前目标；登记不代表接通 |
| 证据资产层 | 文本、表格、站点序列、预报网格、影像、质量层、已有标签 | 按任务选取，逐步形成十万级资产候选池；不盲目下载全球原始数据 |
| 固定评测核心 | 经过自动 Gold 与公开支持检查的多灾种任务，保留普通天气和临界对照 | v1 目标约 1,600 个物理事件组；不是保证，也不是当前数量 |
| 深度与在线轨 | 较小的主动取证子集、滚动新事件快照、条件满足后的结果验证 | 先证实测量意义，再扩量；不要求所有灾种同时具备全部任务 |

## 0.4 不变约束

- 不重建旧 starter，不将新项目迁移到另一套大型评测框架。
- 不更改历史 Gold、原 scorer、旧 schema、模型原始回答、失败、已消耗 launch claim 或冻结源码。
- 不新增逐题人工 Gold、逐题专家裁决或 LLM judge 主评分。允许复用已有合法发布标签；允许人工核查许可、产品语义和方法，不将其伪装成完全无人治理。
- 模型生成、数据抓取、GEE 计算、权重下载、训练、heldout 和发布分别需要明确 scope；本计划不授权任何一项真实运行。
- 已过期的自主工作窗口、历史 GPU 配额或模型预算不得自动沿用。
- 未实际取得的数量为 `null`；mock、程序控制、历史运行、当前运行分开记。
- 不为得到预期结果删除失败、替换难题或事后调整来源、成本、阈值和分母。

---

# 1. 当前起点：复用什么，不再重复做什么

## 1.1 本轮重新核查的事实

仓库的阶段导航是 **2026-09-08 20:31 UTC 的快照**，不是实时服务器状态。[C1]

- P6 已记录 2,160 个实际回答及 1,861 个完整正确结果。
- P7 已完成真实 NHC 预报目标任务，1,542 个实际回答；不再只有合成 PATCH。
- P8 是 JSON/文本载体表示对照，不是主动取证。
- P9 记录真实历史载体超上下文造成停止，986/1,542 返回，556 个未尝试保留在分母。
- P10 已准备额外六个开发来源风暴、36 份原始公告、144 个有效时间目标和 804 个 checkpoint。
- P11–P14 在该提交中的记录仍为运行/等待/注册阶段。本轮没有查询服务器终态；开始新工作时必须先读当前实际工作区的终态证据，不能重启旧任务。

以上数字为仓库保存事实，不是本轮复验结果。

## 1.2 当前正式接口的边界

`forecast_task/contract.py` 固定经纬度、最大持续风、KT 单位、预报有效时刻与文本行引用。它支持“最新已交付且明确覆盖该目标时刻的预报”，并禁止阵风替代、插值或把观测当预测。[C3]

`forecast_task/protocol.py` 把当前全部可见文本放入请求。三个方法的区别是 own-answer carrier，不是主动获取哪些证据。[C2]

因此，新研究需要独立任务/访问协议。旧协议是严谨的对照，不应通过放宽 validator 变成一个允许任意字段的通用输入。

## 1.3 模块复用表

| 现有位置，相对 `disastertrace-starter/` | 可复用内容 | 新增范围 |
|---|---|---|
| `forecast_source/` | HTTP capture、原始哈希、规范化、双解析器、行映射 | 持续发现、内容版本、游标和在线 ready-time |
| `forecast_catalog/`、`forecast_cohort/` | 事件/来源准入与隔离、原字节重建 | 多来源统一索引，但不改旧固定来源范围 |
| `forecast_task/` | 精确目标、原文/Gold 分离、来源与定位评分 | 新 task profile，不修改原三字段格式 |
| `controlled/` | 局部更新、作用域、程序负控 | 保留 controlled 标签，不称为自然历史 |
| 已有 local/forecast/cohort runtime | 实际请求、响应、token、解码和重算 | 新轨迹级失败隔离、图文 processor、获取动作日志 |
| 已有原始失败与执行档案 | 当前研究局限和回归素材 | 只读保护，不能把失败“修复成正确结果” |

## 1.4 首先建立现有代码清单

Codex 先输出 `docs/multihazard/BASELINE_REVIEW.md`：HEAD、工作区差异、适用 AGENTS、完成/进行中/未核验阶段、可访问数据包、原始 captures 覆盖、实际运行的离线测试。

不要以历史“通过 N 项测试”替代本环境测试。缺数据包时继续做不依赖它的接口与 fixture，相关历史重算标 `BLOCKED_MISSING_CAPTURE`。

---

# 2. 数据广度与数量：17 类都进入路线，正式题目按资格生成

## 2.1 统一计数，不混加数量

每个 snapshot 至少报告：

```text
raw_report_count                 原生目录/报告行数
physical_event_group_count       按声明规则归并的物理过程数
asset_version_count              产品内容版本数
frame_or_tile_count              图像帧/空间切片数
labelled_asset_count              具有已知级别参考的资产数
eligible_opportunity_count       合格任务机会数
prospective_snapshot_count       真正前瞻采集的冻结批次数
```

每项同时记录 `count_unit`、`source_version`、`selection_scope`、`completed_pagination` 和 `as_of`。只得到一页元数据不能声称总量。来源宣传数字保存在 `published_quantity`，不能填入 `actual_counts`。

FPA-FOD、EM-DAT 等大目录支持大规模候选池，但其记录不全部属于独立极端天气事件。图像、站点小时、公告版本和派生问题更不能相加成事件总数。[CAT; S11; S12]

## 2.2 17 类的首选来源、首发任务与候选配额

下表配额是**非重叠 primary_hazard 的规划预算**，总计 1,600；真实事件可以有多个次级危害标签。它不是对来源现状的统计，也不要求稀有类别用重复切片凑数。

| ID | 类别 | 首选数据/产品 | 首发可认证任务 | v1 候选主事件配额 |
|---|---|---|---|---:|
| T01 | 热带气旋/台风/飓风 | NHC、IBTrACS、Digital Typhoon V2 | 同目标预报修订、文本/图像支持、主动读取 | 200 |
| T02 | 非龙卷强风/温带风暴 | Storm Events、GHCNh、GFS、ECMWF、IEM | 风定义/阈值、预警生命周期、版本选择 | 80 |
| T03 | 龙卷风 | Storm Events、IEM、SEVIR、NEXRAD | 警报与已报道事件区分、时空证据关联 | 60 |
| T04 | 冰雹 | Storm Events、IEM、SEVIR、MRMS | 预警、测量/报告范围、雷达产品支持 | 60 |
| T05 | 雷暴/雷电 | SEVIR、GOES GLM、HKO、Storm Events | 多模态支持、计数窗口、缺测 | 80 |
| T06 | 极端降水/暴雨 | SEVIR、IMERG、MRMS、GHCNd、GFS、MeteoNet | 累计窗口、阈值、产品修订 | 160 |
| T07 | 山洪/快速洪水 | Storm Events、IEM、IMERG、MRMS、USGS | 警报时效、降雨/水文证据，结果验证候选 | 100 |
| T08 | 河流洪水/城市内涝 | WorldFloods、Global Flood Database、Sen1Floods11、Sentinel、USGS/NWPS | 空间覆盖、可比性、主动取证 | 200 |
| T09 | 风暴潮/沿海洪水 | CO-OPS、GESLA-4、Storm Events、NHC | datum/潮汐/总水位、窗口与阈值 | 60 |
| T10 | 热浪/湿热 | GHCNd/GHCNh、GFS、ERA5、HKO、CMA | 温度/湿热定义、持续时间、预测修订 | 100 |
| T11 | 寒潮/极端低温/霜冻 | GHCNd/GHCNh、GFS、ERA5、HKO、CMA | 持续时间、阈值、缺测与预报版本 | 80 |
| T12 | 暴雪/吹雪 | SNODAS、MODIS Snow、GHCNd/GHCNh、Storm Events | 雪盖/雪深/降雪量区分与覆盖 | 60 |
| T13 | 冻雨/冰暴 | Storm Events、IEM、GHCNh、NWS | 已发布预警与天气现象报告；不伪造像素冰厚 | 40 |
| T14 | 干旱/骤旱 | CHIRPS v3、USDM、GHCNd、ERA5 | 基准期、累计窗口、产品等级与持续性 | 60 |
| T15 | 火险天气/野火 | FPA-FOD、FIRMS、TS-SatFire、FLOGA、Sentinel | 火点/烧毁范围、缺观测与主动区域读取 | 160 |
| T16 | 沙尘暴 | CAMS、GHCNh、风云、Storm Events | 模式/实测与能见度、作用范围 | 40 |
| T17 | 浓雾/极端低能见度 | GHCNh、HKO、Storm Events、NWS | 能见度阈值/时长/缺测 | 60 |
| | **合计** | | | **1,600** |

数据来源能力来自已有目录 [CAT]；配额、任务和优先级是本次规划。海洋热浪、烟霾和降雨诱发滑坡独立扩展；地震/火山不计入 17 类天气范围。不要把每个来源中“有这一类标签”解释成“所有任务、模态与标签均已就绪”。

## 2.3 规模分阶段增长

| 里程碑 | 必须交付 | 数据规模目标（非保证） |
|---|---|---|
| M0 | 17 类、45 源全部登记，有权限/覆盖/实际状态 | 实际获取计数未知则 null |
| M1 | 多灾种事件与两类媒体能够进入统一封装 | 约 80 个事件组，覆盖至少 8 类；达不到报告缺口 |
| M2 | 多族自动 Gold、原文/产品/图像轨分离 | 约 300–500 个事件组，争取覆盖至少 12 类 |
| M3 | 固定 v1 数据核心、事件级划分与模型实验 | 约 1,600 个事件组、17 类目标；实际类别以认证结果为准 |
| M4 | 深度主动取证和条件性的独立结果验证 | 从核心中选择约 200–300 个可认证事件；不是再计算新事件 |
| M5 | 稳定 online releases 与更大扩展 | 5,000 事件组为后续伸展目标，不是首篇硬性条件 |

示例容量：`1,600 × 8 checkpoints × 4 questions = 51,200` 个机会，只用于估算。正式机会数为每个事件可认证 task profile 的总和，**不对所有类别强制填充同一四题模板**。普通天气/无事件对照单独计数，不计入极端事件目标。

---

# 3. 45 项来源如何接入：元数据优先、短窗口先保全、重资产按需取

## 3.1 四条并行数据工作流

### A. 广覆盖事件索引

立即准备 Storm Events、IEM、IBTrACS、FPA-FOD 的 adapter；EM-DAT 权限未获时标阻塞，不阻塞其他目录；EONET/GDACS 补新事件发现。

先获得类型、原生 ID、时间、位置、引用和许可，再获取大影像。目标是可审计事件目录，不是抓取同一事件的所有网页。

### B. 已对齐/已有标签的多模态资产

优先并行接 SEVIR、Digital Typhoon V2、WorldFloods、Global Flood Database、Sen1Floods11、TS-SatFire；FLOGA/MeteoNet 补地域和传感器。

首先使用官方 catalogue/loader/split；不复制整套训练框架，不重新绘制像素标签。标签类型、质量和版本单独登记。每个 adapter 先通过少量真实资产 smoke，再按事件配额扩展。[S5–S8; CAT]

### C. 连续气象/水文观测与预测

GHCNd/GHCNh 支持温度、风、能见度和长尾类型；GFS/ECMWF 支持发行版本；IMERG/CHIRPS 支持降水；USGS/NWPS/CO-OPS 支持独立观测和结果验证。ERA5 是历史背景/再分析角色，不填补当时未获得的数据。[S1–S4; S9; S10; CAT]

### D. 长尾类别与非美国地域

SNODAS/MODIS Snow、USDM/CHIRPS、CAMS、GESLA、HKO、CMA/FY 同步做目录和许可可行性；对有自动任务资格的类别立即加入，而不是等待全部洪水实验完成。认证较弱的类别仍出现在 coverage matrix 中，状态可以是 `index_only` 或 `product_grounding_only`。

## 3.2 具体优先级

- **P0，先完成**：旧 NHC 资料适配、WorldFloods 小样本；Storm Events/IEM/IBTrACS/FPA-FOD 索引；NHC/NWS/ECMWF/NWPS 短窗口采集器；GEE GFS 单 AOI 原型。
- **P1，并行扩大**：SEVIR/Digital Typhoon/洪水与野火集；GHCNd/GHCNh、USGS、FIRMS、Sentinel、IMERG、HKO、CO-OPS；EM-DAT 有权限后加入。
- **P2，补齐类别和地域**：雪、旱、沙尘、风云/CMA、GESLA、MeteoNet、FLOGA；MRMS/NEXRAD/GOES 只先选少量产品和事件窗口。
- **P3，独立扩展/相关工作**：OISST、Landslide4Sense、CLLMate、AFDBench。它们保留候选身份，不因为论文有数据规模就假定已获得许可和文件。

完整映射在 `SOURCE_REGISTRY_NEXT_V1.json`。P0 不表示已经获准执行网络任务。

## 3.3 本轮复核到的几项接口变化

1. ECMWF Open Data 是 IFS/AIFS 公开子集，最近 12 个运行滚动保留；官方文档说明 IFS Cycle 50r1 后 06/18 UTC 的部分旧 stream 已迁移。adapter 不能照抄过时脚本；具体参数在 source lock 中逐项冻结。[S1]
2. NWS API 的 alerts 历史窗口短，且雷达端点不等于可直接下载雷达栅格。先保存实际 CAP/JSON 正文和生命周期关系。[S2]
3. GEE GFS 有 `creation_time`、`forecast_time`、`forecast_hours`；累计降水时间窗口随时效变化，不能直接把全部时效相加。[S3]
4. GEE IMERG 的 provisional 可被后续产品替换；算法迁移期间更需区分 run/version。保留当前资料，不用历史日期重查冒充同版本。[S4]
5. FPA-FOD 第七版官方已提供约 266 万条 1992–2024 记录，但页面说明地图服务仍可能是第六版；获取归档版本与地图服务必须分开核验。[S11]
6. GHCNh 为下一代小时资料，新增持续接口优先评估它，而不是假定旧 ISD 是唯一当前来源。[S9]
7. 本轮 NHC GIS RSS 文档再次访问未成功，因此在来源记录中只能保留 prior-documented、live-connectivity-unverified；不能标成新 feed 已接通。

不是本轮逐一核查全部 45 个接口。registry 保留前期目录口径，对少数关键条目标记本轮文档复核；所有真实数据/连接器计数仍为空，待实际取得后更新。

---

# 4. 事件身份、极端性和划分：在扩大数量前先做好

## 4.1 三种“事件”必须分开

- `source_record`：EM-DAT 国家行、Storm Events 县报告、IEM 预警记录、FIRMS 检测点等原生对象。
- `physical_event_group`：按公开的、版本化的归并规则认为同属一次物理过程的对象。
- `split_group`：为了避免训练/测试相互泄漏而共同分配的关联事件集合；可能比单个物理事件更大。

同一气旋引发不同地区洪水，可用 `related_to`/`triggered_by_claim` 表达关联，不直接删成一类或把关联当成经证实因果。共享原影像、预报、同一天气系统的近重复切片需要 split 隔离。

## 4.2 链接策略

1. 优先官方 stable ID 与可信跨表映射，例如气旋 SID/ATCF、预警 lifecycle key。
2. 然后使用受约束的地点、时间、类别与来源链接，记录匹配方法。
3. 不确定匹配记 `candidate_link`；没有证据不强行合并。
4. 归并规则不能只靠“时间相近”；避免传递闭包把整季风暴串成一个事件。为每条边保留原因，检查异常巨大连通组。
5. 对尚未能确认同一物理事件、但可能泄漏的项，可保守共置 split 或隔离，同时不宣称物理去重已经完全解决。

验收包含跨国多行、县级展开、图块重叠、同源派生产品、跨盆地 ID 和一季连续天气的最小样例。

## 4.3 极端性规则

`ExtremeDefinition` 保存：变量、单位、空间/时间统计、阈值来源、基准期、季节调整、最短持续时间、缺测容忍与事件合并规则。

- 历史站点百分位仅用开发资料或测试开始前既定基准期确定，不对全测试期重估。
- 所有野火不自动是极端火灾；火险天气与火灾发生/损失分别定义。
- 警报不等于灾害已发生；灾害目录没有记录不等于无灾害。
- 站点小时、周干旱图、每天一张热浪图不自动成为独立事件。
- 质量差/参考缺失的项为 `label_unavailable`，不生成负例。
- 对长尾类别，可以首先评价产品报告忠实度，而不是假装已有完整物理结果标签。

## 4.4 划分与对照

先按事件/资料 lineage 冻结 split，再构造 checkpoint、配对干预、瓦片和问答。保留已有数据集的官方测试使用限制；不把其 test 当开发集试题。

候选 v1 划分为 development / validation / hidden-test，比例先作为配置，不以每个小类别都强行精确比例为目标。已有受保护风暴保持受保护；若项目方案中已看过具体内容，登记 exposure，不继续声称完全未见。

另外留出一条 `prospective_holdout`：模型/任务设置冻结后才采集的事件。它降低部分回忆污染风险，但不是“绝对无污染”证明。

普通天气/无事件窗口从同区域季节和连续时间抽样，保留自然发生率与病例富集集的区别。预警评估不能只由正例灾害目录组成。

---

# 5. 共享数据契约：资产统一，答案按任务定义

## 5.1 最小对象集合

### SourceSpec

```text
source_id, upstream_version, official_origin, access_mode
license_id, redistribution_policy, authentication_kind
native_hazard_mapping, advertised_quantity_with_unit
adapter_version, bounded_scope, actual_capture_status
```

### EventRecord / EventGroup

```text
native_id, provider, hazard_labels, primary_hazard
event_time_or_interval, geometry_or_location, location_precision
event_linkage_version, physical_group_id, split_group_id
extreme_definition_id, reporting_status, source_refs
```

### AssetVersion

```text
asset_version_id, provider_product_key, provider_version
raw_blob_ref, raw_sha256, semantic_metadata_hash
media_type, modality, product_family, measurement_kind
issued_at, observed_at, valid_time_or_window, updated_at
footprint, grid_descriptor, band_definitions
processing_definition_id, derived_from, license_id
```

资产身份至少绑定内容和重要语义元数据。捕获时间、临时 URL、认证 token、无关 HTTP header 不混入内容身份。相同 bytes 但单位/处理语义改变仍需识别新版本。

### AcquisitionObservation / Snapshot

```text
source_scope_id, acquisition_id, discovered_at
body_captured_at, evidence_ready_at, availability_basis
request_result, cursor_partition, retry_history
snapshot_id, cutoff, included_asset_versions, source_coverage
```

历史可用时间未知保留 null。first-seen 仅为本采集器观察；目录项出现不等于正文已经可交付。

### SpatialSupport / CitationSelector

```text
AOI, CRS, coordinate_order, affine_transform, shape, resolution
bands, scale_offset, nodata, valid_mask, public_quality_definition
selector_kind: text_span / table_cell / raster_window / geometry_region
selector binds immutable asset_version and relevant grid/canonical hashes
```

文本定位可复用原行/字节映射；空间定位必须能回到实际提供的裁剪和网格，不能只给一个未定义 region_id。

### TaskSpec / ReferenceSpec

```text
task_profile_version, query_id, query_created_at, target_definition
input_cutoff_mode, snapshot_id, information_access_profile
public_output_schema, private_reference_id, label_tier
cost_latency_profile, deadline_rule, opportunity_id, split_group_id
```

私有参考与公共输入物理隔离。asset 中的自动测量可以作为 private 标签，也可在明确的 structured-input 控制轨公开；不能暗中同时向 raw-image 主轨提供正确测量。

## 5.2 不用一个 enum 表达所有“不知道”

- `not_stated`：合法可见资料未明确陈述目标事实。
- `not_observed`：目标时空支持没有有效观测。
- `not_comparable`：口径、时间、空间或产品类型不足以支持所要求的比较。
- `conflicting_estimates`：兼容对象的不同来源估计未被公开规则仲裁。
- `fetch_failed`、`parser_rejected`、`context_blocked`：基础设施或执行状态，不直接作为自然世界标签。
- `DISSIPATED/ABSORBED` 等保留产品专用状态，不当作其他灾害的通用终止语义。

## 5.3 事实键与版本关系

事实键包括实体或区域、变量定义、测量类别、有效窗口、空间支持、统计口径；必要时增加垂直层、产品族和 ensemble member。

forecast、observation、analysis/reanalysis、impact_report 不能无条件互相 supersede。不同来源同时给出估计通常是并列关系，不是全局按抓取时间 latest-wins。

例：GFS 格点风、NHC 最大持续风、阵风不同；水位和流量不同；总水位与潮汐/增水不同；雪盖、雪深与降雪量不同；热点、活跃火与累计烧毁范围不同。

## 5.4 文件与库

初始使用：JSON/YAML 配置、JSONL 日志、SQLite 单写索引、Parquet 统计、COG/GeoTIFF 与必要的 NetCDF/Zarr。空间资产可导出 STAC，但 STAC 不代替 benchmark 的获取时刻、参考答案和任务语义。[FMT]

依赖按功能 extras/lazy import；离线导入不得初始化 EE、下载权重或请求网络。未知地理/许可字段拒绝进入相应严格轨，不静默丢掉后继续。

---

# 6. Online 设计：先保存容易丢失的业务版本，再按批次发布

## 6.1 三种数据来源时间模式

1. `historical_controlled_replay`：使用历史资料，交付计划是实验控制；不证明历史真实可用性。
2. `collector_observed_replay`：只使用采集器实际获得并可交付的版本；允许断网重放。
3. `prospective_outcome`：预测提交时刻已锁定，未来结果后到；输入与标签成熟时间分别冻结。

模型运行名中的 live 不代表数据实时；读取网页也不自动成为前瞻评测。

## 6.2 在线闭环

```text
discover bounded pages
  → persist discovery record
  → capture raw bytes + safe metadata
  → normalize + validate/quarantine
  → materialize public representation
  → evidence_ready_at
  → seal snapshot at cutoff
  → benchmark replays snapshot without network
```

- 只在对应内容已持久化后推进游标；分区游标和适当重叠回查发现迟到/重处理资料。
- 同 URL 不同内容保存多版；重复同内容复用 blob 但新增捕获观测。
- ETag 不当成 SHA；304 只能复用已真实捕获版本。
- 对 429/5xx 可按预登记有界策略重试数据 GET；每次失败保留。模型输出错误不触发重新生成。
- 请求跳转、大小、路径、内容类型与原生身份校验；密钥和临时签名参数不得写入公开日志。
- snapshot 封存后不补入后来迟到产品。新版本单独发布，旧题目与分母不改。
- 同一个 snapshot 在隔离网络环境生成相同公共输入与预处理身份。

## 6.3 第一个真实采集 scope

实现先用 mock。获得独立授权后再运行小规模 source smoke，参数是候选而非本计划授权：

```yaml
scope_kind: bounded_data_smoke
max_http_requests: 100
max_download_bytes: 2147483648
max_gee_exports: 2
max_runtime_hours: 2
max_AOIs: 2
max_station_count: 5
model_generations: 0
training: false
background_daemon: false
```

大体积数据按独立范围批准，不用该 smoke 范围隐含许可整库下载。ECMWF/NWS/NWPS 等短窗口来源可在第一/第二周启动独立的有限持续采集，其他静态数据慢慢补。

## 6.4 GEE 首发范围

- GFS：`NOAA/GFS0P25`，单 AOI、2m 温度、固定有效时刻、两个发行周期。[S3]
- 随后 Sentinel-1/2：保留轨道/极化或波段/质量层、固定裁剪、重采样与渲染。
- Global Flood Database：历史事件参考/结果层，不是实时洪水帧。
- IMERG：Early/Late/Final 和算法版本登记，保存实际内容，不用一个历史日期再次查询代替版本归档。[S4]

GEE 认证要求具有权限的项目；仅在显式联网 adapter 内初始化。[S13]

不要在循环中对全球 collection 无界 `getInfo()`。按事件范围、时间、变量读取；导出成功并持久化后才 ready。平台计算成本、存储/流量费用与模拟取证成本分开，不承诺无限免费。

## 6.5 前瞻题目目录

旧离线 compiler 使用多期产品目标并集是原先公开设计；新前瞻轨目标必须提前规定，或仅基于当时可用目录生成，保存 `query_created_at`、`catalog_snapshot_id` 和 selection rule。

“因为未来后来恰好有标签而选择早期题目”的样本可作为后验研究子集，不能混入预注册 prospective 主集。

---

# 7. 任务体系：四条轨，避免灾种很多却只有同一种查表题

## R：有来源支持的读取与修订

覆盖尽可能多灾种。任务按产品精确定义：

- 同对象、同目标有效时间的产品版本刷新。
- 数值不变但当前依据变化。
- 不同实体/窗口/统计量的记录不相互覆盖。
- 预警新发、更新、取消、到期的生命周期。
- 缺失支持恢复，已观察的阴性不同于没有观察。

优先数据：现有 NHC、IEM/NWS、GFS、GHCN、CO-OPS、CHIRPS/USDM 等。产品/报告忠实度不是该产品预测真实准确性。

## S：空间与时间证据支持 / 可比性

这是跨模态主任务：

- 同一物理场景，仅改变可见区域；不能说灾情随时间扩大。
- 同一有效时空对象，仅更新产品估计；不能说已观测物理增强。
- 两个实际时刻，在兼容共同空间支持上比较变化。
- 无效像素、未读取、明确无水/无火点分开。
- 雪盖与降雪量、热异常与烧毁面积等测量定义不同，允许不可比较。

优先数据：WorldFloods、Sen1Floods11、Global Flood Database、TS-SatFire、FLOGA、SEVIR、Digital Typhoon；类别不强制使用相同 schema。

自然过程可能同时有多个变化机制。参考允许 `mixed` 或 `undetermined`，不强制单一“真实原因”。严格配对干预只声明控制了的因素，不推断 LLM 内部因果机制。

## A：有限成本与时限的主动取证

先做 NHC READ 环境控制；主研究使用覆盖感知洪水，随后扩展火灾/强对流/站点时序。

初始只给 query、当时允许的目录元数据、已有证据和预算。动作：

```text
READ(public_source_id, optional_selector)
STOP(task_specific_answer)
ABSTAIN(public_reason_code)
```

WAIT 后置，只有时钟/产品到达语义验收后开放。禁止开放任意 URL、目录、Python 或直接访问 Gold 存储。

## V：独立结果验证与预警收益

不作为 R/S/A 发布前置条件。只有数据资格满足时建设：

- 未来站点水位/流量阈值；或未来温度/持续时长阈值。
- 预报/判断在目标结果发生前锁定。
- 后续独立、质量合格观测作为结果，不把当天完整图像当未来标签。
- 同时有无事件窗口，报告虚警、漏报和提前量。
- 各方法共享天气/水文预报底座；获取策略实验中只改变证据选择。

前期无可信预测发行档案或站点映射时，停在 DATA_BLOCKED；不使用 ERA5/NWM retrospective 冒充当时业务输入。

## 7.1 各灾种的任务资格矩阵

数据集发布需生成 `hazard × task_family × modality × label_tier × time_mode` 表。状态至少为：

```text
registered / index_available / assets_captured / reference_certified
public_view_verified / model_ready / evaluated
```

“17 类覆盖”必须同时展示每类实际提供的任务，不声称 17 类都具备未来预警或主动视觉能力。没有可靠标签的类别可先提供非主分数资源，不为凑齐主类而造 Gold。

---

# 8. 自动参考答案：四层可信度、独立检查、失败控制

## 8.1 LabelTier

- `L1_product_fact`：官方/公开产品明示事实。用于读取、版本、作用域；不是物理真值。
- `L2_existing_reference`：已有公开人工标签或已说明的方法参考。保留许可、split、质量和误差。
- `L3_derived_proxy`：冻结算法、阈值/模型产生的测量或代理标签。单列，不当绝对物理事实。
- `L4_verified_outcome`：后续独立观测、成熟质量版本，匹配目标时空/统计量。

L1–L4 不是简单从低到高的通用排名；适合的任务不同。终态报告、事后最大淹没范围和损失数可作结果来源，但不能进入更早的输入。

## 8.2 两条实现应真的有差异

参考编译器从可信源结构求解，独立 public oracle 只从实际公开文本/测量协议重建。可以共享数据类型和哈希，不共同调用决定答案的 reducer。

空间参考分别用像素面积路径与独立网格/几何路径核查，小 fixture 可精确穷举；复杂地理转换用明确容差，不能把浮点差异静默归零。

两者一致只降低实现错误风险，不证明绝对物理正确性或所有任务都有充分标签。

## 8.3 必须击败的错误程序

```text
always_unknown / always_certain
always_latest_document / latest_arrival
ignore_entity_or_window / mix_forecast_observation
copy_previous_forever / keep_stale_same_value_citation
cloud_or_nodata_means_land / sum_overlapping_tiles
use_gust_as_sustained_wind / mix_units_or_datums
read_everything_despite_budget / gold_aware_query
```

`gold_aware_query` 只能是显式 hindsight 诊断上界，不进入可部署方法。若任务无法区分对应错误程序，先修任务定义，不急着增加模型数量。

## 8.4 不能把不支持的任务变成 unknown

解析失败、标签缺失、空间对齐无法确认、许可不明，在准入前记录为独立状态；不能生成看起来正常的 unknown 问答。已经冻结的模型任务出现缺失/失败必须保留分母，不能事后按错误类型删题。

数据有效性撤销需要新的版本/勘误和完整影响记录，而不是悄悄改旧 Gold。

---

# 9. 主动环境的关键规格

## 9.1 三层参考防止“什么也不读就得满分”

- `goal_reference`：当前有限可用证据池与任务 cutoff 下目标的参考答案。
- `visible_reference`：模型实际读取内容支持什么。
- `sufficiency_reference`：在已读取内容和公共目录规则下，目标是否已可确定。

NHC 读到一个旧版 90 KT，不等于已确认最新也是 90 KT；尚未读取的新版是否覆盖目标必须处理。公开 catalogue 不得泄漏 `covers_target` 或最优查询顺序，除非那确实是可获得的公开信息，并作为一个独立元数据条件报告。

## 9.2 覆盖感知的精确诊断

在固定 AOI `D`、已获得有效支持 `O`、已有参考水域 `Y` 下：

```text
L = area(Y ∩ O)
U = L + area(D \ O)
```

对于 `area ≥ T`，`L ≥ T` 支持 yes，`U < T` 支持 no，其余不足。重叠按空间并集；参考缺失不当 land；经纬度像素面积不机械乘常数。

该界限只在相应参考/观测模型下成立，不是现实洪水置信区间。新时刻不能直接与旧时刻的界限相交；自然云下地面不能在同一影像中被“查询出来”。

## 9.3 三条表示轨隔离视觉与规划

1. `oracle_measurement_diagnostic`：按请求区域返回准确参考测量，只用来隔离规划/停止，不评价感知。
2. `frozen_product`：各策略共享固定感知器或实际产品；相对于该产品和独立标签的分数分别报告。
3. `raw_multimodal`：实际图像、公开质量元数据与文字进入模型。私有 water/fire labels、正确面积和正确区域不进入输入。

VLM 不自动理解任意多谱段栅格。冻结 RGB/伪彩组合或专用感知器，记录所有 band、scale、processor 和裁剪。文件路径字符串不算图像实际输入。

## 9.4 信息不足再分为两类

在小型离散操作池中，离线穷举可认证：

- `unavoidable_under_profile`：可用资料、预算、截止时间下无法达到任务充分条件。
- `avoidable_under_profile`：存在可行查询集合，但该策略未取得。

穷举知道完整结果，因此仅是后验测量工具。大空间找不到可行集合不证明不存在，使用 `not_certified`。

## 9.5 成本、时钟和停止

模拟取证成本、实测 token/字节/延迟分别记录。缓存节省实际运行费用，但不能使某个策略在研究成本账本中免费获取证据。

第一版最多四次 READ，再允许一次 final，故每轨迹最多五次模型决策。无效 action 的扣费和结束规则在协议中固定；不得事后为了成功容错重试。

固定 cutoff 任务与滚动时钟任务分开：前者问题目标不随 query耗时改变，后者目标随明确环境时钟变化；不能混用两者的 Gold。

事实不确定不等于必须不行动。V 轨可在研究损失协议下允许预防行动，但不允许伪造确定事实。

---

# 10. 代码组织与开发边界

以下都是新增候选命名；Codex 必须先检查是否存在等价实现再采用，不得盲目创建重复模块。

```text
src/disastertrace/
  data_contract_v2/
    sources.py             # SourceSpec / capabilities / license
    assets.py              # immutable AssetVersion
    acquisitions.py        # capture observations / ready time
    measurements.py        # variable/time/support/units
    selectors.py           # text/table/raster/geometry locators
    tasks.py               # task profile / eligibility
    public_view.py         # explicit allowlist
    legacy_adapter.py      # read-only envelopes for frozen tracks
  event_index/
    taxonomy.py
    native_mapping.py
    linkage.py
    splits.py
    counts.py
    extreme_definitions.py
  source_stream/
    base.py
    scope.py
    store.py
    cursors.py
    snapshot.py
    adapters/              # one source family per adapter
    cli.py
  task_profiles/
    revision.py
    alert_lifecycle.py
    threshold_duration.py
    comparability.py
    eligibility.py
  spatial_evidence/
    grids.py
    masks.py
    comparability.py
    render.py
  coverage_task/
    dataset_adapters.py
    reference.py
    independent_reference.py
    controls.py
  active_evidence/
    environment.py
    nhc_adapter.py
    coverage_adapter.py
    scheduler.py
    baselines.py
    audit.py
  warning_task/
    alignment.py
    targets.py
    fixed_forecaster.py
    outcome_versions.py
    metrics.py
  multihazard_eval/
    model_adapters.py
    budgets.py
    schema_tracks.py
    reports.py
    statistics.py
    release.py
```

新模块首先依赖最小纯 CPU 类型/工具，地理、EE、雷达、transformers/vLLM 等为可选依赖。按源使用官方 loader，并锁版本和许可。不要复制整套 WorldFloods/SEVIR/AFABench 训练栈。

在 AFS 或等价持久目录保存数据/运行结果。路径通过 `DT_DATA_ROOT`、`DT_RUN_ROOT` 配置，不把某个 CCI 临时路径写死到新协议。历史绝对路径不回写修改，而由新 adapter 重定位并记录。

## 10.1 最小接口

```python
# 拟实现的协议，不是当前已有 API。
class SourceAdapter:
    def discover(self, scope, cursor): ...  # bounded page + continuation
    def capture(self, reference, scope): ...
    def normalize(self, captured_asset): ...
    def validate(self, normalized_asset): ...

class TaskProfile:
    def eligible(self, event_bundle): ...
    def build_queries(self, snapshot, frozen_selection): ...
    def compile_reference(self, query, private_inputs): ...
    def render_public(self, query, allowed_assets, carrier): ...
    def score(self, submitted_answer, reference): ...

class ActiveEnvironment:
    def reset(self, episode_id, config_id, repeat_id): ...
    def step(self, state_id, public_action): ...
    def observe(self, state_id): ...
    def replay(self, initial_state, journal): ...
```

## 10.2 来源状态机

```text
documented → schema_mapped → mock_passed → permission_ready
→ live_smoke_passed → snapshot_verified → reference_certified → evaluated
```

每一步有具体产物；不能只用一个 `downloaded=true`。失败和许可阻塞保留在 dashboard。一个来源可只达到 snapshot_verified而没有任务Gold；这不是导入失败，但不能进入主评分。

---

# 11. 运行层：先把成本和故障解释清楚，再扩模型

## 11.1 新轨迹级隔离

每轮读取实际消息、文本token、视觉token、完整输出预留。越界终止本轨迹，写 `context_blocked`，不取消其他独立轨迹；旧 worker-stop 实验保持原状。

不能静默裁剪来源、删除错误历史或降低个别样本输出额度。存在信息压缩方法时，设新 profile并在相同预算下比较。

## 11.2 身份、日志与缓存

trajectory_id绑定任务、事件、模型/processor、方法、重复、成本和曝光设置；每轮记录 source_version、tool结果、实际消息、媒体哈希、裁剪、生成设置、原始 final与acceptance。

不同repeat不能通过复用同一生成缓存伪装重复。配对seed只减少部分差异，不能承诺不同硬件/批次完全确定。模型回答错误/格式错误不重新生成；不确定网络发送保留，恢复策略事先规定。

## 11.3 严格输出与自由输出分轨

沿用“结构约束不编码答案”的原则。grammar只限定格式、类型和公开枚举，不按当前Gold裁掉不正确数值或来源ID。

图文模型需要其真实processor和能力核验，不能复用纯文本Qwen3 thinking分隔假设。已经准备的第二文本模型适配优先复用，不将所有模型工作重复从零做。

## 11.4 实验预算示例

以下全部是后续申请用的候选算术，不是调用授权。实际以已认证task manifest和冻结schedule为准。

| 实验 | 计算 | 上限 |
|---|---|---:|
| 小型静态接口筛选 | 80个指定任务机会 × 2模型 × 3方法 × 2重复 | 960次生成 |
| 主动闭环筛选 | 24个eligible episode × 3策略 × 2模型 × 2重复 × 最多5决策 | 1,440次生成 |
| 两者全部执行 | 上述两项，无额外隐藏条件 | 2,400次生成 |
| 后续正式静态示例 | 3,000个封存机会 × 3模型 × 2方法 × 2重复 | 36,000次生成 |

80任务机会不等于80独立事件；24主动episode先确保所需模型能力，文本/图像/诊断轨分别报告。固定程序策略可能减少生成，但不能把省下预算自动花到额外题。51,200个数据机会不要求每个模型都跑完整多因素矩阵。

预算分开绑定数据字节、GEE计算/导出、GPU-hours、模型调用/token、存储与期限。历史“四H100”只可作新申请的候选上限，不是当前授权。没有确认额度时只产生 dry-run估算。

---

# 12. 指标、基线与统计

## 12.1 四条任务的指标

| 轨 | 主结果 | 必须分开的诊断 |
|---|---|---|
| R | 固定分母的值/键/当前来源联合正确 | 单位、时间、版本、定位、同值旧来源、invalid/missing |
| S | 可答/不可答配对通过、可比性与变化结论正确 | 感知误差、覆盖不足、产品修订、混合机制、无效观测 |
| A | 固定预算下成功率—成本/延迟曲线 | 不足时过度断言、充分时过度拒答、冗余读取、未能认证不可解 |
| V | 检出/漏报、虚警、有效提前量、研究代理损失 | 标签覆盖、已审核/暂定、未检出事件、概率校准条件 |

不要把所有灾种所有任务合成唯一总分。先报task family/hazard macro及事件级结果；零分母为NA，不填0或1。语义正确条件下的分数是诊断，主结果仍保留格式、缺失和执行失败。

## 12.2 强基线

- 最新覆盖版本的确定性解析程序。
- 发行时间倒序读取直到覆盖目标的NHC策略。
- 固定顺序、随机、最便宜优先、最大新增公开覆盖/成本贪心。
- 相同预测底座/感知产品下，仅替换获取策略。
- 全证据能力参考：若超预算，不算合法竞争策略。
- raw-image、structured/oracle-measurement控制、frozen-product轨。
- 主动LLM策略；可选开发集上改进的缺口规划器。

Greedy不能读取私有水面积或未请求内容。所有方法可访问同一候选池、工具能力和公开元数据，不给LLM独占信息来制造优势。

## 12.3 预警损失

先选一种明确任务：同站点未来水位与官方datum/阈值；或可信河段-站点映射下的流量阈值。经验百分位只用训练/既定历史，称高流量代理不称直接淹没。

```text
研究损失 = 漏报代价 + 虚警代价 + 延迟代价 + 取证成本
```

系数与敏感性范围预先冻结。预警提前量同时在匹配虚警约束、检出水平下比较；不能只统计成功预警。若使用概率，必须实际ensemble或仅开发集标定；不编造单次事件唯一正确概率。

NWPS主API与实验接口历史范围有限，必须先检查预测发行档案、后续实测、单位与站点映射。[S10] 无完整数据就不启动V主评分。

## 12.4 统计设计

同一物理事件、同一原图的瓦片、邻近重叠站点窗口、同一预报版本的派生题有依赖。按预声明事件或split cluster重采样；多任务配对按root配对，不以模型调用数代替独立样本数。

报告逐灾种、逐来源/地域、逐表示轨、逐repeat与成本区间。类别多但某类只有少量事件时，给数量和不确定性，不作强总体结论。探索子集与最终确认子集分开，避免将开发后筛选的难题声称为自然总体。

---

# 13. 论文定位与近邻：不靠模块堆叠宣布 novelty

| 近邻 | 已覆盖的方向 | 本项目需要实证证明的增量 |
|---|---|---|
| StateMemBench | 当前/过时状态、替代关系、依赖检查，且考虑长度/成本对照 | 不仅状态更新；时空观测支持与取证充分性是否形成独立能力 [R1] |
| EarthVerse | 多灾种事件调查、主动选证、兼容尺度/单位、可执行计算和provenance | 成本和时间改变主要成功指标；信息不足与模型错误分开，而非仅最终调查完成度 [R2] |
| DORA | 多传感器灾害感知、工具、时序和业务任务 | 可认证的证据缺口与受预算主动获取；不能宣称首次动态灾害Agent [R3] |
| AFABench | 有代价的序贯特征获取及多个策略 | 灾害版本、异步可用性、空间支持与决策窗口的专门协议；主动获取思想本身不是新提出 [R4] |
| AFDBench | 单时间步结构化预报到专业讨论与输入忠实度 | 不生成长AFD争风格分数，评价跨来源/版本/覆盖下判断与取证 [R5] |
| SEVIR / WorldFloods / TS-SatFire | 已有天气感知、范围/时序与预测数据 | 复用标签，提出不同的支持/获取问题；不把上游原任务重新命名成自己的创新 [S5–S8] |

研究主张分三个可证伪问题：

- RQ1：完整输入下得分高，是否仍能在不完整、延迟或版本变化下形成可靠判断？
- RQ2：在证据不足、充分、不可比较之间，模型能否正确区分；这是否与单纯最新值抽取不同？
- RQ3：相同底座、相同成本约束下，主动获取是否优于强固定/贪心流程，并跨事件、灾种和观测条件泛化？

正式贡献建议：

1. 带版本、观测支持与获取时间的多灾种证据资源和可复现任务。
2. 区分目标真值、已见支持与信息充分性的配对/主动评测协议。
3. 实证分解信息、感知、版本、规划和时效瓶颈；有条件报告独立结果验证的增量收益。

没有观察结果前不用“显著提高”“首个全球”“非常novelty”作事实结论。若Agent不优于简单程序，保留负结果；benchmark的价值可以是揭示局限，不必保证自己的方法胜出。

## 13.1 AutoResearch 的位置

只作为后续dev-only方法/测试发现case study：冻结任务、Gold、成本、隐藏测试，研究Agent根据失败改变一个查询/停止组件，比较真实改进与预算；隐藏测试不参与迭代。

不要同时启动完整FrontierSearch、GRPO、新视觉模型训练和多Agent架构。先证明核心测试值得研究，再决定是否增加独立方法论文。

---

# 14. 12周完整路线与并行安排

这是开发排期参考，不是工期保证。按“一名主要研究者＋Codex并行分支，具备现有CPU/GPU环境但需新授权”的假设规划。受限数据审批、真实事件积累、观测审核可能超出12周。

| 时段 | 主要任务 | 并行任务 | 阶段出口 |
|---|---|---|---|
| W1 | 实际状态、schema、17类/45源注册、mock快照 | 旧NHC只读封装；短窗口来源权限清单 | 数据层与旧任务兼容，2种fixture断网回放 |
| W2 | 事件索引、版本/游标、NHC/GFS小连接器 | 取得新许可后短窗口有界采集；WorldFloods loader | 至少两种真实源smoke，否则明确阻塞 |
| W3–4 | 索引广覆盖；SEVIR/台风/洪水/野火资产按需接入 | 站点、冰雪/旱/海岸长尾资料映射 | M1约80事件/8类，R/S任务初始资格表 |
| W5–6 | 参考编译器、独立求解、负控、事件划分 | 所有17类的缺口补齐与在线快照 | M2约300–500事件/12类；主动环境离线闭环 |
| W7–8 | 获授权的小型图文/文本实验、成本基线、故障隔离 | 扩展主数据核心；水文结果资料可行性 | 可解释的R/S/A结果，不仅格式差异 |
| W9–10 | 固定v1核心、跨域/源/预算实验、统计 | V轨数据资格通过才运行；滚动版本 | M3约1600目标及200–300主动子集的实际认证清单 |
| W11–12 | 隐藏测试冻结与独立执行、复现、数据卡、论文 | 新事件滚动发布原型 | 可引用release、可复算结果、明确覆盖与局限 |

建议并行分支：`mh/data-foundation`、`mh/source-adapters`、`mh/task-oracles`、`mh/eval-runtime`。由同一接口版本和接口测试控制合并；不要让四个Codex各自发明schema。运行中实验固定源码，开发分支不热更新生产任务。

---

# 15. 可直接执行的PR拆分

每个PR需要更新 `docs/multihazard/IMPLEMENTATION_STATUS.md`，列实际命令、退出码、测试、新数据/生成调用、产物、阻塞。新命令先实现再宣称可运行。

## MH-00｜现有基线与历史保护

- 依赖：无。
- 输入：当前HEAD、AGENTS、CURRENT_PHASE、已有源包与审阅计划。
- 实现：核查已完成/未知阶段；定位本地数据；列冻结路径；区分文本正式接口与早期通用scaffold。
- 交付：BASELINE_REVIEW、HISTORICAL_PROTECTION、实际CPU测试记录。
- 验收：不改变旧科学产物；缺全包明确阻塞；不重启P11–P14。
- 能消除的不确定性：避免再重复P6/P7/P10或误判当前作业状态。

## MH-01｜统一资产与公共视图契约

- 依赖：MH-00。
- 实现：第5章对象、强类型时间/单位/selector、public allowlist、legacy只读封装。
- 交付：JSON Schema与NHC/GFS/raster三个fixture。
- 验收：同bytes不同语义可区分；未知时间不造假；私有字段/标签/未来metadata不泄漏；旧request/scorer不变。
- 能消除的不确定性：新来源是否能进入实际任务，而不是堆在metadata。

## MH-02｜17类/45源注册与计数

- 依赖：MH-01。
- 实现：导入随包registry，保留native分类、online类别、许可、来源版本与实际状态。
- 交付：机器注册表、taxonomy映射、hazard coverage表。
- 验收：45个唯一source ID、17类；所有actual counts初始null；同一数量单位不可混加；未知许可禁止再分发。
- 能消除的不确定性：明确要接哪些源、每类真实能提供什么。

## MH-03｜事件索引与划分

- 依赖：MH-02。
- 实现：Storm Events/IEM/IBTrACS/FPA-FOD接口先mock/本地小样本；事件链接与split规则。
- 交付：native records、link evidence、physical groups、split groups、dedup报告。
- 验收：跨国/县展开与图块不计独立事件；不因宽泛时间连接吞并整季；heldout保护和别名碰撞检查。
- 能消除的不确定性：扩量是真正新增过程还是重复报告。

## MH-04｜Online存储、游标与冻结快照

- 依赖：MH-01、MH-02。
- 实现：discover/capture/normalize/validate/snapshot，mock版本覆盖、分页、中断和重试。
- 交付：内容寻址存储、acquisition log、cutoff snapshot、replay。
- 验收：同URL新内容两版；304/404/429/5xx分别记；未落盘不ready；迟到不回填；断网同输入。
- 能消除的不确定性：在线数据能否真正成为可重复证据。

## MH-05｜短窗口流与GEE真实smoke

- 依赖：MH-04；真实执行另需DATA_SCOPE/GEE_SCOPE。
- 实现：NHC/NWS/ECMWF/NWPS受限采集、GFS双cycle小AOI；本地不能认证则保持mock。
- 交付：每源至少一份实际内容与安全元数据、版本/时间比较、限额报告。
- 验收：不把目录发现当正文ready；参数对应当前源文档；credential不落日志；0模型调用。
- 能消除的不确定性：明确哪些online接口真的接通，而不是只存在代码。

## MH-06｜现成多模态资产接入

- 依赖：MH-01、MH-02、MH-03；实际获取另scope。
- 实现：WorldFloods、SEVIR、Digital Typhoon、Sen1Floods11/GlobalFloodDB、TS-SatFire薄adapter；后续FLOGA/MeteoNet。
- 交付：小文件/资产manifest、原事件ID、split、label tier、raw/derived/private层。
- 验收：不把弱标签当人工；不将原test调参；不补造跨传感器配对；实际图像bytes可还原。
- 能消除的不确定性：多模态数据可用性和标签范围。

## MH-07｜全球站点、连续场与长尾类别

- 依赖：MH-02、MH-03、MH-04。
- 实现：GHCNd/GHCNh、USGS/CO-OPS、CHIRPS/USDM、SNODAS/MODIS Snow/CAMS、HKO和许可源。
- 交付：按站/变量/季节的可用性、ExtremeDefinition、质量/缺测表。
- 验收：单位/datum/积累窗口；普通天气对照；模型分析不作原始实测；许可阻塞不影响其他source。
- 能消除的不确定性：17类不是仅标签列表，长尾确有可评分内容。

## MH-08｜R/S自动任务与独立oracle

- 依赖：MH-03、MH-06或MH-07的至少一个可用来源。
- 实现：R修订/预警/阈值；S覆盖/可比性；双实现与负控；按profile声明资格。
- 交付：TASK_CARDS、public/private包、mutant matrix、reference一致性报告。
- 验收：错误程序在对应任务失败；zero-denominator为NA；没有参考不生造unknown；形成M1/M2真实计数。
- 能消除的不确定性：任务是否测目标能力而非模板/标签捷径。

## MH-09｜主动环境与NHC工程控制

- 依赖：MH-01、MH-08。
- 实现：reset/READ/STOP/ABSTAIN、三层参考、成本、状态日志、有限catalogue。
- 交付：已有开发NHC目标的主动episode和倒序读取基线。
- 验收：永远不读/unknown不能满分；目录无隐藏coverage收益；同journal重放一致。
- 能消除的不确定性：接口是否真正改变模型可见信息。

## MH-10｜洪水主动覆盖与跨灾种复用

- 依赖：MH-06、MH-08、MH-09。
- 实现：L/U参考、重叠/掩膜、三表示轨、公开覆盖贪心；野火/强对流通过同环境task adapter接入。
- 交付：eligible主动子集、不可避免/可避免不足证书（可计算部分）、场景级配对。
- 验收：同景访问变化不伪装自然演化；不能查云下真值；贪心不看隐藏labels；阈值标签选择子集独立标记。
- 能消除的不确定性：CV、取证和证据充分性是否各自可被定位。

## MH-11｜多模态runner与轨迹故障隔离

- 依赖：MH-09；图文部分依赖MH-06。
- 实现：真实processor、图像/文本token预算、trajectory独立停止、结构约束与自由输出分轨。
- 交付：ModelCapability卡、actual input捕获、mock/installed-adapter诊断。
- 验收：一条溢出不取消邻居；不能静默裁剪；不同repeat独立；图片进入实际wire/processor；grammar无答案依赖。
- 能消除的不确定性：格式/上下文/适配器是否造成伪方法差异。

## MH-12｜开发模型实验与统计

- 依赖：MH-08、MH-10、MH-11、新MODEL_SCOPE。
- 实现：强基线、固定机会、阶段预算、hazard/task/source/repeat报告、失败分类。
- 交付：success–cost曲线、来源绑定/覆盖错误、实际资源、配对结果。
- 验收：完整分母，非只成功样本平均；负结果保留；探索性选择有记录；不复用旧轨成绩填新cell。
- 能消除的不确定性：新任务是否产生独立研究发现、是否值得规模化。

## MH-13｜结果验证可行性与V轨

- 依赖：MH-05、MH-07、MH-11；执行另MODEL_SCOPE。
- 实现：3–5站点资料可行性、可信crosswalk、预测与后续观测锁定、无事件对照、固定底座。
- 交付：DATA_GATE、OUTCOME_TASK_CARD、预警/代理损失报告或DATA_BLOCKED。
- 验收：水位/流量同口径；阈值不用测试调；缺测不当负例；后验不能回填输入；无数据不称预警改善。
- 能消除的不确定性：判断可靠性是否能与独立结果相关联。

## MH-14｜正式v1与隐藏测试

- 依赖：MH-03、MH-08、MH-12；V结果仅在MH-13通过时纳入。
- 实现：数据/标签/模型/提示/成本/scorer冻结，独立heldout执行计划和event-cluster统计。
- 交付：实际达到的17类资格矩阵、目标1600事件核心、主动子集、固定denominator。
- 验收：先冻结后看测试；不足类别不造数；不因追加来源重写旧split；新测试运行另授权。
- 能消除的不确定性：开发发现是否具有跨事件泛化。

## MH-15｜复现、许可与滚动发布

- 依赖：MH-14、MH-04；发布另scope。
- 实现：source/data/model cards、下载脚本、允许分发的资产、受限source分发策略、离线重放、小benchmark示例。
- 交付：版本化release、覆盖/许可证矩阵、复现说明、一个新事件rolling版本流程。
- 验收：授权资产才入公开包；敏感headers/凭据不存在；无网络重建固定输入；修改/删除源有勘误机制。
- 能消除的不确定性：其他研究者能否实际使用并复现，而不是只看hash报告。

---

# 16. Gate、停止条件与研究风险

| Gate | 通过标准 | 未通过时 |
|---|---|---|
| G0 历史与范围 | HEAD/资料/旧授权确认，科学文件未改 | 不启动新生产，离线可独立工作继续 |
| G1 来源快照 | 同名版本、迟到、断点、时钟与内容均可重放 | 先修来源层，不把最新查询当benchmark |
| G2 标签语义 | 自动参考、public重建、负控可区分 | 相应profile隔离，不用LLM补Gold |
| G3 多模态真实性 | 实际图像进入模型、raw轨无私有标签，空间关系可还原 | 只称结构化/产品理解，不称视觉能力 |
| G4 主动环境 | 三层参考、预算与止步语义成立，基线不能靠拒答投机 | 修协议，不增加“更难”任务掩盖漏洞 |
| G5 执行可靠性 | 轨迹独立、实际token上下文、完整失败记录 | 先解决接口/资源混杂 |
| G6 研究发现 | 能分解信息不足/模型错误，或展示强基线下的可靠负结果 | 收缩方法claim，不调整题保证胜出 |
| G7 结果验证 | 当时发行输入、独立后续观测、无事件、对齐齐全 | 不纳入预警价值结论，不阻塞R/S/A发布 |
| G8 发布 | 许可/数据卡/冻结/复现/隐藏测试状态明确 | 只发布代码和可分发manifest |

几个高风险点：

- 45个adapter同时完整开发不可控：先共同capture/registry，source-specific语义逐个验收；任务资格而非adapter数量驱动。
- 大量真实资料但没有自动标签：可留资源层，不能全部生成主评分题。
- 多模态只是重复文本：做同数据的text-only/structured/raw对照，视觉非必要则诚实定位。
- 长历史只制造截断：固定信息/长度控制，单独分析引用ID复杂度。
- 全球覆盖其实主要美国：报告地域份额和来源密度，不在标题中暗示均匀代表性。
- “在线”缺真实监听：标controlled replay，不填first-seen；短滚动捕获尽早另scope执行。
- 新事件积累不足：固定历史核心先发，prospective作为持续版本，不承诺12周自然灾害数量。
- 结果改善仅在任意成本表下出现：报告多预声明成本设定，不声称已减少实际损失。

---

# 17. 第一轮交给Codex的范围与第一周产物

## 17.1 第一轮实施范围

只实施 **MH-00、MH-01、MH-02、MH-04 的离线部分，以及 MH-03 的本地fixture/已有资料映射**。不要一开始先花两周写新模型runner；也不要再次只生成方案文档。

第一周应当实际产生：

1. 当前工作区/历史保护清单和真实测试记录。
2. 17类/45源机器注册表，所有未取得数量为null，权限明确。
3. 一个NHC文本和一个地理fixture能进统一资产与来源日志，并断网重放。
4. 至少四个事件目录的native字段映射/小样本测试，先从本地已有文件或fixture开始。
5. 有界online scope与mock版本/分页测试，实际联网待独立授权。
6. 可追踪的PR/backlog状态与下一阶段数据许可/文件阻塞表。

## 17.2 后续小规模联网范围

第一轮代码验收后，先对已允许公共源实施有限真实smoke：NHC/NWS、一个索引文件、GEE小AOI。受限源没有凭据时不绕过、不借他人账号、不抓网页代替授权下载。

数据抓取权限与GPU生成权限分开；常驻采集需明确持续时间、请求率、磁盘上限和停止命令。当前对话不启动后台服务。

## 17.3 拟新增CLI示意

以下命令只有在相应模块实现后才可使用，不是现在仓库已有命令：

```bash
python -m disastertrace.source_stream registry-validate --registry SOURCE_REGISTRY_NEXT_V1.json
python -m disastertrace.event_index ingest --source noaa_storm_events --input LOCAL_FILE --offline
python -m disastertrace.source_stream plan --scope scopes/data_smoke.yaml --dry-run
python -m disastertrace.source_stream snapshot-verify --snapshot SNAPSHOT --offline
python -m disastertrace.task_profiles certify --profile PROFILE --snapshot SNAPSHOT --offline
python -m disastertrace.active_evidence rehearse --suite SUITE --backend deterministic-fixture
```

不得把命令设计示意写成“已经运行成功”。实际CLI应遵循仓库风格，并在实现后替换计划中的拟定接口说明。

---

# 18. 来源、核查与本文件可主张范围

## 18.1 前期附件

- [CAT] 45项数据源目录和JSON注册表（2026-09-10）。数量/接口是前期核查的公开口径，不是本项目实际下载总量。
- [AE] 主动取证与预警验证增量计划（2026-09-10）。本次保留其语义，扩大数据接入并行度。
- [FMT] 数据格式审阅与online接入计划。保留资产/时间/支持/快照设计。

原附件的哈希及本次读取范围记录在 `REVIEW_SCOPE_AND_SOURCES.json`。本计划新增的配额、时间表、PR编号、预算示例均为设计建议。

## 18.2 本轮重新读取的仓库来源

```yaml
C0:
  source: GitHub branch list
  url: https://api.github.com/repos/sisuolv/disastertrace-benchmark/branches?per_page=100
  reviewed_branch: next-phase-v1
  reviewed_commit: 36082c42a93e11f67d274d8000c87cd1dc098d74
C1:
  path: disastertrace-starter/CURRENT_PHASE.md
  note: 内容时间2026-09-08，不是实时服务器状态
C2:
  path: disastertrace-starter/src/disastertrace/forecast_task/protocol.py
  note: 累计公开文档与精确自身历史前缀
C3:
  path: disastertrace-starter/src/disastertrace/forecast_task/contract.py
  note: 固定NHC三字段自然预报输出
```

## 18.3 本轮外部原始来源复核

```yaml
S1:
  name: ECMWF Open Data
  url: https://www.ecmwf.int/en/forecasts/datasets/open-data
S2:
  name: NWS API documentation
  url: https://www.weather.gov/documentation/services-web-api
S3:
  name: GEE GFS catalog
  url: https://developers.google.com/earth-engine/datasets/catalog/NOAA_GFS0P25
S4:
  name: GEE IMERG V07 catalog
  url: https://developers.google.com/earth-engine/datasets/catalog/NASA_GPM_L3_IMERG_V07
S5:
  name: WorldFloods v2 loader and masks
  url: https://spaceml-org.github.io/ml4floods/content/ml4ops/HOWTO_WF2_load_dataset.html
S6:
  name: SEVIR author code
  url: https://github.com/MIT-AI-Accelerator/eie-sevir
S7:
  name: Digital Typhoon author code
  url: https://github.com/kitamoto-lab/digital-typhoon
S8:
  name: TS-SatFire author code
  url: https://github.com/zhaoyutim/TS-SatFire
S9:
  name: NOAA GHCNh
  url: https://www.ncei.noaa.gov/products/global-historical-climatology-network-hourly
S10:
  name: NOAA NWPS API coverage
  url: https://api.water.noaa.gov/about/api
S11:
  name: FPA-FOD seventh edition
  url: https://www.fs.usda.gov/rds/archive/catalog/RDS-2013-0009.7
S12:
  name: EM-DAT official
  url: https://www.emdat.be/
S13:
  name: GEE authentication
  url: https://developers.google.com/earth-engine/guides/auth
R1:
  name: StateMemBench
  url: https://arxiv.org/abs/2608.19652
R2:
  name: EarthVerse
  url: https://arxiv.org/abs/2608.23525
R3:
  name: DORA
  url: https://arxiv.org/abs/2605.11633
R4:
  name: AFABench
  paper: https://arxiv.org/abs/2508.14734
  code: https://github.com/Linusaronsson/AFA-Benchmark
R5:
  name: AFDBench
  basis: 本对话提供的7页论文，任务定义section3.1
  paper: https://arxiv.org/abs/2608.24954
```

本轮未对全部外部项目做clone/安装/测试。论文/文档存在不等于代码已适配。NoAA Storm Events入口重定向仅核对地址；NHC GIS文档访问未成功，不把它写成live验收。所有上游代码引用前需pin实际revision和许可。

## 18.4 交付验收与诚实边界

本次实际交付：总计划、Codex启动提示、45源路由表、17类数量规划、PR依赖backlog、来源/核查范围、文件完整性检查。

本次未交付：已实现新adapter、已下载的新增事件集、已认证GEE、已运行的多灾种模型实验、已证实的预警收益、已更新的Notion或GitHub页面。

**最终判断标准不是接入了多少名字、写了多少测试或生成了多少问题，而是：数据能否被复现地交付，任务是否具有可信参考，模型失败是否可以被科学解释，新增能力是否在强基线下具有可检验价值。**
