# Codex 启动与恢复指令

## 放置方法

将 `DISASTERTRACE_COMPLETE_NEXT_PLAN_2026-09-10.md` 和本包的 JSON 规划文件放到当前项目的新目录，例如 `plans/multihazard_v1/`。不要覆盖已有计划、冻结 AGENTS、历史数据或旧执行包。

`AGENTS_MULTIHAZARD_ADDENDUM.md` 是补充执行规则，不是替换现有 AGENTS.md 的文件。先遵守当前目录中适用的 AGENTS，再采用本包中与当前任务一致的规则；冲突需明示，不修改冻结文件来消除冲突。

## 首轮指令：完成代码与测试，而不是再写一份方案

```text
请完整读取：
1. 当前目录适用的 AGENTS.md；
2. disastertrace-starter/CURRENT_PHASE.md 与实际较新的阶段终态材料；
3. DISASTERTRACE_COMPLETE_NEXT_PLAN_2026-09-10.md；
4. SOURCE_REGISTRY_NEXT_V1.json、HAZARD_COVERAGE_PLAN_V1.json、IMPLEMENTATION_BACKLOG_V1.json；
5. 本包 AGENTS_MULTIHAZARD_ADDENDUM.md。

计划核查基线为 next-phase-v1 的
36082c42a93e11f67d274d8000c87cd1dc098d74。
如果工作区更晚、有用户修改或已有等价模块，先列相关差异，使用实际当前代码。
不 checkout/reset 到旧版本，不从 main 或早期 starter 重建。

本轮只实施 MH-00、MH-01、MH-02、MH-04 的离线部分，
以及 MH-03 可使用本地既有文件或 fixture 完成的映射/归并测试。

目标：
- 核对现有源码、数据、结果和冻结范围；
- 17类/45源全部进入机器注册表，但未取得数量保持 null；
- 新资产、采集时间、selector、任务资格与公共视图契约；
- 统一 source_stream，而不是重复创建 online_sources/source_stream；
- 同URL内容变更、分页、迟到、304/429/5xx、崩溃与snapshot重放的mock测试；
- 一个NHC文本和一个地理fixture能够进入新封装并断网重放；
- 对本地可用的事件目录写薄adapter、native字段映射和事件/切片计数测试。

请先补针对错误行为的测试，再实现最小改动。充分复用当前现有模块，
不要只产生README、摘要、空类或pass占位函数，然后声称功能完成。

不得改变历史 controlled/forecast_task 协议、Gold、scorer、引用标准、
capture、失败、执行claim、历史源码快照和已消费的生产任务。
新增轨道使用新namespace/version/output，不为了新数据放宽旧validator。

默认零外部调用：不读取凭据、不下载新数据/权重、不认证GEE、
不提交云导出、不启动daemon、不进行模型生成/GPU/训练/heldout、不push或公开发布。
旧自主窗口已经失效，历史270次/2160次/四H100等数字不是当前授权。
模型调用、数据下载、云端计算和部署各自需要新scope与资源预算。

缺少原始capture、真实数据、许可证或当前环境依赖时，明确标BLOCKED，
继续完成不受阻塞的纯离线实现。不要以程序诊断充当模型回答，
不要以历史通过的测试数量充当当前验收。

每个PR完成后更新 docs/multihazard/IMPLEMENTATION_STATUS.md：
实际修改、命令、退出码、测试、scope、数据/模型调用数量、产物路径、
已实现与未验证范围、阻塞及下一步。

停止时交付可审阅diff与实际测试结果；默认停在 OFFLINE_READY。
不要自行进入MH-05真实采集或MH-12模型实验。
```

## 恢复指令

```text
继续执行 DisasterTrace 完整后续计划。
先读取 IMPLEMENTATION_STATUS 与 backlog，再核对当前HEAD、工作区和冻结文件差异。
只继续上一轮尚未完成的离线PR，不重新执行已消费任务。
如已经得到外部scope，先核对其期限、来源/区域/变量、请求/字节/模型预算，
不能将DATA_SCOPE当MODEL_SCOPE或CLOUD_SCOPE。
按依赖和验收推进，每步留下真实命令、测试和调用账本。
```

## 后续授权后的有限采集指令模板

```text
离线验收已通过。现在仅执行一个明确提供的 DATA_SCOPE（另附文件）。
先校验许可、来源/时间/AOI、最大请求数、字节数、截止时间和停止条件。
先dry-run，随后只在scope内捕获数据，保存原始响应、版本、时间和失败。
没有GEE_SCOPE时不提交GEE计算；没有MODEL_SCOPE时不生成模型答案。
scope结束后封存snapshot并断网验证；不自动转为无限期采集。
```
