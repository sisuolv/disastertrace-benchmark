# DisasterTrace 完整后续计划执行包

这是基于已有代码与前期方案的**规划包**，不是新实现或实验归档。

## 主要文件

- `DISASTERTRACE_COMPLETE_NEXT_PLAN_2026-09-10.md`：总计划，覆盖17类、45源、数据契约、事件划分、online快照、R/S/A/V任务、PR与验收。
- `CODEX_START_COMPLETE_PLAN.md`：首轮、恢复与有界采集提示。
- `AGENTS_MULTIHAZARD_ADDENDUM.md`：补充规则；不要覆盖冻结AGENTS。
- `SOURCE_REGISTRY_NEXT_V1.json`：沿用前期45源目录，增加优先级、路线、权限与实际计数空字段。
- `HAZARD_COVERAGE_PLAN_V1.json`：17类与候选1600主事件配额；全部是规划值。
- `IMPLEMENTATION_BACKLOG_V1.json`：MH-00～MH-15依赖、scope与交付。
- `REVIEW_SCOPE_AND_SOURCES.json`：本次材料范围、哈希、核查与未完成事项。
- `DOCUMENT_VALIDATION.json`：文档/JSON内部一致性检查；不是仓库测试。
- `SHA256SUMS.json`：本包其他交付文件的内容校验。

## 第一轮使用

先打开总计划第0、1、14、15、17章，然后使用启动提示。

全体数据源先进入注册与可用性清单；多模态深度任务按资格开展。这调整了旧计划中全局限制到少数灾种的调度，但没有改变旧实验的科学事实或协议。

所有真实运行默认未授权。上游数据宣传规模不是项目已获取规模，实际计数初始为null。

本轮仅做了选定代码/资料读取、关键外部文档复查与规划文件校验。没有新数据采集、GEE认证、GPU/API生成、训练或整仓测试。
