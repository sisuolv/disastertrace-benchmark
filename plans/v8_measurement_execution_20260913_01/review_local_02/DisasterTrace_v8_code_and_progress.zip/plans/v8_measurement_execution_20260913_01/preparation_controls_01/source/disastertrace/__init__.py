"""Frozen synthetic decision controls."""
