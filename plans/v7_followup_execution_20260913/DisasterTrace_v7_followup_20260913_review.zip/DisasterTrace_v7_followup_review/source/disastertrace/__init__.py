"""Isolated offline replay package without optional app dependencies."""
