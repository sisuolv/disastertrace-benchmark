#!/usr/bin/env python3
"""Validate THIS planning bundle only. Never runs repository code, network, or models."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


def load_json(path: Path):
    def reject_constant(value: str):
        raise ValueError(f'Nonfinite JSON value: {value}')
    return json.loads(path.read_text(encoding='utf-8'), parse_constant=reject_constant)


def validate(root: Path) -> dict:
    import yaml  # Used solely to check the configuration templates in this bundle.

    task_doc = load_json(root / 'tasks.json')
    tasks = task_doc['tasks']
    ids = [t['id'] for t in tasks]
    assert len(ids) == len(set(ids)) == 13, 'Expected 13 unique planning tasks'
    table = {t['id']: t for t in tasks}
    visited: set[str] = set()
    active: set[str] = set()
    order: list[str] = []

    def visit(key: str) -> None:
        assert key in table, f'Unknown dependency {key}'
        assert key not in active, f'Dependency cycle at {key}'
        if key in visited:
            return
        active.add(key)
        for dep in table[key]['depends_on']:
            visit(dep)
        active.remove(key)
        visited.add(key)
        order.append(key)

    for key in ids:
        visit(key)
    for task in tasks:
        assert task['status'] == 'planned', 'Plan must not claim a completed research task'
        assert task['scientific_admitted'] is False
        assert not any(task['implementation_status'].values())
        assert task['proposed_outputs'] and task['acceptance_criteria']

    intents = load_json(root / 'test_cases.json')['cases']
    assert len({c['id'] for c in intents}) == len(intents)
    assert all(c['owner_task'] in table and c['status'] == 'not_run' for c in intents)

    sources = load_json(root / 'sources.json')['sources']
    source_ids = {s['id'] for s in sources}
    assert len(source_ids) == len(sources)
    assert all(s['rerun_or_reproduced'] is False for s in sources)
    main = (root / 'CODEX_NEXT_PLAN_CN.md').read_text(encoding='utf-8')
    refs = set(re.findall(r'\b[RE]\d{2}\b', main))
    assert refs <= source_ids, f'Missing sources {refs-source_ids}'
    assert len(re.findall(r'^```', main, flags=re.M)) % 2 == 0, 'Unclosed Markdown code fence'
    for key in ids:
        assert re.search(rf'^### {key}｜', main, flags=re.M), f'Missing main section {key}'
    for i in range(1, 17):
        assert f'| H{i:02d} |' in main
    for i in range(10):
        assert f'| X{i:02d} |' in main
    assert task_doc['existing_scientific_scope']['X09_original_meaning'] == '联合目标推理扩展'

    configs = {p.name: yaml.safe_load(p.read_text(encoding='utf-8'))
               for p in sorted((root / 'configs').glob('*.yaml'))}
    offline = configs['offline_first.yaml']
    for dim in ('new_model_calls','paid_api_usd','gpu_count','gpu_hours','download_bytes','network_requests'):
        assert offline['budget'][dim] == 0, f'Unsafe default {dim}'
    for key in ('allow_git_push','allow_license_acceptance','allow_public_warning',
                'allow_operational_control','allow_background_service'):
        assert offline[key] is False
    assert configs['bounded_pilot.yaml']['enabled'] is False
    assert configs['bounded_pilot.yaml']['authorization_ref'] is None
    assert configs['shadow_run.template.yaml']['enabled'] is False
    assert configs['confirmation_prereg.yaml']['status'] == 'unfrozen_do_not_run_confirmation'

    manifest_path = root / 'ARTIFACT_MANIFEST.json'
    checked_hashes = 0
    if manifest_path.exists():
        for row in load_json(manifest_path)['files']:
            target = (root / row['path']).resolve()
            assert root.resolve() in target.parents, 'Manifest path escapes bundle root'
            payload = target.read_bytes()
            assert len(payload) == row['bytes'], f'Size mismatch {row["path"]}'
            assert hashlib.sha256(payload).hexdigest() == row['sha256'], f'Hash mismatch {row["path"]}'
            checked_hashes += 1

    return {
        'schema':'disastertrace.plan_bundle_validation.v1',
        'scope':'planning_artifact_only_not_repository_or_weather_validation',
        'passed':True,
        'base_commit':task_doc['base_commit'],
        'task_count':len(tasks),
        'test_intent_count_not_executed_tests':len(intents),
        'source_count':len(sources),
        'configuration_templates':len(configs),
        'dag_topological_order':order,
        'legacy_x00_x09_and_16_hazards_preserved':True,
        'safe_offline_defaults':True,
        'research_tasks_executed':False,
        'repository_tests_executed':False,
        'model_calls_executed':0,
        'scientific_data_downloads_executed':0,
        'checked_manifest_files':checked_hashes,
        'templates_ready_to_launch_experiments':False,
    }


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--write-report',action='store_true',
                        help='Write structural validation report BEFORE generating the final manifest')
    args=parser.parse_args()
    try:
        report=validate(args.root)
    except (AssertionError, ValueError, KeyError, OSError, ImportError) as exc:
        print(json.dumps({'passed':False,'scope':'plan_bundle_only','error':str(exc)},ensure_ascii=False))
        return 1
    if args.write_report:
        if (args.root/'ARTIFACT_MANIFEST.json').exists():
            print('Refusing to rewrite a report after the manifest has been frozen.')
            return 2
        (args.root/'PLAN_BUNDLE_VALIDATION.json').write_text(
            json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0


if __name__=='__main__':
    raise SystemExit(main())
