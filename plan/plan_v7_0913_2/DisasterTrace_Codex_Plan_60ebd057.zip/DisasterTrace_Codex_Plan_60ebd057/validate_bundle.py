#!/usr/bin/env python3
"""Validate this PLAN bundle only. Never executes the target repository or a model."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
from typing import Any

BASE = Path(__file__).resolve().parent
REQUIRED = [
    'README.md', 'START_HERE_CN.md', 'CODEX_PLAN_CN.md',
    'TASK_GRAPH.json', 'ACCEPTANCE_CASES.json', 'EXPERIMENT_MATRIX.json',
    'CODE_MAP.json', 'REFERENCES.json', 'EXECUTION_POLICY.example.json',
    'OPERATION_PROFILE.example.json', 'SYNTHETIC_SINGLE_STEP.example.json',
]

def read_json(name: str) -> Any:
    return json.loads((BASE / name).read_text(encoding='utf-8'))

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true', help='Validate without changing files.')
    args = parser.parse_args()
    checks: list[dict[str, Any]] = []
    def check(name: str, ok: bool, details: str = '') -> None:
        checks.append({'check': name, 'passed': bool(ok), 'details': details})

    check('required_files_exist', all((BASE / n).is_file() for n in REQUIRED))
    if not checks[-1]['passed']:
        print(json.dumps(checks, ensure_ascii=False, indent=2))
        return 1
    try:
        loaded = {p.name: json.loads(p.read_text(encoding='utf-8'))
                  for p in BASE.glob('*.json')}
        check('all_json_parse', True)
    except (ValueError, OSError) as exc:
        print('Invalid JSON:', exc, file=sys.stderr)
        return 1
    tasks = loaded['TASK_GRAPH.json']['tasks']
    cases = loaded['ACCEPTANCE_CASES.json']['cases']
    exps = loaded['EXPERIMENT_MATRIX.json']['experiments']
    refs = loaded['REFERENCES.json']['references']
    tids = {t['id'] for t in tasks}
    cids = {c['id'] for c in cases}
    rids = {r['id'] for r in refs}
    eids = {e['id'] for e in exps}
    check('unique_task_ids', len(tids) == len(tasks))
    check('unique_acceptance_ids', len(cids) == len(cases))
    check('unique_reference_ids', len(rids) == len(refs))
    check('unique_experiment_ids', len(eids) == len(exps))
    check('all_task_dependencies_exist', all(set(t['depends_on']) <= tids for t in tasks))
    check('all_cases_have_known_owner', all(c['task_id'] in tids for c in cases))
    check('task_case_refs_exist', all(set(t['acceptance_case_ids']) <= cids for t in tasks))
    check('case_ownership_consistent', all(c['id'] in next(t for t in tasks if t['id']==c['task_id'])['acceptance_case_ids'] for c in cases))
    check('task_source_refs_exist', all(set(t['references']) <= rids for t in tasks))
    check('experiment_task_refs_exist', all(set(e['depends_on']) <= tids for e in exps))
    check('experiment_case_refs_exist', all(set(e['acceptance_case_ids']) <= cids for e in exps))
    todo = {t['id']: set(t['depends_on']) for t in tasks}
    order: list[str] = []
    while todo:
        ready = sorted(k for k, v in todo.items() if not v)
        if not ready:
            break
        order.extend(ready)
        for k in ready:
            todo.pop(k)
        for deps in todo.values():
            deps.difference_update(ready)
    check('task_graph_acyclic', not todo, 'Topological order: ' + ', '.join(order))
    check('all_work_is_planned', all(t['status']=='planned' and t['execution_result'] is None for t in tasks)
          and all(c['status']=='planned' and c['execution_result'] is None for c in cases)
          and all(e['status']=='planned' and e['results'] is None for e in exps))
    first = loaded['TASK_GRAPH.json']['default_first_wave']
    check('first_wave_is_cpu_foundation', first == ['DS00','DS01','DS02','DS03','DS04'])
    check('first_wave_dependencies_closed', all(set(t['depends_on']) <= set(first) for t in tasks if t['id'] in first))
    pol = loaded['EXECUTION_POLICY.example.json']
    check('example_does_not_grant_execution', pol['does_not_authorize_execution_by_itself'] is True)
    zero_names = ['max_model_calls','max_model_tokens','max_gpu_concurrency','max_gpu_seconds',
                  'max_external_network_requests','max_external_download_bytes','max_paid_api_spend']
    check('external_and_model_budgets_zero', all(pol['limits'][k] == 0 for k in zero_names))
    check('risky_actions_disabled', all(pol['disabled'].values()))
    plan = (BASE / 'CODEX_PLAN_CN.md').read_text(encoding='utf-8')
    md_refs = set(re.findall(r'\b[PRU]\d{2}\b', plan))
    check('plan_reference_ids_resolve', md_refs <= rids, 'Unresolved: ' + ', '.join(sorted(md_refs-rids)))
    md_tasks = set(re.findall(r'\bDS\d{2}[RHT]?\b', plan))
    check('plan_task_ids_resolve', md_tasks <= tids, 'Unresolved: ' + ', '.join(sorted(md_tasks-tids)))
    check('experiment_namespace_preserved', eids == {f'DX{i:02d}' for i in range(10)} and loaded['EXPERIMENT_MATRIX.json']['preserve_existing_ids']=='X00-X09')
    code = loaded['CODE_MAP.json']
    check('new_paths_are_proposals', all(c['status']=='planned' and c['task_id'] in tids for c in code['proposed']))
    check('profile_is_research_example', loaded['OPERATION_PROFILE.example.json']['provenance']=='research_assumption'
          and loaded['OPERATION_PROFILE.example.json']['practitioner_review'] is None)
    check('toy_is_not_weather_evidence', loaded['SYNTHETIC_SINGLE_STEP.example.json']['scope']=='synthetic_unit'
          and loaded['SYNTHETIC_SINGLE_STEP.example.json']['counts_as_real_weather_sample'] is False)
    # Signed URLs and credentials should not be copied into a shareable plan.
    combined = '\n'.join(p.read_text(encoding='utf-8') for p in BASE.iterdir()
                         if p.suffix in {'.md','.json'} and p.name not in {'MANIFEST.json','BUNDLE_VALIDATION.json'})
    check('no_signed_urls_or_obvious_secrets', not re.search(r'https?://\S*[?&](?:token|X-Amz-Signature|sig)=', combined, re.I)
          and not re.search(r'(?<![A-Za-z0-9])(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{15,}', combined))
    check('utf8_text_readable', '\ufffd' not in combined)
    if args.check_only and (BASE/'MANIFEST.json').exists():
        manifest = read_json('MANIFEST.json')
        invalid = []
        for row in manifest['files']:
            target = (BASE / row['path']).resolve()
            if target.parent != BASE or not target.is_file():
                invalid.append(row['path'])
                continue
            payload = target.read_bytes()
            if len(payload) != row['bytes'] or hashlib.sha256(payload).hexdigest() != row['sha256']:
                invalid.append(row['path'])
        check('delivery_manifest_hashes', not invalid, 'Mismatches: ' + ', '.join(invalid))
    result = {
        'schema':'disastertrace.codex.bundle_validation.v1',
        'scope':'Structural validation of plan files only; NOT execution of repository code, acceptance specifications, models, or experiments.',
        'base_commit':'60ebd05723f9483590611976d379da2e4edd85b0',
        'counts':{'work_packages':len(tasks),'acceptance_specifications':len(cases),'experiment_plans':len(exps),'source_records':len(refs)},
        'repository_tests_executed':False,'model_calls':0,'repository_modified':False,
        'passed':all(c['passed'] for c in checks),'checks':checks,
    }
    if not args.check_only:
        (BASE/'BUNDLE_VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
