"""Validate planning artifacts only; never import the user repository or call a model."""
from pathlib import Path
import json

def main():
    root=Path(__file__).resolve().parent
    b=json.loads((root/'CODEX_BACKLOG.json').read_text())
    tasks={t['id']:t for t in b['tasks']}
    assert len(tasks)==len(b['tasks'])==b['task_count']==20
    visiting=set(); done=set(); order=[]
    def visit(k):
        assert k in tasks, ('missing dependency',k)
        if k in done:return
        assert k not in visiting, ('cycle',k)
        visiting.add(k)
        for d in tasks[k]['dependencies']:visit(d)
        visiting.remove(k);done.add(k);order.append(k)
    for k in tasks:visit(k)
    for t in tasks.values():
        for f in ('implementation','deliverables','acceptance','release_gate','permission'):
            assert t[f], (t['id'],f)
        assert t['status']=='planned_not_executed'
    assert not b['policies']['allow_gpu']
    assert not b['policies']['allow_new_training']
    assert not b['policies']['auto_push']
    assert not b['policies']['require_positive_gain_for_admission']
    e=json.loads((root/'SYNTHETIC_PREPARATION_FIXTURE.json').read_text())
    assert e['synthetic_fixture'] and not e['real_weather_data'] and not e['deployable']
    # Arithmetic sanity, not a preparedness-engine implementation/test.
    assert 12*60+180<=16*60
    assert 13*60+30+180>16*60
    assert 12*60+180+30<=16*60
    # The same marginals do not identify a joint event.
    sync=[((0,0),.5),((1,1),.5)]
    exclusive=[((1,0),.5),((0,1),.5)]
    assert sum(w*(a+b) for (a,b),w in sync)==sum(w*(a+b) for (a,b),w in exclusive)==1
    assert sum(w*(a and b) for (a,b),w in sync)==.5
    assert sum(w*(a and b) for (a,b),w in exclusive)==0
    report={'plan_structure_valid':True,'task_count':len(tasks),'topological_order':order,
      'default_first_batch':b['default_first_batch'],'synthetic_arithmetic_checked':True,
      'repository_tests_run':0,'model_calls':0,'scientific_data_downloads':0,
      'meaning':'Only planning artifact consistency and stated synthetic arithmetic were checked.'}
    (root/'PLAN_VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
