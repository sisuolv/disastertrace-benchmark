#!/usr/bin/env python3
"""Validate plan-package consistency only; never run project code or contact networks."""
from __future__ import annotations
import ast, hashlib, json
from pathlib import Path

def load(p):
    return json.loads(p.read_text(encoding="utf-8"))

def main():
    root=Path(__file__).resolve().parents[1]
    tasks=load(root/"specs/work_packages.json")["work_packages"]
    names={r["id"] for r in tasks}
    if len(names)!=len(tasks): raise ValueError("Duplicate package IDs")
    graph={r["id"]:r["depends_on"] for r in tasks}
    visited,active=set(),set()
    def visit(k):
        if k in active: raise ValueError("Dependency cycle")
        if k in visited: return
        active.add(k)
        for d in graph[k]:
            if d not in names: raise ValueError("Unknown dependency "+d)
            visit(d)
        active.remove(k);visited.add(k)
    for k in names:visit(k)
    tests=load(root/"specs/acceptance_tests.json")["tests"]
    if len({r["id"] for r in tests})!=len(tests):raise ValueError("Duplicate test ID")
    for r in tests:
        if r["work_package"] not in names:raise ValueError("Orphan test")
        if not r["expected_cn"]:raise ValueError("No acceptance criterion")
    for e in load(root/"specs/experiment_plan.json")["experiments"]:
        if not set(e["depends_on"])<=names:raise ValueError("Orphan experiment")
    input_files=load(root/"specs/input_manifest.json")["user_materials"]
    for f in input_files:
        p=root/f["package_path"]
        if hashlib.sha256(p.read_bytes()).hexdigest()!=f["sha256"]:
            raise ValueError("Input material was modified")
    for p in root.rglob("*.json"):load(p)
    for p in root.rglob("*.py"):ast.parse(p.read_text(encoding="utf-8"))
    scope=load(root/"specs/execution_scope.template.json")
    if scope["allow_repo_push"] or scope["allow_real_world_actions"] or scope["max_gpu_concurrency"]:
        raise ValueError("Unexpected automatic execution grant")
    if not (root/"DISASTERTRACE_CODEX_NEXT_PLAN_CN.md").exists(): raise ValueError("Missing plan")
    print(json.dumps({"plan_structure":"passed","work_packages":len(tasks),"proposed_acceptance_specs":len(tests),
       "source_entries":len(load(root/"specs/source_and_reuse_registry.json")["sources"]),
       "input_materials_unchanged":len(input_files),"project_tests_run":0,"model_calls":0,"network_requests":0},ensure_ascii=False,indent=2))
if __name__=="__main__":main()
