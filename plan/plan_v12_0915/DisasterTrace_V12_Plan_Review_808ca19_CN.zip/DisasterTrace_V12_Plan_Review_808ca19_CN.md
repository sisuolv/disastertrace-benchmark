# DisasterTrace v12 执行前复核与阶段 A 补充规格

审查对象：`sisuolv/disastertrace-benchmark` / `next-phase-v1`。
固定读取提交：`808ca1912c7065ff6c774004626867676118a9cf`。
该提交发布时间：2026-09-15 14:02:13 UTC / 北京时间 22:02:13。
性质：只读审查与计划建议；不是执行授权。不得据此启动研究作业。

## 1. 结论

保留 v12 的 C1/C2/C3 及 A→B→C→D 顺序。阶段 A 的既有结果整理、E/年度摘要修复、最小 bank 守卫、来源普查和下载清单登记可优先推进；C2 真分支必须增加父状态可用性与独立 fork 资格，再决定能否运行。不是把所有 API、温度、MM 风险排成统一串行前置。

本次已读 v12 总入口、整体计划、下一批规格、意见取舍、机器工作包、状态回执，以及相关生产模块和调用者。局部执行仅为从已读源码摘取的隔离函数/表达式测试，不是生产包导入测试、原 750 项回归、完整天气复算或新模型实验。没有访问 CCI/ACP 实时状态，没有修改 GitHub/生产文件，也没有新来源 HTTP、模型/API、GPU 或确认资料访问。网页文档核查不属于 benchmark 来源采集。

## 2. 原计划中应保留的设计

- 不重开原 launcher，不热改 `fullweek_02/source`、输入、结果、费用或原始失败。
- 同后端的 F_BASE_ONLY/BATCH/COVERAGE 与跨后端的 F_COMMON 比较分开。
- C2 拆成共同 TAF 处理和补充 METAR 获取；改变 E 标签不必改变 F。
- 来源先验证历史可见性和版本，再判断覆盖；旧 144 题作为 supplied-packet sanity 保留。
- 6 个父状态、24 条有限程序路径仅验证工程，不承担独立过程推断。
- no further paid query 不终止免费更新、既定预测和截止评分。
- 无正收益不是准入失败；真实选择空间、可检查的消费路径和强对照才是进入模型实验的条件。
- 2023 训练/内部选择、2024 最终校准、已读 2025 开发、未读确认分别记录依赖与暴露。
- 温度/API/MM 分别按即将执行的消费者设门槛。

## 3. 已确认的既有问题与影响边界

| 问题 | 代码位置 | 本次判断 | 最小处理 |
|---|---|---|---|
| E 肯定状态漏计 | `plans/v11_execution_20260915_01/fullweek.py::audit`；`monitoring_v1/evidence.py::exists_report_support` | 汇总计 entailed/refuted，生产者输出 supported/refuted；隔离四状态例旧计 1、新计 2 | 新派生 E 报告；不改 F/Y/分母 |
| C2 来源预筛覆盖 | `prepare_c2.py::main`；`build_native_v2.py::main` | candidates 在 project 失败或不覆盖时跳过；影响 C2 来源全集，不自动证明 F 版本选取错误 | 从完整已验证索引/原文回执重建；新任务 ID |
| 失败样例重复拼接 | `annual_catalogs.py::execute` | 精确括号表达式为 sample + (rest if sample_ok else sample)；2 成功 1 失败时变成 6 条、4 成功计数 | 返回唯一注册 unit；保留 69 not_attempted；不重下已完成样例 |
| 校准映射守卫过宽 | `monitoring_fixed_v1/native_feature.py::validate_feature_bank` | 隔离验证接受负输出、反向域、重叠域；巨大整数触发 OverflowError | 在实际 consumer 回归；保留合法空隙/原外推语义；raw 轨不因此重跑 |
| 配对分析不全 | `analyze_fullweek.py::PAIRS` | 缺 F_BASE_ONLY→BATCH、COMMON→BASE_ONLY 等关键配对 | 原审计行上补十个描述性配对，禁止升级为预注册检验 |

这里的局部反例不能证明当前 71/72 月结果重复计数，也不能证明原始整周概率已经受校准守卫缺陷影响。历史影响必须按实际输入和消费者扫描。

## 4. 阶段 A 必须补的执行规格

### A-R1：先证明父状态存在；区分 restore 与 fork

`fullweek.py::run_arm` 调用 `FormalSession.finish()` 后导出 journal；这条路径没有显式调用逐 tick `persist()`。`SessionCoordinator.step()` 只保留当前内存 checkpoint 并覆盖前一个；`FormalSession.restore()` 拒绝带 STOP 的目录，并绑定原目录、合同、数据/银行与文件哈希。

因此不能假设已完成日会话天然保存了中午父 checkpoint，也不能删除 STOP 或复制目录来伪装恢复。journal/评分引擎不自动等于完整 coordinator 状态。

增加拟议 `C2_PARENT_AVAILABILITY.json`，逐父状态记录：

- 原 arm/case/opportunity、目标截止、实际 decision/fork 时刻；
- 是原来持久化的 checkpoint，还是经原冻结环境和已捕获回执重建的前缀；
- prefix journal/hash、controller/runtime、source/store、spent/reserved、额度释放、pending、baseline/override、seed；
- 重建是否完整、哪些文件不可用、哪些源索引是否尚未结算。

无原 checkpoint 时，只在新审查执行范围明确允许“最多六个前缀的确定性重建”。它与重做原 840 个实验不同，单独计数，不能使用新 HTTP 或新模型答案。无法重建则 `NOT_RECONSTRUCTABLE`，不换有利样本。

子分支应使用新 run_id/新目录/新合同，绑定父合同、父前缀和干预 ID，保持旧 STOP 与旧 marker 不动。若由底层 SessionCoordinator 构造、未通过子分支正式资格，明确标记为工程/legacy 诊断，不冒充 formal。

先做 NO-INTERVENTION（继续原 γ）来检验恢复等价；它不是 NO-FURTHER-QUERY。为避免 24 分支上限歧义，登记最多 6 次原前缀/无干预等价验证与最多 24 个干预分支，二者分别统计。任何额外验证都必须在实际获批规格内。

### A-R2：给“共同 TAF 处理实验”写明实际消费入口

`NativeFeaturePredictor.predict()` 调用 `feature_vector()`；后者重新 parse_taf(raw)，投影目标，并要求投影等于登记 projection。最终 E 布尔答案没有被读取。直接篡改 projection 应当被拒绝，不应该为了让 F 改变而关闭原生校验。

两条可接受路线：

1. 阶段 A 只做处理合同、字段依赖和不变性检查；明确本批实际 GET 分支不覆盖 PROCESS→F。
2. 有已捕获真实处理结果时，另建带处理器身份、来源、完成时刻、成本和 schema 的派生字段适配器；错误但合法的处理输出进入被测路径，原生解析器留作强基线/评估参考。无效输出按固定政策回退。

新适配器是新研究路径，不改旧生产原文、基线或评估真值。没有真实替代输出时，不生成伪“真实错误”；合成边界测试单列。

取得新 METAR 应变化的是可见支持和可能的特征，而不是改变过去天气的事实真值。未读取、已请求未完成、已完成但缺报、完成且有值必须区分。

### A-R3：修正机器依赖与收尾语义

`WORK_PACKAGES.json` 的 W05.acceptance 硬依赖 W07.closeout；后者等待原全周最终审计。这与正文允许待审计节点 pending 后结束的表述不一致。W11.branch_engineering 也应有显式的原 parent 终态/来源/hash 资格，而非只依赖 universe。

建议分开：

- `SCOPED_IMPLEMENTATION_ACCEPTANCE`：已实现修复和可用父状态的工程验证；
- `BATCH_CLOSEOUT`：所有注册节点成为完成、失败、不可评估或明确阻塞状态；
- `SCIENTIFIC_COMPARISON_COMPLETE`：只在原 roster 全量审计与对应派生结果完整时为真。

超时后可以 `CLOSED_WITH_PENDING_EXTERNAL`，但不能改成 PASS、不能启动 B—D，也不能重新运行原任务。原年度失败不得污染成 fullweek 失败；原科学不完整也不得由工程通过遮盖。

### A-R4：将观察范围完整性与 E 事实状态分开

`NATIVE_PRODUCT_INDEX` 是已取得资料范围的索引，不自动证明全世界或提供方历史完整。

除了 active/full/partial/CNL/NIL/conflict/unparsed，增加或明确区分：

- 在核验范围内确无当前产品；
- 目录缺片/获取失败导致不知道是否有产品；
- 产品可见但解析不支持；
- 已被取消或不覆盖目标。

仅在关闭的、来源覆盖已验证的 scope 内解释“没有产品”。未知目录状态不能被记成 none/refuted。先于 fork 的所有可见资产与后续新增资产分区；源宇宙和未来标签只给评估器，selector 只看许可视图。

### A-R5：登记有限计划的真正动作与截止语义

保留 v12 对有限残余查询计划的定义，不新增统一 γ 的完整自适应科学实验作为阶段 A 前置。

但必须绑定 eligible qid/payer/排序/授权/版本与实际执行的 source_receipt；不能只把 selector_kind 改为 first/second 等不存在的能力，或用伪 LLM 后端绕开程序动作身份和费用。

若有 pending，先以同一次真实原完成过渡建立共同 fork 状态，消耗原时间；不存在真实完成回执则保留未知，不免费重发。提前截止与晚到分支全保留。

固定剩余会话目标集合 U_parent；四条路径用相同未来参考和分母。主报余下会话效果、另报目标局部效果及全日效果。不能对每条路径重新删到只剩它改善的目标。

no-op 等价要求科学状态、输入、原预测与计费一致；新身份和执行机器的墙钟元数据不必与旧文件逐字节相同。来源、原合同及旧 F 哈希必须保持。

### A-R6：固定预测后端不等于固定预测日程

`selection.py` 输出同时包含 query_order 与 forecast_handles。`policies.py` 已有 scheduled_starts 路径，会标 forecast_handles_are_ignored 并重建固定 forecast_order。这是已有保护，应复用而非重造。

阶段 C 的 selector-only 注册必须明确是 query-only 还是同时控制预测计算。在 query-only 主表中，显式要求该固定日程配置非空并绑定机会顺序；改变合法 forecast_handles 而保持 query_order 的负控制不得改变规划日程。实测模型迟到可以影响能否及时采用，但不能由模型无声明地删去预测目标或节省预测成本。

## 5. 修订后的阶段 A 顺序

| 工作 | 等待条件 | 交付/可关闭状态 |
|---|---|---|
| 当前身份、原任务与保护清单 | 用户后续明确授权 | 发布/开发/运行身份与新观察时间 |
| E、年度摘要、bank 守卫 | 原输入可读 | 定向回归、真实影响分类；无 F 重跑 |
| 原全周配对分析 | 原正式全量审计 | 完整描述性配对或 PENDING_EXTERNAL |
| C2 全来源普查 | 已暴露资料、完整性合同 | 普通与边界状态全保留 |
| C2 父前缀审计 | 原 parent 合法终态、prefix 资料 | AVAILABLE/RECONSTRUCTABLE/NOT_RECONSTRUCTABLE |
| ≤6 前缀等价、≤24 有限分支 | fork 资格与行动消费者 | 工程链完整；退化/失败也记录 |
| 年度缺片/唯一原文清单 | 现有目录与缓存 | 仅范围登记，不新下载 |
| 有界回归与收尾 | 可实施项均有终态 | 工程、外部等待、科学完整性分开 |

不增加新核心贡献、GPU、模型/API、全年拟合、确认或 MM 实验到这一批。

## 6. B—D 的进一步限定

### 年度原文与 bank

62,691 是目录引用，不是唯一未缓存原文数。维护 reference、原生产品身份、版本/发行元数据、精确请求、raw hash 和多对多引用。产品 ID 冲突时保留 variants 或不可恢复状态，不只用 ID 覆盖原文。IEM 官方也明确其 product identifier 并非总是唯一。

至少 2024 年 12 月曾用于旧冬季 bank；其他月份是否参与过开发，应另列暴露清单，不能由新 role 字段变成“从未使用”。增加曝光与角色记录：哪些标签只做质量核查、哪些进入拟合、哪些影响参数/策略。当前待训练 estimator 的训练标签与最终校准标签分开；跨窗口和共享源足迹 purge；确认集另行冻结。重做训练后可使用明确披露的校准数据，不需要为了措辞丢弃全部 2024，但不能抹掉历史暴露。

不要把 Brier 降低单独当校准变好。主表仍是预测损失，另报可靠性与事件支持；不把四个日历块的逐小时记录当独立过程。

### 模型实验

保留一个已验证 235B、selector-only、12×24 正式请求候选上限和最多两次兼容性尝试。进入门槛不是必须有正收益，也不是必须改概率，而是真实不同的合法选择、预算竞争、可验证消费链、完整强对照及失败分母。所有任务相同或 bank 对相关特征零敏感时先报告原因，不扩模型阵列。

### 独立确认与 C3

将“模型预测优势”和“C2 诊断现象是否复现”分别预注册。即便主模型比较为零或负，也能报告独立资料上的可达性/提取/时效诊断；但独立样本不足仍需限制结论，不以否定模型代替 novelty 证明。

温度 F-only 不算跨灾种主动机制已经验证。C3 的近期里程碑可保持第二条合格主动物理链与一条原生视觉资格；不把 16 类全量建设设为 H15 每个结果的前置。

## 7. 最小验收例

1. 四状态 E + missing frame：状态总和等于 E roster；supported/refuted 各计 1；缺 Y 不删除 E。
2. 年度 2/3 样例成功：3 个唯一结果、2 完成、1 失败、69 未尝试；后续真 71/72 与该分支分开。
3. bank 负值/反向域/不兼容重叠/布尔/NaN/巨大整数受控拒绝；合法 sparse gap 维持原映射。
4. STOP 父目录不可重开；新子目录绑定 parent prefix；跨分支新增 cache 不共享。
5. 原前缀延续 γ 与原轨迹科学字段一致；no-further-query 与 no-op 分别命名。
6. pending 结算后的时间/费用对所有分支一致；超出截止不得回填此前预测。
7. 新不覆盖产品不复活旧覆盖产品；取消、冲突、同义镜像和档案缺片按不同状态输出。
8. 只改 E label，F 不变；通过许可的实际特征消费路径改变字段时能定位“何处发生/未发生传播”。
9. 固定 schedule 下修改 forecast_handles 不改变计划预测集合；实际迟到记录不删除目标。
10. 整周外部审计未完成时，工程收尾不伪装完整科学通过，也不自动授权阶段 B。

## 8. 证据索引

核心计划：`LATEST_PLAN_V12_CN.md`；`plans/v12_planning_20260915_01/{OVERALL_PLAN_CN.md,NEXT_BATCH_EXECUTION_CN.md,REVIEW_DECISIONS_CN.md,WORK_PACKAGES.json,CURRENT_STATE_01.json}`。
代码：`fullweek.py`、`prepare_c2.py`、`annual_catalogs.py`、`analyze_fullweek.py`、`build_native_v2.py`；`monitoring_v1/{evidence.py,native_feature_forecast.py,formal_session.py,session_checkpoint.py,regional_calibration.py,selection.py,policies.py}`；`monitoring_fixed_v1/{native_feature.py,taf_tasks.py}`。
本地检查：随包 `isolated_probes.py` 与 `isolated_probe_results.json`。这是隔离源码片段/合成输入检查，不是完整生产 consumer 的验收。
外部核对：IEM《NWS Text Archives》关于产品标识不保证唯一；scikit-learn《Probability calibration》关于训练与校准分离以及 Brier 不等于纯校准指标。它们不证明仓库数据已经泄漏或已存在实际 ID 冲突。
