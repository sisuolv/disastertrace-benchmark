"""Isolated source-fragment checks for DisasterTrace commit 808ca1912c7065ff6c774004626867676118a9cf.

These are NOT production-import tests or benchmark runs. The validator below is
transcribed from the fetched native_feature.py function. Other checks evaluate
individual fetched expressions on synthetic inputs. No network, GPU, API, or
user-workspace access is performed. Results do not establish historical impact.
"""
from __future__ import annotations
import copy
import json
import math
from pathlib import Path

FEATURE_VERSION = "native_h15_features.v1"

# Verbatim function excerpt from monitoring_fixed_v1/native_feature.py.
def validate_feature_bank(bank, *, calibrated=False):
    if (
        not isinstance(bank, dict)
        or bank.get("feature_version") != FEATURE_VERSION
        or bank.get("mode") not in {"common", "values"}
    ):
        raise ValueError("A frozen common or values feature bank is required")
    fields = {"feature_names", "mean", "scale", "coefficients", "intercepts", "mapping_version"}
    if not fields <= set(bank) or not bank["mapping_version"]:
        raise ValueError("Incomplete feature bank")
    names = bank["feature_names"]
    if bank["mode"] == "common" and any(str(name).startswith("slot") for name in names):
        raise ValueError("A common information bank cannot consume paid slot features")
    n = len(names)
    if (
        not n
        or len(set(names)) != n
        or any(not isinstance(s, str) or not s for s in names)
        or len(bank["mean"]) != n
        or len(bank["scale"]) != n
        or len(bank["intercepts"]) != 3
        or len(bank["coefficients"]) != 3
        or any(len(row) != n for row in bank["coefficients"])
    ):
        raise ValueError("Invalid feature bank dimensions")
    numbers = [
        *bank["mean"],
        *bank["scale"],
        *bank["intercepts"],
        *(number for row in bank["coefficients"] for number in row),
    ]
    if any(type(x) not in (int, float) or not math.isfinite(x) for x in numbers) or any(
        s <= 0 for s in bank["scale"]
    ):
        raise ValueError("Feature coefficients and scales must be finite and valid")
    if calibrated:
        maps = bank.get("post_calibration", {})
        if set(maps) != {"1000", "5000"} or any(not blocks for blocks in maps.values()):
            raise ValueError("Both feature calibration maps are required")
        for blocks in maps.values():
            previous = -1.0
            for block in blocks:
                if (
                    set(block) != {"lower", "upper", "value"}
                    or any(
                        type(x) not in (int, float) or not math.isfinite(x) for x in block.values()
                    )
                    or not 0 <= block["lower"] <= block["upper"] <= 1
                    or not previous <= block["value"] <= 1
                ):
                    raise ValueError("Invalid monotone feature calibration")
                previous = block["value"]

# Verbatim function excerpt from monitoring_v1/regional_calibration.py.
def apply_monotone(blocks, probability):
    if not blocks or not math.isfinite(probability) or not 0 <= probability <= 1:
        raise ValueError("Invalid monotone probability mapping")
    for block in blocks:
        if probability <= block["upper"]:
            return block["value"]
    return blocks[-1]["value"]


def check_bank(blocks):
    bank = {
        "feature_version": FEATURE_VERSION, "mode": "values",
        "feature_names": ["taf_present"], "mean": [0.0], "scale": [1.0],
        "coefficients": [[0.0], [0.0], [0.0]], "intercepts": [0.0, 0.0, 0.0],
        "mapping_version": "synthetic_probe_only",
        "post_calibration": {"1000": copy.deepcopy(blocks), "5000": copy.deepcopy(blocks)},
    }
    try:
        validate_feature_bank(bank, calibrated=True)
    except Exception as exc:
        return {"validator": "rejected", "exception": type(exc).__name__, "message": str(exc)}
    return {"validator": "accepted", "mapped_at_0_15": apply_monotone(blocks, 0.15), "mapped_at_0_5": apply_monotone(blocks, 0.5)}


def main():
    results = {
        "commit": "808ca1912c7065ff6c774004626867676118a9cf",
        "scope": "isolated transcribed source fragments and synthetic inputs; not production imports or historical experiment verification",
        "production_regression_rerun": False, "new_weather_cases": 0,
        "model_calls": 0, "source_http_calls": 0, "gpu_jobs": 0,
        "source_locations": {
            "bank": "disastertrace-starter/src/disastertrace/monitoring_fixed_v1/native_feature.py::validate_feature_bank",
            "map": "disastertrace-starter/src/disastertrace/monitoring_v1/regional_calibration.py::apply_monotone",
            "annual": "plans/v11_execution_20260915_01/annual_catalogs.py::execute",
            "E": "plans/v11_execution_20260915_01/fullweek.py::audit",
        },
    }
    cases = {
        "negative_output": [{"lower": 0.1, "upper": 0.9, "value": -0.25}],
        "reversed_domains": [{"lower": 0.8, "upper": 0.9, "value": 0.2}, {"lower": 0.1, "upper": 0.2, "value": 0.3}],
        "overlapping_domains": [{"lower": 0.1, "upper": 0.8, "value": 0.2}, {"lower": 0.5, "upper": 0.9, "value": 0.3}],
        "legitimate_sparse_gap": [{"lower": 0.1, "upper": 0.2, "value": 0.2}, {"lower": 0.8, "upper": 0.9, "value": 0.4}],
        "boolean_output": [{"lower": 0.1, "upper": 0.9, "value": False}],
        "huge_integer_output": [{"lower": 0.1, "upper": 0.9, "value": 10**400}],
    }
    results["calibration"] = {name: check_bank(blocks) for name, blocks in cases.items()}
    states = ["supported", "refuted", "undetermined", "inconsistent"]
    results["E_count"] = {
        "synthetic_states": states,
        "existing_expression": sum(s in {"entailed", "refuted"} for s in states),
        "planned_expression": sum(s in {"supported", "refuted"} for s in states),
    }
    sample = [{"unit": "a", "complete": True}, {"unit": "b", "complete": True}, {"unit": "c", "complete": False}]
    sample_ok = all(r["complete"] for r in sample)
    # Parse and evaluate the exact fetched expression, avoiding any acquisition.
    import ast
    exact_line = 'results = sample + (list(pool.map(acquire_unit, [(out, repo, n) for n in rest])) if sample_ok else sample)'
    expression = ast.parse(exact_line).body[0].value
    local = {"sample": sample, "sample_ok": sample_ok, "pool": None,
             "acquire_unit": None, "out": None, "repo": None, "rest": []}
    value = eval(compile(ast.Expression(expression), "<isolated-fetched-expression>", "eval"),
                 {"__builtins__": {"list": list}}, local)
    results["annual_sample_failure"] = {
        "sample_ok": sample_ok,
        "exact_source_expression": exact_line,
        "exact_source_ast_root": type(expression).__name__,
        "exact_parenthesized_source_result_count": len(value),
        "exact_parenthesized_source_complete_count": sum(r["complete"] for r in value),
        "expected_unique_result_count": 3,
        "expected_unique_complete_count": 2,
        "important": "The parentheses place the conditional inside the right operand of +: sample + (map_result if sample_ok else sample). Failure duplicates the samples. This does not establish that the actual successful-sample annual run duplicated records.",
    }
    path = Path(__file__).with_name("isolated_probe_results.json")
    path.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
