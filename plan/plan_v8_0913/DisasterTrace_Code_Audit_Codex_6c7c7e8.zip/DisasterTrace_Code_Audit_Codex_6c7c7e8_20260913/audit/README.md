# Audit evidence scope

- `preparation.py` and `event_loop.py` are exact copies read with the GitHub connector. Their Git blob SHA-1 hashes match the reviewed commit.
- `contract_excerpts.py` contains selected source definitions; comments/imports were adapted for the isolated test module, not a complete hash-verified module. Runtime statements implement the fetched source definitions.
- `score_admitted_excerpt.py` contains the original score function and local imports. Its AdmissionEngine.from_journal is mocked by the probe harness to supply sealed-state fixtures. No claim of testing journal integrity or full admission follows from these probes.
- P11/P12 are input-validation/comparison-contract gaps observed at this function boundary, not evidence that published data contain inconsistent results or different common baselines.
- P02/P03 confirm the frozen preparation card. They are not code bugs under that card, although the main-plan proposal describes a different resource/coverage model.
- P08/P09 show same-valued override versus FOLLOW semantics, not a historical model-skill result.
- All inputs are synthetic. No weather source arrays, original model generations, full repository tests or full archive replay were run here.

Run `python audit/probe_suite.py` from the package root. The report is written to `audit/PROBE_RESULTS.json`.
