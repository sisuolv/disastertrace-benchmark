"""Source function from admission.py; parent blob f89c71a582cbc3eaf14ff935ab4928bd63ccbb2f.
Only external AdmissionEngine.from_journal is mocked in tests. This does not test real journal recovery.
"""
from contract_excerpts import require_fields, fingerprint, paired_scores


def score_admitted(outcomes, arms):
    engines = {name: AdmissionEngine.from_journal(path) for name, path in arms.items()}
    if not engines:
        raise ValueError("No admitted arms")
    first = next(iter(engines.values()))
    for engine in engines.values():
        if engine.contract != first.contract or set(engine.snapshots) != set(first.opportunities):
            raise ValueError("All arms need the same full sealed opportunity contract")
        if engine.calls and {c["head"] for c in engine.calls.values()} == {"e_only"}:
            raise ValueError("E-only calls are not a forecasting arm")
    results = {r["opportunity_id"]: r for r in outcomes}
    if len(results) != len(outcomes) or set(results) != set(first.opportunities):
        raise ValueError("Every opportunity needs an explicit outcome or missing status")
    rows = []
    for oid, o in first.opportunities.items():
        outcome = results[oid]
        require_fields(
            outcome, "opportunity_id target_contract_hash value status source_revision", "outcome"
        )
        if outcome["target_contract_hash"] != o.target.contract_hash:
            raise ValueError("Outcome target mismatch")
        if outcome["status"] not in {"mature", "provisional", "missing"}:
            raise ValueError("Unknown maturity status")
        if outcome["status"] == "mature" and (
            outcome["value"] is None or not outcome["source_revision"]
        ):
            raise ValueError("Mature outcome needs value and revision")
        rows.append(
            {
                "opportunity_id": oid,
                "target": o.target.to_dict(),
                "outcome": outcome["value"] if outcome["status"] == "mature" else None,
            }
        )
    return {
        "schema": "disastertrace.admitted_scores.v1",
        "contract_sha256": first.contract_hash,
        "time_basis": first.time_basis,
        "outcome_sha256": fingerprint(outcomes),
        "scores": paired_scores(
            rows,
            {
                name: {oid: s["forecast"] for oid, s in engine.snapshots.items()}
                for name, engine in engines.items()
            },
        ),
        "admission_statuses": {
            name: [r["status"] for r in engine.attempts] for name, engine in engines.items()
        },
    }
