"""Focused CPU-only audit of 6c7c7e8. No model inference or network.

Default: two complete Git-blob-verified modules + selected source definitions.
Scoring probes mock *only* journal loading, supplying sealed-state fixtures.
This is not the repository's 313-test run nor its portable evidence replay.
"""
from __future__ import annotations
import copy
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'audit_sources'))
from preparation import PreparationReducer, score_preparation
from event_loop import run_clock
from contract_excerpts import Target, Forecast, ForecastState, fingerprint
import score_admitted_excerpt as scoring

RESULTS = []
def record(identity, kind, observed, meaning):
    RESULTS.append({'id': identity, 'classification': kind, 'observed': observed, 'interpretation': meaning})

def card(*jobs, capacity=1):
    return dict(schema='disastertrace.preparation_scenario.v1', kind='research_assumption',
                units='synthetic_units', capacity=capacity, budget=100, jobs=list(jobs))
def job(name, duration=3, deadline=10, expires_at=20):
    return dict(job_id=name, target_id='t'+name, duration=duration, deadline=deadline,
                expires_at=expires_at, cost=5, cleanup_duration=2, cleanup_cost=2)
def expect_error(fn):
    try: fn()
    except ValueError as e: return str(e)
    raise AssertionError('Expected ValueError')

for filename, expected in {
    'preparation.py':'2ed78ebbfc54a60d25e15c709a055ba889aabda2',
    'event_loop.py':'250553e445f3e026fbd957c196250b466fe216ac',
}.items():
    data=(ROOT/'audit_sources'/filename).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==expected
record('P01','source_integrity',{'whole_modules':2,'git_blob_match':True},'Only these two whole modules have byte-for-byte Git blob verification. Other files are identified source excerpts.')

p=PreparationReducer(card(job('A'),job('B',duration=2)))
p.request('A',0); p.progress(3); p.request('B',3)
assert p.states['A']['status']=='ready' and p.occupied()==1
assert p.history[-1]['status']=='capacity_rejected'
record('P02','declared_contract_confirmed',{'A_status':p.states['A']['status'],'B_request':p.history[-1]['status'],'occupied':p.occupied()},'Matches frozen scenario card: ready capacity stays occupied. It is not a completion-releases-crew scheduling model.')

p=PreparationReducer(card(job('A',deadline=3,expires_at=3)))
p.request('A',0); p.progress(3); p.seal(3)
assert p.snapshots['A']['ready'] is True
p.after_seal(3); assert p.states['A']['status']=='expired'
record('P03','declared_contract_confirmed',{'ready_at_deadline_equal_expiry':True,'status_after_seal':'expired'},'Matches frozen closed-interval scenario card; differs from half-open coverage proposed in overall plan. Version semantics, do not relabel as an existing F error.')

p=PreparationReducer(card(job('A'),job('B')))
p.request('A',0); p.cancel('A',1); p.cancel('A',1)
assert p.spent==7 and p.occupied()==1
p.progress(3); assert p.occupied()==0
p.request('B',3); assert p.states['B']['status']=='running' and p.spent==12
record('P04','regression_control',{'A_start_plus_cleanup_cost':7,'A_released_at':3,'total_after_B_starts':12},'Cancellation retains sunk expense and occupies capacity through cleanup; repeated cancellation does not double-charge.')

p=PreparationReducer(card(job('A',deadline=3,expires_at=5)))
p.request('A',0); p.progress(3); p.seal(3)
r=score_preparation(p,{'A':None},miss_penalty=10)
assert r['total_cost'] is None and (r['cost_lower_bound'],r['cost_upper_bound'])==(5,15)
record('P05','regression_control',r,'Missing result is not converted to a negative event; operation cost remains.')

class Ev:
    def __init__(self, event_id, time, kind): self.event_id,self.time,self.kind=event_id,time,kind
    def to_dict(self): return dict(event_id=self.event_id,time=self.time,kind=self.kind)
owner=SimpleNamespace(_events={},_processed=set(),_last_time=None,journal=None,
                      opportunities={'o':SimpleNamespace(cutoff=5,opportunity_id='o')}, snapshots={})
trace=[]
owner._expiry_times=lambda upcoming:[]
owner._process=lambda e:trace.append(e.kind)
owner._invalidate=lambda t:trace.append('invalidate')
def seal(t):
    trace.append('seal'); owner.snapshots['o']={'time':t}
owner._seal=seal
owner._after_seal=lambda t:trace.append('after_seal')
run_clock(owner,[Ev('b',5,'baseline'),Ev('c',5,'completion'),Ev('d',5,'begin')],until=5,
          event_order={'baseline':0,'completion':1,'begin':5},decode=lambda r:Ev(**r))
assert trace==['baseline','completion','invalidate','seal','after_seal','begin']
record('P06','regression_control',trace,'Actual shared clock executes declared baseline/completion/seal/control order; test owner is synthetic.')
error=expect_error(lambda:run_clock(owner,[Ev('new',5,'begin')],until=5,event_order={'begin':5},decode=lambda r:Ev(**r)))
record('P07','regression_control',error,'No newly inserted backdated event after a processed boundary.')

t=Target('t','station:S','visibility','m','event_probability','interval',100,110,'future_physical','fixed-test.v1','lt',1000)
def f(value): return Forecast(t.contract_hash,'event_probability','probability',value)
vals={}
for protocol in ('persistent_override','base_bound_override'):
    s=ForecastState(t,protocol)
    s.update_baseline(f(.2),'baseA',0)
    assert s.propose(f(.2),'baseA',1,90)=='accepted'
    s.update_baseline(f(.8),'baseB',2)
    vals[protocol]=s.effective(3).value
    restored=ForecastState.restore(s.to_dict())
    assert restored.effective(3)==s.effective(3)
assert vals=={'persistent_override':.2,'base_bound_override':.8}
record('P08','semantics_control',vals,'Same numeric value as baseline is not FOLLOW: installing a same-value override can remain stale under persistent mode. This is not evidence of an error in recorded fixed F scores.')
s=ForecastState(t,'persistent_override');s.update_baseline(f(.2),'baseA',0);s.follow(1);s.update_baseline(f(.8),'baseB',2)
assert s.effective(3).value==.8
record('P09','regression_control',{'follow_after_new_baseline':s.effective(3).value},'Explicit FOLLOW follows the later baseline; differs from P08 persistent same-value override.')
assert s.update_baseline(f(.9),'baseC',100)=='invalid_target_time'
assert s.propose(f(.9),'baseB',100,105)=='invalid_target_time'
record('P10','regression_control',{'late_baseline_and_proposal':'rejected'},'At physical target start, both new baseline and proposal are rejected by current typed reducer.')

opps={x:SimpleNamespace(opportunity_id=x,target=t,cutoff=c) for x,c in [('o1',20),('o2',30)]}
contract={'opportunities':[{'id':k,'target':t.to_dict(),'cutoff':v.cutoff} for k,v in opps.items()],
          'protocol':'base_bound_override','fallback':f(.2).to_dict()}
def engine(base):
    return SimpleNamespace(contract=copy.deepcopy(contract),contract_hash=fingerprint(contract),opportunities=opps,
        snapshots={k:{'forecast':f(base).to_dict(),'base_forecast':f(base).to_dict(),
                      'baseline_context_hash':fingerprint({'base':base}),'mode':'FOLLOW'} for k in opps},
        calls={},attempts=[],time_basis='declared_archive_scenario')
ENGINES={'A':engine(.2),'B':engine(.9)}
scoring.AdmissionEngine=SimpleNamespace(from_journal=lambda path:ENGINES[path])
def outcomes(y1,y2):
    return [{'opportunity_id':oid,'target_contract_hash':t.contract_hash,'value':y,'status':'mature','source_revision':'same_final_result_v1'}
            for oid,y in [('o1',y1),('o2',y2)]]
r=scoring.score_admitted(outcomes(0,1),{'arm':'A'})
assert abs(r['scores']['arms']['arm']['mean_loss']-.34)<1e-12
record('P11','validation_gap',{'accepted_inconsistent_same_target_outcomes':[0,1],'mean_loss':r['scores']['arms']['arm']['mean_loss']},'Actual scorer function does not enforce one frozen outcome per target across opportunities. Only journal loading was mocked; no real historical dataset inconsistency is asserted.')
r=scoring.score_admitted(outcomes(0,0),{'arm_A':'A','arm_B':'B'})
assert len(r['scores']['arms'])==2
record('P12','comparison_contract_gap',{'baseline_probabilities':[.2,.9],'score_accepted':True},'Same opportunity/fallback contract does not bind a common professional-baseline event stream across arms at the scorer boundary. Fixture engines simulate this difference; published arms have not been shown to differ.')
error=expect_error(lambda:scoring.score_admitted(outcomes(0,0)[:1],{'arm':'A'}))
record('P13','regression_control',error,'Complete opportunity outcomes are required; gap P11 is cross-row target consistency, not lack of full denominator validation.')
ENGINES['E']=engine(.2);ENGINES['E'].calls={'c':{'head':'e_only'}}
error=expect_error(lambda:scoring.score_admitted(outcomes(0,0),{'E_only':'E'}))
record('P14','regression_control',error,'E-only-only runs cannot be reported as forecasting arms.')

payload={'reviewed_commit':'6c7c7e81ad88e1d3a553727607e24c858136899d',
 'scope':'14 local CPU probes; 2 full blob-verified modules plus identified source excerpts. Synthetic input fixtures. Journal loading mocked in scoring probes. No repository-wide test run, weather-array verification, GPU or original model inference.',
 'probes_completed':len(RESULTS),'results':RESULTS}
(ROOT/'PROBE_RESULTS.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(payload,ensure_ascii=False,indent=2))
