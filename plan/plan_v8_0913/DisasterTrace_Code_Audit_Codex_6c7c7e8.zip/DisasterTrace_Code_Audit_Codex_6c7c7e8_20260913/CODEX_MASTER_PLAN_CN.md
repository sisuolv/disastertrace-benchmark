# DisasterTrace 当前实现复查与 Codex 执行补丁

审阅基线：`next-phase-v1@6c7c7e81ad88e1d3a553727607e24c858136899d`。
父提交：`60ebd05723f9483590611976d379da2e4edd85b0`。
日期：2026-09-13。用途：只读复查与后续实施规格；不是已向仓库提交的修复。

## 0. 结论与核查范围

最新新增实现与报告基本对应。F-only 已实际运行；类型化准入、真实会话获取回执、原生METAR支持桥、专用TAF任务、无在途控制器恢复均已有代码/开发证据，不应重复列为从零实现。

不能据此保证整个仓库正确。此次执行14个局部CPU探针：`preparation.py` 与 `event_loop.py` 两个完整模块逐字节核对Git blob；另用明确标识的原函数定义节选检查ForecastState与评分边界。评分探针mock了日志加载，不是完整AdmissionEngine端到端回放。没有重跑313项仓库测试、没有恢复全部科学数组或360条模型捕获，也没有新增模型调用。

完整复查ZIP的GitHub UTF-8接口拒绝二进制；容器原始域名下载因DNS失败，故本次没有独立验证其压缩包哈希。仓库报告的313测试、36日志、8分支与252+108模型调用均属于来源报告，不冒称本次执行。

本次确认两个评分入口防错缺口，并核实两项容易误解的语义。没有发现已发布数据实际使用矛盾标签或不同共同基线的证据。局部防错缺口不是对当前全部F成绩的否定。

## 1. 最新进度需要怎样更新

| 项目 | 6c7c7e8下的状态 | 后续重点 |
|---|---|---|
| F-only | 已实际运行，不再是0次 | 不再无限重复同类head试跑；进入受控预测/采纳诊断 |
| typed admission | 已由旧控制器调用，begin/complete/seal同钟 | 补比较身份、结果一致性和在途失败 |
| paid evidence | 从已settled ledger、cache和source receipts构造 | 通用provider与实际异步失败扩展 |
| C2 | H15原文重解码与有限真实图已有 | 新任务支持与联合资源路径逐provider验证 |
| TAF E | 已新增覆盖/版本真实任务；模型6/18、16/18 | 按时间解码、表示和窗口运算分层，不宣称领域泛化失败 |
| checkpoint | 类型化真实会话的完成tick恢复已有 | CP04b在途恢复不是完成事项 |
| D | 独立合成状态机和冻结卡已有 | 语义与总计划精确对应；不能叫真实准备收益 |
| 温度 | 先前点标量日志链已有 | 旧控制器仍航空专用，需要真实数值会话adapter |
| 16灾种 | 总体路线不变，逐类科学准入仍未完成 | 不用来源数、测试数或prompt数替代能力 |

本轮252调用=12机会×3证据×3head×2表示+36TAF产品题。它不是新闭环LLM策略的252次独立天气试验。全部144个含F输出等于基线；新2025程序全量补证比FOLLOW差。当前有价值的事实是机制可测与负结果被保留，不是主动收益成立。

## 2. 优先修订一：同目标结果和比较基线的完整性

### 2.1 OutcomeRegistry必须以未来目标为主键

现有`score_admitted`检查每个opportunity的target hash、成熟状态和完整分母，但不跨机会检查同一个固定目标的冻结结果一致性。

局部反例给同一目标两次提前量分别传入0和1，两行均写同一个final source revision；评分函数接受并返回均值0.34。此探针模拟日志加载，仅验证函数本身的防错能力，不证明现有真实标签发生此错误。

建议先在真实包的EventJournal链构造红测试，再新增：

```text
OutcomeRegistry[(target_contract_hash, resolution_version)]
    -> value / maturity / support / source resolution fingerprint
OpportunityOutcomeRef[opportunity_id]
    -> canonical outcome key
```

同一最终目标的多提前量必须引用同一冻结结算。不允许不同机会偷偷用不同订正版或把同一目标一处标missing另一处标mature而不解释。若研究不同发布事件或订正版本，它们要有独立目标/结果版本，不覆盖旧数据。

### 2.2 C1比较必须绑定共同基线流

现在同机会、fallback、protocol的contract相同，仍可对应不同到达的baseline事件。评分端没有自动拒绝此种C1比较。

新增评估侧`ExperimentSignature`，至少绑定目标/机会、结果版本、共同基线策略与规范事件流、校准器、外部资料宇宙、时间政策。每个实验预先声明哪些因素允许改变。X00允许明确研究不同基线，X02允许明确研究不同wrapper；但它们不能混成C1主动选择收益。

不要把完整未来事件清单、内容或隐藏结果manifest暴露给模型。复现实验身份属于评估器。

## 3. 优先修订二：同值预测不是FOLLOW动作

`adaptive.execute`的F-only/joint仅返回概率；成功完成后，admission会将它作为proposal安装。它没有模型明确选择FOLLOW/KEEP的字段。

局部真实reducer函数验证：baseline=.2，提交同值覆盖，再更新baseline=.8；persistent继续.2，base-bound回到.8；明确FOLLOW则跟随.8。

此行为符合覆盖协议，但意味着“144条概率与基线相同”只能说明当次输出相同，不能证明模型执行了一种长期跟随最新基线的策略。

采用三个接口：

```text
ForecastHead.predict(view) -> candidate
AdoptionPolicy.decide(state, candidate) -> FOLLOW | KEEP | OVERRIDE
AdmissionEngine -> effective forecast at public cutoffs
```

原auto-propose路径保留为独立诊断协议。不要把旧回答事后改成FOLLOW，也不要用必须改概率的提示制造差异。新增统计分别报告candidate equality、action、active mode、context change与effective score change。

## 4. 基线取消/乱序发布是需要补的集成用例

当前withdrawal分支检查target和非空revision后直接移除当前baseline。它自身没有验证取消消息是否有权替代当前较新的产品；当前按issue加固定延迟的档案可能不触发这类情况。

先查看provider是否已做完整的语义解析，再加迟到旧取消、迟到旧普通产品、最新有效取消、同issue冲突的端到端测试。取消bulletin ID未必等于被取消forecast ID，不能用简单ID相等补丁替代规则。普通文件获取时间也不能作为上游版本优先级。

## 5. CP04b：先区分确定性回放与真实执行恢复

现有quiescent checkpoint是正确的受限实现。下一步不只是保存一个pending列表：`execute`目前仍是阻塞调用和完成入账，需要拆成显式阶段。

```text
reserve -> begin -> dispatch -> acknowledged/running
                         -> response_durable -> admitted/late/rejected
                         -> failed/unknown_external_outcome
```

必须保存logical_operation_id、attempt_id、provider/job handle、锁定输入、预算预留、已花资源、返回状态、响应hash和提交身份。

先实现录制完成事件的pending重放，用CPU和故障注入完成；真实执行器恢复另行试验。已经持久化的响应读取复用；执行器支持幂等查询时核对并续接；未知是否已执行时显式记录unknown，不无限免费重发。

“逻辑提交只生效一次”不等于“外部GPU/网络请求物理上只执行一次”。重试的实际成本都应计入。没有保存或继续实际GPU状态时，不声称同seed会恢复逐token生成。

故障矩阵至少包括：预留后未发送、已提交未收到确认、结果返回未落盘、落盘未记账、重复完成、取消与完成同刻、新基线与完成同刻、截止相等、超时后返回。不能通过丢掉失败机会保持分数。

Temporal的幂等/持久执行材料可借鉴设计原则，但本计划不要求安装Temporal、Redis或另一套工作流平台。

## 6. D准备：当前代码匹配冻结卡，不要把它误判为坏实现

`DECISION_SCENARIO_CARD_CN.md`明确：开始即支付固定费、预留清理费、运行和ready期间都占资源、就绪为闭区间[完成,过期]。本次P02-P05实际验证与该卡一致。

总体计划中的可周转队伍、半开覆盖和实际工时费用是另一种任务。新实验必须版本化：

- `hold_while_ready`：安装/值守型资源，ready保持占用；保留旧卡。
- `release_on_completion`：施工/准备队伍完成后释放，防护能力状态独立保存。
- 分开`prepare_by`与`demand_at/coverage_interval`；不能在准备截止就ready却需求时已过期还给保护信用。
- `fixed_start_charge`和`metered_labor`是不同成本模型；不把旧固定费说成实际人工时。
- 取消、清理、重启规则有显式合同。预测回退不撤销真实已花准备费用。

旧闭区间D卡在过期恰等于截止时给ready，是合同选择；新半开区间必须新版本。D仍是research_assumption，不能解释为现实灾损减免。

小任务先独立枚举，后接OR-Tools的资源约束；优化目标为当前合法风险下研究损失，而不是默认makespan。共同资源的可加风险中性损失未必需要联合分布；只有真正非可加容量后果或多阶段依赖需要时再建联合风险。

## 7. 科学优先级：从小格式实验走向有解释力的比较

### 7.1 不重复制造新F-only烟雾试验

已运行F-only并且同值；下一批要有明确问题：从原生TAF解读、科学事实组织、概率融合、采纳控制中，究竟哪一环发生变化？保持旧输出。候选优劣依赖未来样本整体，不以改得多为好。

TAF6/18覆盖正确率需要分解当前源选择、native ddhh解码、目标epoch/ISO转换、窗口包含。把已给UTC微秒改成ISO是可逆表示；把TAF端点解析成ISO是额外处理工具。后二者不可混称纯格式对照。所有方法可用相同廉价解析工具。

### 7.2 固定证据、固定预测器两个方向都保留

比较B、f(B)、f(B,E)，并在少量合法证据组合上交换统计预测器与已冻结模型。当前all_registered不是全部天气资料，最新本站和邻站序列等候选要按物理关系与可用性登记。

本地化已经做且跨年份方向不同，不重新要求同样工作。后续应区分地区、训练长度与信息表达；检查期无正例不认证尾部校准。不要依据已暴露日历挑赢家银行。全部历史负结果保留。

首批比较有限、合法且能给出解释的条件；模型配置可以加入一个有依据的推理/非推理对照，但不把官方推荐配置当保证，更不把换配置后获胜设为准入条件。

### 7.3 2x2与真实费用

固定同一selector做quota/global×private/shared，再在global/shared下比较策略。现有1ms程序、30秒公用时隙和目录请求费用是声明情景，不能写成2025年实测资源约束。保留现实批量全读很便宜的事实。

源查询E参照只优化可认证事实，不是未来F/D最优；所有目标共同可达必须来自同一条费用与截止合法路径，不能相加单目标预算。

### 7.4 第二领域并行，不被D阻塞

当前`TypedAviationRuntime`依然包含航空专用概率和槽位逻辑；不能仅因为通用Forecast支持scalar就宣称温度/水文已经进入同一个自适应controller。

温度负责最快数值会话迁移；H07负责候选原生降水时序+专业处理选择；H08并行核断面、调蓄与时间支持。H07可以复用pysteps，但要求合法降水量/率、规则时步、网格和motion field，不能直接喂VIL或任意图。H08没有官方警戒水位阈值不必阻断已合格连续流量，但物理支持未知不能评分。16类范围继续登记，不同时造16套引擎。

## 8. Codex实施顺序

第一批RV00-RV05：核对差异，新增真实包回归，补目标结果和比较合同，验证源生命周期，分开F与采纳，利用旧响应做TAF诊断。不新增大规模模型调用。

第二批RV06：CPU故障注入下的在途状态；可并行RV10的已有数据provider工作。

第三批RV07/RV08：获准后真实执行器恢复与有限模型/统计比较；不复用已消费job。

第四批RV09/RV11：D语义分版本、小优化器、真实C2联合路径和公平资源曲线。

最后RV12：新的独立时空块确认和分级发布。D/MM/prospective分别有门槛，不让全依赖链阻断F/C2核心。

机器工作包见`CODEX_BACKLOG.json`；问题性质见`AUDIT_FINDINGS.json`。这里的文件名和职责为实施建议，不宣称已经在仓库创建。

## 9. 复现与验证要求

先将本地探针迁成真实package测试，不能把此次mock单元结果当作端到端验证。现有文档列出的回归入口是：

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=disastertrace-starter/src python -m pytest \
  disastertrace-starter/tests/test_monitoring*.py \
  plans/v7_execution_20260913/tests/test_fixed*.py -q
```

这是仓库已有说明，不是本复查已执行的命令。新增测试另列，原313结果不重复记为天气样本。独立CPU证据包按仓库`REPRODUCE_CN.md`恢复到新目录。

每个结果至少绑定：数据及处理版本、模型运行冻结、状态协议、评分器、比较签名、结果结算版本。若新检查发现真实历史数据差异，生成独立correction报告并保留旧版，不覆盖原统计。

## 10. 研究主张与停止条件

C1仍测共同基线变化下补证和处理是否值得，C2仍测合法支持及联合可达性怎样与模型表现联系，C3仍要求不同物理过程与独立时空确认。修JSON、修时钟或加hash是可信测量基础，不作为主要novelty。

发布允许正/零/负增益。若强便宜批量已经最好，保留。若准备收益只由任意费用比例造成，说明情景敏感性。若仅有时间格式错误，不外推成天气科学推理失败。若新D没有可信来源或业务审查，明确称研究规则下的仿真。

本轮完成：源码定向读取、14个局部CPU探针、补丁工作包和依赖检查。未完成：完整仓库回归、所有归档复验、真实新模型/数据/业务动作。
