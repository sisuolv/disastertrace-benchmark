# Codex 首轮启动说明

请先完整阅读 `REVIEW_AND_CODEX_PLAN_CN.md` 和 `plan/`。它是原CP00–CP14的增量计划，参考提交为 `6c7c7e81ad88e1d3a553727607e24c858136899d`；实际HEAD可能更新，先对照差异，不reset。

## 本轮先执行

1. `CP00-update`：检查AGENTS.md、工作区、已有授权、源码/执行快照和313项已发布测试；更新已完成/待完成表。不要重新实现已有AdmissionEngine、F-only、航空C2和quiescent恢复。
2. `CP01-version`：将附带TAF反例变成直接项目函数回归；统一E、F builder和运行时的当前产品选择。先按同系列真实替代关系确定当前产品，再判断覆盖；同刻冲突不以文件名定输赢。
3. `CP01-comparison`：在现有合法日志评分之前加入ComparisonManifest，绑定共同基线外部流、provider、资费和允许的因素差异。保留合法2x2和协议敏感性实验。
4. `CP02-bind`：独立绑定query目录与原始站点/槽位/单位，复用已有支持桥和joint solver，给出同一条真实资源路径。
5. 对已有本轮24小时日历完成完整程序对照和影响统计，不先增加GPU矩阵。

## 先量化影响，不事后改写成绩

附带源码摘录只证明边界行为，并未证明91份自然TAF中已有该情况。必须扫描真实文件，分别输出affected与unaffected数量，允许为0。旧输入、原回复、原基线、Gold和失败保持原样。新provider导致输入改变时，旧回答不能叫作新条件模型输出。

可先用只读辅助脚本做候选筛查；它不是完整原文验真或Gold修正器：

```bash
# 在项目根目录运行；将 REVIEW_PACKAGE 设为已解压的本复查包路径。
python "$REVIEW_PACKAGE/probes/audit_taf_candidate_index.py" \
  --dataset plans/v7_adaptive_execution_20260913/development_dataset_01 \
  --declared-replay-lag-seconds 120 \
  --output plans/v7_review_6c7c7e8_next/impact/TAF_INDEX_SCREEN.json
```

120秒是在复用旧builder的显式归档情景，不是测得的历史延迟。若原数据封存在已有归档，先按仓库复现说明恢复准确数据；缺失时报告，不能自动换日期或伪造资料。

## 第一批必须交付

- 实际代码修改和定向回归，而不只是复述研究计划。
- `CURRENT_STATE_DELTA.json`、`TAF_PROVIDER_RECONCILIATION.json`、`VERSION_IMPACT_AUDIT.json`。
- `COMPARISON_MANIFEST.json`、`COMMON_BASELINE_PARITY.json`。
- `QUERY_SOURCE_BINDING_AUDIT.json`、`JOINT_PATH_WITNESSES.json`。
- 原测试/新增测试真实输出、全部失败与不能验证的范围。
- 完整日历程序结果与下一批模型/数据的明确预算请求。

## 边界

当前请求是审查与计划；默认先离线和本地已有数据。有效授权已明确的事项不重复询问，但不能把历史4卡/两小时窗口当永久许可。新科学下载、权重、GPU、训练、付费API需对应有效范围；不push，不控制现实设备、不发布公众告警。

CP04b在途恢复、CP05原生多模态数据准备、CP07准备语义审计可并行；F/MM不必等待完整D、训练型选择器或所有16类通过。无增益是允许的研究结果，不以LLM获胜筛选确认样本。
