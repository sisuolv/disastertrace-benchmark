# DisasterTrace v7：6c7c7e8 实现复查与 Codex 增量执行计划

- 复查日期：2026-09-13。
- 仓库：`sisuolv/disastertrace-benchmark`，分支：`next-phase-v1`。
- 本轮固定提交：`6c7c7e81ad88e1d3a553727607e24c858136899d`，前一参考提交为 `60ebd05723f9483590611976d379da2e4edd85b0`。
- 用途：先确认当前实现边界、修正会影响实验解释的规则，再推进原生多模态、完整状态分支和独立验证。本文件不是新的 v8。
- 状态：本轮完成只读源码/报告复查及局部合成诊断，未修改仓库，未重新执行313项项目测试、252次模型推理、原始科学数组或原发布ZIP。
- 继承：v7、C1/C2/C3、X00–X09、六组16类、E/F/D/MM以及原CP00–CP14。下面11项是原CP的增量排程，不是另建11个宏大研究方向。

## 0. 给 Codex 的首要决定

**先执行 CP00-update、CP01-version、CP01-comparison、CP02-bind 的离线工作。**完成现有24小时日历的版本一致性和程序化影响重算后，再执行新的限额模型实验。原生多模态的数据准备可以并行；不要求它等待完整在途分支、D-sim或全部16类准入。

不要继续沿用这些已经过时的判断：

- “正式评分准入尚未实现”：现有 `AdmissionEngine` 与 `score_admitted` 已建立日志和截止路径；需要补的是跨方法比较合同，而不是重写准入。
- “F-only从未运行”：本轮已有真实F-only。新问题是含F输出仍没有相对基线的变化。
- “C2只有字段没有实现”：`support_bridge.py`已对真实航空原文做重解析、范围与版本支持；需要补的是provider职责一致性、独立请求身份绑定和真实共享动作图。
- “只能单题运行”：类型化适配器已使用原 `run_session`、共享时钟和全局资源。
- “完全没有分支恢复”：已有独立进程的静止点恢复；尚未实现任意在途恢复。
- “D状态机需要从零写”：已有 `PreparationReducer`，应补语义、真实合同和组合恢复。

## 1. 核实的当前进度

### 1.1 代码与证据层

| 部件 | 当前已实现/已发布的证据 | 后续范围 |
|---|---|---|
| `monitoring_fixed_v1/admission.py` | 调用开始、冻结bundle、完成与持久回执、截止封存、日志重放和有效预测评分 | 加入实验级共同外部流与费用/权限比较准入 |
| `monitoring_fixed_v1/adaptive.py` | 新类型接回原控制器；实际已付证据回执转为可见bundle | 当前专门支持H15；不是通用原生图片/任意连续量自适应环境 |
| `monitoring_fixed_v1/support_bridge.py` | 原生METAR重解析与可见事实支持，TAF覆盖/版本工具 | 更严格的查询目录绑定、统一provider、真实动作资源见证 |
| `monitoring_fixed_v1/taf_tasks.py` | 完整TAF的当前版本/覆盖E任务及评分 | 与F构建器的“当前”规则必须统一 |
| `monitoring_v1/session_checkpoint.py` | 静止点保存/恢复，原控制器逐tick继续，前缀不重发 | 预留非零或调用未完成时明确拒绝，不能称任意时刻fork |
| `monitoring_v1/event_loop.py` | 原/类型化归约器共用确定性时钟 | 继续复用，不引入第三套生产时钟 |
| `monitoring_v1/preparation.py` | 合成准备、占用、完成、取消、清理和成本 | 规则身份、容量语义、准备与在途恢复、真实业务验证仍独立 |

### 1.2 本轮数据与实验，注意计数单位

最新发布记录：313项相关测试通过；97次新增来源请求；288条METAR和91份TAF被解析；新开发日历包含174个目标、432个机会。低于1km为0/216正例，低于5km为2/216正例。多个提前量、阈值与同一天多站仍不增加独立天气过程数。

模型设计为：12个机会 × 3种证据条件 × 3种head × 2种表示 = 216次，另加18次TAF覆盖与18次TAF版本选择，合计252次新调用。另有108次旧调用保留，不应算作360个新样本。

| 条件 | 已发布结果 | 解释 |
|---|---:|---|
| 含F输出 | 144/144沿用共同基线 | F-only已实际运行；没有观察到该切片中的数值修订收益 |
| E-only：full / focused | 24/36 / 33/36 | 输入组织、任务相关内容与额外说明共同变化，不能只归因于时间显示或纯格式 |
| joint E：full / focused | 30/36 / 32/36 | 开发对照，不是跨过程泛化 |
| TAF覆盖 | 6/18 | 需要拆分版本选择、原生时间解码与包含关系，不先认定天气知识失败 |
| TAF版本选择 | 16/18 | 不等于已经通过所有自然冲突、取消与不可解析边界 |

本轮程序型共享会话在两组3小时/27机会窗口完成，6种对照、独立进程分支有记录。发布包重放36份typed日志和8个controller分支。这证明工程行为可复查；不等于新的252调用是在完整共享预算下作出的主动策略轨迹。

记录中的1ms程序耗时、1ms持久化、30s公共调用槽位属于声明的归档成本/时间条件，不是历史业务真实延迟。新720/252等批次数值不得覆盖旧版本相应报告。

## 2. 实现复查发现：先区分缺陷、门槛与未完成

本轮局部检查位于 `probes/source_excerpt_probes.py`：共6个函数摘录级场景，其中3个暴露问题/缺口，3个是正确行为对照。输入为合成已解析产品或已恢复engine fixture；**不是原项目的313项测试，也没有重新执行原文获取、完整parser/build/journal链**。

### R01 / P0：E与F对“当前TAF”的选择顺序不一致

实际代码位置：

- `plans/v7_adaptive_execution_20260913/build_regional.py:155–180,216–231`。
- `monitoring_fixed_v1/taf_tasks.py::evaluate`及其 `COMMON` 说明。
- `monitoring_v1/providers/taf_timeline.py::target_withdrawals`。

当前构建器先要求 `product.project(target_start,target_end)` 成功；不完整覆盖目标的产品被跳过。随后才在剩余候选中选最新。因此它回答的是“最新的、能覆盖这个目标的产品”。

TAF E任务则先从所有合法披露的产品中选最新发行版，再检查覆盖，并明确规定较新的CNL或短有效期产品不能让旧覆盖版复活。它回答的是“当前产品是否覆盖目标”。

**合成反例：**同站旧产品00Z发布、覆盖到次日00Z；06Z已发布AMD、只覆盖到12Z；10Z时预测当日15–16Z。当前候选构建逻辑会留下旧产品；withdrawals又跳过active新版。E协议会看到最新产品不覆盖目标。二者可在同样前缀下给出不一致状态。

AWC官方TAF说明指出，AMD发行后即取代/取消此前TAF，不必等待新有效期起点。因此至少对声明为同系列替代的AMD，不能仅因新版不覆盖就继续把旧版当当前业务预报。[AWC]

**范围限定：**这是代码路径和任务契约的已确认不一致。本轮未扫描全部自然报文，尚不知道现有91份报文/432机会及旧日历是否真正出现该条件；不能据此断言已发布Brier或6/18覆盖题分数错误。

**实施决定：**统一provider生命周期归约器，先解决时刻可见的当前产品，再计算目标覆盖/条件投影。系列、站点、发布/到达/订正顺序按来源合同；缺失、取消、未支持语法与不覆盖都显式记录。原产品、原失败和旧结果全部保留。对其他非TAF来源不能盲目套用“任意最新产品抹掉全部历史”。

### R02 / P1：同发行时刻的语义冲突，不应由source_id字典序裁决

当前 `latest` 使用 `(issued_at, source_id)` 排序，产品内容不参与冲突处理。两个同刻且内容不同的候选，会确定性选择字典序较大的ID。E任务却会重解析当前产品并对语义差异标conflict。

这是已复现的函数行为，**不是已经在本轮自然资料中发现同刻冲突**。同刻有原报与COR/AMD时，只有经来源资料证明的修订顺序能作为优先级；没有这种证据，就保留冲突/unsupported与fallback。等价镜像应保留全部来源身份但不增加独立观测权重。

R01/R02合并一个provider修复，不要写两套补丁分别处理E与F。

### R03 / P1：正式评分已有时间准入，但跨方法“同共同基线”不是自动保证

`score_admitted()`先从持久日志恢复engine，并检查engine.contract相同、全部机会封存。现有contract含目标/机会、fallback、protocol、time_basis和可选preparation，未绑定全部外部baseline时间线和实验费用/权限配置。

本轮以同contract的已恢复fixture分别给A、B不同共同baseline，评分函数接受。它说明：**两个运行各自合法，不自动意味着它们可以被解释为公平的同基线比较。**这个局部fixture没有测试日志读取器，更没有证明现有运行数据被篡改。

当前 `execute_typed_session.py` 对全部方法确实使用同一份data和bank，并检查实际账本，因此不能将上述防御性缺口写成已发表对照不公平。

**实施决定：**加入必经 `ComparisonManifest`，绑定共同exogenous stream、provider/数据构建版本、目标/结果合同、公开基线身份、资费定义和允许的因素差异。不同方法的授权、分配或wrapper作为显式实验因素允许变化。不要为了“严格”而禁止合法2×2。

### R04 / P1：CP04a已经通过；CP04b才是尚未实现的恢复能力

`capture_session()`明确拒绝非零reserved或未完成calls，正确地将当前能力限制在quiescent checkpoint。不要删除该保护来“支持在途”。

CP04b要区分：

1. 逻辑事件只应用一次，可以由幂等ID与日志控制。
2. 外部推理/网络请求物理上只执行一次，在发送后崩溃且无供应方可查回执时未必能保证。

对第二种情况保存 `SENT_UNCERTAIN`，对账、保留可能发生的费用，并按预先规则决定重试；重试是另一次物理尝试，不可择优选回答。新schema才能承诺对应恢复范围。

### R05 / P1：当前E成绩变化不能当作已识别的纯感知或多模态收益

`focused_view`除按槽位呈现证据外，在E-only条件移除了target/baseline/state，系统指令也追加了说明。它可以作为实用的任务聚焦方案，但原比较同时改变了多个因素。

下一步先分析已有36条TAF回答，不盲目再运行大批量。时间表示对照应将同一个整数UTC时刻用可逆ISO字符串显示；额外解析出TAF的正确有效期或覆盖关系属于工具辅助，不应悄悄混成格式修复。

新batch没有原生图像消息。旧视觉能力保留，但“旧MM演示 + 新文本未来评分”不能相加成“主动多模态未来监测已实现”。

### R06 / P2：C2请求与原文的独立绑定需要补抗错误重标测试

目前bridge会检查原始METAR与payload的站点/时刻/区间自洽；上游builder也真实检查站点对应。尚未观察到错误配对。

但未来替换provider时，应再对独立注册的query catalog验证站点、槽位、报告政策与单位。不要只检查“raw站号==payload站号”而放过“这两者都不是题目要求的站”。此项属于防御性准入测试，不是已经证实原数据有错。

## 3. 第一轮必须输出的影响审计

源语义修复不能悄悄覆盖旧数据，也不应为了保留旧成绩而不修。

对每个目标/机会输出：

```text
原共同产品及来源链
新统一resolver的当前产品及来源链
旧/新状态：active / no_coverage / partial / canceled / nil / unsupported / conflict
旧/新规范投影与context hash
对应实际模型输入是否变化
参考结果本身是否变化（与输入变化分开）
旧输出仍可重算哪些诊断，哪些必须新调用
```

真实影响报告必须包括：总机会、可比较机会、受影响数、每类原因、旧/新来源哈希以及已检查范围。若0受影响，则说明“现有样本未触发该边界，回归修复用于后续扩展”；不可将这个修复当作已解释当前模型负结果。

原始F回复不能被套到新的baseline/输入后称为新模型结果。可以在明确限定下重新算旧预测相对另一个参考的描述性指标，但要注明不是该新运行条件下的策略实验。

## 4. 正确性与novelty之间的关系

本计划坚持用户附件的研究主线：让取证与处理选择服务真实监测任务，并通过同状态真实分支验证收益来源；准备任务另有时间、占用和取消规则。不是继续堆叠功能名称。

| 贡献 | 下一步可检验的具体问题 | 不能拿来替代的东西 |
|---|---|---|
| C1 | 共同更新基线、真实共享资料与计算条件下，选哪里/用什么工具/是否修改是否值得？ | 查询次数、强行提高API价格、让LLM独占工具 |
| C2 | 同一合法前缀下，E/F对产品版本是否一致？同一路径可完成哪些目标？信息在获取、处理或采用哪一步失效？ | 原始图像被隐藏标签自动认证、解释文本、单目标最优相加 |
| C3 | 这些规则和效果能否在新过程、不同物理量、原生多模态和前瞻记录中复现？ | 更多帧、时效、阈值或重复调用 |

代码正确性是必要条件，不是独立的首创性证明。当前本轮没有进行完整新文献首创性检索，因此不提出“全球首次”或保证发表。已有附件对近邻的比较作为研究背景保留；在写论文前由CP13再次以完整原文核验具体主张。

**计划成功不等于必须让LLM赢。**允许相同专业基线+廉价批量+专业工具持续优于Agent；只要过程独立、任务非退化、对照公平且边界清楚，这就是研究结果。禁止根据模型获胜、失败题或事后最佳路径选确认样本。

## 5. 新实验最小设计：不要再展开所有组合

### 5.1 数据正确性先行，但不等待全部16类

先复用已有本轮24小时日历；修复后以新冻结建立全432机会程序对照。无正例期保留，不得改阈值凑正例；它仍可用于工程/非事件表现，但不能证明极端召回或校准。

确认性队列使用新的预登记时间与区域，训练、概率映射、prompt和策略先冻结。所有已观察日历均是开发材料。主队列为固定时间生成目标，另设可标明富集标准的机制集合，不能把富集样本的发生率当自然发生率。

### 5.2 预测损失的两种差值同时保存

对相同预测器f、基线B、额外证据E和未来结果Y：

```text
补证对模型自身的变化 = L(f(B),Y) - L(f(B,E),Y)
整个系统相对基线的变化 = L(B,Y) - L(f(B,E),Y)
```

前者可能只是在修复模型自行从合理基线退化到0.5的问题；只有第二个量才能说明系统超过相应共同基线。二者都不提供每个样本唯一正确概率，也不证明某一次修订在当时理性。

### 5.3 分别测四个环节

- 固定预测器与预算，比较selector。
- 固定已获合法证据，比较表示/感知和预测融合。
- 固定已实际生成的候选和完成时间，比较两种wrapper或gate。
- 固定完整状态与继续策略，比较有限真实动作分支。

同样内容更好表示的收益不是新增观测；专业派生产品也不自动独立于原始传感器和业务预报。只测已实际运行的分支；没有实际回复的反事实方法不得复用不对应的旧回答。

### 5.4 模型预算建议：先限定实验问题，再给数值上限

第一批是离线正确性工作，不运行新GPU。下一次模型批次的请求数应由冻结矩阵自动展开，例如 `N机会 × 证据条件 × head × 表示 × repeats`；每项都保留父过程ID，矩阵元素不算独立事件。

在已有F-only已实际跑过的前提下，下一批只测试有新的明确因素：可读时间对照、可选视觉或有物理依据的补充资料；不为追求不变概率以外的回答添加诱导修改指令。

总预算比较包含selector、预测器和重读费用；固定预测机会的诊断额外费用单列。合理批量下载和专业工具开放给所有方法；模型耗时/下载延迟实测与声明仿真时钟分开。

## 6. 多模态及第二物理过程：近期必须有独立交付

### H15 / 现有任务的最短迁移

先用合法同期ABI资料扩展一个同目标固定输入链，不要求首先自由选图。通过后再开放概览、预登记ROI和时序读取动作。保存真实图片、原始产品、观测/可用/交付时间、通道/投影/渲染、像素网格、视觉token、处理器和完整请求。

固定供图、主动选择图、工具辅助和特权参考分别报告。不是以PNG路径存在证明VLM看图，不用隐藏mask生成的答案替代视觉任务。

### H07 / 强化时空图像与处理方式选择

保留连续真实雷达/QPE来源，按产品核定是雨率、反射率、VIL或累计量。资料缺时、扫描/QC或空间支持错误不能用零填成晴天。固定物理支持、时间间隔、网格和目标结果。

可复用pysteps的STEPS/外推或融合接口作为强领域对手和所有策略可调用的工具。它要求正确时序与物理输入，输出是预测而不是真值。原生QPE产品可做命名产品结果，不能未经论证改称全部地面真实降雨。[pysteps]

### H08 / 保持已有实质进度，不跳物理合同

CNRFC历史QINE已有文件和版本变化，不再把它当“没有档案”。仍需核准小时支持、regulated/unregulated、站点/断面、SCOC1与SCOC1F、历史成员身份、单位与观测身份。未核准前可做产品版本E，不打连续F正式分数。不能拿水位阈值套流量或从地理距离猜上下游。

### 温度 / 类型迁移与极端过程分开

EUPP/DWD的点温度可以用来验证概率以外的标量和严格时效/结果准入；普通温度片段不称热浪/寒潮。reforecast与原生历史业务forecast分轨。CMA、xBD等未闭合细节不阻塞当前合格路线。

## 7. 在途恢复和分支：最小正确语义

扩展前保存旧quiescent快照与测试。新快照至少包含：目标/机会封存、基线/覆盖状态、外部流位置、账本已花与预留、缓存和访问权、在途动作、实际返回/持久化状态、model input/hash、RNG、继续策略以及D准备状态。

单个逻辑调用对应0至多次物理尝试；明确 `RESERVED -> SENT -> RESPONSE_DURABLE -> APPLIED`，对无法查明的发送使用 `SENT_UNCERTAIN`。不要求在没有供应方支持时做到不可能证明的外部exactly-once。

在受控回放中，已有响应按冻结完成时间交付；真实前瞻中以真实回执/持久化为准。不得为了让恢复成功将迟到回答的提交时间改早。

同一目标多个机会分别封存；较早截止不关闭后续合法机会；全部目标关闭后的控制动作不得改历史快照。未来产品清单、未读返回、结果奖励、oracle路线不得被检查点公开视图带入策略。

## 8. D-sim：保留，但不要让它拖住E/F/MM

现有 `PreparationReducer`已经有running、ready、cleaning和成本。下一步先写清其规则：

- `ready`是否持续占用资源？若资源是安装后设备，可合理占用；若是施工人员，可能应在完成后释放。不能一个字段同时解释两种对象。
- 到期时刻是否仍保护？代码、场景卡和论文必须一致，旧版本单独保留。
- 当前容量不足是拒绝还是排队？没有队列的版本不可称完成排队调度。
- 原代码启动时支付固定cost，是否等同工时模型？不同成本定义单列，不能事后转换成现实工资或避免损失。
- 预测回退不取消已开始的准备；取消和清理不可免费。

先固定实际预测序列比较简单规则与同优化器，再固定调度器比较预测器。OR-Tools可以提供互斥/先后关系的参考实现，但不能提供真实的准备时长、资源需求和防护效果。[OR-Tools]

同天气不同需求实验继续保留：固定信息和计算时只改成本不应被系统定义成新的天气事实；若策略因此取得不同合法资料，后续预测可合理改变。输入隔离的软件测试与端到端模型行为测试分开。D仅称研究假设下结果，不向公众发预警，不控制设备。

## 9. 前瞻与确认：一个有限闭环，不是无限等新灾害

可以并行准备固定地区、时段、目标、预算与停止条件的影子运行，先用普通窗口检查数据到达、版本、实际推理、截止提交和结果结算。

首次观察即已存在的产品只形成左删失first-seen；连续轮询可给出发现区间，不是精确全球发布时间。结果为provisional/final/missing时按预登记成熟度规则分别结算。

历史回放的时间门控不能证明模型预训练未见过事件；隐藏事件名也不能提供这种保证。前瞻解决部分时间污染问题，但仍需权限隔离和不得对外操作。核心历史研究不必等待未来重大灾害，前瞻成绩也不得由事后重跑替代。

## 10. 交付与运行边界

本轮调用者要求的是审查与计划，不是新执行授权。Codex开始时读取实际有效执行范围；有明确现行许可时按其上限执行，不重复询问已知事项；没有新的GPU/网络/付费范围时先完成离线修复和本地审计。

此前“最多4张H100”是并发上限惯例，不是永久授权。旧已结束的启动目录、token、job不复用。任何首次新源/权重/大归档/付费调用在对应范围内进行，凭据只留本地且不得出现在GitHub或审阅包。

新代码优先在已有职责模块增量修改，保留旧执行源码快照。不自动reset、不覆盖旧Gold、不改原失败、不push。新增固定版本结果独立目录；语义修复如影响输入要新冻结，模型输出不能跨输入借用。

## 11. 本轮审查的范围与诚实边界

已完成：当前分支定位，核心报告与定向代码读取，官方TAF说明核对，6个函数摘录级fixture诊断，以及本计划包的结构/依赖/完整性检查。

没有完成：全仓库完整审计、313项回归重跑、原科学数组重下载、252次/旧批次推理复现、原发布ZIP的独立解压。原ZIP的connector接口只支持UTF-8文本；工作容器的直接获取遇到DNS失败。不得据此推断用户CCI不可联网。

已执行的6个场景详见 `evidence/SOURCE_EXCERPT_PROBE_RESULTS.json`。3个问题观察是版本筛选、同刻字典序裁决、跨方法基线比较检查；3个正确对照为普通新版、覆盖NIL撤回、不同机会合同被拒绝。它们需要由Codex转成直接项目导入测试，并对真实报文做影响统计。

**本计划的68条验收规格均是待执行的规格，不是68项已通过的项目测试。**


## 12. Codex增量工作包（完整定义）

所有项目均待执行；表中路径为已读取现有位置或建议新增位置，应先检查工作区再修改。

### CP00-update｜更新实施状态与本轮复查基线

继承：CP00。依赖：无。执行：`offline_cpu`。

代码/资料位置：
```text
plans/v7_adaptive_execution_20260913/
plans/v7_next_20260913_2/
plans/v7_review_6c7c7e8_next/
```

实施步骤：

1. 读取实际HEAD、所有适用AGENTS.md及未提交/暂存差异；参考SHA不是reset目标。
2. 将CP01准入、CP02航空桥、CP04a静止点恢复、CP06真实F-only、CP07合成准备从待实现更新为已实现/有限验证。
3. 建立当前源码、原执行源码、来源快照、已暴露数据和待确认数据的身份表。
4. 保存现有313项测试的原始清单；实际重跑的集合和新增集合分别记录，不将历次数量相加。

交付物：`CURRENT_STATE_DELTA.json`、`SOURCE_LOCK.json`、`READ_SCOPE.json`、`REGRESSION_BASELINE.json`。

验收：

- 无旧捕获/Gold/权重/原始失败被覆盖；现有保护集不变化。
- 不把源下载、工程测试、模型调用、独立过程计成同一种完成量。

### CP01-version｜统一TAF生命周期与E/F当前版本规则

继承：CP01, CP02, CP03。依赖：CP00-update。执行：`offline_cpu`。

代码/资料位置：
```text
disastertrace-starter/src/disastertrace/monitoring_v1/providers/taf_timeline.py
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/taf_tasks.py
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py
plans/v7_adaptive_execution_20260913/build_regional.py
```

实施步骤：

1. 先将附带反例转成直接导入项目函数的回归，并增加真实原文parse_taf与builder fixture；不要只复述摘录诊断。
2. 新增或复用唯一provider级当前产品归约器：先按当时已交付产品与已核验系列/订正规则解决版本，再计算对目标的覆盖。
3. 明确已废止、不覆盖、NIL/CNL、当前不可解析、同刻冲突、等价镜像；旧版不因新版缩短或不可解析而复活。
4. 同发行时刻仅按官方可证明的序列/修订关系排序；否则语义相同保留镜像，语义不同冲突/回退，禁按source_id选真假。
5. E评估、LATEST_BASELINES生成、baseline事件与withdrawal事件共同调用该归约器，不在四个地方各维护一套规则。
6. 只读扫描本轮91份原文、432机会及其他实际复用日历；输出每个受影响机会的旧/新候选、原因、覆盖、基线上下文与输入哈希。
7. 若输入/基线发生变化，只对新冻结进行新程序执行；原LLM回答保留，不能声称它们是在新输入下产生。

交付物：`TAF_LIFECYCLE_ADR_CN.md`、`TAF_PROVIDER_RECONCILIATION.json`、`VERSION_IMPACT_AUDIT.json`、`TAF_REGRESSION_RESULTS.xml`。

验收：

- 缩短AMD、同刻冲突、正常新版、镜像、NIL/CNL和月末边界均有实际函数回归。
- E当前版本身份、F共同基线身份与运行时事件一致；若不同须有明确不同provider合同。
- 实际受影响数量由扫描得出，允许0；未扫描不得把合成缺陷写成历史成绩已错。

### CP01-comparison｜补齐跨方法比较准入而非重写评分器

继承：CP01, CP09。依赖：CP00-update。执行：`offline_cpu`。

代码/资料位置：
```text
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py
plans/v7_adaptive_execution_20260913/execute_typed_session.py
disastertrace-starter/src/disastertrace/monitoring_v1/session_checkpoint.py
```

实施步骤：

1. 保留score_admitted的日志重放和数学评分，增加不可绕过的实验级ComparisonManifest校验。
2. 绑定共同目标/机会、参考成熟度、基线外部时间线、校准器、provider解析规则、允许动作、成本定义、时钟规则、数据与表示版本。
3. 允许实验事先登记的因素差异：分配、授权或wrapper；不要要求2x2所有config完全一样。
4. 对每个共同检查点和关键基线事件检查共同源集合/规范内容；不要只比较最后一个概率或最终基线。
5. 恢复分支绑定实际旧前缀与允许controls。绑定资源账本摘要和回执，用于判断结果属于纯预测对照还是成本公平对照。
6. 原execute_typed_session已经共用data/bank：先验证现有运行满足新的检查，不宣称它已使用不公平基线。

交付物：`COMPARISON_MANIFEST.json`、`COMMON_BASELINE_PARITY.json`、`COMPARISON_NEGATIVE_TESTS.xml`。

验收：

- 相同机会但不同共同基线的两个合法日志必须在声明的公平主比较中被拒绝。
- 合法的分配×授权2x2必须能通过；协议变化只进入明确登记的重放/独立运行子实验。
- 跨方法基线、源权限和资费定义不能静默改变。

### CP02-bind｜加强真实E对象绑定与同会话联合路径

继承：CP02。依赖：CP01-version, CP01-comparison。执行：`offline_cpu`。

代码/资料位置：
```text
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/support_bridge.py
disastertrace-starter/src/disastertrace/monitoring_v1/reachability.py
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py
```

实施步骤：

1. 保留已实现native_slot_support，不再把C2写成完全未接入。
2. 将query_id绑定到独立登记的站点/槽位/报告政策/单位，验证原生站号和时刻属于该请求，而不只验证payload内部自洽。
3. 覆盖/版本E使用统一provider规则；需要精确支持时按公开产品合同，原生图像仍属perception而非隐藏标签证书。
4. 从真实会话目录、已付/预留资源、权限、发布时间、处理时长与目标截止构建有限剩余动作图。
5. 新语义bridge输出证据见证及拒收原因；联合solver复放同一条路径，不把单目标独占预算最优相加。
6. 区分源查询E上界、包括处理/推理的可行性参照、F或D损失的事后路径差异。

交付物：`QUERY_SOURCE_BINDING_AUDIT.json`、`REAL_E_CONTRACTS.json`、`JOINT_PATH_WITNESSES.json`。

验收：

- 错误站点/槽位、未读源、隐藏标签、未支付父资产一律不能认证。
- 两个各自可达但联合不可达、共享资产仅付一次、处理依赖、版本过期均有见证与反例。
- 截断搜索输出界和exact=false，不用未来结果为部署策略选动作。

### CP04b｜在途恢复与完整状态分支

继承：CP04。依赖：CP01-comparison, CP02-bind。执行：`offline_cpu_then_bounded_tools`。

代码/资料位置：
```text
disastertrace-starter/src/disastertrace/monitoring_v1/session_checkpoint.py
disastertrace-starter/src/disastertrace/monitoring_v1/event_loop.py
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py
disastertrace-starter/src/disastertrace/monitoring_v1/resources.py
```

实施步骤：

1. 保留已验证quiescent checkpoint版本；新增显式inflight schema，不放宽旧schema的保证。
2. 保存未完成查询/渲染/推理的逻辑ID、物理尝试ID、冻结输入、上限预留、完成/持久化状态、剩余情景耗时和外部请求身份。
3. 外部请求已发送但没有可确认结果时标SENT_UNCERTAIN：先对账/查询回执，不能保证外部恰好执行一次。
4. 逻辑事件幂等提交；物理重试按全部消耗计账，用预定首次合法结果规则，不能选最好回答。
5. 同刻基线/已在途完成/cutoff按现有ADR执行；迟到结果保留但不回填。
6. 分支继承实际已付与预留资源、缓存权限、state、RNG、继续策略、准备进度与外部归档；无响应的反事实分支标不可评估。

交付物：`INFLIGHT_SCHEMA_ADR_CN.md`、`CRASH_MATRIX.json`、`CROSS_PROCESS_BRANCH_REPLAY.json`、`UNCERTAIN_REQUEST_LEDGER.json`。

验收：

- 崩溃注入覆盖reserve后、send后、响应到达但未持久化、持久化后未apply、apply后重复通知。
- 没有双重预算消费/免费继承/重复逻辑提交/历史封存变化；不能声明无法证明的物理exactly-once。
- 静止点旧重放保持一致；新分支只在声明动作空间中解释差异。

### CP06-next｜先完整CPU日历与可解释时间诊断，再小型新模型对照

继承：CP03, CP06。依赖：CP01-version, CP01-comparison, CP02-bind。执行：`offline_cpu_then_bounded_gpu`。

代码/资料位置：
```text
plans/v7_adaptive_execution_20260913/execute_typed_session.py
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/heads.py
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/representations.py
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/taf_tasks.py
```

实施步骤：

1. F-only已有实际运行，不再列为从未执行；保留144个F均不变和TAF6/18、16/18原结果。
2. 先对本次预登记24小时432机会完成程序/FOLLOW/固定一条/合理批量全读，分1km/5km及提前量；阈值不可因正例少而改。
3. 对现有36个TAF回答确定性拆分：current_source_ids、原生日期解码、支持区间和包含关系；不使用LLM judge。
4. 微秒数与ISO时间采用严格可逆转换；原始产品有效期的额外解析属于工具辅助条件，不能暗加到时间显示对照。
5. E-only原完整/聚焦对照还改变无关F内容和说明文字；将格式与任务相关上下文两因素登记，不把旧收益说成单一表示因果。
6. 固定同模型/同证据head，再在未用于提示调试的新日历小量比较；模型强弱二模型确认可后置。
7. 分开补证相对模型自身的恢复、整个系统相对共同基线的净收益，不奖励必须修改。

交付物：`FULL_CALENDAR_PROGRAM_REPORT.json`、`TAF_ERROR_DECOMPOSITION.json`、`HEAD_INPUT_DIFF.json`、`NEXT_MODEL_PREREGISTRATION.json`、`MODEL_RESULTS_WITH_BASELINE.json`。

验收：

- 完整432机会和缺失有共同分母；没有把12机会诊断Brier写成全日历分数。
- 时间显示没有新增覆盖答案；旧分数不重命名。
- 只在输入/Gold/基线正确性通过后使用新的限额模型批次；无收益不触发按结果筛样本。

### CP05-mm｜接一条真正可选的原生多模态证据链

继承：CP05, CP10。依赖：CP01-comparison, CP02-bind。执行：`bounded_data_cpu_then_bounded_gpu`。

代码/资料位置：
```text
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/representations.py
disastertrace-starter/src/disastertrace/multimodal_live_v1/adapter.py
plans/v7_review_6c7c7e8_next/multimodal/
```

实施步骤：

1. 复用已有视觉处理器核验；先读源代码确认原权重/processor与新输入格式兼容，禁止把旧演示当新链。
2. H15配同期ABI作为小迁移；H07配连续真实降水场作为重点路线。二者数据门槛分别验收。
3. 建立fetch原产品、render概览、crop预登记ROI、read时序、run专业处理的有类型动作；同源重新呈现不是新增观测。
4. model_request实际包含图片及视觉token/尺寸/裁剪/通道和源哈希；结果、未来帧、隐藏mask不得进入策略目录。
5. 固定供图、仅文本/数值、规则视觉查询、主动视觉分别比较，不从固定供图直接声称主动图像选择。
6. 专业处理结果允许全部策略访问并计费；传感器原始值、派生概率和最终参考保持身份。

交付物：`SAME_TARGET_MM_JOIN.json`、`VISUAL_ACTION_CATALOG.json`、`MM_REQUEST_AUDIT.json`、`MM_CONTROL_REPORT.json`。

验收：

- 至少一条同目标的合法原生图像→独立F结果链，不用孤立图片演示相加。
- 缺测/QC、观测与可得时间、波段和单位可核验；图像不是仅存在于磁盘。
- 固定供图已运行与主动视觉待验证分别计数，不预设图像必然带来增益。

### CP09-next｜公平共享资源与真实动作机制对照

继承：CP09, CP11。依赖：CP06-next, CP02-bind, CP01-comparison。执行：`cpu_then_bounded_gpu`。

代码/资料位置：
```text
disastertrace-starter/src/disastertrace/monitoring_v1/policies.py
disastertrace-starter/src/disastertrace/monitoring_v1/resources.py
plans/v7_review_6c7c7e8_next/resource_experiments/
```

实施步骤：

1. 先固定同一selector/预测器做分额×授权2x2，再在global/shared同格比较规则与LLM。
2. 保留FOLLOW、持续性/已冻结统计映射、批量共享、公开覆盖/风险排序、可行全读。
3. 分别报告端到端同总预算与固定预测机会的选择诊断；selector/重复处理成本不免费。
4. 旧1ms/30s/2048bytes等为归档场景参数，新真实成本测量单列；不因API便宜就抬价。
5. 小型前缀动作探针固定继续策略与真实返回；固定证据、固定候选、完整state分支不混称。
6. 低成本触发/短期计划复用作为强基线；训练风险回归选择器放后置，不能用确认集结果训练。

交付物：`FACTORIAL_MANIFEST.json`、`RESOURCE_BOTTLENECK_REPORT.json`、`ACTION_BRANCH_EFFECTS.json`、`COST_QUALITY_FRONTIER.json`。

验收：

- 禁止把两个因素同时改变的收益归因于单因子。
- source-E可达不等于预测或准备最优；事后分支不可部署。
- 在途机制实验须先通过CP04b；固定检查点对照不必等待完整D层。

### CP07-08｜复用合成准备层，补清语义与需求配对

继承：CP07, CP08。依赖：CP01-comparison, CP00-update。执行：`offline_cpu_then_optional_gpu`。

代码/资料位置：
```text
disastertrace-starter/src/disastertrace/monitoring_v1/preparation.py
disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py
plans/v7_review_6c7c7e8_next/preparation/
```

实施步骤：

1. PreparationReducer已实现，先审阅而非重建；running/ready/cleaning已占容量，一目标一作业是现行范围。
2. 用ADR声明容量是安装后持续占用的设备，还是完成后可释放的人员；不要用同一个capacity模糊两者。
3. 声明deadline/expiry的开闭端点、是否排队、无效取消、释放/清理成本与沉没成本；当前语义保持旧冻结，扩展单独版本。
4. 固定实际预测序列比较FOLLOW+规则和同优化器；再固定调度器比较预测器，D-sim不代替F分数。
5. 同天气与已读证据改变准备时长/容量/成本；F偏好字段隔离与端到端偏好污染分别检验。
6. 完整D在途恢复绑定CP04b；无业务验证时只称research_assumption，禁止真实公众预警或设备控制。

交付物：`PREPARATION_SEMANTICS_ADR_CN.md`、`FIXED_FORECAST_D_CONTROLS.json`、`DEMAND_PAIR_REPORT.json`、`D_RESTORE_GATES.json`。

验收：

- 预测基线变化不自动撤销准备；取消不退实际沉没成本。
- 未结算天气保留不确定损失，不自动将准备判为浪费。
- 核心E/F/MM发布不被整个D系统和现实专家验证串行阻塞。

### CP10-next｜第二物理过程和16类资格更新

继承：CP10, CP14。依赖：CP00-update, CP01-comparison。执行：`offline_and_bounded_data`。

代码/资料位置：
```text
plans/v7_execution_20260913/hydrology/
plans/v7_execution_20260913/sources_numerical/
plans/v7_0912_overall_research/
plans/v7_review_6c7c7e8_next/provider_admission/
```

实施步骤：

1. 保留97来源登记及所有旧解析证据，不为本轮另造竞争数量表。
2. H07严格雨率/累计窗、负码、网格、完整扫描和QPE/O参考；pysteps输出只是预测。
3. H08先核小时QINE的瞬时/平均、regulated/unregulated、SCOC1/SCOC1F、43/44成员、单位/历史基准，再评分。
4. 温度EUPP/DWD连续窗口可并行验证类型；普通温度不是热浪，reforecast不是历史业务可得证明。
5. LAMP维持原生英里/15分钟最低值新子目标，不改原小时1km/5km任务。
6. 逐hazard填写来源、工程接口、E、F、原生MM、完整会话、D、前瞻、独立确认不同状态；联合风险仅在有真实同时结果/成员结构时后置。

交付物：`PROVIDER_SEMANTIC_DECISIONS.json`、`SECOND_PROCESS_MINILOOP.json`、`HAZARD_QUALIFICATION_DELTA.json`。

验收：

- 第二过程不是第二张孤立MAE表；共享关系有真实空间/水系证据。
- 数据缺口阻塞其子任务，不阻塞其他合格路线。
- 未知字段与许可保持unknown，不能把图像量/时效/帧数加成独立事件。

### CP12-13｜独立确认、有界影子运行与分级发布

继承：CP12, CP13。依赖：CP06-next, CP01-comparison。执行：`pre_registered_bounded_live_and_replay`。

代码/资料位置：
```text
plans/v7_review_6c7c7e8_next/confirmation/
plans/v7_review_6c7c7e8_next/live_shadow/
publication/
```

实施步骤：

1. 冻结数据构建、baseline、prompt、selector、模型、处理器、阈值/资费及分析；以独立天气过程/保守时空块隔离并purge。
2. 自然日历与富集极端机制集分开；选样不看模型胜负，零正例期仍保留但不声称完成尾部能力验证。
3. 有限前瞻先普通窗口：真实捕获、合法可见、实际提交、结果成熟再结算，不能回填first-seen。
4. 采集器预登记范围内独立保存候选流；被测策略只能通过代理，研究采集成本与策略预算分开。
5. 分级发布工程/机制/MM/第二过程/D-sim/live，证据不足不贴更高标签。
6. 端到端模型结果与旧输出重放分开；任何权重/新数据/GPU/付费调用先读取明确有效执行范围。

交付物：`CONFIRMATION_PREREGISTRATION.json`、`PROSPECTIVE_SUBMISSION_LEDGER.json`、`OUTCOME_SETTLEMENT_REPORT.json`、`CLAIMS_TO_EVIDENCE.json`、`REPRODUCE_CN.md`。

验收：

- 不允许模型自报时间授予准时；失败/未选目标仍在分母。
- 至少两种真实物理过程支撑跨灾种MM主张；未做到可发布较窄版本。
- 前瞻服务有固定停止条件，不真实干预天气/设施/公众。

## 13. 参考入口与读取身份

以下是本轮读取的固定版本或官方说明。源码读取不等于全项目运行。私人签名下载URL及凭据未收入本包。

- [repo_ref: branch snapshot](https://github.com/sisuolv/disastertrace-benchmark/tree/6c7c7e81ad88e1d3a553727607e24c858136899d)。
- [final_report: plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md)；Git blob `5d3959f3291bc8d7647cb5858a670cc7db3e6ef4`。
- [next_plan: plans/v7_adaptive_execution_20260913/NEXT_EXECUTION_CN.md](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/NEXT_EXECUTION_CN.md)；Git blob `0c3b74f20563154d71bd5800ef0259ad087b41fe`。
- [builder: plans/v7_adaptive_execution_20260913/build_regional.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/build_regional.py)；Git blob `dd032b319049ef89451840f64ac78759f7cc14b3`。
- [taf_task: disastertrace-starter/src/disastertrace/monitoring_fixed_v1/taf_tasks.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/taf_tasks.py)；Git blob `e61fb22ffec5986fdc9a9f1eb3fdecab1288706c`。
- [taf_timeline: disastertrace-starter/src/disastertrace/monitoring_v1/providers/taf_timeline.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/providers/taf_timeline.py)；Git blob `07397f1cebcae4c874473f2ce16e11826eaf18eb`。
- [admission: disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py)；Git blob `f89c71a582cbc3eaf14ff935ab4928bd63ccbb2f`。
- [adaptive: disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py)；Git blob `d542a54bb6c05864348df3ec06f076eec4a3965b`。
- [support_bridge: disastertrace-starter/src/disastertrace/monitoring_fixed_v1/support_bridge.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/support_bridge.py)；Git blob `9077e2de8e81450463bcb553a3f553cfa83ec594`。
- [checkpoint: disastertrace-starter/src/disastertrace/monitoring_v1/session_checkpoint.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/session_checkpoint.py)；Git blob `49d51e8e1d90d7c120be683bf234c01078e76e3b`。
- [representation: disastertrace-starter/src/disastertrace/monitoring_fixed_v1/representations.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/representations.py)；Git blob `2f8504c0234be0bf71ed5e6b967de49db63894e4`。
- [same_clock: disastertrace-starter/src/disastertrace/monitoring_v1/event_loop.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/event_loop.py)；Git blob `250553e445f3e026fbd957c196250b466fe216ac`。
- [program_run: plans/v7_adaptive_execution_20260913/execute_typed_session.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/execute_typed_session.py)；Git blob `51a8a3935eae3e0d4d419b1da3c8a638d53a8da6`。
- [preparation: disastertrace-starter/src/disastertrace/monitoring_v1/preparation.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/preparation.py)；Git blob `2ed78ebbfc54a60d25e15c709a055ba889aabda2`。
- [validation: plans/v7_adaptive_execution_20260913/VALIDATION.json](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/VALIDATION.json)；Git blob `325f9a37d6c2dabec058a251bada1cfb0e4d4568`。
- [awc: AWC Product Info](https://aviationweather.gov/help/data/)。
- [pysteps: STEPS official API](https://pysteps.readthedocs.io/en/latest/generated/pysteps.nowcasts.steps.forecast.html)。
- [ortools: Job shop official example](https://developers.google.com/optimization/scheduling/job_shop)。

用户两份材料的研究要求：保留“同状态真实分支”与“准备时间/资源/取消”的方向；此处作为用户给定方案依据，不将材料中的全部文献描述视为本轮新全文复查。

## 14. 只读辅助工具与本包验收

`probes/audit_taf_candidate_index.py`读取现有区域的产品索引、目标、机会与旧latest表，筛查新版不覆盖仍保留旧版、同刻多候选等线索。它不联网、不改数据、不生成新Gold，并明确要求原文/provider后续核验。同刻多文件只标“需要语义检查”，不擅自判冲突。

该新辅助脚本完成3个合成fixture检查；与前述6个源码摘录诊断分别记录。二者都不是仓库回归或实际气象资料全量审计。`plan/acceptance_tests.json`的68条为待实施验收规格。
