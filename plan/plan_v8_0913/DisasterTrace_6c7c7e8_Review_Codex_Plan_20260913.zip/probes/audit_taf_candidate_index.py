#!/usr/bin/env python3
"""Read-only metadata screen for TAF version/coverage inconsistencies.

This does NOT parse raw TAFs, correct labels, validate provider supersession,
or establish that any published score was affected. Run only on a frozen
DisasterTrace regional directory, then resolve flagged cases using raw products.
A declared historical lag is mandatory: it is not measured public availability.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
from typing import Any

FILES = {
    'products': 'environment/NATIVE_PRODUCT_INDEX.json',
    'targets': 'public/TARGETS.json',
    'opportunities': 'public/OPPORTUNITIES.json',
    'legacy_latest': 'environment/LATEST_BASELINES.json',
}

def strict_int(value: Any, field: str) -> int:
    if type(value) is not int:
        raise ValueError(f'{field} must be an integer UTC microsecond timestamp')
    return value


def keyed(rows: list[dict], field: str) -> dict:
    out = {}
    for r in rows:
        k = r[field]
        if k in out:
            raise ValueError(f'Duplicate {field}: {k}')
        out[k] = r
    return out


def coverage(product: dict, target: dict) -> str:
    if product['status'] in {'nil', 'canceled'}:
        return 'none'
    start, end = product.get('valid_start'), product.get('valid_end')
    if type(start) is not int or type(end) is not int or start >= end:
        return 'unknown_envelope'
    left = max(start, strict_int(target['physical_start'], 'physical_start'))
    right = min(end, strict_int(target['physical_end'], 'physical_end'))
    if left >= right:
        return 'none'
    if left == target['physical_start'] and right == target['physical_end']:
        return 'full'
    return 'partial'


def screen(data: dict[str, list[dict]], lag_seconds: int) -> dict:
    if type(lag_seconds) is not int or lag_seconds < 0:
        raise ValueError('The declared replay lag must be a nonnegative integer')
    lag = lag_seconds * 1_000_000
    targets = keyed(data['targets'], 'target_id')
    old = keyed(data['legacy_latest'], 'opportunity_id')
    ops = keyed(data['opportunities'], 'opportunity_id')
    products = keyed(data['products'], 'source_id')
    by_station: dict[str, list[dict]] = defaultdict(list)
    for p in products.values():
        strict_int(p['issued_at'], 'issued_at')
        by_station[p['station']].append(p)
    flagged, counters = [], Counter()
    for oid, op in ops.items():
        t = targets[op['target_id']]
        cutoff = strict_int(op['cutoff'], 'cutoff')
        station = t['entity'].removeprefix('station:')
        visible = [p for p in by_station[station] if p['issued_at'] + lag <= cutoff]
        if not visible:
            counters['no_visible_product'] += 1
            continue
        last_issue = max(p['issued_at'] for p in visible)
        current = [p for p in visible if p['issued_at'] == last_issue]
        legacy = old.get(oid)
        flags = []
        covers = {p['source_id']: coverage(p, t) for p in current}
        if len(current) > 1:
            flags.append('same_issue_requires_raw_semantic_or_correction_resolution')
        if legacy and legacy['issued_at'] < last_issue:
            flags.append('legacy_precedes_latest_visible_product')
            if all(c != 'full' for c in covers.values()):
                flags.append('potential_old_coverage_resurrection')
        if legacy and not any(p['source_id'] == legacy['source_id'] for p in visible):
            flags.append('legacy_source_not_in_visible_index')
        if flags:
            counters.update(flags)
            flagged.append({
                'opportunity_id': oid, 'target_id': op['target_id'], 'cutoff': cutoff,
                'target_support': [t['physical_start'], t['physical_end']],
                'legacy_source_id': None if legacy is None else legacy['source_id'],
                'latest_native_issue': last_issue,
                'latest_candidates': [{
                    'source_id': p['source_id'], 'status': p['status'],
                    'valid_start': p.get('valid_start'), 'valid_end': p.get('valid_end'),
                    'coverage': covers[p['source_id']],
                } for p in current], 'flags': flags,
                'conclusion': 'candidate_for_raw_review_not_a_corrected_gold',
            })
    return {
        'schema': 'disastertrace.read_only_taf_index_screen.v1',
        'registered_opportunities': len(ops), 'indexed_products': len(products),
        'flagged_opportunities': len(flagged), 'flag_counts': dict(counters),
        'declared_replay_lag_seconds': lag_seconds,
        'assumption': 'latest issuance among same-station disclosed index entries; confirm native logical series/revision rules before correction',
        'raw_products_parsed': False, 'published_scores_recomputed': False,
        'labels_changed': False, 'historical_availability_verified': False,
        'items': flagged,
    }


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--declared-replay-lag-seconds', required=True, type=int)
    a = p.parse_args()
    if a.output.exists():
        raise SystemExit('Refuse to overwrite an existing output')
    data, bindings = {}, {}
    for k, rel in FILES.items():
        path = a.dataset / rel
        raw = path.read_bytes()
        rows = json.loads(raw)
        if not isinstance(rows, list) or any(not isinstance(r, dict) for r in rows):
            raise ValueError(f'{rel} must contain a JSON list of objects')
        data[k] = rows
        bindings[rel] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    report = screen(data, a.declared_replay_lag_seconds)
    report['input_files'] = bindings
    a.output.parent.mkdir(parents=True, exist_ok=True)
    with a.output.open('x', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')
    print(json.dumps({k: report[k] for k in ('registered_opportunities','indexed_products','flagged_opportunities','flag_counts')}, ensure_ascii=False))

if __name__ == '__main__':
    main()
