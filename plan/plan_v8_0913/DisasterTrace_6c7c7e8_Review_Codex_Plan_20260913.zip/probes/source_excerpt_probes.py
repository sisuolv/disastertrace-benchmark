"""Independent, source-excerpt diagnostics for commit 6c7c7e8.

Not the project's test suite. Pure functions below preserve fetched expressions;
small product fixtures replace IO. No original weather record is relabeled.
"""
from __future__ import annotations
import hashlib, json, math
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from copy import deepcopy

ROOT = Path(__file__).resolve().parents[1]
COMMIT = "6c7c7e81ad88e1d3a553727607e24c858136899d"

# Exact selection expressions from build_regional.py:217-231, wrapped for fixtures.
def builder_latest(baseline_candidates, all_products, opportunities, targets):
    MINUTE = 60_000_000
    latest = {}
    for candidate in baseline_candidates:
        key = candidate["opportunity_id"]
        if key not in latest or (candidate["issued_at"], candidate["source_id"]) > (latest[key]["issued_at"], latest[key]["source_id"]):
            latest[key] = candidate
    # Canceled/NIL revisions cannot silently expose an older active product.
    for opportunity in opportunities:
        target = targets[opportunity["target_id"]]
        visible_products = [p for p in all_products if p["station"] == target["entity"] and p["issued_at"] + 2 * MINUTE <= opportunity["cutoff"]
            and (p["valid_start"] is None or p["valid_start"] <= target["physical_start"])
            and (p["valid_end"] is None or target["physical_end"] <= p["valid_end"])]
        if visible_products:
            last = max(visible_products, key=lambda p: (p["issued_at"], p["source_id"]))
            if last["status"] in {"nil", "canceled"}:
                latest.pop(opportunity["opportunity_id"], None)
    return latest

# Exact function from taf_timeline.py; only already-parsed dictionaries are used.
def target_withdrawals(products, targets, latest_cutoff, *, declared_replay_lag_us=120_000_000):
    withdrawals = []
    for product in products:
        if product["status"] not in {"active", "nil", "canceled", "unparsed"}:
            raise ValueError("Unknown native TAF timeline status")
        if product["status"] in {"active", "unparsed"}:
            continue
        available = product["issued_at"] + declared_replay_lag_us
        if available > latest_cutoff:
            continue
        for target in targets:
            if (
                target["entity"] == product["station"]
                and (
                    product["valid_start"] is None
                    or product["valid_start"] <= target["physical_start"]
                )
                and (product["valid_end"] is None or target["physical_end"] <= product["valid_end"])
            ):
                withdrawals.append(
                    {
                        "target_id": target["target_id"],
                        "source_id": product["source_id"],
                        "available_at": available,
                        "reason": product["status"],
                        "availability_rule": "native_issued_at_plus_declared_replay_lag",
                    }
                )
    return withdrawals

# Fixture clock, not an upstream observation parser.
def us(text):
    d=datetime.fromisoformat(text.replace("Z","+00:00"))
    epoch=datetime(1970,1,1,tzinfo=timezone.utc)
    dt=d-epoch
    return (dt.days*86400+dt.seconds)*1_000_000+dt.microseconds


def forecast_fixtures():
    target={"target_id":"t","entity":"KSFO", "physical_start":us("2025-02-03T15:00:00Z"), "physical_end":us("2025-02-03T16:00:00Z")}
    old={"source_id":"old", "station":"KSFO", "issued_at":us("2025-02-03T00:00:00Z"), "valid_start":us("2025-02-03T00:00:00Z"), "valid_end":us("2025-02-04T00:00:00Z"), "status":"active", "raw":"TAF KSFO 030000Z 0300/0400 00000KT P6SM SKC"}
    new={"source_id":"new", "station":"KSFO", "issued_at":us("2025-02-03T06:00:00Z"), "valid_start":us("2025-02-03T06:00:00Z"), "valid_end":us("2025-02-03T12:00:00Z"), "status":"active", "raw":"TAF AMD KSFO 030600Z 0306/0312 00000KT 1/2SM FG OVC002"}
    opp={"opportunity_id":"o", "target_id":"t", "cutoff":us("2025-02-03T10:00:00Z")}
    return target,old,new,opp


def original_projection_candidates(products, target, opportunity):
    """Fixture emulation of TafProduct.project's native full-window precondition.
    We do not claim to re-execute the complete build()/HTTP/parser pipeline.
    """
    cs=[]
    for p in products:
        if p["station"] != target["entity"] or p["issued_at"]+120_000_000>opportunity["cutoff"]:
            continue
        if p["status"]!="active" or not(p["valid_start"]<=target["physical_start"]<target["physical_end"]<=p["valid_end"]):
            continue
        cs.append({"opportunity_id":opportunity["opportunity_id"],"target_id":target["target_id"],"issued_at":p["issued_at"],"source_id":p["source_id"]})
    return cs


# Source-identical local type and elementary scores are not claimed here. The
# scoring boundary is exercised by executing the verbatim score_admitted body
# with pre-restored engine fixtures and a transparent loss function.
def require_fields(r,fields,label):
    if not isinstance(r,dict) or set(r)!=set(fields.split()):
        raise ValueError(label)
def fingerprint(v):
    return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()

class EngineFixture:
    registry={}
    @classmethod
    def from_journal(cls,path):
        return cls.registry[path]
AdmissionEngine=EngineFixture

def paired_scores(rows, arms):
    ids={r["opportunity_id"] for r in rows}
    if any(set(v)!=ids for v in arms.values()): raise ValueError("denominator")
    return {"arms":{name:{"mean_loss":sum((v[r["opportunity_id"]]["value"]-r["outcome"])**2 for r in rows if r["outcome"] is not None)/sum(r["outcome"] is not None for r in rows)} for name,v in arms.items()}}

# Exact score_admitted function from admission.py.
def score_admitted(outcomes, arms):
    engines = {name: AdmissionEngine.from_journal(path) for name, path in arms.items()}
    if not engines:
        raise ValueError("No admitted arms")
    first = next(iter(engines.values()))
    for engine in engines.values():
        if engine.contract != first.contract or set(engine.snapshots) != set(first.opportunities):
            raise ValueError("All arms need the same full sealed opportunity contract")
        if engine.calls and {c["head"] for c in engine.calls.values()} == {"e_only"}:
            raise ValueError("E-only calls are not a forecasting arm")
    results = {r["opportunity_id"]: r for r in outcomes}
    if len(results) != len(outcomes) or set(results) != set(first.opportunities):
        raise ValueError("Every opportunity needs an explicit outcome or missing status")
    rows = []
    for oid, o in first.opportunities.items():
        outcome = results[oid]
        require_fields(
            outcome, "opportunity_id target_contract_hash value status source_revision", "outcome"
        )
        if outcome["target_contract_hash"] != o.target.contract_hash:
            raise ValueError("Outcome target mismatch")
        if outcome["status"] not in {"mature", "provisional", "missing"}:
            raise ValueError("Unknown maturity status")
        if outcome["status"] == "mature" and (
            outcome["value"] is None or not outcome["source_revision"]
        ):
            raise ValueError("Mature outcome needs value and revision")
        rows.append(
            {
                "opportunity_id": oid,
                "target": o.target.to_dict(),
                "outcome": outcome["value"] if outcome["status"] == "mature" else None,
            }
        )
    return {
        "schema": "disastertrace.admitted_scores.v1",
        "contract_sha256": first.contract_hash,
        "time_basis": first.time_basis,
        "outcome_sha256": fingerprint(outcomes),
        "scores": paired_scores(
            rows,
            {
                name: {oid: s["forecast"] for oid, s in engine.snapshots.items()}
                for name, engine in engines.items()
            },
        ),
        "admission_statuses": {
            name: [r["status"] for r in engine.attempts] for name, engine in engines.items()
        },
    }


def main():
    observations=[]
    t,o,n,opp=forecast_fixtures()
    # Case 1: latest amended active bulletin no longer covers the future target.
    candidates=original_projection_candidates([o,n],t,opp)
    out=builder_latest(candidates,[o,n],[opp],{"t":t})
    obs={"id":"TAF-01","scope":"verbatim selection and withdrawal functions on synthetic parsed products","condition":"new active AMD ends before target", "builder_selected":out.get("o",{}).get("source_id"),"contract_expected":"no current covering forecast; fallback","withdrawals":target_withdrawals([o,n],[t],opp["cutoff"]),"synthetic_fixture":True}
    assert obs["builder_selected"]=="old" and not obs["withdrawals"]
    observations.append(obs)
    # Case 2: two different latest-issuance forecasts; arbitrary source ID wins.
    equal=deepcopy(o); equal.update(source_id="z-conflicting",raw="TAF KSFO 030000Z 0300/0400 00000KT 1/2SM FG OVC002")
    out=builder_latest(original_projection_candidates([o,equal],t,opp),[o,equal],[opp],{"t":t})
    assert out["o"]["source_id"]=="z-conflicting"
    observations.append({"id":"TAF-02","scope":"source selection expression","condition":"same issuance, distinct semantic payloads","builder_selected":out["o"]["source_id"],"contract_expected":"conflict or documented COR/AMD sequence, not lexical ID ranking","synthetic_fixture":True})
    # Positive control: covering NIL causes removal.
    nil=deepcopy(n); nil.update(status="nil",valid_end=o["valid_end"])
    out=builder_latest(original_projection_candidates([o,nil],t,opp),[o,nil],[opp],{"t":t})
    assert "o" not in out
    observations.append({"id":"TAF-CONTROL-01","condition":"covering NIL supersedes older active product","observed":"old removed","expected":"old removed","scope":"source selection expression","synthetic_fixture":True})
    # Positive control: a new normal covering product wins.
    covered=deepcopy(n); covered["valid_end"]=o["valid_end"]
    out=builder_latest(original_projection_candidates([o,covered],t,opp),[o,covered],[opp],{"t":t})
    assert out["o"]["source_id"]=="new"
    observations.append({"id":"TAF-CONTROL-02","condition":"new covering active product","observed":"new selected","expected":"new selected","scope":"source selection expression","synthetic_fixture":True})

    from types import SimpleNamespace
    class TinyTarget:
        contract_hash="a"*64
        def to_dict(self):return {"output_kind":"event_probability","units":"m"}
    target=TinyTarget(); op=SimpleNamespace(target=target)
    contract={"schema":"disastertrace.typed_admission.v1","protocol":"base_bound_override","time_basis":"declared_archive_scenario","opportunities":[{"opportunity_id":"o"}],"fallbacks":{"t":{"value":0.1}}}
    def eng(value,baseid):
        return SimpleNamespace(contract=deepcopy(contract),contract_hash=fingerprint(contract),opportunities={"o":op},snapshots={"o":{"forecast":{"value":value},"base_forecast":{"value":value},"baseline_context_hash":baseid}},calls={},attempts=[],time_basis="declared_archive_scenario")
    EngineFixture.registry={"a":eng(.1,"base-A"),"b":eng(.9,"base-B")}
    outcomes=[{"opportunity_id":"o","target_contract_hash":target.contract_hash,"value":1,"status":"mature","source_revision":"result1"}]
    score=score_admitted(outcomes,{"A":"a","B":"b"})
    observations.append({"id":"ADMISSION-01","scope":"verbatim score_admitted with pre-restored synthetic engine fixtures; does not test journal reader","condition":"same opportunity/fallback/protocol contract but different common baseline streams","observed":"score accepted","scores":score["scores"],"requirement":"mandatory comparative gate must bind common exogenous baseline timeline and resource/provider contracts","synthetic_fixture":True})
    # Control: opportunity contract mismatch rejected.
    EngineFixture.registry["b"].contract["time_basis"]="other"
    try:score_admitted(outcomes,{"A":"a","B":"b"})
    except ValueError: rejected=True
    else: rejected=False
    assert rejected
    observations.append({"id":"ADMISSION-CONTROL-01","scope":"same function fixture","condition":"different experiment contract","observed":"rejected","expected":"rejected","synthetic_fixture":True})
    manifest={"commit":COMMIT,"scope":"source-excerpt and pure-function fixture diagnostics; NOT full repository, raw-data or inference rerun","observations":observations,"diagnostics":len(observations),"all_probe_assertions_passed":True,"source_blobs":{"build_regional.py":"dd032b319049ef89451840f64ac78759f7cc14b3","taf_timeline.py":"07397f1cebcae4c874473f2ce16e11826eaf18eb","admission.py":"f89c71a582cbc3eaf14ff935ab4928bd63ccbb2f"}}
    (ROOT/"evidence"/"SOURCE_EXCERPT_PROBE_RESULTS.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(manifest,ensure_ascii=False,indent=2))

if __name__=="__main__": main()
