"""Check this review/plan package, not the upstream benchmark's scientific claims."""
from pathlib import Path
import hashlib, json, sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
failures=[]
for row in manifest['files']:
    p=root/row['path']
    if not p.is_file():
        failures.append({'path':row['path'],'reason':'missing'}); continue
    raw=p.read_bytes()
    if len(raw)!=row['bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:
        failures.append({'path':row['path'],'reason':'hash_or_size'})
tasks=json.loads((root/'TASKS.json').read_text())['tasks']
ids={t['id'] for t in tasks}; seen=set(); pending=list(tasks)
if len(ids)!=len(tasks): failures.append({'reason':'duplicate_task_ids'})
while pending:
    ready=[t for t in pending if set(t['depends_on'])<=seen]
    if not ready:
        failures.append({'reason':'task_cycle_or_unknown_dependency','pending':[t['id'] for t in pending]});break
    for t in ready:seen.add(t['id']);pending.remove(t)
print(json.dumps({'package_files':len(manifest['files']),'tasks':len(tasks),'passed':not failures,'failures':failures},ensure_ascii=False,indent=2))
sys.exit(bool(failures))
