# DisasterTrace 当前实现审计与 Codex 后续计划

审阅提交：`6c7c7e81ad88e1d3a553727607e24c858136899d`，分支 `next-phase-v1`，日期 2026-09-13。

先读 **AUDIT_REPORT_CN.md**，再把 **START_HERE_CODEX_CN.md** 和 **CODEX_NEXT_PLAN_CN.md** 交给 Codex。
机器任务和依赖位于 `TASKS.json`。全部后续修改是建议，尚未在远端执行。

本次实际做了：连接器读取当前源码/报告；7份原始源码的Git blob校验；22项合成边界测试，17通过、5触发待修问题。
没有做：完整检出、上游313项测试、完整360捕获离线重放、新GPU/API推理、科学数据下载、远端修改。

## 文件

- `AUDIT_REPORT_CN.md`：缺陷、协议缺口、研究解释边界与验证范围。
- `CODEX_NEXT_PLAN_CN.md`：沿当前CP00–CP14体系的执行顺序、交付和退出条件。
- `START_HERE_CODEX_CN.md`：直接发送的启动指令。
- `FINDINGS.json`：5个运行反例和2个静态问题的证据登记。
- `TASKS.json`：24个现有CP后缀工单，不另建研究框架。
- `PLANNED_ACCEPTANCE_CASES.json`：55个待写/扩展的验收情形，不是本次通过的测试。
- `AUDIT_EXECUTION.json`：本次实际测试结果。
- `SOURCE_READ_SCOPE.json`：读取范围和不带临时token的来源链接。
- `audit_probes/`：可复现探针、日志、7份hash一致的源码与隔离加载器。
- `configs/`：默认离线和两份待实现配置示例。
- `verify_package.py`、`MANIFEST.json`：计划包自身的完整性检查，不是benchmark科学验证。

## 重现本次探针

```bash
cd audit_probes
python -m pytest -q test_review_regressions.py
```

在该审阅版上预期是5失败、17通过。失败是新提出的边界断言，不等于仓库原313项失败。
隔离加载器只去掉顶层相对import并注入对应源码定义；没有修改函数体。但它不是全包集成测试，
没有调用真实航空provider、D、外部模型或跨进程controller。

在用户真实检出目录的Python环境中，改用生产包导入：

```bash
DISASTERTRACE_AUDIT_MODE=repo PYTHONPATH=/absolute/checkout/disastertrace-starter/src \
  python -m pytest -q /absolute/this-package/audit_probes/test_review_regressions.py
```

语义修复后如变更fixture或评分模式，应保留旧反例并补对应生产回归，而不是删除失败断言。
本包包含用户项目的少量源码仅用于本次复查，不是新benchmark发布。
