# DisasterTrace `6c7c7e8` 实现审计

## 结论

当前代码已经超过上一轮计划的“固定输入接口”阶段：类型化准入已接入步进会话，独立F-only真实运行，静止点恢复、专属TAF题型和原生证据桥都有实现。
但不能据此判定当前实现完全正确。本次在hash一致的生产定义上执行22项新合成探针，17通过、5失败。
失败主要涉及**共同基线版本、同刻事件语义和策略比较合同**。另发现提示中的校准时间描述不一致，以及外部后端异常路径尚需闭合。

这些问题足以要求下一批优先修复与影响审计，**不足以证明已发布真实实验分数已经被污染**。当前数据使用声明固定延迟，最新报告没有自然同发行冲突；触发条件可能未出现在已有轨迹中。

## 1. 身份与审计范围

- 提交：`6c7c7e81ad88e1d3a553727607e24c858136899d`；父提交 `60ebd05723f9483590611976d379da2e4edd85b0`。提交时间2026-09-13 13:08:38 UTC。
- 阅读依据：最新执行报告、复查书、下一阶段、整合主计划和CP工作包；定向阅读准入、适配、控制器、时钟、恢复、证据、表示和原生解析模块。
- 本次实际执行：7份源码Git blob SHA1核验；22项合成边界探针；测试与计划包结果另存。
- 本次没有执行：仓库自带313项、360条完整捕获重放、完整原生清洗、GPU/API、全仓lint、完整异步会话。
- 无完整检出：GitHub连接器不能读取所需二进制ZIP，运行环境未能联网下载其字节。因此使用哈希一致的原文定义进行隔离测试。

隔离方法只省略顶层相对import，依赖从对应已取原文注入；函数体未改。探针只使用program head及通用schema，
不检验原生气象解析、真实backend、E映射或D准备。请在Codex完整检出中用`DISASTERTRACE_AUDIT_MODE=repo`再次确认。

### 不混淆四类证据

| 类型 | 本次例子 | 能声称什么 |
|---|---|---|
| 仓库报告 | 313测试、252新调用、36日志8分支 | 仓库记录了这些结果，本次未独立全量重跑 |
| 静态代码证据 | prior-month提示、backend调用位于try之前 | 确认该路径或描述存在，影响还需回执/故障注入 |
| 本次合成反例 | 较旧issue晚到替换新基线 | 在登记的合法schema输入下可复现，不等于真实天气样本失败 |
| 研究假设 | 模型依赖显示的共同概率 | 需要有控制的实验，不能从144次不变概率直接确诊 |

## 2. 当前进展要更新，不应继续重复旧待办

| 项目 | 已有实质进展 | 尚未获得的结论 |
|---|---|---|
| 类型化会话 | `TypedAviationRuntime`接现有`SessionCoordinator`，用真实结算获取构造bundle | 仍是H15适配，不是16灾种通用控制器 |
| F-only | 先108次smoke，后252次新实验中独立E/F/joint | 并非LLM自适应selector完整系统收益 |
| 恢复 | 两个27机会会话，静止点跨进程续跑；报告36日志/8分支 | 不包括在途预留、异步重复完成、D完整控制状态 |
| 新资料 | 97次请求、288 METAR、91完整TAF、432机会 | 432不是432天气过程，也尚非完整432机会程序会话实验 |
| 产品E | TAF覆盖18题、版本18题、原生支持桥 | 覆盖6/18、版本16/18；产品事实不等于物理天气预测 |
| 模型F | 144个含F回答均等于共同基线，Brier0.0848092 | 没有LLM预测增益；相同概率不一定是主动FOLLOW决策 |
| 程序对照 | 新日期FOLLOW0.0651123，全局共享/全读0.0742844 | 全读有时更差；不支持智能调度优势 |
| 广度与应用 | H15开发较深；温度/水文/降水保留已有样例；D合成子轨 | 完整16类、独立过程、原生MM应用价值未由本轮证明 |

该状态依据S02/S18/S20。静态主计划中的planned状态属于旧冻结，更新状态应新增执行delta，不回写旧计划。

## 3. 复现的边界问题

### F01：旧发行晚到会覆盖更新的共同基线（P1）

位置：`monitoring_fixed_v1/admission.py::_process` baseline分支，约199–214行；控制器送入全部baseline事件。

合成事件：新issue20在20到达，概率0.8；旧issue10在40到达，概率0.2；截止900、目标物理窗口1000–1100。
实际封存0.2。代码按事件到达时间调用`update_baseline`，没有判断该来源族内的发行/替代先后。

这违反拟模拟的“当时最新专业预报”语义。修复应在provider明确的版本族内使用发行/订正证据，旧版本可以进入审计历史但不变成当前。
不能简单对所有预报机构/来源做全局max(issue)，也不能把合法新订正错误拒绝。

真实影响：尚未全量扫描。当前固定delay情景可能保持issue与available顺序，不能直接认定旧成绩受影响。

### F02：旧撤回消息会清掉新版（P1）

位置：同文件`baseline_withdrawal`约215–224行；`policies.py`构造payload只带目标、source_id与reason。

新issue20概率0.8已当前；issue10的旧取消在40晚到，结果退回0.05。代码只检查target/source非空就pop。

**不能仅比较取消的source_id是否等于当前预报的source_id来修复。** 新发行CNL本来就有自己的ID，必须能够撤销旧业务产品。
需要区分“撤回具体版本”和“在某一发行代际取消某产品族”，将取消自身issue/替代对象传入状态机。

真实影响：unknown；下一轮按回执逐条统计旧取消、新取消、同刻取消与新TAF。

### F03：同发行冲突由事件ID决定赢家（P1）

位置：`event_loop.py::run_clock`约33–35行，`admission.py`baseline路径；对照`taf_tasks.py::evaluate`。

同issue、同available的两个不等价基线0.2/0.8，仅交换事件ID字典序，最终得到0.8或0.2。
程序是确定性的，但这种确定性没有天气产品语义。

TAF E合同已经说明：等价镜像共同保留，同最新发行实质不一致则conflict。F当前基线的选择也应使用同一族内resolver。
有官方COR/AMD先后证据时按证据处理；没有就保留冲突并按冻结回退规则给F。不得因JSON键序/随机hash而选赢家。

真实影响：最新报告说实际样例中无自然同发行冲突，本次也没有证明它出现过。

### F04：同刻取消/完成的语义未定，由ID裁决（P2；CP04b前必须解决）

cancel和completion都在phase1。开始30、完成60、取消60，仅改取消ID的a/z，截止得到0.2或0.9。

不能武断说必须取消优先：具体语义由ADR决定。问题是应有可解释的优先级或可信接收序，而不是任意标签。
若来源提供独立提交序，将序作为证据字段；只改事件ID不应改变环境。旧日志仍按旧协议解释，新协议单独版本化。

### F05：准入评分未验证策略比较的共同基线相同（P1科研比较）

位置：`score_admitted`555–604行及`AdmissionEngine.contract`。

当前检查机会/目标、协议、回退、时间身份和完整封存，但没有把外生共同基线轨迹和校准清单绑定到比较合同。
合成两个无模型调用的FOLLOW臂，基线分别0.2/0.8，观测1；函数接受并给Brier0.64/0.04。
数学是正确的，但若将这个差异当“主动策略收益”就不公平。

应有`strategy`严格模式与显式`baseline_ablation`/`protocol_ablation`模式。前者核对相同外生源、发行/可用时间、
目标投影与校准，后者公开哪些不同，不能归因于selector。不要去比较整条策略前缀hash，因为合法动作本来不同。

真实影响：现有构造器可能已保证比较同源，尚未证实旧臂不公平；缺的是评分边界的可执行保护。

## 4. 静态发现和实现边界

### F06：校准期描述与当前实验不一致

`heads.py::_F`写“frozen prior-month research probability”，最新报告却明确说Dec2023映射转到2025日历。
应按实际校准元数据描述训练期、地区、版本和迁移，不让模型把它理解成近期本地校准。
本次未下载全部实际提示捕获，所以需要逐条统计该字符串影响范围；更不能认定它造成全部144次不变概率。

### F07：异常调用的终态尚需闭合

`TypedAviationRuntime.execute`在解析try之前调用backend；已读控制器typed分支直接调用execute。
TimeoutError、提交后连接中断等路径没有在这段适配代码中变成持久完成/未知状态。
费用超预留当前fail-closed是正确保护，不能为了让测试绿而吞掉异常或当免费失败。

下一批要用真实全包fault injection确认：是否上游已有统一异常处理？如有复用；没有则新增明确终态、回退和恢复。
外部服务缺幂等/请求查询能力时不能承诺exactly-once。未知是否已计费的请求不得自动重发并只扣一次。

### 不把合规限制误说成bug

1. `session_checkpoint.py`明确只接静止点：这是已声明限制，不是“恢复功能不存在”。
2. `native_slot_support`、原生重解析、枚举桥和专属TAF head已经存在；残余预算联合见证及跨物理过程尚未完成。
3. `representations.py`的focused同时改变系统说明、字段组织和E任务信息负荷；24/36到33/36可以报开发差异，不是纯时间或排序因果效应。
4. typed路径自动采用有效候选，回答概率等于基线是“FOLLOW等价数值”，不等于模型明确决定FOLLOW。X02需独立gate/动作层。
5. 当前声明查询费用和公共slot可以研究受控配额，但不能据此声称测到了真实业务稀缺。
6. 普通温度配对、河流源读取、原图进入VLM都有价值，但各自不等于灾种和应用完成。

## 5. 通过的17项检查说明什么

本次通过了：单调新基线、无基线回退、截止恰好完成、截止后不可回填、新基线使旧在途候选失效、无EOS回退、
重复完成不二次安装、同ID冲突/回填事件拒绝、排队未来基线的导出恢复、checkpoint篡改、全机会分母、共同缺失mask、
非法物理未来cutoff拒绝、资源结算幂等、超预留不释放、不同连续量单位不混算。

因此不是“整个框架不能用”。应该保留这些已有保护，新增反例针对未覆盖的交界面。
17/22也不是系统正确率，不能拿来估计代码质量百分比。

## 6. 直接改变下一步优先级

原NEXT_EXECUTION顺序先做覆盖题/全日历，再CP04b。建议插入必要的修复门槛：

**完整检出重现 → 版本/取消/同刻/比较合同修复 → 旧轨迹影响审计 → 432机会完整程序对照 → 小型时间与F诊断。**

C2剩余资源图和第二数值领域可并行；CP04b在上述语义固定后推进。D/MM/shadow各自保留，不使它们阻塞核心F/C2。
详细工单在主计划和TASKS.json。

## 来源

- S01：分支身份。https://api.github.com/repos/sisuolv/disastertrace-benchmark/branches/next-phase-v1 阅读范围：已实际读取；只证明读取时分支指向该提交。
- S02：最新实施结果。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md 阅读范围：全文阅读；运行数量/天气结果为仓库报告，不是本次重跑。
- S03：下一阶段。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/NEXT_EXECUTION_CN.md 阅读范围：全文阅读；保留现有CP与研究方向。
- S04：整合后的主计划。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_next_20260913_2/OVERALL_PLAN_CN.md 阅读范围：分段阅读；其planned状态属于此前规划，不替代最新执行结果。
- S05：原CP工作包。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_next_20260913_2/WORK_PACKAGES.json 阅读范围：分段阅读27任务定义；新任务只用其下的后缀。
- S06：类型化会话适配。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py 阅读范围：全文静态审阅；未完整加载此适配器运行。
- S07：准入与评分。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py 阅读范围：全文审阅；原始字节blob校验并隔离执行相关定义。
- S08：共同事件时钟。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/event_loop.py 阅读范围：全文审阅；blob校验并隔离执行。
- S09：静止点恢复。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/session_checkpoint.py 阅读范围：全文静态审阅；本次不声称独立重跑跨进程会话。
- S10：原生TAF任务。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/taf_tasks.py 阅读范围：全文静态审阅；同发行冲突/镜像合同。
- S11：C2支持桥。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/support_bridge.py 阅读范围：全文静态审阅；native_slot_support及compile_recipes已存在。
- S12：输入表示。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/representations.py 阅读范围：全文静态审阅；不是只改变时间显示的单因素实验。
- S13：类型与数学评分。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/contracts.py 阅读范围：完整原文与旧同blob对应校验；隔离执行。
- S14：独立输出head。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/heads.py 阅读范围：全文读取、blob校验；program探针未运行E语义。
- S15：旧控制器接入。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/policies.py 阅读范围：定向阅读1–250及380–670行；不是全仓审计。
- S16：原生TAF/METAR解析。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/providers/aviation.py 阅读范围：分段静态阅读；parse_taf确实检查原生issue与档案metadata对应。
- S17：复现说明。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/publication/v7_adaptive_review_20260913/REPRODUCE_CN.md 阅读范围：全文读取；本次未取得完整CPU ZIP字节。
- S18：验证声明。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/VALIDATION.json 阅读范围：全文读取；313项通过为仓库自带记录。
- S19：TAF错误分层。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/reports/DEVELOPMENT_DIAGNOSTICS.json 阅读范围：全文读取；覆盖题混淆不只一个类别。
- S20：复查任务书。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/publication/v7_adaptive_review_20260913/REVIEW_FOR_CHATGPT_PRO_CN.md 阅读范围：全文读取；区分固定输入模型诊断和自适应selector实验。
- S21：预算账本。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/resources.py 阅读范围：此前已读完整原文；本次核对HEAD返回blob未变，隔离测试验证费用行为；未整库检出。
- S22：日记账。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/journal.py 阅读范围：全文读取、blob校验与隔离执行。
- S23：目标定义。https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/targets.py 阅读范围：全文读取、blob校验与隔离执行。
