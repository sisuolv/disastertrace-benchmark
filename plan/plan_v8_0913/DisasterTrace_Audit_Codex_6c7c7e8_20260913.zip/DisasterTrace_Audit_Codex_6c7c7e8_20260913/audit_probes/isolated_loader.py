"""Load hash-verified production definitions without unavailable package imports.

Only module-level relative import statements are omitted. The supplied globals
come from the corresponding fetched production modules. No engine/score/event
function body is rewritten. This is NOT a full repository import/integration run.
Program-head probes do not exercise aviation parsing or preparation submodules.
"""
from pathlib import Path
import ast
import hashlib
import json
import sys
import types

ROOT = Path(__file__).resolve().parent / 'review_sources'
EXPECTED = {
 'contracts':'8287a69d4628b1c2f9a9ff9dad85eea4e2bbc625',
 'admission':'f89c71a582cbc3eaf14ff935ab4928bd63ccbb2f',
 'event_loop':'250553e445f3e026fbd957c196250b466fe216ac',
 'targets':'df3862303f5ec9b28ab4c20969b88861ed06bf74',
 'journal':'5b2799b0046796d7fcbb4c62db82d1fb16507d65',
 'resources':'48e0e1a002ec21bc8e02886be9007a74d3fb63e5',
 'heads':'40498b255b2f98ec47c0300d0c4b9bb9ba1eedba',
}
CHECKS = []

def load(name, dependencies=None):
 p=ROOT/(name+'.py'); raw=p.read_bytes()
 sha=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 assert sha==EXPECTED[name], (name,sha,EXPECTED[name])
 tree=ast.parse(raw, filename=str(p))
 tree.body=[n for n in tree.body if not (isinstance(n,ast.ImportFrom) and n.level)]
 module=types.ModuleType('_review_'+name); module.__file__=str(p)
 if dependencies: module.__dict__.update(dependencies)
 sys.modules[module.__name__]=module
 exec(compile(tree,str(p),'exec'),module.__dict__)
 CHECKS.append({'module':name,'bytes':len(raw),'git_blob_sha1':sha,'matches_remote_blob':True,'sha256':hashlib.sha256(raw).hexdigest()})
 return module

T=load('targets'); C=load('contracts'); R=load('resources'); E=load('event_loop')
J=load('journal', {'canonical_hash':T.canonical_hash})
# Program-head probes do not use the E label mapping; no substituted E semantics.
H=load('heads', {k:getattr(C,k) for k in ('EvidenceBundle','Forecast','Target','canonical')})
A=load('admission', {
 **{k:getattr(C,k) for k in ('EvidenceBundle','Forecast','ForecastState','Target','canonical','fingerprint','paired_scores','require_fields','timestamp')},
 'run_clock':E.run_clock,'read_journal':J.read_journal,'Cost':R.Cost,
 '_unique_object':H._unique_object,'_reject_constant':H._reject_constant,'parse_response':H.parse_response,
})
if __name__=='__main__':
 print(json.dumps(CHECKS,indent=2))
