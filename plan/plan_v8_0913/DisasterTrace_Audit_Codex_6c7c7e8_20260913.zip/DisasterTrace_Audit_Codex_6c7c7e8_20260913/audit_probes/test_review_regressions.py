"""Synthetic audit probes, not the upstream 313-test suite or weather results.

Default: execute hash-verified production definitions through isolated_loader.
Against a real checkout:
  DISASTERTRACE_AUDIT_MODE=repo PYTHONPATH=<checkout>/disastertrace-starter/src \
      python -m pytest -q test_review_regressions.py

Desired-invariant assertions deliberately fail on the reviewed implementation.
A failure must be investigated before converting it into a project regression;
not all source-policy choices have the same deployment semantics.
"""
import hashlib
import json
import os
import pytest
if os.environ.get('DISASTERTRACE_AUDIT_MODE') == 'repo':
    from disastertrace.monitoring_fixed_v1 import contracts as C, admission as A
    from disastertrace.monitoring_v1 import resources as R, journal as J
else:
    from isolated_loader import C, A, R, J


def target():
    return C.Target('t','station:TEST','visibility','m','event_probability','interval',
                    1000,1100,'future_physical','iem_routine_unique_hour.v1','lt',1000.0)

def forecast(p):
    return C.Forecast(target().contract_hash,'event_probability','probability',p)

def bundle(revision='v1', issued=10, available=10, p=0.2, cutoff=900, *, oid='o'):
    f=forecast(p).to_dict()
    return C.EvidenceBundle.freeze({
      'schema':'disastertrace.frozen_evidence.v1','opportunity_id':oid,
      'target':target().to_dict(),'cutoff':cutoff,
      'baseline':{'forecast':f,'source_revision':revision,'issued_at':issued,
        'available_at':available,'valid_until':1000,'kind':'research','mapping_version':'map.v1',
        'content':{'E_question':{'predicate':'any_registered_neighbor_slot_below_threshold',
          'query_ids':['q'],'threshold_m':1000}, 'provider_fixture':'synthetic_boundary_probe'}},
      'state':{'forecast':f,'mode':'FOLLOW','protocol':'base_bound_override'},
      'assets':[],'receipts':[],'authorization_mode':'session_shared',
      'representation':'synthetic_schema_valid_fixture',
      'availability_basis':'declared_archive_scenario','provider_version':'review_fixture.v1'})

def engine(journal=None):
    return A.AdmissionEngine([A.TypedOpportunity('o',target(),900)],
      fallbacks={'t':forecast(0.05).to_dict()},journal=journal)

def base_event(b, name='base'):
    return A.AdmissionEvent(name,b.policy_view()['baseline']['available_at'], 'baseline',
                            {'bundle':b.to_dict()})

def begin(b, at=30, call_id='call'):
    return A.AdmissionEvent(call_id+'-begin',at,'begin',
      {'call_id':call_id,'bundle':b.to_dict(),'head':'program','executor':'fixture-program'})

def completion(b, at=60, *, call_id='call', name='complete', p=0.9, raw=None, eos=True):
    raw=C.canonical(forecast(p).to_dict()) if raw is None else raw
    return A.AdmissionEvent(name,at,'completion',{
      'call_id':call_id,'bundle_hash':b.bundle_hash,'raw':raw,
      'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),
      'started_at':30,'completed_at':at,'persisted_at':at,'expires_at':900,
      'cost':{'requests':0,'bytes':0,'tokens':1,'compute_ms':1},
      'ended_with_eos':eos,'head':'program','executor':'fixture-program'})

def sealed(e): return e.snapshots['o']['forecast']['value']

# Confirmed boundary vulnerabilities / scientifically insufficient contracts.
def test_late_older_baseline_must_not_replace_newer_issuance():
    e=engine()
    e.run([base_event(bundle('new',20,20,0.8),'new'),
           base_event(bundle('old',10,40,0.2),'late-old')],until=900)
    assert sealed(e)==0.8, f'late old issuance replaced new: {sealed(e)}'

def test_stale_withdrawal_must_not_remove_newer_product():
    e=engine()
    e.run([base_event(bundle('new',20,20,0.8),'new'),
      A.AdmissionEvent('old-withdrawal',40,'baseline_withdrawal',{
       'target_id':'t','product_revision_id':'old-cnl', 'issued_at':10,
       'reason':'synthetic late delivery of an older cancellation'})],until=900)
    assert sealed(e)==0.8, f'stale cancellation changed newer state to {sealed(e)}'

def test_same_issuance_conflict_must_not_depend_on_event_id():
    observed=[]
    for aid,bid in [('a','z'),('z','a')]:
        e=engine()
        e.run([base_event(bundle('same-issue-A',10,20,0.2),aid),
               base_event(bundle('same-issue-B',10,20,0.8),bid)],until=900)
        observed.append(sealed(e))
    assert observed[0]==observed[1], f'event IDs select conflicting baseline: {observed}'

def test_same_time_cancel_completion_needs_semantic_not_id_order():
    observed=[]
    for cancel_id in ['a-cancel','z-cancel']:
        b=bundle(); e=engine()
        e.run([base_event(b),begin(b),completion(b,name='m-complete'),
               A.AdmissionEvent(cancel_id,60,'cancel',{'call_id':'call'})],until=900)
        observed.append(sealed(e))
    assert observed[0]==observed[1], f'cancel/complete result depends on event ID: {observed}'

def test_scored_strategy_arms_must_share_common_baseline_trace(tmp_path):
    paths={}
    for name,p in [('A',0.2),('B',0.8)]:
        path=tmp_path/(name+'.jsonl'); paths[name]=path
        with J.EventJournal(path) as j:
            e=engine(j);e.run([base_event(bundle('base-'+name,10,10,p))],until=900)
    outcomes=[{'opportunity_id':'o','target_contract_hash':target().contract_hash,
               'value':1,'status':'mature','source_revision':'observed'}]
    with pytest.raises(ValueError):
        A.score_admitted(outcomes,paths)

# Positive controls: basic contracts and correct boundary behavior.
def test_latest_monotone_baseline_is_adopted():
    e=engine();e.run([base_event(bundle('old',10,10,.2),'old'),
       base_event(bundle('new',20,20,.8),'new')],until=900)
    assert sealed(e)==.8

def test_missing_baseline_uses_registered_fallback():
    e=engine();e.run([],until=900);assert sealed(e)==.05

def test_completion_exactly_at_cutoff_is_sealed():
    b=bundle();e=engine();e.run([base_event(b),begin(b),completion(b,900)],until=900)
    assert sealed(e)==.9 and e.attempts[-1]['status']=='accepted'

def test_completion_after_cutoff_cannot_rewrite_snapshot():
    b=bundle();e=engine();e.run([base_event(b),begin(b),completion(b,901)],until=901)
    assert sealed(e)==.2 and e.attempts[-1]['status']=='late'

def test_new_baseline_invalidates_old_inflight_candidate():
    b=bundle();e=engine();e.run([base_event(b),begin(b),
       base_event(bundle('new',40,40,.8),'new'),completion(b)],until=900)
    assert sealed(e)==.8 and e.attempts[-1]['status']=='stale_base'

def test_unfinished_response_retains_fallback_prediction():
    b=bundle();e=engine();e.run([base_event(b),begin(b),completion(b,eos=False)],until=900)
    assert sealed(e)==.2 and e.attempts[-1]['status']=='invalid_response'

def test_duplicate_completion_does_not_admit_twice():
    b=bundle();e=engine();e.run([base_event(b),begin(b),completion(b),
        completion(b,70,name='duplicate',p=.4)],until=900)
    assert sealed(e)==.9 and e.attempts[-1]['status']=='duplicate_completion'

def test_duplicate_event_conflict_rejected():
    e=engine();e.run([base_event(bundle())],until=20)
    with pytest.raises(ValueError): e.run([base_event(bundle(p=.8))],until=30)

def test_backdated_event_rejected():
    e=engine();e.run([],until=20)
    with pytest.raises(ValueError):e.run([base_event(bundle())],until=30)

def test_restore_preserves_queued_future_baseline_and_cutoffs():
    b=bundle(); e=engine()
    e.run([base_event(b),begin(b),completion(b),
       base_event(bundle('new',100,100,.4),'new')],until=70)
    record=e.export(); restored=A.AdmissionEngine.restore(record)
    e.run([],until=900);restored.run([],until=900)
    assert e.export()==restored.export() and sealed(e)==.4

def test_checkpoint_tamper_rejected():
    e=engine();e.run([],until=20);record=e.export();record['payload']['clock']=19
    with pytest.raises(ValueError):A.AdmissionEngine.restore(record)

def test_missing_method_prediction_cannot_reduce_denominator():
    row={'opportunity_id':'o','target':target().to_dict(),'outcome':0}
    with pytest.raises(ValueError):C.paired_scores([row],{'a':{}})

def test_missing_outcome_mask_common_to_arms():
    row={'opportunity_id':'o','target':target().to_dict(),'outcome':None}
    res=C.paired_scores([row],{'a':{'o':forecast(.2).to_dict()},'b':{'o':forecast(.9).to_dict()}})
    assert res['settled']==0 and all(r['scored']==0 for r in res['arms'].values())

def test_illegal_future_target_cutoff_rejected():
    with pytest.raises(ValueError):A.TypedOpportunity('o',target(),1000)

def test_idempotent_resource_settlement():
    ledger=R.BudgetLedger({'requests':10});cost=R.Cost(requests=2)
    ledger.reserve('r',cost,'t');ledger.settle('r',cost);ledger.settle('r',cost)
    assert ledger.spent.requests==2 and ledger.reserved.requests==0

def test_resource_overrun_retains_reservation():
    ledger=R.BudgetLedger({'requests':10});ledger.reserve('r',R.Cost(requests=2),'t')
    with pytest.raises(ValueError):ledger.settle('r',R.Cost(requests=3))
    assert ledger.reserved.requests==2 and not ledger.entries['r']['settled']

def test_scalar_units_not_pooled():
    a=target().to_dict();a.update(output_kind='scalar',event_operator=None,threshold=None,units='K')
    b=dict(a,units='m3/s',target_id='t2',variable='streamflow')
    with pytest.raises(ValueError):
        C.paired_scores([{'opportunity_id':'a','target':a,'outcome':1},
                         {'opportunity_id':'b','target':b,'outcome':2}],{'arm':{}})
