# 给 Codex 的启动指令

请实际审计、修复并推进当前 `sisuolv/disastertrace-benchmark / next-phase-v1`，不要仅再写总计划。
本附件审阅基线是 `6c7c7e81ad88e1d3a553727607e24c858136899d`。若本机HEAD已经更新，先读取差异并按已完成内容调整，不能回退/覆盖。

先按仓库适用的 `AGENTS.md` 工作，再读本包 `AUDIT_REPORT_CN.md`、`CODEX_NEXT_PLAN_CN.md`、`FINDINGS.json`、`TASKS.json`。
保留v7/C1/C2/C3、E/F/D/MM、原X00–X09、六组16灾种和现有CP00–CP14；不要另外建v8/第三个时钟。

## 第一批执行

1. 做 `CP00.audit_6c7c7e8`：记录HEAD、dirty工作区、环境；先复现原相关测试与发布包。
2. 用真实包导入运行 `audit_probes/test_review_regressions.py`。附件记录的22项是合成边界探针，17通过5失败；不是原313项失败。
3. 并行解决 `CP01.version_rules`、`CP01.comparison_contract`、`CP06.prompt_metadata`、`CP01.failure_terminal`；再完成 `CP04a.same_time_rules`。
4. 对每个旧真实日志做 `CP13.impact`。明确“反例存在”和“旧实验实际受影响”不同；无数据就写unknown。
5. 修复通过后，用现有已下载2025完整432机会做 `CP03.1.full_day`，不必新增GPU；并行CPU准备TAF时间诊断和残余联合E参照。

## 关键要求

- 晚到旧issue不能替代新预报；旧CNL不能清除新版。新CNL有自己的ID，不允许用ID简单相等修复取消语义。
- 同发行冲突与等价镜像分开；F与E使用一致的版本resolver。任意事件ID不能决定物理意义上的优先级。
- `strategy`比较必须同共同基线/可用时间/校准；有意基线差异用显式ablation。
- 删除无条件`prior-month`描述，使用真实训练期/地区/映射元数据；不要改旧提示捕获或答案。
- 后端超时/断连、未知投递、费用超限要有终态和恢复规则，不能当0费用或偷偷重试。
- 不强制模型改概率。新typed输出自动采用并非自主gate，相关贡献单独验证。
- 实际F-only和静止点恢复已有，不要再次称从零实现。CP04b只补在途和故障恢复。

## 授权和记录

默认使用本包offline_first：允许本地CPU、修复与测试，不自动启动新GPU、付费API、数据/模型下载、live daemon或git push。
若当前真实Codex会话已有明确授权，按该授权登记本批范围和上限，不让模板抹除它，也不继承无关旧轮次预算。
GPU作业与科学下载并非本轮复查已执行内容。

每批输出：具体源码改动、命令与退出码、通过/失败/跳过、真实回执、费用、旧文件hash保全、新旧结果差异、阻塞项和下一项。
无收益、零正例和失败原样保留；不得x-fail、删断言、改baseline或挑日期来制造完成。

只有权限或不可恢复数据语义真正阻塞时才记录blocked并推进独立CPU任务；不要反复总结规划代替代码。
