"""Proposed repository regression tests. NOT executed against the full repo here.

Run in a fresh checkout with PYTHONPATH=disastertrace-starter/src.
These assert the proposed latest-native-version invariant, rather than bless the
current behavior. Expected to expose the unguarded baseline/withdrawal branches.
If a formal provider intentionally uses another lifecycle, register that contract
explicitly instead of applying issuance ordering universally to every product.
"""
from datetime import datetime, timezone

from disastertrace.monitoring_fixed_v1.admission import AdmissionEngine, AdmissionEvent, TypedOpportunity
from disastertrace.monitoring_fixed_v1.contracts import EvidenceBundle, Forecast, Target
from disastertrace.monitoring_v1.providers.aviation import parse_taf


def us(s):
    dt=datetime.fromisoformat(s.replace('Z','+00:00'))
    epoch=datetime(1970,1,1,tzinfo=timezone.utc)
    delta=dt-epoch
    return (delta.days*86400+delta.seconds)*1_000_000+delta.microseconds


def case():
    target=Target(
        target_id='audit-target', entity='station:KSFO', variable='visibility', units='m',
        output_kind='event_probability', support_kind='interval',
        physical_start=us('2025-02-03T16:00:00Z'),physical_end=us('2025-02-03T17:00:00Z'),
        temporal_semantics='future_physical',report_policy='iem_routine_unique_hour.v1',
        event_operator='lt',threshold=1000,
    )
    opp=TypedOpportunity('audit-opportunity',target,us('2025-02-03T15:00:00Z'))
    fallback=Forecast(target.contract_hash,'event_probability','probability',0.05)
    return target, AdmissionEngine([opp],fallbacks={target.target_id:fallback.to_dict()})


def baseline(target, sid, issued, arrival, probability, raw):
    native=parse_taf(raw,station='KSFO',archive_issue=issued)
    f=Forecast(target.contract_hash,'event_probability','probability',probability).to_dict()
    candidate={
        'source_id':sid,'issued_at':us(issued),'raw':raw,
        'projection':native.project(target.physical_start,target.physical_end),
    }
    base={
        'forecast':f,'source_revision':sid,'issued_at':us(issued),'available_at':us(arrival),
        'valid_until':target.physical_start,'kind':'research','mapping_version':'audit.fixed.v1',
        'content':{'native_taf':candidate,'mapping_details':{'probability':probability},
                   'calibration_bank_sha256':'0'*64},
    }
    b=EvidenceBundle.freeze({
        'schema':'disastertrace.frozen_evidence.v1','opportunity_id':'carrier-'+sid,
        'target':target.to_dict(),'cutoff':us(arrival),'baseline':base,
        'state':{'forecast':f,'mode':'FOLLOW','protocol':'base_bound_override'},
        'assets':[],'receipts':[],'authorization_mode':'session_shared',
        'representation':'audit_native_taf','availability_basis':'declared_archive_scenario',
        'provider_version':'native_h15_snapshot.v1',
    })
    return AdmissionEvent('base-'+sid,us(arrival),'baseline',{'bundle':b.to_dict()})


def test_late_old_taf_does_not_replace_new_native_issuance():
    t,e=case()
    new=baseline(t,'new','2025-02-03T10:00:00Z','2025-02-03T11:00:00Z',.8,
                 'TAF KSFO 031000Z 0310/0410 00000KT 1/2SM FG BKN001')
    old=baseline(t,'old','2025-02-03T09:00:00Z','2025-02-03T12:00:00Z',.2,
                 'TAF KSFO 030900Z 0309/0409 00000KT P6SM SKC')
    e.run([new,old],until=us('2025-02-03T13:00:00Z'))
    assert e.baselines[t.target_id]['source_revision']=='new'


def test_delayed_older_cancellation_does_not_clear_newer_taf():
    t,e=case()
    new=baseline(t,'new','2025-02-03T10:00:00Z','2025-02-03T11:00:00Z',.8,
                 'TAF KSFO 031000Z 0310/0410 00000KT 1/2SM FG BKN001')
    old_cancel=AdmissionEvent('late-old-cancel',us('2025-02-03T12:00:00Z'),
        'baseline_withdrawal',{'target_id':t.target_id,'product_revision_id':'old-cnl',
        'issued_at':us('2025-02-03T09:30:00Z'),'reason':'canceled',
        'raw':'TAF KSFO 030930Z 0309/0409 CNL','station':'KSFO'})
    e.run([new,old_cancel],until=us('2025-02-03T13:00:00Z'))
    assert e.baselines.get(t.target_id,{}).get('source_revision')=='new'
