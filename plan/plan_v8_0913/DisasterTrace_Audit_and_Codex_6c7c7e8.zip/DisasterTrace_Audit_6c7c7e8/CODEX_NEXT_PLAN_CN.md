# 给Codex的后续实施计划：从6c7c7e8继续

## 0. 任务和边界

目标是复查并修复当前实现，在已有v7系统上完成更可信的证据、预测修订及研究性准备实验。基准审阅提交是`6c7c7e81ad88e1d3a553727607e24c858136899d`；实际执行若已有新提交，先比较差异并标记哪些发现已修复，不回退。

保留v7、C1/C2/C3、E/F/D/MM、六组16类与原X00–X09。以仓库`plans/v7_next_20260913_2/WORK_PACKAGES.json`的CP00–CP14为主索引，本文只增加后缀工作，不启动另一个v8/DS项目。

本次建议执行目录：`plans/v7_audit_followup_6c7c7e8/`。以下输出文件名都是将来应生成的产物，不是已完成报告。

不覆盖旧冻结源码、模型回答、原始失败或分数。不重启已消费GPU目录，不自动push/force-push/reset/clean。第一批仅本地CPU和已有本地数据；不因历史“最多4张H100”的旧窗口而自动启动新作业。之后需本批明确的执行许可、成本与停止条件。凭据、签名下载URL及完整环境变量不得进入报告。

## 1. 先更新当前状态，不重复完成旧任务

| 原工作包 | 当前状态（仓库记录与源码） | 本轮动作 |
|---|---|---|
| CP00 / CP03.1 | 原版本/日历/暴露登记已有 | 增量记录新commit与本次开发暴露，不改旧计划的历史planned字段 |
| CP01 | 类型化正式准入、截止回放评分、原控制器接入已完成 | 补生命周期、运行故障、提交完整性及全日历验证 |
| CP02 | 原生METAR支持桥、TAF独立E、有限联合图已有 | 补slot绑定、真实资源见证和E错误分项 |
| CP04a | quiescent跨进程恢复已有，8条分支报告 | 保留回归，推进CP04b，不再从零写checkpoint |
| CP06.smoke / development | 108与252次真实调用；F-only已运行 | 消费原回答做离线诊断，只有新输入才新调用 |
| CP07 | PreparationReducer及4组合成场景已有 | 补终点、完整恢复和实际H15研究任务，不另写一套时钟 |
| CP10.numeric | 标量准入/配对已有 | 补连续provider会话、合法补充证据，不将普通温度叫热浪 |
| CP05 / CP10.hydro / CP08 / CP13 | 完成程度分项 | 按数据、准备与独立确认门槛继续 |

313项测试和360次捕获为原仓库记录。本执行开始后，必须把“继承的通过记录”与“本次真正重跑的结果”分开。

## 2. 论文目标必须对应实验，不再加抽象卖点

C1：相对同期更新的共同专业/研究基线，在相同实际或声明资源条件下，哪些查询、处理、预测修订和提前准备值得做？
C2：当前资料能确定哪些事实，同一预算和截止内哪些目标能共同确定；通过固定证据、固定预测器和完整状态分支，检查事实支持、预测利用和准备安排之间的关系。
C3：同样的规则在不同物理过程、来源和时间尺度下能否复现，并公开失败范围、数据许可和独立过程证据。

保留上一轮更激进的应用扩展，但先做小而可靠的CP08：同一真实天气与相同资料，改变准备时长/容量/成本，观察取证和安排是否相应改变。F、E和D分别评分。research_assumption只能说明研究规则下的准备损失，不能宣称真实经济减损/安全保障。

## 3. 本轮工作顺序与依赖

第一批：CP00.audit → CP01.lifecycle、CP01.failure、CP02.slot（可按文件隔离并行）→ CP07.horizon → CP06.calendar。
第二批：CP04b.recovery与CP02.joint；现有TAF错误拆解CP06.taf可并行，不依赖GPU。
第三批：CP03.1.baseline → CP11.rules / CP09.cost → CP08.paired。
数据支线：CP05.preflight、CP10.hydro、CP10.numeric继续并行，原生MM比较必须等自己的数据资格。
确认：CP13.freeze及对应confirmF/confirmD/confirmMM分别放行；前瞻CP12和非线性联合风险CP14不阻塞首个可靠E/F交付。

### 3.1 CP00.audit：建立一次可靠的复查起点

执行`git status --short`、`git rev-parse HEAD`、检查AGENTS.md与当前环境。发现本地改动时只记录，不擅自stash或覆盖。读取最新README、最终报告、NEXT_EXECUTION、VALIDATION与CP计划。

输出：
- `BASELINE_STATE.json`：实际HEAD、审阅HEAD、差异、未提交改动、允许执行范围。
- `CURRENT_STATUS_DELTA.json`：implemented/runtime_validated/development_validated/scientific_admitted四级，不以旧任务planned字段重置已完成状态。
- `EXPOSURE_LEDGER_DELTA.json`：此前全部已见日历/输入/结果与本次再分析。
- `TEST_SCOPE.json`：原313测试范围、新增反例、未运行/缺依赖，逐条列明。

先运行现有CPU测试和原复现器，失败时保留最初日志。原仓库给出的测试命令见第9节，不构造“313”固定期待数掩盖新增/缺失。

### 3.2 CP01.lifecycle：把TAF最新版本规则落实到F会话

涉及`providers/taf_timeline.py`、`dataset.py`、实际BASELINE_CANDIDATES构建器、`adaptive.py`和`admission.py`。先定位实际构建器；仅helper未发撤回不能直接推断整链已经错。

新增或扩充原生产品生命周期合同：provider_family、station、native_issued_at、received/available_at、source_revision、semantic_hash、status、supersedes/withdrawal_scope、order_basis。保留真实时间未证实的标识。

规则：
1. 已出现更新原生版本后，迟到旧版只进入历史，不回滚当前状态。
2. 新版缩短有效期/不覆盖、NIL/CNL或不支持语法，都必须作为产品生命周期事件保留；不要仅过滤成“能覆盖目标的候选”。
3. 同签发时刻的完全等价镜像去重；冲突则有独立状态和冻结处理，不以hash或输入顺序选赢家。
4. 延迟的过时撤回不能清除更晚版本；取消公告ID与被取消预报ID不是必然相等。
5. 一般不同产品能否并存由provider合同决定，不能把TAF规则推广到所有模式起报。
6. E覆盖题与F运行时对相同披露前缀使用一致的最新产品状态；“当前无合格预报”可用明确fallback，但不得冒充专业预报。

最小反例：迟到旧版、旧取消迟到、新版缩短窗口、同刻冲突、同值但条件变化、镜像、更新恰好落在截止、目标已经关闭。

输出`LIFECYCLE_REGRESSION.json`、`LIFECYCLE_IMPACT.json`。后者扫描原3个日历及新432机会，列target/机会/原新输入hash/原新状态。历史输入变化的记录不复用旧回答称新实验。

### 3.3 CP01.failure：让正常运行故障产生可恢复终态

主要在`adaptive.execute`、查询执行和backend适配器处理。先拆清配置拒绝、编程错误、服务/模型运行失败；不要一层catch-all。

固定状态：reserved → dispatched → response_received → response_persisted → admitted/invalid/late/canceled；另有failed或completion_unknown。查询和模型使用各自不可变call/receipt ID。

对超时、连接错误、格式错误、EOS未完成、返回超限、落盘失败、实际费用超过预留逐项规定：是否停止该任务、是否可取消、如何封存F机会、保留哪份旧预测、如何记录费用。已过截止的结果不能改写封存。

实际消耗未知时保留预算预留或明确上下界，不假装0；超出公共时隙时不能偷偷回填为固定30秒。必要时将该arm标为协议失败而不是删去。编程错误停止后也应保存日志/最后可靠checkpoint。

不要承诺任意外部服务“推理只发生一次”：只有存在服务端幂等/查询回执时才能断言；否则恢复时记录完成状态未知，不盲目重试。保证的是本地准入与结算的幂等，不是无限制的外部exactly-once。

输出`FAULT_INJECTION_REPORT.json`、`RESOURCE_RECONCILIATION.json`、`COMPLETION_STATE_CONTRACT.json`。先用CPU假backend/已记录响应，不需要真实GPU。

### 3.4 CP02.slot：使原生报告与查询槽位一一绑定

每条查询建立不可变`QuerySlotContract`：query_id、站点、原生报告选择政策、slot_start/end、变量/单位、reference_kind、支持假设、可得时间依据。报告时间必须落在政策定义的槽位；跨月、SPECI、COR与多个报告按原有声明处理。

将“raw与缓存内部相同”升级为“raw与缓存相同，且属于这个查询”。验收：替换站点并同步修改全部report内字段仍应被槽位合同发现；替换时刻、错单位、伪造receipt归属、错误父资产分别拒绝。

在首次导入和begin前执行来源资格检查。不能等F值安装后才发现输入错误。E未知/缺槽/未查询是合法状态，不以E是否真/是否充分作为F提交资格；不把评估器答案暴露到agent视图。

输出`QUERY_SLOT_CONTRACTS.json`、`SOURCE_BINDING_AUDIT.json`及已有真实数据逐条核验记录。

### 3.5 CP07.horizon：补准备终点，不重建PreparationReducer

读取已有事件顺序ADR并冻结D端点：截止完成、恰好过期、取消恰好完成/截止时如何处理。若计划与实现不同，明确版本和重评分边界。

新增SessionHorizon或同等明确字段，至少区分F最后截止、D需求/准备截止、准备到期、清理完毕、整个观察结束。F全封存不等于D/清理已结束。默认run(None)是否“推进到所有任务结束”必须文档化；可保留旧API并新增finish_session，不直接改变旧结果。

保留已实现的开始收费、取消沉没成本、清理占用、重复请求和未知结果费用界。扩展后仍需一任务只结算一次；真实需求不从事后首次越阈倒推出准备截止。准备有效期、资源移动/清理和收费都属于公开研究规则。

输出`SESSION_HORIZON_ADR.md`、`PREPARATION_BOUNDARY_REPORT.json`。这不需要等完整CP04b；完整恢复在CP04b.D再验证。

### 3.6 CP06.calendar：先把已有432机会完整跑好

使用已取得的2025-02-03完整日历，阈值1km与5km分别跑；不再只展示两个27机会会话或12机会模型表。保留所有机会、目标及缺失原因，不把解析失败删成负例。

主要程序对照：FOLLOW、同信息研究映射、固定round-robin的分额/全局×私有/共享2×2、强批量读取。当前typed仅支持frequency，增加其他predictor前必须显式适配；不得因为函数名存在就说支持了neighbor_persistence。

报告target数、机会数、正例数、可评分数、实际调用、候选值改变、控制动作、最终值改变、baseline变化、失败/回退、资源使用。若432不能完整封存，先修工程，不能先加模型。

输出`FULL_CALENDAR_432_REPORT.json`及逐机会明细。Brier只在完全相同机会和掩膜上比较；1km零正例时ROC/AP等不适用应记null/原因，不输出伪稳定指标。

### 3.7 CP06.taf：用已有36道题拆清楚错误

先离线查看原覆盖18题与版本18题：时间解码、原生有效窗、区间包含/重叠、选版、NIL/CNL、无支持语法和同刻冲突分项。不要按模型答错情况挑确认集。

下一组输入消融应分开：
- 微秒与一一对应的ISO UTC表示，事实与其他字段保持相同；
- 显式列未查询槽位，其余字段保持相同；
- 是否提供与该E任务无关的F上下文；
- system指导是否变化。

不做全笛卡尔积；预先选少数可解释对照。原24/36与33/36保持原命名，不事后宣称纯时间格式效应。程序解析器是确定性产品题对照，不作为模型输入中的免费正确答案。

E按真/假/未知/冲突与充分/未决分层；unknown常量基线明确列出。新输入需要真实新调用时单独冻结，先CPU检查样例和输入diff。

输出`TAF_ERROR_ATLAS.json`、`INPUT_EQUIVALENCE_REPORT.json`、`TAF_NEXT_MISSION.json`。

### 3.8 CP04b.recovery：从已完成静止点恢复推进到在途

保存正在执行查询/模型的：实际输入hash和基线版本、已预留费用、已花费用、剩余时间或外部任务ID、已持久化响应、幂等身份、控制器游标、cache权限、RNG/策略记忆、准备和清理状态。

先做三个CPU故障点：请求发出但无响应、收到响应但未落盘、落盘但未准入。原策略恢复与不断点运行的合法事件/费用/封存应一致；新分支只能从当时可见信息选择，不能看到未来队列或评估器E证书。相同外部未读资料没有归档就标不可评估，不让LLM补造响应。

使用同一个run_clock；不要创建独立D时钟。允许选择/查询期间已开始准备继续推进。相同起点各分支继承一次prefix成本，后续成本各自记录。固定前缀回放和完整会话重跑分别标注。

输出`INFLIGHT_BRANCH_REPORT.json`和调用状态恢复表。准备/清理状态另由`CP07.recovery`在CP07.horizon通过后验收并输出`PREPARATION_RECOVERY_REPORT.json`。核心CP04b不依赖D完成，F确认不会通过依赖链被准备子轨阻塞。廉价规则可并行开发；需要完整状态前瞻的规则，在核心恢复通过后再运行对应比较。

### 3.9 CP02.joint / CP09.cost：联合参照和成本必须对应真实会话

保留原有限图求解器，不重写成最优未来预报oracle。将真实已付receipt、已有cache、剩余预算、在途占用、依赖及截止映射到小图；由一条共同见证满足多个E目标，不相加每个目标各占全预算的单独最优值。

先小图精确枚举并独立复放。大图仅报可行下界/乐观界；求解器超限不能写exact=true。reference知道未读内容是评估侧特权，不能进入selector。

保留受控每槽预算轨，另建真实获取/处理成本轨。后者允许合法批量、缓存、同源ROI复用；会话按唯一receipt去重下载费，重复模型处理仍收费。token、实际计算、等待/传输、失败及工程成本分开。缓存命中不使后运行的方法免费拥有逻辑信息。

先固定同一selector做2×2，再在同一global/shared与相同总预算下比较规则/LLM。匹配预测机会数量的诊断单列，不冒充相同总成本。

输出`RECEIPT_TO_JOINT_GRAPH.json`、`JOINT_WITNESS_REPLAY.json`、`COST_MODEL_CARD.json`、`RESOURCE_FACTORIAL_REPORT.json`。

### 3.10 CP03.1.baseline / CP11.rules：先加强可执行对照

保留Dec2023旧映射与负结果；为更长未参与调试的日期准备本地、跨年、跨区分表。所有拟合、阈值、缺失回退和选择规则只使用训练/开发，确认集不开箱。基线身份明确：TAF文本专业、研究概率映射不是官方原生概率。

信息阶梯：共同预报 → 目标站最新合法报告 → 邻站最新合法报告 → 同源程序特征 → 合法专业图像产品/原生影像。每步保持预测器/训练范围可比；旧E的较早邻站槽位继续保留，不把它代表全部未来相关信息。

比较L(f(B),y)-L(f(B,E),y)与L(B,y)-L(f(B,E),y)，避免把修复自身空证据0.5错误当取证贡献。不因为全读变差就断言资料没有信息，也不要求F强制偏离基线。

X02另立版本化gate合同：CandidateForecast与RevisionControl分离；FOLLOW、NO_CHANGE、OVERRIDE语义分别固定。现有typed概率head原样保留为无显式gate对照。统计“数值相同”“状态跟随”“自动失效”不混为一项。

规则优先于大规模训练：持续性/气候态、合格同信息统计、风险/年龄/截止/覆盖、事件触发、强批量，之后小规模一步/两步。两步规划同信息前缀不得根据后见分支选不同首动作。后见最优仅作为评估参照。

输出`BASELINE_CARD.json`、`EVIDENCE_PREDICTOR_MATRIX.json`、`REVISION_CONTROL_CONTRACT.json`、`RULE_BASELINES.json`。

### 3.11 CP08.paired：让更激进的应用贡献变成可检验实验

先把H15已有真实预测轨迹接到研究准备规则，不控制真实机场/设备。准备岗位可解释为远程保障分析容量；跨机场现场人员不可瞬移，地理转移要独立合同。

第一层固定信念：同天气目标、同证据、同predictor输入和seed，改变准备duration/capacity/cost。天气预测器不接收偏好字段；这是软件隔离。先同预测比阈值、最早截止、风险规则和小规模滚动优化器；优化器不能读取未来结果。

第二层端到端：准备需求可影响查询，查询改变后证据和F可以合理不同。此时比较准备损失/查询与处理成本，不强求F逐字相同。只改变成本而仍给完全相同资料的联合模型，另测概率是否不当地跟着偏好变化。

至少一个资源不紧张/低成本全读条件；不得抬高便宜资料价格制造优势。准备参数网格在看模型胜负前固定，报告各项费用、错失准备、无效启动/撤销和协议违例，不只给一个有利权重总分。

同一天气过程的所有profile/站点/阈值留在同一split。天气真实、行动规则是研究假设，应分别写明；没有业务方证据不写经济减损百分比。E/F核心确认不等待CP08完成。

输出`READINESS_PAIRED_MANIFEST.json`、`PREFERENCE_ISOLATION_REPORT.json`、`READINESS_BASELINES.json`、`READINESS_PAIRED_REPORT.json`。

### 3.12 CP05 / CP10：第二场景继续按已采用路线推进

H07优先验证连续雷达降水与原生MM：ROI/日期先登记，严格区分雨率与累积量、负码、质量、缺帧、投影和时间间隔。pysteps仅在合格输入后引入，先持续性/平流/领域集合对照；原始VLM、同源数值特征、专业产品分开。工具输出是预测不是Gold；同源传感器做输入/结果需披露依赖。

H08并行核准已有QINE/USGS：瞬时/小时平均、调蓄、断面、单位、时间支持与历史版本；43列不能按当前44成员说明假装已知身份。未核准继续版本E，不算正式流量F或联合跨站风险。

温度继续已有EUPP/DWD标量迁移，补连续实际会话与合法补证；未完成多日阈值、气候参照与过程划分前，不叫热浪/寒潮。

LAMP保留独立英里阈值/15分钟最低值子任务；不能用小时METAR替代完整15分钟最低值，也不能用新产品能力回填2024。SEEPS日降水不能拆小时补旧任务。H01作为有条件候补，不按哪个领域使LLM获胜择路。

原16类source_id与资格表增补，不复制一份冲突新注册表。acquisition/decode/semantics/pairing/availability/E/F/D/MM/confirmation逐项标记。

### 3.13 CP13 / CP12 / CP14：确认、交付与可选扩展

在方法冻结前，把新日历也登记开发暴露。训练、映射、提示开发、方法选择、确认按父过程/保守时空块划分；purge覆盖回看、提前量和标签窗。参数profile、seed和站点不是独立N。

用开发块估计成对差异方差、最小有意义效应、正例率和覆盖，确定确认样本与停止规则。不要按显著性加样本或按模型赢家换日期。自然日历评发生率/虚警/成本；极端富集集仅作诊断，不能混成自然概率校准。

CP13.confirmF、confirmD、confirmMM分别报告。CP12有界前瞻只记录不干预，保留first-seen区间、提交时间、失败和结果成熟状态；它不是必须等未来灾害才能推进历史研究的理由。

CP14只有非线性共同需求/超容量/后续决策等条件真实成立时再做。可加固定行动损失先做“边际足够”的零差异单测。共享容量本身不证明需要联合风险。原X09联合目标推理可继续输出边际概率，不受CP14绑定。

## 4. 对当前结果必须保持的正确表述

- 不把144次概率复制写成144次自主FOLLOW决定。
- 不把输入整理E改善写成未来预测改善，也不改名成纯时间格式单因素。
- 不把0/216严重低能见度正例的日历抛掉，或把5km改称浓雾/严重灾害。
- 不把97次请求、432机会、174目标、252调用、独立天气过程混为一种样本数。
- 不把静止点恢复写成在途恢复，不把合成准备写成真实业务效果。
- 不把313测试通过写成任意输入均正确，不因新边界问题否定全部已有验证。

## 5. 研究结果与旧回答复用规则

旧输入、旧回答、旧冻结评分保留不可变。修复后至少区分：
A. 原协议原结果复现；B. 固定旧候选的版本化重评分/干预诊断；C. 新输入新运行。

修复若改变任一模型可见输入、候选可得性、时刻或策略继续路径，不能仅重算旧答案后称为完整新实验。只有逐项hash/语义等价已证明的复用才能避免新推理，记录原因与费用口径。

多组新实验使用同一数据时登记共享暴露，不因此增加独立样本。无正增益也是结果，但要有可信对照和可解释的适用边界。

## 6. 首批退出门槛

CP00.audit、CP01.lifecycle、CP01.failure、CP02.slot、CP07.horizon完成明确的测试与日志；原冻结复放或无法复放的原因有记录；完整432程序日历成功封存或提供具体阻塞；没有任何未经授权的新GPU/API/外部大下载。

首批不强制完成CP04b、H07、CP08或论文确认，但必须交付下一批可直接执行的未完成项，而不是重复本计划。

## 7. 本轮必须新增的反例测试

见`REGRESSION_CASES.json`。每项需保存失败前记录（若实际失败）、修复后结果、运行命令和源码hash。合成反例与真实数据分开。`tests/test_admission_lifecycle_contract.py`提供两个待在完整仓库运行的起始测试；不要把其语法检查说成pytest已过。

## 8. 每次交付统一文件

`CURRENT_STATUS_DELTA.json`、`ISSUES_RESOLVED.json`、`TEST_RESULTS.json`、`IMPACT_AUDIT.json`、`MODEL_CALL_LEDGER.json`、`FINAL_REPORT_CN.md`、`NEXT_EXECUTION_CN.md`、`MANIFEST.json`。

报告分别列：本批新增源码/测试、本批真实执行、继承结果、局限和剩余门槛。README只追加最新入口，旧历史正文保持带日期。发布包不包含模型权重、凭据、私人token或未获许可再分发数据。

## 9. 已知真实复现入口

从完整仓库根目录，使用合适的现有环境：

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=disastertrace-starter/src python -m pytest \
  disastertrace-starter/tests/test_monitoring*.py \
  plans/v7_execution_20260913/tests/test_fixed*.py -q
```

这是仓库给出的313项范围，不等于全部历史测试。新增测试另计，不强写固定计数。

完整CPU归档：`plans/v7_adaptive_execution_20260913/DisasterTrace_v7_typed_adaptive_20260913_review.zip`，SHA256：`b7e9a42812a3d5baee9fe8c15f156c1a70b3c93eebad15a52ac93da481bf8ee6`。解压至新目录后：

```bash
python3 -I -B verify_portable.py . ../adaptive-replay-output
```

输出目录必须不存在。复放36日志、8分支、252新捕获和108旧捕获；不启动launcher，不新增推理。原包冻结与当前工作树测试必须分别记录。[GH06]

本次审阅者的局部检查可单独运行：

```bash
python run_local_probes.py
```

它只验证两个Git-blob一致底层文件的10个局部行为，不替代上述全环境运行。
