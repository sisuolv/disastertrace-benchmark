"""Offline, source-identity-checked helper probes, not the repository test suite.

Two complete source files match their Git blob SHA1 at commit 6c7c7e8.
The timeline function is extracted by AST (unused package imports are not run).
The event-loop owner is an explicit test double, NOT AdmissionEngine.
Assertions document current behavior; some observed behaviors are audit concerns.
"""
from __future__ import annotations
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
from dataclasses import dataclass, asdict

ROOT = Path(__file__).resolve().parent
EXPECTED = {
    'event_loop.py': '250553e445f3e026fbd957c196250b466fe216ac',
    'taf_timeline.py': '07397f1cebcae4c874473f2ce16e11826eaf18eb',
}

def git_blob(b: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()

for name, expected in EXPECTED.items():
    actual = git_blob((ROOT / 'extracted' / name).read_bytes())
    if actual != expected:
        raise RuntimeError(f'Source identity mismatch: {name}')

spec = importlib.util.spec_from_file_location('verified_event_loop', ROOT/'extracted/event_loop.py')
clock_mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(clock_mod)
tree = ast.parse((ROOT/'extracted/taf_timeline.py').read_text())
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name=='target_withdrawals')
namespace = {}
exec(compile(ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[])), 'taf_timeline.extracted', 'exec'), namespace)
withdraw = namespace['target_withdrawals']

@dataclass
class Event:
    event_id: str
    time: int
    kind: str
    payload: dict
    def to_dict(self):
        return asdict(self)

class Owner:
    """Clock protocol double. Optional D deadline intentionally after F cutoff."""
    def __init__(self, d_deadline=None):
        self._events, self._processed, self._last_time = {}, set(), None
        self.journal = None
        self.opportunities = {'f': SimpleNamespace(cutoff=100, opportunity_id='f')}
        self.snapshots, self.trace = {}, []
        self.d_deadline, self.d_sealed = d_deadline, False
    def _expiry_times(self, upcoming):
        if self.d_deadline is not None:
            yield self.d_deadline
    def _process(self, e): self.trace.append(e.kind)
    def _invalidate(self, at): pass
    def _seal(self, at):
        if at==100 and 'f' not in self.snapshots:
            self.snapshots['f']={'trace_at_cutoff': list(self.trace)}
        if at==self.d_deadline:
            self.d_sealed=True
    def _after_seal(self, at): pass

def run(owner, events=(), until=None):
    return clock_mod.run_clock(owner, events, until=until,
        event_order={'completion':1, 'begin':5}, decode=lambda d:Event(**d))

results=[]
def record(name, observation, audit_note):
    results.append({'id':name,'asserted':True,'observed':observation,'interpretation':audit_note})

# Fixture times are synthetic relative UTC units, NOT actual weather records.
target={'target_id':'T','entity':'KSFO','physical_start':1600,'physical_end':1700}
old={'source_id':'old','station':'KSFO','issued_at':900,'status':'active','valid_start':900,'valid_end':1800}
short={**old,'source_id':'new-short','issued_at':1000,'valid_end':1500}
rows=withdraw([old,short],[target],1200,declared_replay_lag_us=0)
assert rows==[]
record('L01',{'withdrawals':rows},'Helper alone emits no active-shorter-version invalidation; end-to-end candidate-builder impact is NOT established by this probe.')
cnl={**old,'source_id':'cancel','issued_at':1000,'status':'canceled'}
rows=withdraw([cnl],[target],1200,declared_replay_lag_us=0)
assert len(rows)==1 and rows[0]['reason']=='canceled'
record('L02',{'withdrawals_count':len(rows)},'Positive control: matching CNL does produce a withdrawal.')
rows=withdraw([{**cnl,'station':'KOAK'}],[target],1200,declared_replay_lag_us=0)
assert rows==[]
record('L03',{'withdrawals_count':0},'Positive control: a different station is excluded.')
rows=withdraw([{**cnl,'issued_at':1300}],[target],1200,declared_replay_lag_us=0)
assert rows==[]
record('L04',{'withdrawals_count':0},'Positive control: withdrawal not yet available is excluded.')

owner=Owner(d_deadline=200);run(owner)
assert owner._last_time==100 and not owner.d_sealed
record('L05',{'clock':owner._last_time,'d_deadline_sealed':owner.d_sealed},'Without explicit until, run_clock ends at max(F cutoff,event time), not the later D boundary; helper-protocol fixture, not an observed production failure.')
owner=Owner(d_deadline=200);run(owner,until=200)
assert owner._last_time==200 and owner.d_sealed
record('L06',{'clock':owner._last_time,'d_deadline_sealed':owner.d_sealed},'Positive control: an explicit session horizon processes the D boundary.')
owner=Owner();e=Event('once',10,'begin',{});run(owner,[e],until=20);run(owner,[e],until=100)
assert owner.trace==['begin']
record('L07',{'processed':owner.trace},'Positive control: duplicate equal event ID is not processed twice.')
owner=Owner();run(owner,[e],until=20)
try:run(owner,[Event('once',10,'begin',{'different':True})],until=100)
except ValueError: pass
else:raise AssertionError('Conflicting duplicate accepted')
record('L08',{'conflicting_duplicate_rejected':True},'Positive control: idempotency identity conflict is rejected.')
owner=Owner();run(owner,[Event('c',100,'completion',{}),Event('b',100,'begin',{})],until=100)
assert owner.snapshots['f']['trace_at_cutoff']==['completion'] and owner.trace==['completion','begin']
record('L09',{'at_cutoff':owner.snapshots['f']['trace_at_cutoff'],'after':owner.trace},'Positive control: completion is processed before seal, begin after seal.')
owner=Owner();run(owner,until=100)
try:run(owner,[Event('late',100,'completion',{})],until=100)
except ValueError: pass
else:raise AssertionError('Backdated event accepted')
record('L10',{'backdated_event_rejected':True},'Positive control: cannot append a fresh event at an already processed boundary.')

out={'commit':'6c7c7e81ad88e1d3a553727607e24c858136899d',
     'scope':'10 isolated helper probes; two Git-blob-identical sources; explicit clock-owner test double',
     'repository_313_tests_rerun':False,'capture_replay_rerun':False,
     'model_calls':0,'cases':results,'all_assertions_passed':True}
(ROOT/'results'/'LOCAL_PROBES.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False,indent=2))
