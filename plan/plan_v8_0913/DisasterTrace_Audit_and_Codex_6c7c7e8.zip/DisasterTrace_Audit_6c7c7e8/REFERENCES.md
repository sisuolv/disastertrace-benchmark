# 来源与复查范围

所有仓库引用固定在同一个提交；路径是审阅材料，不表示这些文件已在本轮完整重跑。

## GH01
`README.md`

1–95：最新状态入口

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/README.md

## GH02
`plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md`

完整：最新数据、模型与限制

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md

## GH03
`plans/v7_adaptive_execution_20260913/NEXT_EXECUTION_CN.md`

完整：当前后续顺序

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/NEXT_EXECUTION_CN.md

## GH04
`publication/v7_adaptive_review_20260913/REVIEW_FOR_CHATGPT_PRO_CN.md`

完整：指定复查范围

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/publication/v7_adaptive_review_20260913/REVIEW_FOR_CHATGPT_PRO_CN.md

## GH05
`plans/v7_adaptive_execution_20260913/VALIDATION.json`

完整：报告313项测试与离线重放，未在本轮完整重跑

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/VALIDATION.json

## GH06
`publication/v7_adaptive_review_20260913/REPRODUCE_CN.md`

完整：原仓库CPU复现入口

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/publication/v7_adaptive_review_20260913/REPRODUCE_CN.md

## GH07
`plans/v7_followup_execution_20260913/FINAL_REPORT_CN.md`

主体：108次模型调用、CP01/02/04a/07进展；末尾截断不作额外推断

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_followup_execution_20260913/FINAL_REPORT_CN.md

## GH08
`plans/v7_next_20260913_2/OVERALL_PLAN_CN.md`

1–350范围定向阅读，部分返回截断；采用已看到的规则、路线与CP组织

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_next_20260913_2/OVERALL_PLAN_CN.md

## GH09
`plans/v7_next_20260913_2/WORK_PACKAGES.json`

任务表分段阅读，CP00–CP14定义；这是原冻结计划，不以planned字段否认后续完成

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_next_20260913_2/WORK_PACKAGES.json

## S01
`disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py`

TypedAviationRuntime：构造、run、freeze_acquired、execute

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py

## S02
`disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py`

完整分段：AdmissionEngine、baseline_context、score_admitted

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py

## S03
`disastertrace-starter/src/disastertrace/monitoring_fixed_v1/taf_tasks.py`

完整：产品E任务、evaluate、parse_answer

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/taf_tasks.py

## S04
`disastertrace-starter/src/disastertrace/monitoring_fixed_v1/support_bridge.py`

完整：native_slot_support、compile_recipes、TAF支持

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/support_bridge.py

## S05
`disastertrace-starter/src/disastertrace/monitoring_fixed_v1/representations.py`

完整：focused_view与提示变化

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/representations.py

## S06
`disastertrace-starter/src/disastertrace/monitoring_fixed_v1/aviation.py`

完整：固定证据provider、频率预测器

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/aviation.py

## S07
`disastertrace-starter/src/disastertrace/monitoring_fixed_v1/contracts.py`

上一基线已读源码；本次目录核对Git blob仍为8287a69d4628b1c2f9a9ff9dad85eea4e2bbc625

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/contracts.py

## S08
`disastertrace-starter/src/disastertrace/monitoring_fixed_v1/heads.py`

上一基线已读源码；本次目录核对Git blob仍为40498b255b2f98ec47c0300d0c4b9bb9ba1eedba

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/heads.py

## S09
`disastertrace-starter/src/disastertrace/monitoring_v1/policies.py`

35–155与230–535：入口限制、查询、selector、类型化调用；不是全文件审计

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/policies.py

## S10
`disastertrace-starter/src/disastertrace/monitoring_v1/session_checkpoint.py`

完整：静止点checkpoint与恢复

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/session_checkpoint.py

## S11
`disastertrace-starter/src/disastertrace/monitoring_v1/event_loop.py`

完整；本地副本Git blob一致并运行局部测试

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/event_loop.py

## S12
`disastertrace-starter/src/disastertrace/monitoring_v1/preparation.py`

完整静态阅读；本轮没有运行此模块的全仓库测试

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/preparation.py

## S13
`disastertrace-starter/src/disastertrace/monitoring_v1/dataset.py`

完整：session输入与撤回生成器接入

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/dataset.py

## S14
`disastertrace-starter/src/disastertrace/monitoring_v1/providers/taf_timeline.py`

完整；本地副本Git blob一致并运行target_withdrawals局部测试

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/providers/taf_timeline.py

## S15
`disastertrace-starter/src/disastertrace/monitoring_v1/providers/aviation.py`

完整分段：原生时间、METAR、TAF解析与投影

https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/providers/aviation.py

## EXT01
NOAA Aviation Weather Center，Aviation Weather Data / TAF说明。
https://aviationweather.gov/help/data/

本轮只核对与版本/原生报告有关的官方说明，不宣称完成新一轮全面文献查新。既有方法借鉴以原v7计划记录为准；新增依赖在真实引入前仍需固定版本、LICENSE和复现范围。
