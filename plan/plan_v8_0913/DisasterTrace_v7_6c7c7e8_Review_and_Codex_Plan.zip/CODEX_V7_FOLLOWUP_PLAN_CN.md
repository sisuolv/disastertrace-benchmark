# 交给 Codex 的 v7 后续执行计划

## 0. 任务入口与不可更改的主线

你将在现有 `sisuolv/disastertrace-benchmark` / `next-phase-v1` 上继续工作。
本计划审查的远端基线为 **6c7c7e81ad88e1d3a553727607e24c858136899d**（2026-09-13），不是旧ae69453或a08486d。
执行前读取真实HEAD和git status；若已更新，先审查差异，将本计划已被修复/完成的条目标记为无需重做。
不reset/clean/覆盖未提交与暂存；不删除旧失败、源文件、历史GPU目录或受保护split。需要代码提交时采用小步独立提交，是否push遵循本次执行会话权限。

保持 **v7 / C1 / C2 / C3 / E-F-D-MM / H01-H16 / X00-X09 / CP00-CP14**，不提出v8，不训练新天气模型，不增加新的核心任务方向。
C1仍为多目标资源分配及共享，C2仍为证据支持集合及联合可达，C3仍为有时间/质量/来源合同的跨过程和跨灾种资格。
附带的CODEX_WORK_ITEMS.json是原CP任务的补充执行视图，不能替换或改写原计划的历史状态。

本文件是待执行计划，作者本次只做源码审查与40项局部CPU回归，没有启动模型或采集。
未来最大4张H100是工程上限，不等于授权。先核对当前执行会话已经明确的资源许可；有明确且适用的授权时保留，不反复询问已知信息；未知时只执行本地CPU、旧捕获复放和计划冻结。
不得新增逐题人工Gold或使用LLM judge裁定真值；允许继承已标明来源的专家/产品标签。无法核实的单位、时间、质量、身份和许可隔离，不用LLM填补。

## 1. 必读顺序

1. README 最新段与 publication/v7_adaptive_review_20260913/REVIEW_FOR_CHATGPT_PRO_CN.md。
2. plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md、NEXT_EXECUTION_CN.md、reports/DEVELOPMENT_DIAGNOSTICS.json。
3. plans/v7_next_20260913_2/OVERALL_PLAN_CN.md 和 WORK_PACKAGES.json。
4. 本包 IMPLEMENTATION_REVIEW_CN.md、REVIEW_FINDINGS.json、两份探针结果及脚本。
5. 当前 monitoring_fixed_v1 和 monitoring_v1 的实际代码与项目测试。

旧 WORK_PACKAGES 把108-call smoke写为planned是历史规划状态。最新108与252已完成，独立head、H15支持桥、typed会话接入及CP04a已有验收，禁止重复启动旧launcher或再次宣布这些模块从零缺失。

## 2. 首先交付当前状态，而不是更多模型输出

| 层次 | 本次应确认的状态 |
|---|---|
| 数据 | 新日历97请求、288 METAR/91 TAF，174目标/432机会；独立过程数另算 |
| 固定输入模型 | 252新回答：216三head/两表示 + 36 TAF专属E；144 F-bearing数值保持base |
| 真实自适应 | 已接入typed运行；最新2×2及batch采用round-robin程序，不能写成LLMselector优势 |
| 恢复 | 静止点4分支×2日期已完成；在途/完整D尚未完成 |
| 科学 | E输入整理有开发改善；F没有增益，新日期程序额外证据变差；完整16类资格没有由此新增 |
| 复现 | 项目报告313tests；执行者实际复验结果单独记录，不能引用旧数冒充本轮 |

执行：
```bash
git rev-parse HEAD
git status --porcelain=v1
# 在现有合格环境中：
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=disastertrace-starter/src python -m pytest \
  disastertrace-starter/tests/test_monitoring*.py \
  plans/v7_execution_20260913/tests/test_fixed*.py -q
```
不在主环境任意pip upgrade。环境缺失时记录缺失依赖与未运行范围，不把skip算pass。
完整CPU包在新目录执行 `python3 -I -B verify_portable.py . ../fresh-output`，核验官方包SHA256 `b7e9a42812a3d5baee9fe8c15f156c1a70b3c93eebad15a52ac93da481bf8ee6`。不运行旧GPU脚本来“复现”。

## 3. 审计修复先行：源仲裁、控制语义和成本

### 3.1 源版本仲裁（CP01 / CP02，X02-X04）

先复现R01-R03，再确定职责：原始source arrival应进入版本登记，只有明确选出的有效基线进入forecast reducer。
要求支持同一源流内晚到旧版本、同issue镜像、同issue冲突、明确COR/AMD顺序、NIL/CNL及缩短有效期。
不能将全体来源按最新issue强行合并：不同模型/传感器可以同时存在。权威顺序必须依赖来源定义，hash仅用于身份和重放。
撤回字段明确 target-stream invalidation 与 revision retraction。取消旧revision不清新版本；真正当前取消不复活旧预测。

候选记录字段：source_stream_id、product_revision_id、native_issued_at、native_revision_sequence（无证据为空）、available_at、semantic_fingerprint、authority_rule_version、supersedes/retracts、withdrawal_scope。
这些是候选合同字段，先查看现有同义字段，避免重复建manifest。

验收至少包括：
- 较旧issue晚到时，当前base仍是较新合法版本，历史记录保留。
- 同issue不等价产品不因event_id重命名改变科学结论；等价mirror不误判冲突。
- E版本判定与F基线选择同规则。
- exact-cutoff新基线先于completion，旧context候选按协议拒绝；已封存机会不重写。
- 扫描已存真实baseline候选是否触发；未触发则记录历史不受这条反例影响，不夸大成旧成绩错。

### 3.2 “数值保留”与“FOLLOW操作”（CP01 / X02）

当前typed head返回概率，运行层默认propose override。persistent_override允许相同概率冻结旧base，因此不得把数值相等推断为FOLLOW。
旧结果保持，只增加numeric_equal_to_base、control_mode、candidate_install_status、baseline_context_age、retained_override_source等审计指标。
若要让新模型真正执行FOLLOW/OVERRIDE/KEEP，输出合同版本化；FOLLOW清override、KEEP保留当前状态、OVERRIDE安装候选，三者不由浮点相等替代。
F-only独立输出仍不依赖E是否正确；不可把E unknown变成F=.5，也不可因E supported强制修订F。

### 3.3 统一成本与失败处理

requests/bytes/tokens/compute_ms使用同一严格整数定义；不要混入情景损失或物理工时成本。
固定2048bytes等预留只是当前场景，扩数据必须重新验证上界，不默默丢超限样本。
保存raw后解析；超slot、超reservation、EOS失败、backend异常都记录已知花费/未决预留和不生效状态。故障不能被记成免费无调用。

## 4. 不调用新模型也应先完成的科学诊断

### 4.1 TAF时间与覆盖

在旧36个专属E回答中按current版本、原生日期、UTCµs、区间重叠分别标错误；none类0/6错误必须单列，不只写6/18。
预登记后续输入对照：
A. 现有原生产品与µs目标；B. 同一合法目标加入等价ISO表示；C. 通过有费用/出处的确定性解析器提供该原文valid_start/end；D. 单独测同样区间算子。
A/B是表示；C是工具处理轨，不把解析工具结果伪装成原生输入；D是能力诊断，不算天气预测。
控制字段、目标和事实不变，不提供full/partial/none答案，不把unsupported记none。不要把追加ISO与额外解释/删上下文同时变动当单因素实验。

### 4.2 F未变化

对144条已有F-bearing记录，首先核对输入中的baseline/state、原始数值、输出精度与解析；不需要新调用。
统计FOLLOW、冻结f(B)、冻结f(B,E)的逐机会help/harm/零差及缺失；按基线概率、天气块、提前量、阈值和E状态描述。
同一时间更完整证据不保证单次Brier更好；不要用事后Y挑出“有用证据”。
若怀疑数值锚定，另立开发诊断（例如隐藏研究映射概率但保留原生TAF），明确改变了输入信息，不能进入共同baseline主比较。

### 4.3 完整日历与概率银行

先跑已经取得的2025-02-03完整24小时432机会，而非反复27机会子窗；保留1km零正例和5km两个正例。
冻结Dec2023银行不变，重现旧/新日期方向相反的结果。跨期失准、证据噪声、任务稀有性是待检验解释，不预先判因。
需要更新银行时新版本独立train/calibration/development/confirmation；原始TAF不是官方单时点概率，研究映射必须明示。
确定性/集合专业产品、校准映射、廉价统计后处理分开报告；不把自己较弱的映射等同整个业务预报能力。

## 5. C2：真实联合可达，而不只是每道题有答案

复用现有solve_joint与validate_witness，不把各目标独占预算的“可达”相加。
从实际checkpoint编译 residual graph：当前时钟、已付/已预留成本、授权缓存、已过期产品、剩余费用、并发、处理动作与各机会截止。
已付共享资产可以复用，但重新处理/输入token要收费；target_private和fixed_quota必须保持相应权限/付款约束。若求解器暂不能表达quota，结果只能标relaxation，不能标精确联合可达。

每条可行见证绑定同一个prefix/source/clock/contract版本，并用独立执行器重放。最小cost与最早time不能拼自两条互不兼容路径。
搜索超上限给bound/unknown，不把未搜索到说成不可达；只在有明确支持语义的有限图上称exact。
E的未完成不一定意味着策略错误：预算可能更合理用于另一F目标。E可达不是F最优、不是物理未来可预测性证明。

## 6. CP04b：在途状态与可靠重放

继续使用现有SessionCoordinator和run_clock，不再实现另一套异步时钟。
快照最低包含：调用/请求ID、输入bundle/source/context锁定、队列、预留及实际开销、response获取与持久化状态、剩余耗时、缓存权限、策略记忆/RNG、controller cursor、pending外部事件、已封存机会；启用D时另含准备作业及清理状态。

建议执行状态：planned → reserved → dispatched → response_received → raw_persisted → settled → admitted/rejected，失败和unknown_external_execution是显式状态。实际事务与偏序先写ADR，不能仅复制对象宣称完整恢复。

故障注入：预留后、发出后、返回前、返回后落盘前、落盘后结算前、结算后安装前、截止同刻；同时测试取消、重复回调和新TAF到达。
外部不具备幂等接口时，不能保证崩溃后外部只执行一次。已有raw按ID重放；只有job handle就核查原作业；无法确定则保留unknown及成本界，不免费重新采样。
本地安装与账本必须幂等；每分支继承原prefix费用一次，分支后不能免费共享新资料；研究探索总成本另列。

CP04b可与完整日历/C2的静止点测试并行。不要把D、原生MM、全部16灾种和live全部设为F核心确认的前置。

## 7. C1：先2×2，再selector，避免把缓存收益叫智能调度

第一层固定同一selector，比较：
`fixed_quota/global_budget × target_private/session_shared`。
固定预测器、bank、目标、可用资料、允许并发、费用定义和失败处理；保留FOLLOW、complete batch与廉价risk/coverage规则。

第二层在同一个global/shared条件比较rr/risk/coverage/LLM selector；当前LLMselector要求actual_cost_clock，不能绕过校验拿它与不匹配的public_schedule数字直接作因果归因。
selector自身的模型调用、输入输出token和时间全部计费。工程GPU并行4张不改变模拟任务允许并发。

分别报告：预测损失、B-relative与强batch-relative增量、获取/计算/等待、无提交、数值不变、control FOLLOW、accepted但改坏、迟到、预留失败与全体结果掩膜。
公平全读如果便宜合法，必须作为普通竞争者；超预算全读是另表诊断。

首个新增GPU矩阵只回答尚未得到答案的问题，不再复刻旧108/252。执行前计算unique opportunity × condition × head × representation × model × seed，并冻结总调用、token和失败上限；只为相关主张选择必要条件。

## 8. 数据路线：保留16类，按现有资格分工

| 路线 | 本轮重点 | 不允许的替代 |
|---|---|---|
| H15 | 连续开发/确认块；完整TAF条件；LAMP原生15min子任务 | 小时例行报告标签替代15min任一时刻低能见度；所有低能见度叫雾 |
| H07 | MRMS合格连续率场或累计场、HRRR/WPC、独立站点结果；pysteps工具 | VIL当雨率，重叠小时累计当瞬时场，用未来归一化范围 |
| H08 | 已取得历史QINE与USGS的物理合同；版本E先行 | 43列按其他版本44成员补齐，流量当水位，调蓄/断面不明直接评分 |
| 温度 | EUPP/DWD现有标量到typed会话；后续连续阈值 | 普通负温和一个站点自动当寒潮/热浪C3确认 |
| 其余H01-H16 | 使用原source_id更新资格门槛，按已取得来源继续桥接 | 把新文件数、帧数或下载成功记为独立灾害/正式任务 |

LAMP官方区分每小时产品与每15分钟更新的能见度/云底、以及15分钟有效窗口；需选择同目标基线，不只是单位换算。
pysteps官方元数据包含unit、timestep、accutime、transform、无雨值等，只有语义合格的序列才接短临工具。
以上为本次外部文档核对的约束；没有下载新的LAMP/MRMS数组或实际运行pysteps。

## 9. D与MM分别交付

D先在固定F轨迹下比较研究准备规则与强优化器，后再比较不同F；天气目标hash不含准备偏好。不能因换DecisionSpec便改变同输入F概率。
准备开始/完成/有效期/容量/取消/清理与沉没费用同钟；预测回退不撤销准备。结果未知保留已知动作成本与未知惩罚区间。同一天气、多F机会只结算一次相应D后果。
没有实际业务效益依据时称D-sim，不谈真实减灾金额。

MM先同源原生图与可计算表示/工具，后新增传感器；有更多未来/图外信息的真值替换叫特权诊断。无可靠逐像元Gold也可以用端到端结果，但不能让LLM judge补Gold。
H07/H08不满足合同便继续隔离，不为达到跨灾种目标降低QC。

## 10. 依赖、阶段和交付

A（本地CPU先行）：CP00.review_sync；CP01.source_arbitration；CP01.control_and_cost；CP06.offline_diagnostics。
B（可并行）：CP03.1.full_calendar；CP02.real_joint_witness；CP04b.inflight；CP05.h07_native与CP10.parallel_semantics的数据预检。
C（新批次需冻结）：CP09.selector_validity；合格CP05.compare；D的CP07/08单列。
D（独立确认）：CP13.freeze / confirmF；D、MM、前瞻分别达到自身门槛后发布。

每项工作必须提交：改动路径与diff、原/新合同版本、命令与退出码、原始日志、输入hash、已发现问题及未解决项、全体样本/机会/独立过程分母、资源账和下一项依赖。
不得只返回“新增X项测试全部通过”，更不能用测试数或调用数证明novelty。

立即停止新模型批量的条件：未来或私有结果可见、旧提交可覆盖、费用/权限可绕过、原生变量或结果无法对齐、源冲突被无理由选边、失败分母丢失。
模型零/负增量本身不是停止发布条件；可发布可靠的负结果，但不能假装证实主动优势。

## 11. 核心验收问题

1. 同源不同版本的乱序与冲突是否有唯一科学规则，而不是事件字符串排名？
2. 当前候选概率相同的时候，控制状态是否仍正确处理未来基线更新？
3. 真正的共享预算联合可达是否绑定实际已付前缀和合法权限？
4. 新日历中，简单batch、固定概率银行和模型行为的影响能否分离？
5. 完整在途恢复是否保留实际成本与输出，且对未知外部执行不造“恰好一次”？
6. 最终科学确认是否使用新独立块，且不以胜出筛题或静默修改bank？

## 12. 本次核对的外部资料

- NOAA LAMP 产品与时间支持：https://vlab.noaa.gov/web/mdl/lamp-elements
- NOAA LAMP 分发形式与更新：https://vlab.noaa.gov/web/mdl/lamp-nws-webservices
- pysteps IO 元数据：https://pysteps.readthedocs.io/en/latest/pysteps_reference/io.html

这些是适配约束，不代表本次取得真实样例，也不代表完成作者方法或新文献全面复现。
