# DisasterTrace 当前实现审查（固定 6c7c7e8）

审查日期：2026-09-13。仓库：sisuolv/disastertrace-benchmark，next-phase-v1。
固定提交：`6c7c7e81ad88e1d3a553727607e24c858136899d`。

## 1. 总体结论

已有类型化数据、独立 E/F/joint head、真实获取账本、唯一事件时钟、截止封存、静止点跨进程恢复与可复现开发结果；不能再沿用 ae69453/a08486d 的“没有这些模块”判断。
但这不等于任意源流、任意中断、所有16类或科学贡献已经通过。首要工作是源版本仲裁、控制语义、完整日历和真实联合参照；不需要新v8、重建时钟或强迫LLM修改概率。

## 2. 证据范围与实际执行

本次读取最新发布说明、整体计划、当前下一批、关键源码和结果；没有修改仓库或启动GPU、模型API、采集器。
标准GitHub连接不能直接传输二进制ZIP，容器的网络下载也未成功，所以没有声称重放8.97MB完整CPU包或项目313项原测试。

实际复制四个源码模块到本地，分别核对 Git blob SHA-1 与远端一致。对它们运行两组独立编写的合成回归：32 + 8 = **40 项通过**，另运行 **5组行为探针**。
第一组直接使用 contracts/resources/event_loop。第二组使用真实 AdmissionEngine 和前三个模块；journal reader、LLM parser 是禁止调用的导入占位依赖，因此它只验证内存程序路径，不验证原生H15、持久化journal、真实LLM或整个SessionCoordinator。
40项通过不等于无缺陷；正常保护回归与暴露边界的5组探针分开记录。以下缺陷未被证明污染已发布真实天气结果。

运行：
```bash
python -B probes/reviewer_tests.py
python -B probes/admission_probes.py
```

项目原测试和完整CPU重放应在原仓库/完整包另行执行：
```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=disastertrace-starter/src python -m pytest \
  disastertrace-starter/tests/test_monitoring*.py \
  plans/v7_execution_20260913/tests/test_fixed*.py -q
# 在官方便携包根目录：
python3 -I -B verify_portable.py . ../fresh-adaptive-replay-output
```
不能把上述“推荐命令”记成本次已经执行。

## 3. 最新进度（来自项目报告，非本次新模型结果）

- 252新调用 = 12机会×3获取条件×3独立head×2表示 + 18覆盖+18版本。全部来自固定输入诊断，不是自适应LLM selector比较。
- 97源请求；288 METAR、91 TAF；174目标、432预测机会。1km阈值0/216正例，5km阈值2/216。多个提前量/阈值不是独立天气过程。
- E-only 24/36→33/36；全读条件4/12→9/12。Joint E30/36→32/36。输入整理改善成立于这个开发矩阵，不等于预测增益或独立确认。
- 144个F-bearing回答数值均等于共同基线，Brier0.0848092。不能因此认为控制状态必为FOLLOW。
- TAF覆盖6/18；其中none类0/6正确，5次判partial、1次判full。版本16/18含6个unknown简单情况。
- 旧27机会程序FOLLOW0.0019392，共享0.0015285；新27机会FOLLOW0.0651123，共享/批量0.0742844。更多证据使E更确定、F却可能更差。
- 313项相关测试和便携包验证是项目发布记录；本次不是这些测试的独立复现。
- CP04a已完成；CP04b、真实回执绑定的联合可达、完整432机会程序日历、独立确认、D/MM/跨过程资格尚有门槛。

## 4. 高影响发现

### R01 / R02：基线原始版本身份未在准入层仲裁
`monitoring_fixed_v1/admission.py:199–214` 按到达事件直接 update_baseline。
合成同一产品流：较新issue30/.8在40到达；较旧issue10/.2在60到达，cutoff100最终为.2。
同issue、同arrival的两条不等价产品，仅交换event_id即可使结果从.8变.2，无conflict状态。

这证明了“任意合法原始版本流可以直接进入reducer”的假设不安全。若架构认为 baseline event 已由可信上游选为当前权威版本，必须在上游实现并绑定可审计仲裁；不能让读者把原始arrival与有效安装混为一谈。
当前H15使用声明的近单调发布延迟，未证明既有批次触发。优先扫描已保存candidate流，只对受影响的新报告重算，不覆盖历史封存。

### R03：撤回范围欠明确
`admission.py:215–225` 只检查revision字符串非空便清掉目标的当前base。合成撤回旧版本会清空更新版本。
当前字段可能意图表示整个目标流失效，而不是撤回给定旧revision；需要明确scope、authority、原生issue与所撤回版本，不能把迟到旧CNL或单版本撤回与当前全流取消混同。

### R04：概率相同与FOLLOW操作不等价
`contracts.py:431–475` 与 typed completion 路径会将返回概率安装为override。
同baseline .2返回.2后，下一baseline改为.8：base-bound协议回到.8，persistent协议保持.2。这是persistent协议的正确语义，却说明“回答没改数值”不等于“控制器执行FOLLOW”。
旧固定输入252实验的静态Brier没有因此被推翻；今后的适应性行为必须同时报告数值差异与控制状态。

### R05：费用类型验证不一致
EvidenceBundle接收requests=.5；BudgetLedger的Cost要求整数并拒绝它。实际TypedAviationRuntime从严格Cost构造费用，不因此认定真实费用已错。应统一规范，防止离线bundle与实际执行接受不同记录。

### R06—R09：已知未完成项或科学边界
CP04b在途恢复、C2真实前缀与联合见证、稀有事件连续日历及独立确认尚未完成；这些是落实现有计划而非新方向。
当前TAF覆盖失败可能包含UTC微秒表达、原生日期解码、区间比较和产品版本理解的混合，应分层诊断。
静态144个F保持基线与程序新日历变差，不能区分模型锚定、证据无增量、冻结概率银行迁移或合理保留；需B/f(B)/f(B,E)和强对照，而不是强迫修订。

## 5. 已有正确保护

本次40项回归支持以下局部性质：负标量可表示，概率拒绝bool/NaN/越界；未来目标截止严格；来源及派生权限不能扩大；未支付资产拒绝；预留计入全局上限；幂等reserve/settle不重复付费；超reservation不静默释放；exact-cutoff完成先于seal，late不能回写；同刻新base使旧context候选无效；取消与重复完成不重复生效；内存日志重建一致；所有方法使用同一缺失结果掩膜。
这些保护值得保留，不应为了更快泛化到16类而删除。

## 6. Novelty 的当前定位

C1：多目标共享预算中，取证/处理/预测策略相对共同预报、固定批量及廉价规则的增量。共享缓存本身不等于LLM智能选择。
C2：真实产品支持集合与同一剩余预算下的联合可达，配合同一完整前缀的分支重放；E可证不等于未来概率可证，后见分支不等于在线信息价值。
C3：数据合同与机制在独立时空块、第二物理过程和逐灾种资格上的复现；登记数量不是科学资格。

保留X00-X09。X09是同输入单目标与联合目标推理，不改为工具选择；CP14非线性共同风险不是X09的前置。
已有组件有研究空间，但当前主要证据仍是工程与开发诊断，尚未建立稳定的C1增量或C3独立机制。结果可为零/负，不以LLM必须赢作为数据准入条件。

## 7. 建议路径

立即：CP00更新完成状态；CP01源仲裁/控制语义；CP06既有错误分析；完整432机会CPU对照。
并行：CP04b故障恢复、CP02真实联合见证；H07连续原生资料预检、H08语义核准、EUPP/DWD标量接入。
随后：连续开发日历、同条件selector、冻结确认。D、MM、第二过程与前瞻各自交付，不全串联阻塞F/C2。
详见CODEX_V7_FOLLOWUP_PLAN_CN.md和CODEX_WORK_ITEMS.json。

## 8. 来源入口
- [README.md](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/README.md)
- [publication/v7_adaptive_review_20260913/REVIEW_FOR_CHATGPT_PRO_CN.md](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/publication/v7_adaptive_review_20260913/REVIEW_FOR_CHATGPT_PRO_CN.md)
- [publication/v7_adaptive_review_20260913/REPRODUCE_CN.md](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/publication/v7_adaptive_review_20260913/REPRODUCE_CN.md)
- [plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md)
- [plans/v7_adaptive_execution_20260913/NEXT_EXECUTION_CN.md](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/NEXT_EXECUTION_CN.md)
- [plans/v7_adaptive_execution_20260913/reports/DEVELOPMENT_DIAGNOSTICS.json](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_adaptive_execution_20260913/reports/DEVELOPMENT_DIAGNOSTICS.json)
- [plans/v7_next_20260913_2/OVERALL_PLAN_CN.md](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_next_20260913_2/OVERALL_PLAN_CN.md)
- [plans/v7_next_20260913_2/WORK_PACKAGES.json](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/plans/v7_next_20260913_2/WORK_PACKAGES.json)
- [disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py)
- [disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py)
- [disastertrace-starter/src/disastertrace/monitoring_fixed_v1/contracts.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/contracts.py)
- [disastertrace-starter/src/disastertrace/monitoring_fixed_v1/heads.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/heads.py)
- [disastertrace-starter/src/disastertrace/monitoring_fixed_v1/taf_tasks.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/taf_tasks.py)
- [disastertrace-starter/src/disastertrace/monitoring_fixed_v1/support_bridge.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/support_bridge.py)
- [disastertrace-starter/src/disastertrace/monitoring_fixed_v1/representations.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_fixed_v1/representations.py)
- [disastertrace-starter/src/disastertrace/monitoring_v1/event_loop.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/event_loop.py)
- [disastertrace-starter/src/disastertrace/monitoring_v1/resources.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/resources.py)
- [disastertrace-starter/src/disastertrace/monitoring_v1/session_checkpoint.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/session_checkpoint.py)
- [disastertrace-starter/src/disastertrace/monitoring_v1/policies.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/policies.py)
- [disastertrace-starter/src/disastertrace/monitoring_v1/providers/aviation.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/providers/aviation.py)
- [disastertrace-starter/src/disastertrace/monitoring_v1/reachability.py](https://github.com/sisuolv/disastertrace-benchmark/blob/6c7c7e81ad88e1d3a553727607e24c858136899d/disastertrace-starter/src/disastertrace/monitoring_v1/reachability.py)
