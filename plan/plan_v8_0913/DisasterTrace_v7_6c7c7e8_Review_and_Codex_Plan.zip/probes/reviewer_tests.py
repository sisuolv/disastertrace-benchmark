"""Offline reviewer tests against three byte-identical modules from commit 6c7c7e8.

No network, model, private weather outcomes, or repository writes are required.
These tests supplement, and do NOT rerun, the project's reported 313-test suite.
"""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import types
import unittest

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {
    'contracts': '8287a69d4628b1c2f9a9ff9dad85eea4e2bbc625',
    'resources': '48e0e1a002ec21bc8e02886be9007a74d3fb63e5',
    'event_loop': '250553e445f3e026fbd957c196250b466fe216ac',
}
MODULES = {}
BINDINGS = []
for name, sha in EXPECTED.items():
    path = ROOT / 'source' / f'{name}.py'
    content = path.read_bytes()
    actual = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
    if actual != sha:
        raise RuntimeError(f'Source mismatch: {name}: {actual} != {sha}')
    spec = importlib.util.spec_from_file_location('reviewed_' + name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    MODULES[name] = module
    BINDINGS.append({'file': f'source/{name}.py', 'git_blob_sha1': actual,
                     'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)})
C, R, E = (MODULES[x] for x in ('contracts', 'resources', 'event_loop'))


def target(tid='t', kind='event_probability', units='m'):
    return C.Target(tid, 'station:KSFO', 'visibility', units, kind, 'interval',
                    1000, 1100, 'future_physical', 'synthetic_test',
                    'lt' if kind == 'event_probability' else None,
                    1000 if kind == 'event_probability' else None)


def forecast(t, value):
    return C.Forecast(t.contract_hash, t.output_kind, t.output_units, value)


def bundle_row(*, private=False):
    t = target()
    f = forecast(t, .2).to_dict()
    return {
        'schema': 'disastertrace.frozen_evidence.v1', 'opportunity_id': 'o',
        'target': t.to_dict(), 'cutoff': 100,
        'baseline': {'forecast': f, 'source_revision': 'b1', 'issued_at': 0,
                     'available_at': 1, 'valid_until': 1000, 'kind': 'research',
                     'mapping_version': 'review-fixture', 'content': {}},
        'state': {'forecast': f, 'mode': 'FOLLOW', 'protocol': 'base_bound_override'},
        'assets': [{'asset_id': 'a', 'source_revision': 'a1', 'raw': 'fixture', 'content': {},
                    'available_at': 10, 'observed_at': 8, 'completed_at': 20,
                    'entitlements': ['t'] if private else ['t', 't2'],
                    'receipt_ids': ['r'], 'parents': [],
                    'transform': {'version': 'fixture', 'parameters': {}},
                    'reference_kind': 'product_label', 'support_assumption': 'product_exact',
                    'visible_information_scope': 'policy_after_query',
                    'support_rule_version': 'fixture', 'missingness': 'none'}],
        'receipts': [{'receipt_id': 'r', 'owner': 't', 'asset_ids': ['a'],
                      'started_at': 10, 'completed_at': 20,
                      'cost': {'requests': 1, 'bytes': 7, 'tokens': 0, 'compute_ms': 0}}],
        'authorization_mode': 'target_private' if private else 'session_shared',
        'representation': 'fixture', 'availability_basis': 'declared_archive_scenario',
        'provider_version': 'review_fixture.v1'
    }

class ContractTests(unittest.TestCase):
    def test_negative_scalar_accepted(self):
        t = target(kind='scalar', units='degC')
        t.check_forecast(forecast(t, -22.8))
    def test_bool_probability_rejected(self):
        with self.assertRaises(ValueError): forecast(target(), True)
    def test_nonfinite_rejected(self):
        for x in [float('inf'), float('-inf'), float('nan')]:
            with self.subTest(x=x), self.assertRaises(ValueError): forecast(target(), x)
    def test_probability_range_rejected(self):
        for x in [-.1, 1.01]:
            with self.subTest(x=x), self.assertRaises(ValueError): forecast(target(), x)
    def test_future_cutoff_strict(self):
        t = target(); t.check_cutoff(999)
        with self.assertRaises(ValueError): t.check_cutoff(1000)
    def test_point_and_interval_validation(self):
        d = target().to_dict(); d['physical_end'] = d['physical_start']
        with self.assertRaises(ValueError): C.Target(**d)
        d['support_kind'] = 'point'; C.Target(**d)
    def test_bundle_roundtrip(self):
        b = C.EvidenceBundle.freeze(bundle_row())
        self.assertEqual(b.to_dict(), C.EvidenceBundle.restore(b.to_dict()).to_dict())
    def test_frozen_view_is_copy(self):
        b = C.EvidenceBundle.freeze(bundle_row()); v = b.policy_view()
        v['assets'][0]['raw'] = 'mutated'
        self.assertEqual(b.policy_view()['assets'][0]['raw'], 'fixture')
    def test_future_evidence_rejected(self):
        d = bundle_row(); d['assets'][0]['completed_at'] = 101
        with self.assertRaises(ValueError): C.EvidenceBundle.freeze(d)
    def test_unpaid_asset_rejected(self):
        d = bundle_row(); d['receipts'] = []
        with self.assertRaises(ValueError): C.EvidenceBundle.freeze(d)
    def test_private_entitlement_rejected(self):
        d = bundle_row(private=True); d['assets'][0]['entitlements'].append('t2')
        with self.assertRaises(ValueError): C.EvidenceBundle.freeze(d)
    def test_wrong_receipt_owner_rejected(self):
        d = bundle_row(private=True); d['receipts'][0]['owner'] = 't2'
        with self.assertRaises(ValueError): C.EvidenceBundle.freeze(d)
    def test_raw_sensor_is_not_exact_label(self):
        d = bundle_row(); d['assets'][0]['reference_kind'] = 'raw_sensor'
        with self.assertRaises(ValueError): C.EvidenceBundle.freeze(d)
    def test_lineage_cannot_widen_permission(self):
        d = bundle_row(); a = d['assets'][0]; a['entitlements'] = ['t']
        child = copy.deepcopy(a); child.update(asset_id='child', parents=['a'], entitlements=['t','t2'])
        d['assets'].append(child)
        with self.assertRaises(ValueError): C.EvidenceBundle.freeze(d)
    def test_sealed_bundle_hash_tampering(self):
        envelope = C.EvidenceBundle.freeze(bundle_row()).to_dict()
        envelope['payload']['assets'][0]['raw'] = 'tampered'
        with self.assertRaises(ValueError): C.EvidenceBundle.restore(envelope)
    def test_same_base_identity_cannot_change_value(self):
        t=target(); s=C.ForecastState(t,'base_bound_override'); s.update_baseline(forecast(t,.1),'b',1)
        with self.assertRaises(ValueError): s.update_baseline(forecast(t,.2),'b',2)
    def test_base_bound_stale_completion_rejected(self):
        t=target(); s=C.ForecastState(t,'base_bound_override')
        s.update_baseline(forecast(t,.1),'b1',1); s.update_baseline(forecast(t,.2),'b2',2)
        self.assertEqual(s.propose(forecast(t,.7),'b1',3,100),'stale_base')
        self.assertEqual(s.effective(3).value,.2)
    def test_expiry_inclusive_then_follow(self):
        t=target(); s=C.ForecastState(t,'persistent_override')
        s.update_baseline(forecast(t,.1),'b1',1); s.propose(forecast(t,.7),'b1',2,100)
        self.assertEqual(s.effective(100).value,.7)
        self.assertEqual(s.effective(101).value,.1)
    def test_historical_lookup_requires_replay(self):
        t=target(); s=C.ForecastState(t,'persistent_override'); s.update_baseline(forecast(t,.1),'b1',20)
        with self.assertRaises(ValueError): s.effective(19)
    def test_state_restore_exact(self):
        t=target(); s=C.ForecastState(t,'persistent_override')
        s.update_baseline(forecast(t,.1),'b1',1); s.propose(forecast(t,.7),'b1',2,100); s.follow(3)
        self.assertEqual(C.ForecastState.restore(s.to_dict()).to_dict(),s.to_dict())
    def test_shared_missing_mask_preserves_denominator(self):
        t=target(); ops=[{'opportunity_id':str(i),'target':t.to_dict(),'outcome':y} for i,y in enumerate([0,None,1])]
        arms={'a':{str(i):forecast(t,.5).to_dict() for i in range(3)},
              'b':{str(i):forecast(t,.2).to_dict() for i in range(3)}}
        r=C.paired_scores(ops,arms)
        self.assertEqual((r['registered'],r['settled'],r['missing']),(3,2,1))
        self.assertEqual(r['arms']['a']['scored'],r['arms']['b']['scored'])
    def test_method_cannot_drop_opportunity(self):
        t=target(); ops=[{'opportunity_id':'o','target':t.to_dict(),'outcome':0}]
        with self.assertRaises(ValueError): C.paired_scores(ops,{'a':{}})

class ResourceTests(unittest.TestCase):
    def test_costs_strict_integers(self):
        for x in [True, .5, -1]:
            with self.subTest(x=x), self.assertRaises(ValueError): R.Cost(requests=x)
    def test_reservation_counts_pending(self):
        l=R.BudgetLedger({'requests':2}); l.reserve('a',R.Cost(requests=2),'t')
        with self.assertRaises(ValueError): l.reserve('b',R.Cost(requests=1),'t')
    def test_reservation_and_settlement_idempotent(self):
        l=R.BudgetLedger({'requests':2}); c=R.Cost(requests=1)
        self.assertTrue(l.reserve('a',c,'t')); self.assertFalse(l.reserve('a',c,'t'))
        self.assertTrue(l.settle('a',c)); self.assertFalse(l.settle('a',c))
        self.assertEqual(l.spent.requests,1)
    def test_conflicting_replay_rejected(self):
        l=R.BudgetLedger({'requests':2}); l.reserve('a',R.Cost(requests=1),'t')
        with self.assertRaises(ValueError): l.reserve('a',R.Cost(requests=2),'t')
    def test_overrun_does_not_release_reservation(self):
        l=R.BudgetLedger({'requests':2}); l.reserve('a',R.Cost(requests=1),'t')
        with self.assertRaises(ValueError): l.settle('a',R.Cost(requests=2))
        self.assertEqual(l.reserved.requests,1); self.assertFalse(l.entries['a']['settled'])
    def test_fixed_quota_pays_complete_shared_request(self):
        l=R.BudgetLedger({'requests':4},allocation_mode='fixed_quota',quotas={'t':{'requests':1}})
        with self.assertRaises(ValueError): l.reserve('a',R.Cost(requests=2),'t')
    def test_failed_call_cost_stays_spent(self):
        l=R.BudgetLedger({'requests':2}); c=R.Cost(requests=1)
        l.reserve('a',c,'t'); l.settle('a',c,outcome='timeout')
        self.assertEqual(l.spent.requests,1); self.assertEqual(l.reserved.requests,0)

class Event:
    def __init__(self,event_id,time,kind,payload=None):
        self.event_id,self.time,self.kind,self.payload=event_id,time,kind,payload or {}
    def to_dict(self): return vars(self).copy()
class Owner:
    def __init__(self):
        self._events={}; self._processed=set(); self._last_time=None; self.journal=None
        self.opportunities={'o':types.SimpleNamespace(opportunity_id='o',cutoff=100)}
        self.snapshots={};self.actions=[]
    def _process(self,e): self.actions.append(e.kind)
    def _invalidate(self,t): self.actions.append('invalidate')
    def _seal(self,t):
        if t==100: self.snapshots['o']=list(self.actions); self.actions.append('seal')
    def _after_seal(self,t): self.actions.append('after_seal')
    def _expiry_times(self,upcoming): return []
class ClockTests(unittest.TestCase):
    def test_equal_time_completion_precedes_seal_begin_after(self):
        o=Owner(); ev=[Event('begin',100,'begin'),Event('complete',100,'completion'),Event('base',100,'baseline')]
        E.run_clock(o,ev,until=100,event_order={'baseline':0,'completion':1,'begin':5},decode=lambda r:Event(**r))
        self.assertEqual(o.snapshots['o'],['baseline','completion','invalidate'])
        self.assertEqual(o.actions[-1],'begin')
    def test_no_backdated_insertion(self):
        o=Owner(); E.run_clock(o,[],until=50,event_order={},decode=lambda r:Event(**r))
        with self.assertRaises(ValueError): E.run_clock(o,[Event('x',50,'completion')],until=100,event_order={'completion':1},decode=lambda r:Event(**r))
    def test_idempotent_event_no_reexecution(self):
        o=Owner(); e=Event('x',20,'completion')
        for end in [20,40]: E.run_clock(o,[e],until=end,event_order={'completion':1},decode=lambda r:Event(**r))
        self.assertEqual(o.actions.count('completion'),1)


def counterexamples():
    t=target(); results={}
    for protocol in ['base_bound_override','persistent_override']:
        s=C.ForecastState(t,protocol); s.update_baseline(forecast(t,.2),'b1',10)
        s.propose(forecast(t,.2),'b1',20,100)
        s.update_baseline(forecast(t,.8),'b2',30)
        results[protocol]={'candidate_value_at_20':.2,'baseline_at_20':.2,
                           'baseline_at_30':.8,'effective_at_30':s.effective(30).value,
                           'mode_at_30':'FOLLOW' if s.override is None else 'OVERRIDE'}
    d=bundle_row(); d['receipts'][0]['cost']['requests']=.5
    b=C.EvidenceBundle.freeze(d)
    try: R.Cost(**b.policy_view()['receipts'][0]['cost'])
    except ValueError as exc: cost_error=str(exc)
    else: cost_error=None
    return {
        'same_probability_is_not_control_follow': results,
        'cost_contract_mismatch': {'bundle_accepted_fractional_request':True,'strict_ledger_rejected':cost_error},
        'scope':'Synthetic contract probes, not evidence that archived experiments contain these defects.'
    }

if __name__=='__main__':
    stream=io.StringIO()
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    report={'commit':'6c7c7e81ad88e1d3a553727607e24c858136899d',
            'scope':'Three exact upstream modules; synthetic reviewer fixtures, not the upstream 313-test suite',
            'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
            'source_bindings':BINDINGS,'diagnostic_probes':counterexamples()}
    (ROOT/'REVIEWER_TEST_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'REVIEWER_TESTS.log').write_text(stream.getvalue())
    print(stream.getvalue()); print(json.dumps(report,ensure_ascii=False,indent=2))
    sys.exit(not result.wasSuccessful())
