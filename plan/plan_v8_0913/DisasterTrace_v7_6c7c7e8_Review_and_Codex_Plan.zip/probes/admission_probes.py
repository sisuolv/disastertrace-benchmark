"""Source-identical AdmissionEngine probes with synthetic, non-aviation bundles.

Four production modules are copied byte-for-byte and checked against Git blobs.
The journal reader and LLM head parser are import stubs which raise if invoked.
No journal I/O, real provider adapter, LLM head, or real weather replay is tested.
The production engine, clock, typed contracts and Cost execute unmodified.
"""
from __future__ import annotations
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import types
import unittest

ROOT=Path(__file__).resolve().parents[1]
P='review_package'
for name in [P,P+'.monitoring_v1',P+'.monitoring_fixed_v1']:
    m=types.ModuleType(name); m.__path__=[]; sys.modules[name]=m

def fail_unused(*a,**k): raise AssertionError('This dependency is outside the probe scope')
journal=types.ModuleType(P+'.monitoring_v1.journal');journal.read_journal=fail_unused
sys.modules[journal.__name__]=journal
heads=types.ModuleType(P+'.monitoring_fixed_v1.heads')
def _unique_object(pairs):
    result={}
    for name,value in pairs:
        if name in result: raise ValueError('Duplicate response field')
        result[name]=value
    return result
def _reject_constant(value): raise ValueError('Nonfinite JSON constant: '+value)
heads._unique_object=_unique_object;heads._reject_constant=_reject_constant;heads.parse_response=fail_unused
sys.modules[heads.__name__]=heads

BINDINGS=[]
def load(leaf,package,expected):
    path=ROOT/'source'/(leaf+'.py'); content=path.read_bytes()
    actual=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
    if actual!=expected: raise RuntimeError('Upstream source differs: '+leaf)
    name=P+'.'+package+'.'+leaf
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec)
    sys.modules[name]=m; spec.loader.exec_module(m)
    BINDINGS.append({'file':'source/'+leaf+'.py','git_blob_sha1':actual,
                     'sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content)})
    return m
C=load('contracts','monitoring_fixed_v1','8287a69d4628b1c2f9a9ff9dad85eea4e2bbc625')
R=load('resources','monitoring_v1','48e0e1a002ec21bc8e02886be9007a74d3fb63e5')
L=load('event_loop','monitoring_v1','250553e445f3e026fbd957c196250b466fe216ac')
A=load('admission','monitoring_fixed_v1','f89c71a582cbc3eaf14ff935ab4928bd63ccbb2f')

def target():
    return C.Target('t','station:TEST','visibility','m','event_probability','interval',
                    1000,1100,'future_physical','synthetic_review_slot','lt',1000)
def fc(value):
    t=target(); return C.Forecast(t.contract_hash,t.output_kind,t.output_units,value).to_dict()
def engine(protocol='base_bound_override'):
    return A.AdmissionEngine([A.TypedOpportunity('o',target(),100)],fallbacks={'t':fc(.05)},protocol=protocol)
def bundle(revision,value,issue,arrival,*,cutoff=None,protocol='base_bound_override'):
    return C.EvidenceBundle.freeze({
        'schema':'disastertrace.frozen_evidence.v1','opportunity_id':'o',
        'target':target().to_dict(),'cutoff':arrival if cutoff is None else cutoff,
        'baseline':{'forecast':fc(value),'source_revision':revision,'issued_at':issue,
                    'available_at':arrival,'valid_until':1000,'kind':'research',
                    'mapping_version':'synthetic_review.v1','content':{'product':'single_family'}},
        'state':{'forecast':fc(value),'mode':'FOLLOW','protocol':protocol},
        'assets':[],'receipts':[],'authorization_mode':'session_shared',
        'representation':'synthetic_scalar','availability_basis':'declared_archive_scenario',
        'provider_version':'synthetic_reviewer_provider.v1'})
def base_event(eid,rev,value,issue,arrival):
    return A.AdmissionEvent(eid,arrival,'baseline',{'bundle':bundle(rev,value,issue,arrival).to_dict()})
def begin_event(b,at=20):
    return A.AdmissionEvent('begin',at,'begin',{'call_id':'c','bundle':b.to_dict(),'head':'program','executor':'review.program.v1'})
def complete_event(b,value,at=80,*,eid='completion'):
    raw=C.canonical(fc(value))
    return A.AdmissionEvent(eid,at,'completion',{
        'call_id':'c','bundle_hash':b.bundle_hash,'raw':raw,'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),
        'started_at':20,'completed_at':at,'persisted_at':at,'expires_at':120,
        'cost':{'requests':0,'bytes':0,'tokens':0,'compute_ms':1},
        'ended_with_eos':True,'head':'program','executor':'review.program.v1'})

class AdmissionRegressionTests(unittest.TestCase):
    def test_exact_cutoff_completion_is_effective(self):
        e=engine(); b=bundle('v1',.2,5,10,cutoff=100)
        e.run([base_event('base','v1',.2,5,10),begin_event(b),complete_event(b,.7,100)],until=100)
        self.assertEqual(e.snapshots['o']['forecast']['value'],.7)
        self.assertEqual(e.attempts[-1]['status'],'accepted')
    def test_late_completion_cannot_rewrite_seal(self):
        e=engine(); b=bundle('v1',.2,5,10,cutoff=100)
        e.run([base_event('base','v1',.2,5,10),begin_event(b),complete_event(b,.7,101)],until=101)
        self.assertEqual(e.snapshots['o']['forecast']['value'],.2)
        self.assertEqual(e.attempts[-1]['status'],'late')
    def test_new_baseline_at_completion_invalidates_old_context(self):
        e=engine(); b=bundle('v1',.2,5,10,cutoff=100)
        e.run([base_event('base','v1',.2,5,10),begin_event(b),
               complete_event(b,.7,80),base_event('new','v2',.8,60,80)],until=100)
        self.assertEqual(e.snapshots['o']['forecast']['value'],.8)
        self.assertEqual(e.attempts[-1]['status'],'stale_base')
    def test_begin_at_cutoff_is_rejected(self):
        e=engine(); b=bundle('v1',.2,5,10,cutoff=100)
        e.run([base_event('base','v1',.2,5,10),begin_event(b,100)],until=100)
        self.assertEqual(e.attempts[-1]['status'],'invalid_begin'); self.assertFalse(e.calls)
    def test_canceled_call_does_not_install_prediction(self):
        e=engine(); b=bundle('v1',.2,5,10,cutoff=100)
        e.run([base_event('base','v1',.2,5,10),begin_event(b),
               A.AdmissionEvent('cancel',30,'cancel',{'call_id':'c'}),complete_event(b,.7)],until=100)
        self.assertEqual(e.attempts[-1]['status'],'canceled')
        self.assertEqual(e.snapshots['o']['forecast']['value'],.2)
    def test_duplicate_completion_has_no_second_effect(self):
        e=engine(); b=bundle('v1',.2,5,10,cutoff=100)
        e.run([base_event('base','v1',.2,5,10),begin_event(b),complete_event(b,.7,80),
               complete_event(b,.9,90,eid='duplicate')],until=100)
        self.assertEqual(e.attempts[-1]['status'],'duplicate_completion')
        self.assertEqual(e.snapshots['o']['forecast']['value'],.7)
    def test_replay_without_journal_matches(self):
        e=engine(); b=bundle('v1',.2,5,10,cutoff=100)
        e.run([base_event('base','v1',.2,5,10),begin_event(b),complete_event(b,.7,80)],until=30)
        record=e.export(); restored=A.AdmissionEngine.restore(record)
        restored.run([],until=100); e.run([],until=100)
        self.assertEqual(e.export(),restored.export())
    def test_bad_hash_receipt_rejected(self):
        e=engine(); b=bundle('v1',.2,5,10,cutoff=100); completion=complete_event(b,.7)
        completion.payload['raw_sha256']='0'*64
        e.run([base_event('base','v1',.2,5,10),begin_event(b),completion],until=100)
        self.assertEqual(e.attempts[-1]['status'],'invalid_receipt')
        self.assertEqual(e.snapshots['o']['forecast']['value'],.2)


def baseline_probes():
    e=engine()
    e.run([base_event('initial','initial',.1,1,5),
           base_event('new','new',.8,30,40),
           base_event('late-old','older',.2,10,60)],until=100)
    delayed={'newer_issue':30,'newer_value':.8,'older_issue':10,'older_arrival':60,
             'installed_revision':e.baselines['t']['source_revision'],
             'effective_at_cutoff':e.snapshots['o']['forecast']['value'],
             'attempt_statuses':[r['status'] for r in e.attempts]}
    permutations=[]
    for ida,idb in [('a','z'),('z','a')]:
        x=engine(); x.run([base_event(ida,'conflicting-A',.2,10,20),
                          base_event(idb,'conflicting-B',.8,10,20)],until=100)
        permutations.append({'event_id_A':ida,'event_id_B':idb,
                             'effective':x.snapshots['o']['forecast']['value'],
                             'installed_revision':x.baselines['t']['source_revision'],
                             'conflict_recorded':any('conflict' in str(v) for v in x.attempts)})
    w=engine(); w.run([base_event('base','new-current',.8,30,40),
            A.AdmissionEvent('old-withdrawal',60,'baseline_withdrawal',
                             {'target_id':'t','product_revision_id':'old-noncurrent','reason':'synthetic_noncurrent_withdrawal'})],until=100)
    return {
        'delayed_older_publication_overwrites_newer':delayed,
        'same_issuance_conflict_depends_on_event_id':permutations,
        'withdrawal_scope_unvalidated':{'event_revision':'old-noncurrent','previous_current_revision':'new-current',
                                       'effective':w.snapshots['o']['forecast']['value'],
                                       'fallback':.05,'attempt_statuses':[r['status'] for r in w.attempts]},
        'interpretation':('These are valid generic engine events, not observed corruption of the archived H15 runs. '
                          'The registered source arbiter must either reject/filter these streams or enforce product-version semantics. '
                          'A target-wide current cancellation differs from a revision-specific retraction; the current event fields do not distinguish them.'),
        'imports_not_exercised':['journal reader','LLM head parse_response','preparation reducer','H15 native provider'],
        'actual_production_code_exercised':['AdmissionEngine','ForecastState','EvidenceBundle','run_clock','Cost']}

if __name__=='__main__':
    stream=io.StringIO(); suite=unittest.defaultTestLoader.loadTestsFromTestCase(AdmissionRegressionTests)
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    report={'commit':'6c7c7e81ad88e1d3a553727607e24c858136899d','tests_run':result.testsRun,
            'failures':len(result.failures),'errors':len(result.errors),'source_bindings':BINDINGS,
            'probes':baseline_probes(),'scope':'Synthetic in-memory engine tests, not full SessionCoordinator/real data replay'}
    (ROOT/'ADMISSION_PROBE_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'ADMISSION_TESTS.log').write_text(stream.getvalue())
    print(stream.getvalue()); print(json.dumps(report,ensure_ascii=False,indent=2))
    sys.exit(not result.wasSuccessful())
