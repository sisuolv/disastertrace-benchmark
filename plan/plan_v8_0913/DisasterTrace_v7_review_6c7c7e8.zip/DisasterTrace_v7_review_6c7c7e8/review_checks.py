#!/usr/bin/env python3
"""Offline boundary probes for 6c7c7e8.

These are isolated-function synthetic probes using test doubles, NOT the upstream
313-test suite, archive replay, native-data decoder verification, or new inference.
With --repo, verify whole-file Git blob IDs and compare function ASTs before running.
Without --repo, use the fetched text excerpts bundled with this review. event_loop.py
is a full file and its upstream Git blob hash is checked in either mode.
"""
from __future__ import annotations
import argparse, ast, hashlib, json, math, types
from dataclasses import dataclass, asdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
COMMIT = '6c7c7e81ad88e1d3a553727607e24c858136899d'
FILES = {
 'run_clock': ('monitoring_v1/event_loop.py', '250553e445f3e026fbd957c196250b466fe216ac', 'event_loop.py', None),
 'score_admitted': ('monitoring_fixed_v1/admission.py', 'f89c71a582cbc3eaf14ff935ab4928bd63ccbb2f', 'score_admitted.py', None),
 'execute': ('monitoring_fixed_v1/adaptive.py', 'd542a54bb6c05864348df3ec06f076eec4a3965b', 'execute.py', 'TypedAviationRuntime'),
}

def blob(raw: bytes) -> str:
 return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def node(source: str, name: str, cls: str | None = None):
 tree = ast.parse(source)
 candidates = tree.body
 if cls:
  candidates = next(n for n in candidates if isinstance(n, ast.ClassDef) and n.name == cls).body
 return next(n for n in candidates if isinstance(n, ast.FunctionDef) and n.name == name)

def load(name, env, repo):
 rel, expected, snippet, cls = FILES[name]
 raw = (HERE/'snippets'/snippet).read_bytes()
 if name == 'run_clock': assert blob(raw) == expected
 n = node(raw.decode(), name)
 if repo:
  native = repo/'disastertrace-starter/src/disastertrace'/rel
  b = native.read_bytes()
  if blob(b) != expected: raise ValueError(f'{rel}: different source version; re-audit, do not bypass')
  m = node(b.decode(), name, cls)
  if ast.dump(m, include_attributes=False) != ast.dump(n, include_attributes=False):
   raise ValueError(f'{rel}: fetched excerpt AST differs from checkout')
  n = m
 exec(compile(ast.fix_missing_locations(ast.Module(body=[n],type_ignores=[])), rel, 'exec'), env)
 return env[name]

@dataclass
class Event:
 event_id: str
 time: int
 kind: str
 payload: dict
 def to_dict(self): return asdict(self)

class Journal:
 def __init__(self): self.rows=[]
 def append(self, key, value): self.rows.append((key, value))

class ClockOwner:
 def __init__(self):
  self._events={}; self._processed=set(); self._last_time=10
  self.journal=Journal(); self.opportunities={}; self.snapshots={}; self.processed=[]
 def _expiry_times(self, events): return []
 def _process(self, event): self.processed.append(event.event_id)
 def _invalidate(self, at): pass
 def _seal(self, at): pass
 def _after_seal(self, at): pass

@dataclass
class Cost:
 requests: int=0
 bytes: int=0
 tokens: int=0
 compute_ms: int=0

class Ledger:
 def __init__(self): self.entries={'call': {'settled': False}}; self.settlements=[]
 def settle(self, key, value, outcome):
  self.entries[key]['settled']=True; self.settlements.append((key,asdict(value),outcome))

class Bundle:
 bundle_hash='b'*64
 def to_dict(self): return {'bundle_hash':self.bundle_hash}
 def policy_view(self): return {'assets':[]}

class Runtime:
 def __init__(self):
  self.config={'typed_head':'f_only','isolation_mode':'public_schedule','public_call_slot_ms':30000}
  self.calls={}; self.attempts=[]; self.opportunities={'o':{'target_id':'t','cutoff':200_000_000}}
 def freeze_acquired(self,*args): return Bundle()
 def run(self, events, until=None):
  for e in events:
   if e.kind=='begin': self.calls[e.payload['call_id']]={'completed':False}
   if e.kind=='completion':
    self.calls[e.payload['call_id']]['completed']=True
    self.attempts.append({'event_id':e.event_id,'status':'accepted'})

class TargetDouble:
 contract_hash='a'*64
 def to_dict(self): return {'target_id':'t','output_kind':'event_probability','units':'m'}


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--repo',type=Path)
 p.add_argument('--output',type=Path,default=HERE/'review_results_new.json')
 a=p.parse_args()
 results=[]
 def add(name, interpretation, observed, ok=True):
  results.append({'test':name,'classification':interpretation,'observed':observed,'probe_behaved_as_described':bool(ok)})
 def expected_error(fn):
  try: fn()
  except (ValueError,TimeoutError) as e: return str(e)
  return None
 clock=load('run_clock',{'json':json},a.repo)
 def run(o, events, until=30):
  return clock(o,events,until=until,event_order={'baseline':0},decode=lambda r:Event(**r))
 o=ClockOwner(); run(o,[Event('future',20,'baseline',{})])
 add('clock_valid_event','positive_control',o.processed, o.processed==['future'])
 run(o,[Event('future',20,'baseline',{})])
 add('clock_same_id_replay','positive_control',{'processed':o.processed,'journal_entries':len(o.journal.rows)},len(o.processed)==1 and len(o.journal.rows)==1)
 err=expected_error(lambda:run(o,[Event('future',20,'baseline',{'different':1})]))
 add('clock_conflicting_id','positive_control',err,err is not None)
 o=ClockOwner(); err=expected_error(lambda:run(o,[Event('old',5,'baseline',{})]))
 add('clock_stale_first','positive_control',{'error':err,'pending':list(o._events)},err is not None and not o._events)
 o=ClockOwner(); err=expected_error(lambda:run(o,[Event('future',20,'baseline',{}),Event('old',5,'baseline',{})]))
 add('clock_partial_batch_mutation','reproduced_boundary_defect',{'error':err,'pending_after_rejection':list(o._events),'journal_after_rejection':len(o.journal.rows)},err is not None and 'future' in o._events and len(o.journal.rows)==1)
 run(o,[])
 add('rejected_batch_event_later_executes','reproduced_boundary_defect',o.processed,o.processed==['future'])

 fingerprint=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()
 def require_fields(x,fields,label):
  if not isinstance(x,dict) or set(x)!=set(fields.split()): raise ValueError(label)
 def math_spy(rows, arms):
  # Deliberately a downstream test double: this probe is about ADMISSION guards,
  # not about revalidating the Brier implementation.
  return {'registered':len(rows),'arms_received':list(arms)}
 mapping={}
 class Reader:
  @staticmethod
  def from_journal(path): return mapping[path]
 score=load('score_admitted',{'AdmissionEngine':Reader,'require_fields':require_fields,'fingerprint':fingerprint,'paired_scores':math_spy},a.repo)
 target=TargetDouble()
 def engine(base,context='context_A'):
  return types.SimpleNamespace(contract={'same_target_fallback_protocol':True},
   contract_hash='c'*64,time_basis='declared_archive_scenario',
   opportunities={'o':types.SimpleNamespace(target=target)},calls={},attempts=[],
   snapshots={'o':{'forecast':{'value':base},'base_forecast':{'value':base},'baseline_context_hash':context,'baseline_kind':'research'}})
 outcomes=[{'opportunity_id':'o','target_contract_hash':target.contract_hash,'value':1,'status':'mature','source_revision':'obs_v1'}]
 mapping.update(A=engine(.2),B=engine(.2))
 add('score_same_contract_baseline','positive_control',score(outcomes,{'a':'A','b':'B'})['scores'])
 mapping['B']=engine(.8,'context_B')
 out=score(outcomes,{'a':'A','b':'B'})
 add('score_mismatched_common_baseline','reproduced_missing_guard',{'accepted':True,'base_A':.2,'base_B':.8,'score_input':out['scores']})
 mapping['B']=engine(.2,'different_mapping_or_projection')
 out=score(outcomes,{'a':'A','b':'B'})
 add('score_same_number_different_baseline_context','reproduced_missing_guard',{'accepted':True,'score_input':out['scores']})
 mapping['B'].snapshots={}
 err=expected_error(lambda:score(outcomes,{'a':'A','b':'B'}))
 add('score_missing_opportunity','positive_control',err,err is not None)
 mapping['B']=engine(.2); mapping['B'].calls={'call':{'head':'e_only'}}
 err=expected_error(lambda:score(outcomes,{'a':'A','b':'B'}))
 add('score_e_only_arm_rejected','positive_control',err,err is not None)

 env={'json':json,'math':math,'hashlib':hashlib,'asdict':asdict,'Cost':Cost,
      'AdmissionEvent':Event,'canonical':lambda x:json.dumps(x),
      'model_messages':lambda b,h:[{'content':'test-only-system'}],
      'parse_response':lambda raw,b,h:types.SimpleNamespace(forecast=types.SimpleNamespace(value=.2),e_status=None),
      'native_slot_support':lambda b,at:{'status':'undetermined'}}
 execute=load('execute',env,a.repo)
 def backend(seconds):
  def f(*_): return '{"probability":0.2}',{'seconds':seconds,'input_tokens':20,'output_tokens':5,'ended_with_eos':True}
  return f
 r=Runtime();l=Ledger()
 record,_=execute(r,{'target_id':'t','opportunity_id':'o'},'call',1,None,l,[],backend(.1))
 add('execute_normal_call','positive_control',{'settled':l.entries['call']['settled'],'completed':r.calls['call']['completed']},l.entries['call']['settled'] and r.calls['call']['completed'])
 r=Runtime();l=Ledger()
 err=expected_error(lambda:execute(r,{'target_id':'t','opportunity_id':'o'},'call',1,None,l,[],backend(31)))
 add('execute_public_slot_overrun','reproduced_failure_accounting_gap',{'error':err,'settled':l.entries['call']['settled'],'call_completed':r.calls['call']['completed'],'runtime_completion_records':len(r.attempts)},err is not None and not l.entries['call']['settled'] and not r.calls['call']['completed'])
 def timed_out(*_): raise TimeoutError('synthetic backend failure after dispatch')
 r=Runtime();l=Ledger()
 err=expected_error(lambda:execute(r,{'target_id':'t','opportunity_id':'o'},'call',1,None,l,[],timed_out))
 add('execute_backend_exception','reproduced_failure_accounting_gap',{'error':err,'settled':l.entries['call']['settled'],'call_completed':r.calls['call']['completed']},err is not None and not l.entries['call']['settled'] and not r.calls['call']['completed'])
 result={'commit':COMMIT,'scope':'isolated fetched functions with deterministic synthetic test doubles; not full-module integration or real-weather failures',
  'source_mode':'checkout Git blobs and ASTs verified' if a.repo else 'fetched excerpts; complete event_loop Git blob verified; other excerpts not independently whole-file verified',
  'upstream_tests_rerun':False,'portable_zip_replayed':False,'model_calls':0,'gpu_jobs':0,
  'probes':len(results),'all_probes_reproduced':all(x['probe_behaved_as_described'] for x in results),'results':results}
 a.output.parent.mkdir(parents=True,exist_ok=True)
 with a.output.open('x', encoding='utf-8') as stream:
  stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False,indent=2))
 if not result['all_probes_reproduced']: raise SystemExit(1)

if __name__=='__main__': main()
