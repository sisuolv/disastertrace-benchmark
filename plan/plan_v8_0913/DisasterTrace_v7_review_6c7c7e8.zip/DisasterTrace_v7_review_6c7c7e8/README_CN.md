# DisasterTrace v7：实现审查与 Codex 交接包

审查提交：`6c7c7e81ad88e1d3a553727607e24c858136899d`（2026-09-13 13:08:38 UTC）。
仓库：`sisuolv/disastertrace-benchmark`，分支：`next-phase-v1`。

## 阅读顺序

1. `CODEX_NEXT_PLAN_CN.md`：完整执行规格，首批 R00–R04 使用 CPU 和已有数据。
2. `CODEX_START_PROMPT_CN.txt`：交给 Codex 的入口指令。
3. `review_results.json`：此次14个隔离边界探针的实际结果。
4. `review_checks.py` 与 `snippets/`：可复运行的最小检查。
5. `WORK_PACKAGES.json`：工作包、依赖及准入要求。

## 结论边界

当前 v7 已有类型化证据接入、同一会话时钟、截止评分、静止点跨进程恢复以及独立 E/F/joint 调用。
本次复现三类边界问题：调用异常/公开时隙超限未最终化；事件批次被拒绝后残留事件；评分入口未检查共同基线语义一致。
另外指出数值复制基线不等于显式 FOLLOW，以及在途恢复和 C2 实际账本桥的已知缺口。

检查使用读取到的原函数和可控 test doubles，不是项目完整集成测试。
完整 `event_loop.py` 的 Git blob 哈希已验证；另两个是函数摘录，可用下面的 `--repo` 模式核对完整检出版本及AST。
没有重跑上游313项测试，没有取得或重放上游完整CPU ZIP，没有新模型调用或科学数据下载。
这些合成反例不证明当前252次真实回答、36份日志或8条恢复分支出现同样错误。

## 在本包内复运行（只用 Python 标准库）

```bash
python3 -I -B review_checks.py --output /tmp/disastertrace-probes-new.json
```

输出路径必须不存在。`all_probes_reproduced=true` 表示观察到与报告一致的正常/异常行为，
**不是**“代码没有缺陷”或“313项项目测试通过”。

## 在完整固定版本 checkout 中核对摘录并复测

```bash
python3 -I -B review_checks.py \
  --repo /path/to/disastertrace-benchmark \
  --output /tmp/disastertrace-checkout-probes-new.json
```

该模式验证三个上游文件的完整 Git blob 和所测函数的 AST。HEAD/源码已变化时停止，不绕过版本检查。
修复后应把反例转成项目自己的真实模块/临时journal集成回归，不能把这个故意复现缺陷的脚本当成修复验收器。

`REVIEW_CHECKS_RERUN.json` 与 `CHECK_RUN.log` 是打包前再次执行的记录，与原 `review_results.json` 内容一致。
`PACKAGE_MANIFEST.json` 仅验证交付包内容，不验证外部科学原始数据或上游运行成绩。

本包只创建本地交付物，没有修改用户GitHub仓库、提交代码、重启旧launcher或消耗新的GPU实验权限。
