# DisasterTrace v7：基于 6c7c7e8 的实现审查与 Codex 后续执行计划

- 审查日期：2026-09-13。
- 审查仓库：`sisuolv/disastertrace-benchmark`。
- 审查分支：`next-phase-v1`。
- 固定提交：`6c7c7e81ad88e1d3a553727607e24c858136899d`，提交时间 2026-09-13 13:08:38 UTC。
- 本计划是下一批工作的实施规格，不是宣称已完成修复或新实验。
- 保留 **v7、C1/C2/C3、E/F/D/MM、X00–X09、六组16类灾害**；不另起 v8，不引入新的核心研究方向。

## 0. 给 Codex 的首条执行指令

先执行 R00–R04：现有材料离线核验、评分可比性、事件批次原子性、失败记账与现有日历复算。
这批只需要已有本地源文件、CPU 与合成回归测试。不要先重跑 GPU 矩阵，不要重新下载已经保存的 2025 日期数据。
后续 CP04b / C2 / 确认日历的工作在这些边界通过后推进。

用户此次要求审查与计划，不构成新数据采集、模型推理、付费接口、训练、GEE 导出或后台任务的新增执行授权。
如已有明确的后续执行授权，先绑定其范围、预算、有效期与未消费 claim；不能复用已消费授权，也不能重复询问已明确的信息。
未获得有效授权的昂贵动作写成待执行计划即可。已有源文件的离线阅读、程序复算与测试不需要新模型调用。

### 工作区保护

1. 先运行 `git status --short`、`git rev-parse HEAD`，记录已有 staged/unstaged/untracked 内容，不覆盖、不清理。
2. 不执行 `git reset --hard`、`git clean`、强制 checkout、force push 或历史结果替换。
3. 若 HEAD 已前进，先比较本计划列出的关键函数；以实际新代码为准重新确认缺口，不能盲目照搬旧反例。
4. 旧运行目录、原始回答、失败日志、数据源、标注、校准银行、归档和 claim 保持不变。
5. 每个新产物使用全新目录并记录 parent commit、输入哈希、配置和用途。现有 launcher 只能阅读，不能再次启动。
6. 不打印或打包 credential、cookie、签名下载参数、访问 token、模型权重或私人环境文件。

---

## 1. 本次审查的证据范围

### 实际完成

- 通过 GitHub 连接读取分支头、v7 当前报告、下一执行计划、整体方案和关键源码。
- 静态检查 `monitoring_fixed_v1` 的 contracts/admission/adaptive/heads/representations/support_bridge/taf_tasks，及 `monitoring_v1` 的时钟、控制器检查点、策略与有限联合可达性。
- 用读取到的原函数文本进行 **14 个离线隔离边界探针**；运行器、日志读取器、资源账本、后端使用显式 test doubles。
- `event_loop.py` 是完整文件，Git blob 哈希与远端 `250553e445f3e026fbd957c196250b466fe216ac` 一致。
- 另外两个被测函数为远端文本摘录；随附脚本支持 `--repo`，可在完整 checkout 中核验原文件 Git blob 与函数 AST 后重测。

### 没有完成

- 没有重跑仓库声明的全部313项测试。
- 没有取得并重放 8,972,043 字节完整 CPU ZIP：容器直接下载遭遇 DNS 解析失败。
- 没有独立重解码所有真实科学资产，没有新 GPU、LLM、外部 API 推理或真实业务操作。
- 合成边界反例不是当前252次真实回答或36份日志失败的证据。

本地 `review_results.json` 和 `review_checks.py` 是此次执行证据，不替代上游完整复现。

---

## 2. 当前事实基线：不要把已经完成的功能再列为待开发

### 已有工程能力

- `TypedAviationRuntime` 已被旧 `SessionCoordinator` 调用，启用 `session_runtime="typed_admission_v1"`。
- 查询来自真实会话已结算回执，绑定付款者、权限、内容与账本；不再只是静态“假定已读”。
- baseline / withdrawal / begin / completion / cutoff 经过同一 `run_clock`。
- `AdmissionEngine` 绑定开始快照、原始回答、完成与持久化时间；E-only 不安装未来预测。
- 静止点的跨进程恢复已经实现。不是“整个恢复机制还没写”，而是**在途恢复尚未完成**。
- 类型层已经支持标量/概率、点/区间、不同未来时间语义；不能沿用 ae69453 的“所有变量非负、只允许气旋/流量”的旧缺陷结论。
- H15 的 typed runtime 与 heads 仍是专属适配；类型层通用不等于16类实际会话全部接通。
- 已有 TAF 原生覆盖/版本两种独立 E 合同，并对 NIL/CNL、同发行时刻冲突与未知状态进行区分。

### 当前结果口径

| 范围 | 实际记录 | 边界 |
|---|---|---|
| 本轮数据 | 97次请求、288条METAR、91份完整TAF | 是来源与记录数，不是独立过程 |
| 开发日历 | 2025-02-03，三机场、1/3/6h、1km/5km | 174唯一目标、432机会；1km 0/216正例、5km 2/216正例 |
| 本轮模型 | Qwen3-8B，252次回答、3张H100 | 固定输入诊断；不是自适应 LLM selector 获益实验 |
| E-only表示 | 24/36 -> 33/36 | 同开发题的输入组织效应；无数据条件下的unknown也进入总体分母 |
| Joint的E | 30/36 -> 32/36 | 与独立E-only不同，不合并算独立过程 |
| F输出 | 144个含F回答的数值等于共同基线 | 固定输入数值相同不等于动态FOLLOW状态相同 |
| TAF专门E | 覆盖6/18，版本16/18 | 产品理解，不是未来物理天气预测 |
| 三小时会话 | 两日期各27机会，2×2+FOLLOW+batch | 36份日志、8条静止点分支；还不是432机会全日历对照 |
| 程序负结果 | 新日期FOLLOW 0.0651123，global/shared与batch 0.0742844 | Brier越低越好；共享与强batch相同，不能归为智能调度收益 |
| 历史模型 | 上轮108次、本轮252次，另有720次和更早大批次 | 分阶段、分目标、分协议报告，不任意相加成统一样本量 |

来源：当前 `FINAL_REPORT_CN.md`、`REVIEW_FOR_CHATGPT_PRO_CN.md`、`NEXT_EXECUTION_CN.md`。

---

## 3. 审查发现与严重性

### F01 / P0（扩展前阻断）：模型失败或超时的执行路径没有闭合账本与状态

文件：`disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py`。
函数：`TypedAviationRuntime.execute()`。
调用者：`monitoring_v1/policies.py::run_session()`，已先 `ledger.reserve()`，随后直接调用 execute。

在 public_schedule 下，真实生成时间+持久化超过公共时隙时，execute 直接 raise；这一检查位于 `ledger.settle()` 和 completion receipt 构建之前。
backend 抛出异常同样在 response parsing 的 try/except 之前。

本次合成探针：
- 30秒公共时隙，模拟31秒后返回：抛异常，预留未结算，call仍未completed，没有runtime完成记录。
- 模拟后端 dispatch 后 TimeoutError：同样留下未闭合预留和call。
- 正常返回控制：结算和completed均完成。

解释边界：故意将该 public_schedule 运行判无效是合理的；问题是失败时仍必须留下耐久、可复算的执行/费用/机会记录。
本轮真实调用都在时隙内，未证明其真实得分受此问题影响。

修复要求：
- 将开始前失败、dispatch后未定状态、已完成但超时、非法响应、账本超支分开。
- 最终化须幂等；所有已开始调用必须有 durable terminal/unknown 状态及其实际/未知成本。
- backend返回的raw先耐久保存，随后解析；不能异常后丢掉已得到的回答。
- 无法确认是否完成的远端请求标 `unknown_after_dispatch` 等明确状态，不猜零费用、不自动再调用。
- 公开时隙超限不能悄悄延长时隙、回填及时提交或删除机会。标记该时间控制无效；冻结协议规定的基线回退仍保留。
- 确认性 arm 遇到此类协议失效，应保留全机会记录并单列协议状态，不能照常宣称公平时间比较。

### F02 / P1：事件批次拒绝不是原子的

文件：`monitoring_v1/event_loop.py::run_clock()`。

函数遍历事件时立即写 journal 和 `_events`。后续事件非法时，前面写入的事件不会撤销。
合成探针：已处理至t=10，提交 `[合法t=20事件, 非法t=5事件]`，调用抛错但t=20仍在队列及journal；随后 `run_clock([], until=30)` 会执行它。
`AdmissionEngine.run()` 只在run_clock成功后追加 `_history`；因此还需核查异常后的 history、journal、队列与恢复是否失配。

修复要求：
- 先校验整个新批次：类型、时钟、与历史ID冲突、批次内部同ID冲突、payload可序列化，再修改状态。
- 同ID同内容重放可以幂等，不能重复扣费；同ID不同内容必须原子拒绝。
- 考虑durable batch begin/commit或等价方法处理落盘崩溃；未提交尾部不得作为合法批次执行。
- reducer过程中发生语义异常也需要明确回滚/毒化状态/不可继续规则，不能留任意半执行状态。
- 不需要发明第二套时钟；在现有run_clock上实现事务边界。

### F03 / P1：正式评分未强制共同基线一致

文件：`monitoring_fixed_v1/admission.py::score_admitted()`。

目前比较机会/回退/协议合同与全机会封存，但不会逐机会比较 `base_forecast`、`baseline_context_hash`、baseline_kind；合同也未绑定完整共同基线流与校准银行。
本次隔离探针在 journal reader test double 提供两份同合同sealed engine后，base=0.2与base=0.8仍通过评分层；相同0.2但不同context也被接受。
这是评分入口缺少保证，不证明当前统一data/bank生成的两份真实臂使用了不同基线。

修复要求：
- 为主比较新增实验/环境manifest，绑定目标、机会、common baseline stream、mapping bank/version、availability与cutoff规则。
- 校验每机会有效基线数值、语义context和kind一致；同概率但不同TEMPO/projection/context也要识别。
- 不要比较各臂完整事件前缀hash是否相同：合法动作和成本轨迹本来可以不同。
- X01 2×2中 allocation_mode/authorization_mode 是声明处理因素，不应被新可比性检查全部禁止。
- 有意改变基线/时间的实验必须声明 estimand 和处理因素，单列表；不能混入“共同基线之上的取证增量”。
- 增加真实临时journal的集成测试，不能只有mock reader测试。

### F04 / 高影响测量限制：预测数值未改变，不等于显式FOLLOW

`heads.py` 的F-only只有probability，joint只有fact_truth+probability。
`adaptive.py` 将含F回答记录为 `decision="override"` 并通过 `ForecastState.propose()` 安装。
所以 `p_AI == p_base_at_begin` 只说明数值复制，不代表执行了FOLLOW、no_change或未来基线更新时同样行为。
在 persistent_override 下，这一区别尤其重要。

不改写历史144个回答。新增统计：`numeric_equal_to_baseline`、`applied_mode`、`context_changed_during_call`、`invalidated_on_update`。
需要研究显式FOLLOW/OVERRIDE/NO_CHANGE时，使用独立输出协议和新实验manifest；不能事后给旧数字猜测意图。
不要为了产生改动而提示模型“必须修订”。

### F05 / 已知设计缺口：CP04b仍只支持静止点

`session_checkpoint.py::capture_session()` 明确拒绝任何资源预留或未完成call。这与报告一致，是明确边界，不是隐瞒缺陷。
新增在途恢复前，必须先解决F01/F02；否则可能重复调用、双重计费或丢掉未完成状态。

### F06 / 已知研究缺口：C2参照还未与真实会话残余预算完全接通

`support_bridge.compile_recipes()` 是有限、评估侧的证据配方；`reachability.solve_joint()` 有精确/截断状态和见证。
下一步应使用同一会话前缀、缓存权限、已支付成本、在途任务与剩余时限编译图，而不是每个目标分别享用全预算后相加。
对冲突或不单调修订，不能假设任意superset保持E结论；明确complete-pool/visible-subset命题及证书语义。
E充分性不是F可预测性，不能用E_supported强制高风险概率或停止取证。

---

## 4. 工作包与依赖

| 工作包 | 优先级 | 对应原计划 | 依赖 | 默认是否新模型/网络 |
|---|---|---|---|---|
| R00 基线与可复现核验 | P0 | CP00、X00 | 无 | 否 |
| R01 评分可比性+事件批次 | P0/P1 | CP00/01、X00/X03 | R00 | 否 |
| R02 模型失败最终化 | P0 | CP01、CP04b、X07 | R00/R01 | 否 |
| R03 E/F已有捕获离线诊断 | P1 | CP03/06、X00/X04 | R00 | 否 |
| R04 全24小时程序矩阵 | P1 | CP06/09、X00/X01 | R01/R02 | 否 |
| R05 在途恢复与时钟 | P1 | CP04b、X03/X07 | R01/R02 | 否，先fake backend |
| R06 C2真实联合可达性桥 | P1 | CP03、X04 | R01/R04，in-flight部分等R05 | 否 |
| R07 开发/确认日历与强基线 | P1 | CP09/13、X00/X06 | R03/R04 | 现有数据先做；新采集需有效范围 |
| R08 有限新模型诊断与selector | P2 | CP06/11、X00/X01/X04 | R03–R07对应门槛 | 需要新的合法冻结和未消费授权 |
| R09 H07/H08/温度分轨 | P2 | CP05/10、X05/X06 | 各自合同，独立推进 | 新资料/模型按分轨授权 |
| R10 D/MM/前瞻与发布分级 | 条件 | CP07/08/12/14、X07/X08/X09 | 各自门槛 | 不阻塞F/C2核心发布 |

R编号仅用于这次执行包，不改变原CP和X编号，也不新增贡献名称。

---

## R00：建立可复现审查起点

### 必读入口

1. `plans/v7_next_20260913_2/OVERALL_PLAN_CN.md`
2. `plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md`
3. `plans/v7_adaptive_execution_20260913/NEXT_EXECUTION_CN.md`
4. `publication/v7_adaptive_review_20260913/REVIEW_FOR_CHATGPT_PRO_CN.md`
5. `publication/v7_adaptive_review_20260913/REPRODUCE_CN.md`
6. `plans/v7_followup_execution_20260913/FINAL_REPORT_CN.md`

记录仓库实际HEAD、工作区变更、关键文件hash、数据/银行版本、已消费运行目录。

### 离线复现

在已有本地ZIP中先核验：
- 文件：`plans/v7_adaptive_execution_20260913/DisasterTrace_v7_typed_adaptive_20260913_review.zip`
- bytes：8,972,043
- SHA256：`b7e9a42812a3d5baee9fe8c15f156c1a70b3c93eebad15a52ac93da481bf8ee6`

安全解压到新目录，在含 `verify_portable.py` 的目录执行：

```bash
python3 -I -B verify_portable.py . ../adaptive-replay-new-output
```

上游预期检查：1800个清单文件、36份类型化日志、8条分支、252次新回答、108次旧回答。
这些数字若不一致，应调查版本/manifest，不通过改统计来使其匹配。
此脚本重算旧输出，不调用模型。

已有环境中运行：

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=disastertrace-starter/src python -m pytest \
  disastertrace-starter/tests/test_monitoring*.py \
  plans/v7_execution_20260913/tests/test_fixed*.py -q
```

预期固定版本313项；修复后测试数可增加。所有skip、环境缺失、失败保留。
不要将缺依赖自动转成联网安装；先使用已保存环境，缺口单列。

### 交付

`BASELINE_REVIEW.json`、`TESTS_BEFORE.log`、`PORTABLE_REPLAY_RECEIPT.json`、`INPUT_HASHES.json`。

---

## R01：评分可比性与事件批次

### 实现

1. 新增声明式实验比较合同，绑定共同环境而不是强制所有处理因素相同。
2. 主比较的共同基线流和bank不可不同；逐机会验证实际有效基线和语义context。
3. 在run_clock入队前预验证整个batch，包含batch内相同ID同/异内容。
4. 把异常后的history、journal、processed、snapshots与pending状态一致性纳入测试。
5. 对撤回事件先写ADR：product_revision_id是撤回公告自身还是被撤回版本？不要粗暴加“必须等于当前ID”，否则可能拒绝合法新CNL。
6. 同一时刻baseline/CNL/completion/cancel的顺序沿用或显式升级现有协议；不得用任意文件名排序替代来源版本语义。

### 必须通过的测试

- 相同机会、不同公共基线数值：主比较拒绝。
- 相同数值、不同相关TAF投影/银行：主比较拒绝。
- 相同公共基线、不同合法获取轨迹：允许。
- 声明的X01 allocation×authorization处理：允许。
- 批次第1个合法、第2个回填或冲突：拒绝后state/journal/history完全不变。
- 同ID同内容重复：不重复执行/记账；同ID异内容：原子拒绝。
- cutoff前、等于cutoff、cutoff后各相位；不同输入列表顺序在协议允许时结果一致。
- 已封存机会不因未来目标仍开放而被回写。

### 交付

`ADR_COMPARISON_AND_BATCH.md`、修复代码、真实临时journal集成测试、`REGRESSION_R01.json`。

---

## R02：执行失败与资源最终化

### 状态表先于代码

至少区分：
- preflight_rejected（未dispatch）；
- dispatched；
- response_received；
- persisted；
- invalid_response；
- late；
- public_slot_overrun；
- resource_overrun；
- canceled；
- unknown_after_dispatch。

状态名可沿用项目约定，语义必须明确。全部费用来自实际回执或明确未知状态，不伪造。

### 实现规则

- preflight可拒绝不可能满足预算/时限的动作，但不能先偷看真实回答。
- backend exception不得绕过audit与最终化；raw捕获、模型返回时间和资源元数据尽早耐久保存。
- settle一次，重复完成不重复计费；成功解析与成功计费/持久化是不同状态。
- public_schedule超限保持该控制无效，不通过调整时隙或只重跑失败样本修复成绩。
- 对实际费用未知的dispatch，只允许恢复器重新核对已有回执；不得盲目再次执行非幂等模型调用。
- 不把计算耗时记录成真实2025网络延迟；档案clock与真实测量说明分别保留。
- E-only无F输出、非法回答、超时都必须保留机会，按冻结fallback规则结算。

### 测试

正常、非法JSON、缺元数据、NaN/负duration、后端异常、时隙超限、实际成本大于预留、持久化前崩溃、重复完成、取消后晚返回。
结果必须要么可完整恢复，要么明确判invalid/unknown并保留费用；不能悄悄消失。

---

## R03：已有回答的离线诊断，不生成替代回答

### TAF 36条捕获

- 按coverage与revision分别输出混淆矩阵及每题原始输出，不合并成一种E任务。
- coverage拆为当前版本选择、UTC日期解码、半开区间比较、NIL/CNL、支持语法/冲突状态。
- 6/18可能是类别塌缩，但必须读取回答验证，不能凭总分推断。
- 设计同内容表示候选：原微秒、ISO替代、微秒+ISO。映射由确定性UTC转换完成；双表示长度增加与格式变化分开记录。
- 不向模型提供覆盖比例、投影出的答案、superseded/current的评估标签。
- 提供原始片段到转换字段的可逆映射与单位测试，不能把额外语义oracle叫作只改格式。

### 邻站E与F 216条捕获

- 分开E-only、F-only、joint；joint中的字段不能事后当成独立模型调用。
- 按none/单资料/全部资料、表示、truth类别、删失边界分别统计。
- 单列无资料unknown容易条件；保留24/36与33/36原总分。
- 对144个含F回答报告精确数值相等、与baseline差值、FOLLOW/OVERRIDE真实状态、与统计预测器的差异。
- F保持基线可能是合理选择、基线锚定、能力不足或证据确无增量；本批数据不能直接区分。
- 不将F不变判成格式失败或强制正向收益门槛。

### 交付

`TAF_ERROR_TAXONOMY.json`、`E_STRATIFIED_SCORES.csv`、`F_UNCHANGED_AUDIT.json`、`REPRESENTATION_DIFF_PROOFS.json`、`DIAGNOSTIC_CANDIDATES.json`。
CSV为程序结果，含每行target/opportunity/source/hash，不手工改数字。

---

## R04：使用已下载432机会完成24小时程序矩阵

### 数据与分母

使用已冻结2025-02-03整个UTC日历；保留3机场、1/3/6h、1km/5km和所有机会。
不得只保留含正例的27机会子集。另按1km与5km分别汇总；不混淆物理目标数、机会数和独立日历块。
用共同成熟结果掩膜，按缺失/删失/解析/质量状态分层；共同mask并不证明总体无偏。

### 最小对照

- FOLLOW；
- 同selector的 fixed_quota/global_budget × target_private/session_shared 四臂；
- batch_complete，使用同样缓存、并发、工具和预算规则；
- 至多增加一个廉价coverage或risk启发式，不做大笛卡尔积。

所有臂共用同一目标、完整共同TAF、概率银行与数据流。程序执行与持久化1ms、30s时隙等仍按声明情景报告。
请求2048bytes/100ms上限是既有设置，不当成通用实测费用；费用估计需单列，不为主动方法调价。

### 结果

- Brier、loss_sum、全分母与缺失；每个机会的预测和baseline；
- `gain_over_baseline = L(B)-L(f(B,E))`；
- 如有相同模型/预测器无补证臂，报告 `gain_over_model = L(f(B))-L(f(B,E))`；
- gain+、gain-、净增量、修订比例、数值未变与实际模式分开；
- 四资源维度、失败、超时、fallback、base失效、真实读取与共享复用；
- threshold/lead/station/calendar block分层。

零/少正例日不删除。1km零正例时漏报率等应标不可估计，不能用高准确率证明预警能力。
旧日期改善、新日期恶化均保留；不在新结果上重新拟合旧银行。

---

## R05：CP04b在途恢复

### 不重新建设调度器

继续复用 `run_clock`、现有 AdmissionEngine 与 SessionCoordinator。先增强快照语义，再接真实异步后端。

### 必须保存的状态

- 单一clock、已处理相位、事件队列、controller cursor；
- 所有目标和机会seal状态、baseline context、active override、expiry、真实控制模式；
- 全部已花/已预留资源、付款者、receipt id、结算状态；
- cache内容、谱系、entitlement、派生变换与父费用；
- 在途query/model的请求快照、开始时刻、预期完成、已耗/剩余声明延迟；
- request id/幂等id、raw是否已收到/是否持久化、持久化回执；
- selector历史及RNG、backend/executor版本与状态策略；
- 准备任务（若启用）的占用、剩余时间、取消/清理、沉没成本和有效期。

### 必须覆盖的崩溃点

预留后dispatch前；dispatch后无响应；收到raw未持久化；已持久化未admit；admit未seal；cutoff同刻；取消后完成；旧基线计算在新TAF之后完成。
真实远端不可幂等任务没有“绝对exactly once”免费保证：恢复时不能确认是否执行，就留unknown并人工/原回执核对，不自动再调用。

### 测试要求

在新的子进程恢复，使用确定性fake backend记录外部调用计数。比较不中断、同策略恢复及声明分支：
- 同策略完整报告相同；
- 前缀调用次数不增加，继承资源不再次扣除；
- 分支后仅新动作导致费用变化；
- 私有cache权限不能被扩宽；
- 晚到结果不回写seal；
- base_bound与persistent分别按照原协议处理；
- D恢复未通过前仍为合成子轨，不阻塞F-only。

---

## R06：C2真实支持配方与联合可达性

继续使用 `support_bridge.py::native_slot_support/compile_recipes` 和
`monitoring_v1/reachability.py::solve_joint/validate_witness`。

### 语义层

明确三类E：注册邻站过去报告存在命题；当前TAF窗口覆盖；当前/替代版本识别。
它们的参照不能互换。Native METAR删失区间是报告语义区间，不是物理测量误差置信区间。
raw image/model_estimate不能变成product_exact。

### 会话图编译

输入必须绑定同一checkpoint hash。使用真实已支付receipt、授权cache、已预留成本、实际已完成状态与截止。
已付资产可以零**边际**获取成本复用，但历史spent仍保留，private臂不能因共享图而免费可见。
在途任务保留剩余duration和已预留资源；query release、expiry、process/delivery及cutoff使用统一时间合同。
不同用途的expiry可能有不同闭区间约定，须显式绑定，不把solver的inclusive与engine的exclusive自动视为等价。

### 见证而非独立最优相加

输出可执行的同一路径：动作开始/结束、费用、权限、resolved goals、预算与时限。
用独立witness replay在真实状态副本中验证，而不仅验证整数规划/枚举内部结构。
搜索截断输出lower/upper与unknown；不能声称exact或最优。
最小三组测试：各目标单独可达但联合不可达；共享同资产后联合可达；信息已知但已来不及提交E。

支持集合与配方可以使用完整冻结池进行事后参照，但绝不进入selector/model视图，且不代表真实期望信息价值。
冲突支持、版本替换或非单调性存在时，先定义证书对应哪个完整池命题，不直接采用单调剪枝。

---

## R07：基线与独立日历

### 先拆分银行迁移和Agent收益

- 现有Dec2023银行保留；2025恶化是跨时间迁移结果，不在其上重拟合。
- 新银行只在预先划分开发/calibration块拟合并锁定，不触及confirmation结果。
- 通过目标一致的B、f(B)、f(B,E)比较，区分映射、额外证据、获取器和预测器。
- 完整TAF条件段仍保留，不能只给基线prevailing而给LLM完整TEMPO。
- LAMP为native threshold/15分钟支持单独任务，不把它替代已有小时报告合同。

### 日历

先登记连续日期、机场群、阈值、lead、缺失规则、主对照、最低有意义差异与停止准则。
若公开事件索引用于富集，只作诊断队列，确认队列按冻结规则独立。
按父天气过程/保守时空块bootstrap或其他预声明区间；purge覆盖最长回看、lead、目标窗和D有效期（若启用）。
本次12机会、两27机会、36产品E、全部已看的2025日历均为development，不能重命名heldout。
尾部指标证据不足时报告不可估计，不承诺多少调用就能显著。

---

## R08：有限新模型实验，必须回答一个已隔离的问题

完成接口与程序分析后才提交新model manifest。不要重跑旧252/108/720目录，也不要因为old F都不改就改变提示强制修订。

### 建议顺序

1. CPU完成新时间表示的可逆映射与对照构建。
2. 独立新批次只比较TAF时间表示这一因素；其他变量固定，任务明确为开发诊断。
3. F诊断保持同一预测器与完整基线，比较B-only和B+合法E，并与固定统计预测器比较。
4. 只有存在可检验的选择需求、成本及强batch对照后，才跑自适应LLM selector。
5. 2×2先固定同一selector；再在指定cell比较规则/批量/LLM，避免把权限与selector同时改变。

### Manifest最低字段

parent_commit、dataset/calendar hash、bank hash、target/opportunity IDs、heads、representation、model/weights、seed、预算/硬上限、最多并行卡数、代码freeze、输出schema、失败规则、claim_id、is_consumed。
call count必须由矩阵程序计算并输出，不能凭文本手填；selector、预测、分支和重试都计入授权上限。
存在有效授权才执行；接口smoke可先1卡，完整新矩阵工程并发至多4H100，算法对照资源仍等价。
付费API、训练、多agent架构均不属于此批默认范围。

### 解释门槛

E变好而F不变可保留为实证，但不自动归因于内部记忆、锚定或信息无价值。
F数值等于baseline与动态FOLLOW分开；若新增显式控制动作另冻协议。
程序批量与共享策略同分则报告同分，不给调度算法额外credit。

---

## R09：第二过程与数值迁移，沿用当前优先顺序

### H15主线

先完成全日历、原生TAF语义诊断、强基线与可信运行器；不再从头建立旧温度/流量两链。

### H07优先原生MM候选

先在已保存资料中核验连续序列、变量、单位、投影、负码、质量、累计重置和缺帧。
选择未来QPE产品累计或真实站点累计中的一种合同，产品P与观测O分开。
不得把VIL等同雨率，不把重叠小时累计直接当瞬时雨率输入pysteps。
使用原生视觉前缀和同源结构化/工具结果对照；派生结果中不得含未来mask。
只有通过连续样例准入后，才授权扩张和VLM实验。

### H08并行，不阻塞

已有历史QINE文件先核同断面、瞬时/平均、调蓄模式、成员身份和版本。43列未明身份不能硬套44成员说明。
可先做合法版本E；没有物理目标与阈值合同不报告洪水预警F/D。

### EUPP/DWD低成本类型回归

普通温度作为scalar/admission接口迁移；负温度、单位和点支持通过不等于热浪机制确认。

### 外部代码

pysteps、scores、OR-Tools、NLDI等仅按任务所需复用。新增依赖先固定版本、许可证、最小输入和离线测试；不因存在README就声称复现。
AFABench只借获取/预测分离和强对照，EarthVerse作相关过程评测近邻，EWB借专业验证；C2支持与联合可达性不改成泛泛错误解释。

---

## R10：分级发布与D/MM/前瞻边界

- 工程版、H15机制开发版、独立确认版、多过程/MM版、16类覆盖版分级发布。
- D-sim使用已有纯reducer，冻结时长/容量/取消/清理/沉没成本；固定信念下F不接收偏好字段。
- 同天气不同准备需求是限定仿真，不是现实救灾收益。
- X09保留联合目标推理；不等同共享cache，也不强制联合概率分布。CP14非线性联合风险后置。
- online捕获与模型评估拆开；新采集须独立冻结/授权；first_seen不冒充全网首次发布。
- 每类维护 acquisition/decode/semantics/pairing/availability/E/F/MM/D/confirmation；没有正式资格的样例不升级。
- 新报告写“本批范围”和parent；旧结果的原始数字、失败、claim与误差不能覆盖。

---

## 5. 首批执行的最终验收清单

- [ ] 实际HEAD、输入、现有工作区状态保存。
- [ ] 完整ZIP本地重放，313基线测试真实执行并披露skip/失败。
- [ ] F01/F02/F03加入最小**真实模块/临时journal**回归；此审查中的隔离mock不能作为唯一验收。
- [ ] 错误事件批次不会残留；异常模型调用不会丢费用、状态或机会。
- [ ] 主比较具有共同基线/银行/时间绑定，合法处理因素仍可变化。
- [ ] 旧252/108 raw逐字保留；没有新生成回答替代旧失败。
- [ ] 36 TAF原回答与144 F数值不变完成离线分类；不强行归因。
- [ ] 432机会全日历完成程序对照，保留零/少正例和全部缺失。
- [ ] 没有把研究概率映射叫NWS官方概率，没有把报告区间叫物理误差界。
- [ ] 没有新GPU/付费API/训练/在线任务超出有效授权。
- [ ] NEXT_STATE.json逐项说明done、blocked、skipped、not_started及证据路径。

首批不以“模型出现正收益”验收。正确代码、可解释负结果和明确的科学缺口可以同时成立。

---

## 6. 来源定位

所有仓库路径均相对于固定提交：
`https://github.com/sisuolv/disastertrace-benchmark/tree/6c7c7e81ad88e1d3a553727607e24c858136899d`

关键文件：
- `publication/v7_adaptive_review_20260913/REVIEW_FOR_CHATGPT_PRO_CN.md`
- `publication/v7_adaptive_review_20260913/REPRODUCE_CN.md`
- `plans/v7_adaptive_execution_20260913/FINAL_REPORT_CN.md`
- `plans/v7_adaptive_execution_20260913/NEXT_EXECUTION_CN.md`
- `plans/v7_next_20260913_2/OVERALL_PLAN_CN.md`
- `monitoring_fixed_v1/{contracts,admission,adaptive,heads,taf_tasks,support_bridge,representations}.py`（完整前缀为`disastertrace-starter/src/disastertrace/`）
- `monitoring_v1/{event_loop,session_checkpoint,policies,reachability}.py`（同上）

当前查证的主要外部资料（不等于本次完成代码复现）：
- AFABench v3，https://arxiv.org/abs/2508.14734
- EarthVerse，https://arxiv.org/abs/2608.23525
- Extreme Weather Bench，https://arxiv.org/abs/2605.01126

本计划强调的区分不是“首个主动获取/首个online灾害benchmark”，而是v7已定义的：
**C1 共享资源下的真实增量；C2 合法证据支持与联合可达性；C3 经过准入的跨过程可复现性。**
