def execute(self, opportunity, call_id, started, store, ledger, source_receipts, backend):
    bundle = self.freeze_acquired(opportunity, started, store, ledger, source_receipts)
    head = "program" if backend is None else self.config.get("typed_head", "joint")
    executor = (
        "frozen_frequency.v1"
        if backend is None
        else self.config.get("executor_id", "typed_backend.v1")
    )
    self.run(
        [
            AdmissionEvent(
                call_id + "-begin",
                started,
                "begin",
                {
                    "call_id": call_id,
                    "bundle": bundle.to_dict(),
                    "head": head,
                    "executor": executor,
                },
            )
        ],
        until=started,
    )
    if call_id not in self.calls:
        raise ValueError("Controller produced an inadmissible typed begin")
    if backend is None:
        raw = canonical(FrozenFrequencyPredictor(self.bank).predict(bundle).to_dict())
        details = {
            "input_tokens": 0,
            "output_tokens": 0,
            "seconds": 0.001,
            "ended_with_eos": True,
            "backend": executor,
            "timing_basis": "declared_program_latency_scenario",
        }
    else:
        messages = model_messages(bundle, head)
        raw, details = backend(messages[0]["content"], bundle.policy_view(), call_id)
    duration = max(1, math.ceil(details["seconds"] * 1_000_000))
    persistence = self.config.get("persistence_latency_ms", 1) * 1000
    elapsed = duration + persistence
    if self.config.get("isolation_mode") == "public_schedule":
        elapsed = self.config["public_call_slot_ms"] * 1000
        if duration + persistence > elapsed:
            raise ValueError("Actual call and persistence exceed the public isolation slot")
    completed, persisted = started + duration, started + elapsed
    actual = Cost(
        tokens=details["input_tokens"] + details["output_tokens"],
        compute_ms=math.ceil(duration / 1000),
    )
    error, forecast, status_e = None, None, None
    try:
        if head == "program":
            forecast = Forecast(**json.loads(raw))
        else:
            answer = parse_response(raw, bundle, head)
            forecast, status_e = answer.forecast, answer.e_status
        if details.get("ended_with_eos") is not True:
            raise ValueError("Response unfinished")
    except (ValueError, TypeError, OverflowError) as exc:
        error = str(exc)
    ledger.settle(call_id, actual, outcome="completed" if error is None else "invalid_response")
    receipt = {
        "call_id": call_id,
        "bundle_hash": bundle.bundle_hash,
        "raw": raw,
        "raw_sha256": hashlib.sha256(raw.encode()).hexdigest(),
        "started_at": started,
        "completed_at": completed,
        "persisted_at": persisted,
        "expires_at": max(
            o["cutoff"]
            for o in self.opportunities.values()
            if o["target_id"] == opportunity["target_id"]
        ),
        "cost": asdict(actual),
        "ended_with_eos": details.get("ended_with_eos", False),
        "head": head,
        "executor": executor,
    }
    self.run(
        [AdmissionEvent(call_id + "-complete", persisted, "completion", receipt)],
        until=persisted,
    )
    admission = next(
        a for a in reversed(self.attempts) if a.get("event_id") == call_id + "-complete"
    )
    record = {
        "call_id": call_id,
        "opportunity_id": opportunity["opportunity_id"],
        "head": head,
        "started_at": started,
        "completed_at": completed,
        "persisted_at": persisted,
        "bundle": bundle.to_dict(),
        "receipt": receipt,
        "expected_e_from_disclosed_products": native_slot_support(bundle, at=started)["status"],
        "reported_e": status_e,
        "decision": "E_only" if head == "e_only" else "override",
        "proposed_probability": None if forecast is None else forecast.value,
        "response_error": error,
        "admission_status": admission["status"],
        "evidence_query_ids": sorted(
            a["content"]["query_id"] for a in bundle.policy_view()["assets"]
        ),
        "details": details,
        "raw": raw,
    }
    return record, persisted
