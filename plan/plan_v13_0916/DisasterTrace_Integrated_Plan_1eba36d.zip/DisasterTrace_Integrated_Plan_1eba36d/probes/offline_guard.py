import socket, urllib.request, runpy, sys
from pathlib import Path
def denied(*a,**k):
    raise RuntimeError("Network disabled during isolated review probes")
socket.socket.connect=denied
socket.socket.connect_ex=denied
socket.create_connection=denied
urllib.request.urlopen=denied
script=str(Path(sys.argv[1]).resolve())
sys.argv=[script]
runpy.run_path(script,run_name="__main__")
