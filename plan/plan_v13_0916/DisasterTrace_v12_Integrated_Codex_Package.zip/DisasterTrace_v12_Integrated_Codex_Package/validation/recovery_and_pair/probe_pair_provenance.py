"""Offline probe of the exact paired() function excerpt from analyze_stage_c.py.

This is NOT a full repository test. No weather data, network, model, or paid
resources are used. The excerpt below was read at commit 1eba36dd272c72573d1309c78d45dbe97dd8af12.
"""
import itertools
import json
import math
from pathlib import Path


def paired(rows, reference, candidate):
    selected = [r for r in rows if reference in r["probabilities"] and candidate in r["probabilities"]]
    settled = [r for r in selected if r["settled"]]
    missing = [r for r in selected if not r["settled"]]
    deltas = [(r["probabilities"][reference]-r["y"])**2 - (r["probabilities"][candidate]-r["y"])**2 for r in settled]
    unknown = []
    for r in missing:
        a, b = r["probabilities"][reference], r["probabilities"][candidate]
        alternatives = [a*a-b*b, (1-a)**2-(1-b)**2]
        unknown.append((min(alternatives), max(alternatives)))
    known = math.fsum(deltas)
    return {"reference": reference, "candidate": candidate, "registered": len(selected),
        "settled": len(settled), "missing": len(missing),
        "positive": sum(r["y"] for r in settled),
        "positive_delta_favors": candidate,
        "mean_brier_improvement": known/len(settled) if settled else None,
        "positive_contribution_per_settled_opportunity": math.fsum(d for r,d in zip(settled,deltas) if r["y"]==1)/len(settled) if settled else None,
        "negative_contribution_per_settled_opportunity": math.fsum(d for r,d in zip(settled,deltas) if r["y"]==0)/len(settled) if settled else None,
        "prediction_specific_missing_Y_bounds": [(known+math.fsum(x[i] for x in unknown))/len(selected) for i in (0,1)] if selected else None,
        "bounds_are_confidence_intervals": False,
        "bank_difference_involved": (reference=="F_COMMON") != (candidate=="F_COMMON"),
        "interpretation": "descriptive exposed development; calendar blocks are not independent-process confirmation"}


def main():
    rows = [
        {"settled": True, "y": 1, "probabilities": {"FOLLOW": .2, "F_COMMON": .3, "F_BASE_ONLY": .4, "LLM_SELECTOR": .45}},
        {"settled": False, "y": None, "probabilities": {"FOLLOW": .1, "F_COMMON": .12, "F_BASE_ONLY": .13, "LLM_SELECTOR": .2}},
        {"settled": False, "y": None, "probabilities": {"FOLLOW": .6, "F_COMMON": .4, "F_BASE_ONLY": .5, "LLM_SELECTOR": .3}},
    ]
    examples = [paired(rows, x, "LLM_SELECTOR") for x in ("FOLLOW", "F_COMMON", "F_BASE_ONLY")]
    bounds_tests = []
    for item in examples:
        a, b = item["reference"], item["candidate"]
        totals = []
        for completion in itertools.product((0, 1), repeat=2):
            ys = (1, *completion)
            totals.append(math.fsum((r["probabilities"][a]-y)**2-(r["probabilities"][b]-y)**2 for r,y in zip(rows, ys))/len(rows))
        direct = [min(totals), max(totals)]
        reported = item["prediction_specific_missing_Y_bounds"]
        bounds_tests.append({"reference": a, "enumerated": direct, "reported": reported,
            "matches": all(math.isclose(x,y,abs_tol=1e-14) for x,y in zip(direct,reported))})
    result = {
        "scope": "isolated exact function excerpt, synthetic rows; not complete production execution",
        "source_commit": "1eba36dd272c72573d1309c78d45dbe97dd8af12",
        "source_path": "plans/v12_execution_20260915_01/analyze_stage_c.py",
        "network_calls": 0, "model_calls": 0, "weather_experiments": 0,
        "provenance_flags": [{"reference": r["reference"], "candidate": r["candidate"], "bank_difference_involved": r["bank_difference_involved"]} for r in examples],
        "finding": "FOLLOW vs LLM_SELECTOR is labelled as no bank difference. This flag does not encode the actual FOLLOW mapping versus native values consumer; numerical losses are unchanged.",
        "missing_bounds_control_tests": bounds_tests,
        "joint_label_scope": "Independent missing binary targets only; shared or nested labels need joint constraints."
    }
    assert all(x["matches"] for x in bounds_tests)
    (Path(__file__).parent / "PAIR_PROBE_RESULT.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    main()
