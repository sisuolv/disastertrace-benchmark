"""Offline boundary probe on two Git-blob-verified upstream source files.
The base committed-spool transport and atomic JSON publisher are isolated test doubles.
No real API, cloud task, production directory, or weather data is used.
This does not claim a full monitoring regression or distributed recovery test.
"""
from pathlib import Path
import hashlib, importlib.util, json, sys, tempfile, time, types

ROOT = Path(__file__).resolve().parent
EXPECTED_BLOBS = {
    "siliconflow_worker.py": "7d2efb6dce9d35f2904c454ab44098bd51e6d9ff",
    "production.py": "cb5a8c7897bd2e08432e48498b151bc54f52d50b",
}
for filename, expected in EXPECTED_BLOBS.items():
    body = (ROOT / filename).read_bytes()
    actual = hashlib.sha1(b"blob " + str(len(body)).encode() + b"\0" + body).hexdigest()
    if actual != expected:
        raise RuntimeError(f"Upstream source blob mismatch: {filename}")

def read(path):
    return json.loads(Path(path).read_text())

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def canonical_hash(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,allow_nan=False).encode()).hexdigest()

def publish(path, value):
    # An exclusive immutable local publisher, deliberately simpler than the real filesystem layer.
    with Path(path).open('x') as f:
        json.dump(value,f,sort_keys=True,allow_nan=False)

class CommittedSpoolDouble:
    def __init__(self,directory,execution_contract,*,run_id):
        self.directory = Path(directory)
        self.run_id = run_id
        self.execution_contract = execution_contract
    def _key(self, call_id):
        return 'call-' + call_id
    def claim_ready(self,call_id,*,worker_id):
        key=self._key(call_id)
        publish(self.directory/(key+'.claim.json'),{'worker':worker_id})
        return read(self.directory/(key+'.request.json'))
    def resolve(self,ticket,call_id):
        return read(self.directory/(self._key(call_id)+'.response.json'))

for name in ('disastertrace','disastertrace.monitoring_v1'):
    m=types.ModuleType(name);m.__path__=[];sys.modules[name]=m
spool=types.ModuleType('disastertrace.monitoring_v1.spool_backend')
spool.read=read;spool.digest=digest;spool.publish=publish;spool.CommittedSpoolBackend=CommittedSpoolDouble
sys.modules[spool.__name__]=spool
target=types.ModuleType('disastertrace.monitoring_v1.targets');target.canonical_hash=canonical_hash
sys.modules[target.__name__]=target

def load(name,file):
    spec=importlib.util.spec_from_file_location(name,ROOT/file)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
    return mod
worker=load('upstream_siliconflow_worker','siliconflow_worker.py')
production=load('disastertrace.monitoring_v1.production','production.py')

results=[]
for inject in (False,True):
    with tempfile.TemporaryDirectory(prefix='dt-recovery-') as tmp:
        directory=Path(tmp)
        backend=production.ProductionSpoolBackend(directory,{'model':'test-model'},run_id='offline-probe',
             bound_files={str(ROOT/'production.py'):digest(ROOT/'production.py'),str(ROOT/'siliconflow_worker.py'):digest(ROOT/'siliconflow_worker.py')})
        cid='select-0';key=backend._key(cid)
        request={'messages':[{'role':'system','content':'Return JSON only.'}], 'execution_sha256':'test-execution'}
        rp=directory/(key+'.request.json');publish(rp,request)
        policy={'allowed_call_ids':[cid],'deadline_wall_ns':time.time_ns()+120_000_000_000,
                'model':'test-model','input_cap':32768,'output_cap':512}
        count=[0];fault=[False]
        def send(payload,policy):
            count[0]+=1
            body=json.dumps({'model':'test-model','usage':{'prompt_tokens':100,'completion_tokens':10},
                'choices':[{'message':{'content':'{"query_order": [], "forecast_handles": []}'},'finish_reason':'stop'}]}).encode()
            return 200,body,hashlib.sha256(body).hexdigest(),False
        def fault_publish(path,value):
            if inject and str(path).endswith('.response.json') and not fault[0]:
                fault[0]=True
                raise OSError('injected response publication failure after durable capture')
            return publish(path,value)
        worker.publish=fault_publish
        original_error=None
        try:
            worker.deliver(backend,cid,policy,send=send)
        except OSError as e:
            original_error=str(e)
        worker.publish=publish
        if inject:
            assert (directory/(key+'.api_capture.json')).exists()
            assert (directory/(key+'.failure.json')).exists()
            worker.reconcile_capture(backend,cid,policy)
        ticket={'remote_id':key,'request_sha256':digest(rp)}
        error=None
        try:
            backend.resolve(ticket,cid)
            resolved=True
        except RuntimeError as e:
            resolved=False;error=str(e)
        result={'fault_injected':inject,'transport_send_count':count[0],
            'original_publication_error':original_error,
            'response_exists':(directory/(key+'.response.json')).exists(),
            'failure_receipt_preserved':(directory/(key+'.failure.json')).exists(),
            'resolve_succeeded':resolved,'resolve_error':error}
        assert count[0]==1
        assert resolved is (not inject)
        results.append(result)
output={'scope':'isolated upstream function boundary; base spool and JSON publisher are test doubles',
        'network_calls':0,'new_weather_experiments':0,'production_files_modified':False,
        'source_manifest':read(ROOT/'SOURCE_MATCHES.json'),'cases':results,
        'finding':'A durable successful response can be reconstructed, but an existing failure marker still unconditionally blocks ProductionSpoolBackend.resolve.'}
(ROOT/'RECOVERY_PROBE_RESULT.json').write_text(json.dumps(output,indent=2))
print(json.dumps(output,indent=2))
