import sys,runpy,json,atexit
from pathlib import Path
blocked=[]
def guard(event,args):
 if event in {"socket.connect","socket.connect_ex","socket.getaddrinfo","socket.sendto","socket.sendmsg"}:
  blocked.append(event);raise RuntimeError("Network disabled for local review probes")
sys.addaudithook(guard)
p=Path(sys.argv[1]).resolve();sys.argv=[str(p)]+sys.argv[2:]
@atexit.register
def receipt():
 p.with_name(p.stem+".network_guard.json").write_text(json.dumps({"network_guard_enabled":True,"blocked_network_attempts":blocked,"scope":"Python audit events for connection/DNS/datagram operations; not an operating-system sandbox"},indent=2))
runpy.run_path(str(p),run_name="__main__")
