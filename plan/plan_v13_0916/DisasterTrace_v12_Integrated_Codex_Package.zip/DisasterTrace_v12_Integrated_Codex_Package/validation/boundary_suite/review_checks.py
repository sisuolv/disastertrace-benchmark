"""Offline review probes. No HTTP, paid model calls, or repository writes.
Real source functions run against temporary files; spool/backend/clock are test doubles.
Exit success means observations reproduced, NOT that all implementation properties passed.
"""
import argparse, contextlib, hashlib, importlib.util, io, json, sys, tempfile, types
from pathlib import Path

BASE=Path(__file__).resolve().parent
COMMIT='1eba36dd272c72573d1309c78d45dbe97dd8af12'
SOURCES={
 'siliconflow_worker.py':('plans/v12_execution_20260915_01/siliconflow_worker.py','7d2efb6dce9d35f2904c454ab44098bd51e6d9ff'),
 'analyze_branches.py':('plans/v12_execution_20260915_01/analyze_branches.py','dffffd3440ab1f6363c3f042759b78118898ec0e'),
 'selection.py':('disastertrace-starter/src/disastertrace/monitoring_v1/selection.py','74f24e9e484e76c350334b55b8dbad2d1efe0c6c'),
 'common.py':('disastertrace-starter/src/disastertrace/forecast_task/common.py','31ed9e5f3cceabda9d9553b28be89ed1858bfc9f'),
}
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def load(name,file):
 spec=importlib.util.spec_from_file_location(name,BASE/'sources'/file)
 m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
for p in ['disastertrace','disastertrace.monitoring_v1','disastertrace.forecast_task']:
 m=types.ModuleType(p);m.__path__=[];sys.modules[p]=m
common=load('disastertrace.forecast_task.common','common.py')
spool=types.ModuleType('disastertrace.monitoring_v1.spool_backend')
spool.read=common.read;spool.publish=common.write;spool.digest=common.digest
sys.modules[spool.__name__]=spool
results=[]
def record(name,category,actual,expected):
 assert actual==expected,(name,actual,expected)
 results.append({'id':name,'category':category,'observation':actual,'expected_observation':expected,'observation_reproduced':True})

def selection_tests():
 m=load('disastertrace.monitoring_v1.selection','selection.py')
 args=dict(query_handles=['q0','q1','q2'],target_handles=['t0','t1'],forecast_cap=1)
 good={'query_order':[],'forecast_handles':[]}
 cases=[
 ('empty',json.dumps(good),True),
 ('all',json.dumps({**good,'query_order':['q0','q1','q2']}),True),
 ('subset',json.dumps({**good,'query_order':['q1']}),True),
 ('reordered',json.dumps({**good,'query_order':['q2','q0']}),True),
 ('whole_fence','```json\n'+json.dumps(good)+'\n```',True),
 ('wrong_alias',json.dumps({'queries':[],'forecast_handles':[]}),False),
 ('extra_field',json.dumps({**good,'why':'x'}),False),
 ('duplicate_handle',json.dumps({**good,'query_order':['q0','q0']}),False),
 ('unknown_handle',json.dumps({**good,'query_order':['future']}),False),
 ('forecast_cap',json.dumps({**good,'forecast_handles':['t0','t1']}),False),
 ('non_json','Here is my answer: '+json.dumps(good),False),
 ('duplicate_key','{"query_order":[],"query_order":["q1"],"forecast_handles":[]}',False),
 ]
 for name,raw,expected in cases:
  try:m.parse_selection(raw,**args);accepted=True
  except ValueError:accepted=False
  record('selector_'+name,'normal_or_guard',{'accepted':accepted},{'accepted':expected})

class Clock:
 def __init__(self):self.now=1_000_000_000
 def time_ns(self):return self.now
class Backend:
 def __init__(self,folder,clock,jump=False):
  self.directory=folder;self.clock=clock;self.jump=jump;self.claims=0
  self.request={'messages':[{'role':'user','content':'Use the public catalog.'}],'execution_sha256':'fixture-execution'}
  common.write(folder/'r.request.json',self.request)
 def _key(self,c):return 'r'
 def claim_ready(self,c,worker_id):
  if self.claims:raise ValueError('test-double already claimed')
  self.claims+=1
  if self.jump:self.clock.now=4_000_000_000
  return self.request
class Response:
 def __init__(self,body,status=200):self.body=body;self.status=status
 def __enter__(self):return self
 def __exit__(self,*a):pass
 def read(self,n):return self.body[:n]
def response_body(model='fixture-model',pi=10,po=3,extra=None):
 d={'model':model,'usage':{'prompt_tokens':pi,'completion_tokens':po},
 'choices':[{'message':{'content':'{"query_order":[],"forecast_handles":[]}'},'finish_reason':'stop'}]}
 if extra:d.update(extra)
 return json.dumps(d).encode()

def worker_case(mode):
 m=load('worker_'+mode,'siliconflow_worker.py');clock=Clock();m.time=clock
 with tempfile.TemporaryDirectory() as td:
  root=Path(td);backend=Backend(root,clock,jump=(mode=='expires_during_claim'))
  credential=root/'credential.json';key='OFFLINE_FIXTURE_KEY_'+('x'*150)
  common.write(credential,{'base_url':'https://offline.invalid/v1','api_key':key})
  policy={'model':'fixture-model','allowed_call_ids':['select-0'],'deadline_wall_ns':3_000_000_000,
          'input_cap':5000,'output_cap':32,'credential_path':str(credential),'base_url':'https://offline.invalid/v1'}
  if mode=='expired_entry':clock.now=4_000_000_000
  request_id='unknown' if mode=='unknown_call' else 'select-0'
  status=429 if mode=='http_error' else 200
  body=response_body(model='wrong-model' if mode=='wrong_model' else 'fixture-model',po=33 if mode=='token_overrun' else 3)
  if mode in ('truncated_body','redacted_truncated_body'):
   body=response_body(extra={'diagnostic':key if mode=='redacted_truncated_body' else 'x'})
   body+=b' '*(4_000_100-len(body))
  calls=[]
  def fake_open(req,timeout):calls.append({'sent_at':clock.now});return Response(body,status)
  m.urlopen=fake_open
  if mode=='expires_during_credential':
   real_read=m.read
   def read(p):
    v=real_read(p)
    if Path(p)==credential:clock.now=4_000_000_000
    return v
   m.read=read
  error=None;answer=None
  try:answer=m.deliver(backend,request_id,policy)
  except Exception as exc:error=type(exc).__name__
  out={'http_calls':len(calls),'accepted':answer is not None,'failure_receipt':(root/'r.failure.json').exists()}
  if calls:out['sent_at_ns']=calls[0]['sent_at']
  cap=root/'r.api_capture.json'
  if cap.exists():out['capture_complete']=common.read(cap)['complete']
  if mode=='reconcile_twice':
   second=m.reconcile_capture(backend,request_id,policy)
   out['same_response']=second==answer;out['http_calls_after_reconcile']=len(calls)
  if mode in ('truncated_body','redacted_truncated_body'):
   out['original_response_bytes']=len(body);out['transport_limit']=4_000_001
  return out

def worker_tests():
 normal={'http_calls':1,'accepted':True,'failure_receipt':False,'sent_at_ns':1_000_000_000,'capture_complete':True}
 for name in ['normal','expired_entry','unknown_call','expires_during_claim','expires_during_credential',
              'http_error','wrong_model','token_overrun','reconcile_twice','truncated_body','redacted_truncated_body']:
  expected=dict(normal)
  category='normal_or_guard'
  if name in ('expired_entry','unknown_call'):expected={'http_calls':0,'accepted':False,'failure_receipt':False}
  elif name in ('expires_during_claim','expires_during_credential'):
   expected['sent_at_ns']=4_000_000_000;category='counterexample_dispatch_deadline'
  elif name in ('http_error','wrong_model','token_overrun'):expected.update(accepted=False,failure_receipt=True)
  elif name=='reconcile_twice':expected.update(same_response=True,http_calls_after_reconcile=1)
  elif name=='truncated_body':expected.update(accepted=False,failure_receipt=True,capture_complete=False,original_response_bytes=4_000_100,transport_limit=4_000_001)
  elif name=='redacted_truncated_body':
   expected.update(original_response_bytes=4_000_100,transport_limit=4_000_001);category='counterexample_redacted_length'
  record('worker_'+name,category,worker_case(name),expected)

def branch_case(missing='none'):
 m=load('branches_'+missing,'analyze_branches.py')
 with tempfile.TemporaryDirectory() as td:
  root=Path(td)/'run';root.mkdir();repo=Path(td)/'repo';repo.mkdir();m.ROOT=root;m.REPO=repo
  rules=['no_further_paid_query','first','second','all'];parents=[]
  common.write(root/'C2_BRANCH_EXECUTION_RESULT.json',{'passed':True,'actual_treatment_attempts':24})
  for idx in range(6):
   name=f'p{idx}';oid='o1';folder=root/'branches'/name;folder.mkdir(parents=True)
   parents.append({'parent':{'case':name,'directory':f'{name}/parent','opportunity_id':oid},'U_parent':[oid]})
   common.write(repo/name/'OUTCOMES.json',[{'opportunity_id':oid,'status':'mature','value':0}])
   common.write(folder/'RESULT.json',{'results':[{'rule':r,'status':'completed','passed':True} for r in rules], 'shared_wakeup_equal':True})
   common.write(root/'parents'/name/'PARENT_CHECKPOINT.json',{'payload':{'ledger':{'spent':{'requests':0}}}})
   for j,rule in enumerate(rules):
    d=folder/rule;d.mkdir()
    report={'snapshots':[{'opportunity_id':oid,'forecast':{'value':0.2+0.01*j}}],
        'calls':[{'opportunity_id':oid,'admission_status':'accepted','adoption_decision':'override'}],
        'frames':[{'e_statuses':{oid:'refuted'}}],'resource_spent':{'requests':j}}
    if missing=='missing_opportunity' and idx==0 and rule=='first':report['snapshots']=[]
    if not (missing=='all_reports' or (missing=='one_report' and idx==0 and rule=='first')):
     common.write(d/'FORMAL_REPORT.json',report)
    trace=[{'opportunity_id':oid,'baseline_sha256':'B','started_at':1,
            'claims_sha256':str(j),'features_sha256':str(j),'proposed_probability':0.2+0.01*j}]
    if missing=='one_trace_row' and idx==0 and rule=='first':trace=[]
    common.write(d/'FIELD_FEATURE_TRACE.json',trace)
    common.write(d/'ACTION_TRACE.json',{'dispositions':[]})
  common.write(root/'C2_BRANCH_ROSTER.json',{'parents':parents})
  exc=None
  try:
   with contextlib.redirect_stdout(io.StringIO()):m.main()
  except Exception as error:exc=type(error).__name__
  p=root/'C2_ENGINEERING_RESULT.json'
  if not p.exists():return {'result_written':False,'exception':exc}
  r=common.read(p)
  return {'result_written':True,'passed':r['passed'],'formal_scored_parents':r['formal_scored_parents'],
          'comparisons':r['comparisons'],'actual_treatment_attempts':r['actual_treatment_attempts'],
          'feature_trace_rows':sum(f['trace'] is not None for f in common.read(root/'C2_FIELD_TO_LOSS.json'))}

def branch_tests():
 normal={'result_written':True,'passed':True,'formal_scored_parents':6,'comparisons':36,'actual_treatment_attempts':24,'feature_trace_rows':24}
 for mode in ['none','one_report','all_reports','missing_opportunity','one_trace_row']:
  expected=dict(normal);category='normal_or_guard'
  if mode=='one_report':expected.update(comparisons=33,feature_trace_rows=23);category='counterexample_diagnostic_completeness'
  if mode=='all_reports':expected.update(comparisons=0,feature_trace_rows=0);category='counterexample_diagnostic_completeness'
  if mode=='missing_opportunity':expected={'result_written':False,'exception':'ValueError'}
  if mode=='one_trace_row':expected['feature_trace_rows']=23;category='counterexample_diagnostic_trace_coverage'
  record('branch_'+mode,category,branch_case(mode),expected)

def main():
 p=argparse.ArgumentParser();p.add_argument('--checkout',type=Path);p.add_argument('--output',type=Path,default=BASE/'review_results.json');args=p.parse_args()
 verified=[]
 for name,(path,sha) in SOURCES.items():
  data=(BASE/'sources'/name).read_bytes();assert blob(data)==sha,(name,blob(data))
  row={'local':name,'repository_path':path,'git_blob_sha1':sha,'bytes':len(data),'verified_against_connector_sha':True}
  if args.checkout:
   other=args.checkout/path;row['checkout_matches']=other.exists() and blob(other.read_bytes())==sha
   if not row['checkout_matches']:raise ValueError(f'Checkout differs: {path}; review current version before running')
  verified.append(row)
 selection_tests();worker_tests();branch_tests()
 result={'commit':COMMIT,'scope':'isolated current-source tests; actual filesystem; stub spool IO/backend/clock/HTTP; synthetic journals/reports, no real experiment rerun',
         'no_actual_http_or_model_calls':True,'source_files':verified,'checks':results,'distinct_checks':len(results),
         'normal_or_guard_count':sum(x['category']=='normal_or_guard' for x in results),
         'counterexample_count':sum(x['category']!='normal_or_guard' for x in results),
         'observations_reproduced':all(x['observation_reproduced'] for x in results)}
 args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ('source_files','checks')},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
