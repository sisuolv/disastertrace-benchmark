# v8 latest review and Codex plan

Fixed commit: 5ed0fb94ae7bf235b37e7528e201b603271edffa.

Read IMPLEMENTATION_REVIEW_CN.md and CODEX_V8_FOLLOWUP_PLAN_CN.md; task dependencies are in CODEX_WORK_ITEMS.json.

Run `PYTHONDONTWRITEBYTECODE=1 python reviewer_checks.py` for the reviewer-created 37 CPU checks and four boundary probes. No network, models, GPU, API keys, or remote writes are used. This is NOT the repository's 502-test suite, nor full journal replay.

Five source modules are byte-for-byte bound to Git blobs in SOURCE_BINDINGS.json. Package __init__.py files are local test scaffolding. The old contracts source is reused only because the current Git blob is unchanged. No temporary access tokens are included.

outcomes_export_isolation.patch is a minimal proposed fix, not applied to the user's repository. Codex should reproduce on actual current source and inspect call sites before deciding whether historical outputs were affected. Nothing here establishes corruption of published scores.

可选：`PYTHONDONTWRITEBYTECODE=1 python validate_proposed_fix.py` 对提议补丁运行5项隔离检查，未修改code内原源码。
