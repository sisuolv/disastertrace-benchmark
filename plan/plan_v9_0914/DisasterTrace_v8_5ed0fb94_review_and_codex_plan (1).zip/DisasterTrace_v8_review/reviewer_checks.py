"""Bounded CPU checks of exact pinned sources; not the repository's 502-test suite."""
from __future__ import annotations
import sys, json, hashlib
from pathlib import Path
from dataclasses import dataclass, asdict
from types import SimpleNamespace
from copy import deepcopy
sys.path.insert(0, str(Path(__file__).parent/'code'))
from disastertrace.monitoring_fixed_v1.contracts import Target,Forecast,ForecastState,paired_scores
from disastertrace.monitoring_fixed_v1.outcomes import OutcomeRegistry,ComparisonContract
from disastertrace.monitoring_v1.providers.versions import current_taf,latest_issuance
from disastertrace.monitoring_v1.event_loop import run_clock

results=[]
def check(name,fn):
    try:
        fn(); results.append({'name':name,'passed':True})
    except Exception as e:
        results.append({'name':name,'passed':False,'type':type(e).__name__,'error':str(e)})
def equal(a,b):
    assert a==b,(a,b)
def rejects(fn,typ=ValueError):
    try: fn()
    except typ: return
    raise AssertionError('Expected rejection')
def target(tid='t',**kw):
    d=dict(target_id=tid,entity='station:X',variable='visibility',units='m',output_kind='event_probability',support_kind='interval',physical_start=1000,physical_end=2000,temporal_semantics='future_physical',report_policy='review.synthetic',event_operator='lt',threshold=1000)
    d.update(kw); return Target(**d)
def record(t,**kw):
    d=dict(target_contract_hash=t.contract_hash,resolution_version='r1',value=1,status='mature',source_revision='s1',source_sha256='a'*64,physical_start=t.physical_start,physical_end=t.physical_end,units=t.units,quality_status='source_checked',observed_at=2000,published_at=2100,fetched_at=2200,resolved_at=2300,availability_basis='declared_archive_scenario',references=[{'asset':'a'}])
    d.update(kw); return d

def product(sid,issued=10,meaning='same',status='active',start=0,end=300,station='X'):
    return dict(station=station,source_id=sid,issued_at=issued,native_semantics_sha256=meaning,status=status,valid_start=start,valid_end=end)
def choose(rows,**kw):
    d=dict(station='X',cutoff=100,start=110,end=120,lag_us=0);d.update(kw);return current_taf(rows,**d)

check('version_latest_not_arrival',lambda:equal(choose([product('new',20),product('old',10)])['selected_id'],'new'))
check('version_latest_order_reverse',lambda:equal(choose([product('old',10),product('new',20)])['selected_id'],'new'))
check('version_future_unavailable',lambda:equal(choose([product('future',101),product('old',10)])['selected_id'],'old'))
check('version_lag_enforced',lambda:equal(choose([product('x',95)],lag_us=10)['status'],'no_product'))
check('version_exact_availability',lambda:equal(choose([product('x',90)],lag_us=10)['status'],'active'))
check('version_noncover_does_not_revive_old',lambda:equal(choose([product('old',10),product('new',20,end=115)])['status'],'current_version_does_not_cover_target'))
check('version_cancel_does_not_revive_old',lambda:equal(choose([product('old'),product('cancel',20,status='canceled',start=None,end=None)])['status'],'canceled'))
check('version_nil_does_not_revive_old',lambda:equal(choose([product('old'),product('nil',20,status='nil',start=None,end=None)])['status'],'nil'))
check('version_conflict',lambda:equal(choose([product('a',20,'A'),product('b',20,'B')])['status'],'conflict'))
check('version_conflict_rename_invariance',lambda:equal(choose([product('z',20,'A'),product('a',20,'B')])['status'],'conflict'))
check('version_equivalent_mirrors_retained',lambda:equal(choose([product('z',20),product('a',20)])['source_ids'],['a','z']))
check('version_station_isolation',lambda:equal(choose([product('wrong',30,station='Y'),product('right',20)])['selected_id'],'right'))
check('version_boolean_issue_rejected',lambda:rejects(lambda:latest_issuance([{'issued_at':True}])) )
t=target()
check('target_hash_ignores_display_id',lambda:equal(t.contract_hash,target('alias').contract_hash))
check('target_hash_binds_physical_window',lambda:equal(t.contract_hash!=target(physical_end=2001).contract_hash,True))
check('target_cutoff_before',lambda:t.check_cutoff(999))
check('target_cutoff_at_start_rejected',lambda:rejects(lambda:t.check_cutoff(1000)))
check('forecast_boolean_rejected',lambda:rejects(lambda:Forecast(t.contract_hash,'event_probability','probability',True)))
check('forecast_nan_rejected',lambda:rejects(lambda:Forecast(t.contract_hash,'event_probability','probability',float('nan'))))
check('forecast_out_of_range_rejected',lambda:rejects(lambda:Forecast(t.contract_hash,'event_probability','probability',1.1)))

def registry_idempotent():
    r=OutcomeRegistry([t]); x=record(t);equal(r.register(x),True);equal(r.register(x),False)
check('outcome_idempotent',registry_idempotent)
def registry_conflict():
    r=OutcomeRegistry([t]);r.register(record(t));rejects(lambda:r.register(record(t,value=0)))
check('outcome_conflict_rejected',registry_conflict)
check('outcome_unit_mismatch_rejected',lambda:rejects(lambda:OutcomeRegistry([t]).register(record(t,units='km'))))
check('outcome_invalid_hash_rejected',lambda:rejects(lambda:OutcomeRegistry([t]).register(record(t,source_sha256='bad'))))
check('outcome_resolution_before_acquisition_rejected',lambda:rejects(lambda:OutcomeRegistry([t]).register(record(t,resolved_at=1))))
def input_copy():
    r=OutcomeRegistry([t]); x=record(t);r.register(x);x['value']=0;equal(r.records[t.contract_hash,'r1']['value'],1)
check('outcome_register_copies_input',input_copy)
def lead_versions():
    r=OutcomeRegistry([t]);r.register(record(t));r.register(record(t,resolution_version='r2'))
    ops=[SimpleNamespace(opportunity_id='a',target=t),SimpleNamespace(opportunity_id='b',target=t)]
    rejects(lambda:r.opportunity_rows(ops,{'a':'r1','b':'r2'}))
check('outcome_mixed_resolution_versions_rejected',lead_versions)
def scoring_mask():
    ops=[{'opportunity_id':'a','target':t.to_dict(),'outcome':1},{'opportunity_id':'b','target':t.to_dict(),'outcome':None}]
    f=Forecast(t.contract_hash,'event_probability','probability',.2).to_dict()
    s=paired_scores(ops,{'A':{'a':f,'b':f}})
    equal((s['registered'],s['settled'],s['missing']),(2,1,1))
    rejects(lambda:paired_scores(ops,{'A':{'a':f}}))
check('score_common_missing_denominator',scoring_mask)
def protocol(p,expected):
    s=ForecastState(t,p);f=lambda v:Forecast(t.contract_hash,'event_probability','probability',v)
    s.update_baseline(f(.2),'b1',1);s.propose(f(.2),'b1',2,100);s.update_baseline(f(.8),'b2',3);equal(s.effective(3).value,expected)
check('base_bound_equal_override_still_bound',lambda:protocol('base_bound_override',.8))
check('persistent_equal_override_not_follow',lambda:protocol('persistent_override',.2))
c=ComparisonContract({'x':1},{'selector':['fixed']})
check('comparison_allows_registered',lambda:c.validate({'x':1},{'selector':'fixed'}))
check('comparison_rejects_unregistered',lambda:rejects(lambda:c.validate({'x':1},{'selector':'other'})))
check('comparison_rejects_changed_invariants',lambda:rejects(lambda:c.validate({'x':2},{'selector':'fixed'})))

@dataclass
class Event:
    event_id:str;time:int;kind:str
    def to_dict(self):return asdict(self)
class Owner:
    def __init__(self):
        self._events={};self._processed=set();self._last_time=None;self.journal=None;self.snapshots={};self.opportunities={'o':SimpleNamespace(cutoff=10,opportunity_id='o')};self.log=[]
    def _expiry_times(self,upcoming):return []
    def _process(self,e):self.log.append(e.kind)
    def _invalidate(self,t):self.log.append('invalidate')
    def _seal(self,t):
        if t==10:self.snapshots['o']=list(self.log)
    def _after_seal(self,t):self.log.append('after_seal')
def advance(o,es,until=10):return run_clock(o,es,until=until,event_order={'base':0,'complete':1,'begin':5},decode=lambda r:Event(**r))
def phase():
    o=Owner();advance(o,[Event('b',10,'begin'),Event('a',10,'complete')]);equal(o.snapshots['o'],['complete','invalidate']);equal(o.log[-1],'begin')
check('clock_completion_before_seal_begin_after',phase)
def invalid_batch():
    o=Owner();rejects(lambda:advance(o,[Event('dup',5,'base'),Event('dup',6,'base')]));equal(o._events,{})
check('clock_duplicate_batch_no_registration',invalid_batch)
def backwards():
    o=Owner();advance(o,[]);rejects(lambda:advance(o,[],9));rejects(lambda:advance(o,[Event('b',10,'base')],11))
check('clock_reversed_and_backdated_rejected',backwards)
def reentry():
    o=Owner();o._clock_running=True;rejects(lambda:advance(o,[]))
check('clock_reentry_rejected',reentry)

# Findings are probes of API boundaries, not claimed failures of published real runs.
probes=[]
r=OutcomeRegistry([t]);r.register(record(t));e=r.export();e['payload']['records'][0]['value']=0
probes.append({'name':'outcome_export_alias','observed_internal_value':r.records[t.contract_hash,'r1']['value'],'original_registered_value':1,'allows_normal_reregistration':None,'scope':'exact OutcomeRegistry export API; no existing experiment mutation established'})
try:r.register(record(t));probes[-1]['allows_normal_reregistration']=True
except ValueError:probes[-1]['allows_normal_reregistration']=False
r=OutcomeRegistry([t]);r.register(record(t));rows=r.opportunity_rows([SimpleNamespace(opportunity_id='o',target=t)],{'o':'r1'});rows[0]['references'][0]['asset']='changed'
probes.append({'name':'outcome_opportunity_nested_provenance_alias','observed_internal_asset':r.records[t.contract_hash,'r1']['references'][0]['asset'],'scope':'optional nested provenance; scalar values in returned rows are separately copied'})
c=ComparisonContract({'fixed':{'bank':'A'}},{'selector':['fixed']});exported=c.export();exported['payload']['allowed_interventions']['selector'].append('UNREGISTERED');c.validate({'fixed':{'bank':'A'}},{'selector':'UNREGISTERED'})
probes.append({'name':'comparison_export_alias','new_value_accepted_after_mutating_export':True,'scope':'contract object encapsulation; no proof published comparisons were widened'})
r=OutcomeRegistry([t]);r.register(record(t,observed_at=1,published_at=2,fetched_at=3,resolved_at=4))
probes.append({'name':'outcome_source_chronology_not_self_validating','accepted':True,'scope':'requires provider-qualified temporal policy; does not establish wrong real labels'})
root=Path(__file__).parent
summary={'commit':'5ed0fb94ae7bf235b37e7528e201b603271edffa','check_count':len(results),'passed':sum(x['passed'] for x in results),'failed':sum(not x['passed'] for x in results),'checks':results,'scope':'Reviewer-created CPU checks on 5 hash-matched source modules; synthetic event-loop owner; NOT full AdmissionEngine/502 upstream tests/GPU replay.'}
(root/'REVIEWER_TEST_RESULTS.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
(root/'BOUNDARY_PROBES.json').write_text(json.dumps(probes,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='checks'},indent=2));print(json.dumps(probes,indent=2))
assert summary['failed']==0
