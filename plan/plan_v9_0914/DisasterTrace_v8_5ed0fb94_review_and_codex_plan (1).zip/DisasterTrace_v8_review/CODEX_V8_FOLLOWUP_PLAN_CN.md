# 给 Codex 的后续执行计划：基于 5ed0fb94 的 v8 结果驱动增补

## 0. 开工基线、权限与不可破坏项

研究框架保持v8/C1/C2/C3/E/F/D/MM、W00-W19、X00-X09和16类灾害。不要新起v9、不要重建既有引擎，不按9月11日V6材料重新安排已完成模块。
参考提交 `5ed0fb94ae7bf235b37e7528e201b603271edffa`。执行时检查实际HEAD、工作区、暂存语义和上游最新报告；有更新先做差异表，不把本计划当作新代码已审查证明。
本轮用户要求审查和规划，不构成新GPU、付费API、训练、持续采集或远端推送操作授权。过去执行窗口不自动续期；未来批次绑定有效资源授权和一次性freeze。工程最多4H100是上限，不是启动命令。
保留用户未提交修改、原索引、原模型输出、失败、NOT_SUBMITTED、已消费launcher、旧概率银行和全部冻结源码。不能为了通过测试删除QC、放宽权限或回写旧标签。
不新增逐题人工Gold/人工复核，不用LLM judge作主Gold；继承已有专家标签需标注来源。无法确定来源语义就隔离，不补造。

## 1. 首先将完成状态读正确

已经完成的注册范围：W00/01/02/04/05/06/07/10，以及W12的52会话自适应批次和W13的日/三日数组结算。完成不表示所有扩展资格已达标。
W07全24h程序40轨迹、原/加速评分一致；W10两个模型1010实际调用；W12 5108调用已完成，不再执行旧P0“继续跑完”。
W08仅本地串行原source/selector/predictor恢复；W09仅3目标10见证；W12的X09本轮0调用；W13仅离线日/三日与480快照；W14物理端点、W15水文物理等价、W16完整反馈、W17确认、W18预测提交仍未全部完成。

本计划新增发现F01/F02只涉及导出对象可变引用。先检查生产模块，不假定旧分数被污染。审阅者37检查不是作者502测试的重跑。

## 2. 第一批：三个必须先做的包

### W00.sync_W19.closeout

1. 输出CURRENT_STATE_DELTA，绑定工作区文件内容而非仅HEAD；列出源码、冻结批次和数据版本。
2. 对照最新EXECUTION_STATUS与WORK_PACKAGE_PROGRESS_02，不把文档中途文字当最终状态。
3. 保留平台FAILED、worker exit=0、原auto35/52、最终补充52/52的分层事实。原自动审计不补写为成功。
4. 将推理、单会话对账、组评分、科学确认和发布状态分开。

### W01_W04.export_isolation

生产位置：`monitoring_fixed_v1/outcomes.py`。

Red用例：
- register(value=1)；修改export.records[0].value=0；内部必须仍为1。
- 修改opportunity_rows中的嵌套references；内部来源必须不变。
- 修改ComparisonContract.export的invariants或allowed_interventions；原validate不能被放宽。

当前源码在这些合成用例中存在共享引用。采用完整深复制或canonical JSON复制；顶层dict复制不足。先以独立小提交修复，原record和hash含义不变。
回归：原register输入拷贝、幂等/冲突、多提前量单结果、正式journal评分及502相同范围测试。完整fixture不在环境时如实记录未执行，不补synthetic伪装通过。
调用方影响审计：搜索所有export与opportunity_rows调用，检查是否修改嵌套结果；有旧实验影响才生成新报告，并并列原版本。
结果时间关系由provider限定：物理未来、未来产品发布、partial-window分别核验，不全局强行要求同一个observed_at不等式。

### W06_W12.visible_value_controls

第一步仅复用已完成可见值归因，别重复调用模型。分别比较candidate对dispatch latest baseline、current effective、prior admitted的精确值和说明性容差；保留一条不等current但等latest的回答。
第二步实现最小程序：
- FOLLOW：不安装候选，随合法共同基线变动。
- COPY_LATEST：返回最新基线数值，再按原typed_auto_propose安装OVERRIDE。
- COPY_CURRENT：返回当前状态数值，再按原规则安装OVERRIDE。

分别运行两种协议。scalar/probability类型不混用。当前概率等于基线不推断动作意图。

必须分开的三种比较：
1. **固定捕获输入等价**：不运行新模型；证明哪些F输出可以被简单规则产生。不是复现selector/E/整个会话。
2. **匹配访问/时序的机制回放**：固定原合法查询路径与声明的捕获耗时，换确定性输出函数；明确这是受控介入，不是实际程序耗时。
3. **程序自身成本的新闭环**：重新执行程序选择/预测，记自己真实或声明的成本；时间改变会改变看到的资料。不能把旧LLM回复搭配新较短时间伪装成新自适应会话。

比较条件保持W12内部的统一源信用、同银行/数据、同权限与阈值；不得直接将W07的72查询公共30s与W12的48查询模型实际时序归因给LLM。
主输出：same_input_equivalence、numerical_origin、control_mode、proposal/admission/effective、help/harm/no-change、源/选择/预测费用及未提交完整分母。
出口不要求LLM赢。COPY解释了全部F变化也是有效结论。

## 3. 第二批：统计基础与真实C2

### W11.regional_baselines

五份已暴露日历全部是开发材料，12528cutoff只对应2148物理窗口。Bay共享30阈值目标/68TAF的事实保留；8h已查包络不是完整purge。

建立训练/校准/开发/确认分离的区域基线方案。旧Bay银行作为明确的时间/区域迁移对照保留；新区域不直接继承其概率并声称区域校准。
最低基线：原完整专业产品B、同模型f(B)、同模型f(B,E)、冻结统计g(B)、g(B,E)、持续性/气候态。g使用相同拟合族、missing mask和age；不能新增E时顺便更换模型，然后归因信息获取。
TAF TEMPO/PROB/FM按真实目标支持保留；研究频率概率不叫官方已校准概率。

数据两集合：
- 自然连续监测日历：普通、零正例、未结算全部保留。
- 外部定义的极端/近失机制集：选择规则在模型结果前冻结；不能拿富集分布解释部署发生率。

依赖闭包包括完整TAF有效窗口、所有上游观测回看、归一化/校准来源、派生资产父节点、会话记忆/持续override、F窗口。固定24h只是候选下限，不是独立性证明；以实际闭包和天气过程保守分组，报告72h/周敏感性。
若旧data_governance只登记pair E slots→F，把其他输入依赖纳入新版本，不改历史记录。

### W09.real_joint_frontier

不重建solve_joint。从已付前缀生成 residual graph：spent/reserved、有效缓存、权限、时钟、版本、释放、执行/处理依赖、并发、截止。
- 单目标各自可达但同预算无法同时完成；
- 已支付共享资料帮助多个目标，只免其源获取成本；
- 更便宜但来不及的路径；
- 当前被替代、冲突/失效资料；
- private授权不因共享磁盘而扩大；
- 搜索截断只给可行下界/放松上界。

完整费用与最早时间必须来自同一路径或真实Pareto前沿。见证经生产引擎复放；对真实receipt和目标截止绑定。
E的联合可判定性不是F信息论可预测性、不是最优D，也不要求策略为追求E覆盖花光预算。
HEFS已有免费共同预报可确定的697事实必须零新增获取费用；付费档案只是传输诊断。

### W10_W12.partial_evidence

不要用更大模型重复整个笛卡尔积。把235B的单条2/48、完整47/48拆成支持类型：一个可见正见证、只见负/非超阈的一部分、完整反驳、删失跨阈、缺报/冲突。
比较always-unknown、严格可见产品程序和模型E；按相同天然资料构造输入子集，而不是人工给每题改Gold。所有构造规则由独立参考程序执行。
既有epoch/ISO无一致改善。新增“程序解析原生日期”必须标为计费工具条件，不暗中把解析后的参考作为原生LLM输入。
在同目标、同预测器的基础上衡量E改变是否伴随F更新；0变化允许，不强迫概率更新。

## 4. 并行工程：W03_W08有限并发，不做无限期平台项目

已经有提交式本地outbox与串行恢复。剩余是最多2个在途任务的并发资格；source和model并行、同刻TAF/完成/取消/截止、持久化与预留的原子性。
故障注入覆盖：reserve后未发送；已发送未回；已回未落盘；落盘未结算；结算未安装；安装后重复completion；截止前开始后完成。
所有恢复都绑定原request hash、backend身份、ticket、claim、首次delivery与资源账本。不因重启重置时钟或source credit。
没有外部后端幂等保证时不声称远端exactly-once；未知执行仍保留费用预留和未知状态，不能免费重新生成。
不强制等待此扩展完成才执行所有静止点/固定输入/数值研究；但不得将未资格的并发路径用于其主张。

## 5. 第二过程按当前真实进度推进

### W13：温度连续会话优先进入低成本验证

已取得的是原生六小时极值，不是瞬时采样替代。复用已有730起报/1489200数值/2920整日/2920三日/480快照，禁止重复下载后称新进度。

新步骤：
1. 基于实际起报和valid坐标建立连续公共ensemble ledger；保留00UTC与文档noon冲突及归档+3h/+4h情景身份。
2. day0不进完整未来日；day1-day4用完整四段极值；跨年参考期外10/14记录保留未结算。
3. 三日概率保持同一成员跨日路径，不乘边际；不同起报的member ID不自动视为同情景。
4. 同一物理日期不同提前量共用规范DWD结果。
5. 全51成员与完整合法专业字段作为共同基线，不能只给均值、把本来共同可见的分布信息设为付费查询。
6. 附加资料从真实截止前DWD观测、其他已核准产品中选择；同源镜像不是新增观测，事后分析不作为当时输入。
7. 先FOLLOW/COPY/冻结统计处理的CPU连续会话，再决定小型LLM资格。

最终阈值和事件身份独立冻结。22高温日期、113低于零日期、27冰日、8/10三日起点不是同数目的独立天气事件。点温度/绝对阈值先称产品定义开发任务，不直接宣称热浪或农作物霜冻。

### W14：H07/MM保留明确数据门槛

已有12小时MRMS、mm、标称1h、-1缺失/-3无覆盖的证据不重做。先证明实际每帧累积起止、是否重叠、原生valid语义、发布可用性与同目标业务预报。仅GRIB instant或S3时间不足以推断。
合法率场/累计场分别建合同。pysteps等工具输入要与其量纲、时间步和累积支持匹配；输出是预测，不是Gold。
同源原生图、合法数值特征、收费工具、特权隐藏mask分轨；新增传感器另条件。

### W15：HEFS先物理等价

43列、697共同有效时刻、2788 E状态已取得。F还需QINE成员身份、调蓄情景、断面、instant/mean、单位和目标阈值。有问题只做版本E，不把普通流量称洪水预警。
不将免费完整共同预报再次按卡片收费。

## 6. X09、D与前瞻分别验收

### W12.X09_equal_budget

旧384请求/576按条件目标回答规格还未执行；保持NOT_SUBMITTED不变。新的开发freeze应并列：
- 每请求输出上限512：三个single合计1536，joint512；可评价每次调用成本场景。
- 每组三目标总上限1536：single各512，joint1536；可更清楚比较联合答题和输出空间。
两者都单列实际token、prefill、wall time和吞吐；不能只看质量就声称纯联合推理效应。

整个上下文union、共同预报、资产、输入表示相同，只变answer_target_ids；不免费继承其他目标私有记忆。响应无效的joint保留全部3个目标分母；E-only不进F。输出三个边际不自动成为联合风险分布。
只做足以检验假设的小开发批次，不先执行所有16灾种×head×预算。

### W16：D是固定F回放之后的增量，不重做已验证部件

原24合成轨迹与12条件D已完成。新工作将decision_inputs接入SessionCoordinator反馈，固定F比D，再固定D比F。
D只读取当前admitted F，不访问future outcome；偏好改变不改天气目标hash；相同证据固定F条件下偏好不流入F。
等待/调用不暂停已开始准备，FOLLOW不撤销准备，取消不退款已耗成本，容量/有效期/清理同钟。
D_synthetic实际需求结算不是真实防灾收益，滚动两步不是全局最优。

### W18/W19

已完成4小时source-only，不能重述为实时模型预测。下一阶段只有新的有效授权与冻结下再加入预先预测提交和后续结果；主历史机制不等它。
发布等级：工程→H15开发→独立核心E/F→多过程/MM→D→前瞻→各灾种子资格。16类长期范围保留，不用全部green作为核心发表门槛。

## 7. W17确认门槛与停止规则

预留Bay2025-02-17至02-23尚未下载，继续封存至以下冻结完成：目标/资料宇宙/源资格、银行与训练校准期、模型/提示/采纳动作、预算/时钟、主比较与指标、块/Purge、缺失与失败、最小可检测效应和采样停止。
一周未暴露并不保证统计充分，独立过程数未知时不造样本量精确承诺。确认结果不用于选提示/换银行/挑样本/决定是否多跑直到显著。
主指标按物理目标及独立块聚合；多阈值/提前量/方法/头是重复条件，调用不能IID。自然集与富集集分表；正例缺失、少正例区间明确。
若COPY/强批量足够好，或额外E不改善F，保留结果并收窄贡献。benchmark准入不要求LLM正增益。

## 8. 有效交付要求与首批执行命令边界

本包提供的是规格和37个局部检查，不是能在用户服务器自动运行完全部研究的launcher。
先在新目录检查：
```bash
git rev-parse HEAD
git status --short
git diff --stat
git diff --cached --stat
```
这些只读命令不替代内容hash；不使用reset/clean/stash覆盖用户状态。

完整原测试命令以当前回执REGRESSION_MATRIX_07和各Junit记录为准；不要凭旧v7通配符声称执行了v8全部502。
本审阅包复现：
```bash
PYTHONDONTWRITEBYTECODE=1 python reviewer_checks.py
```
只运行37项自写CPU检查及4个边界探针，不连网络，不加载模型，不核全部用户资料。

每包交付：实际修改路径、RED/GREEN与失败日志、源/输入hash、运行范围、未覆盖项和下一包依赖。完成状态用新DELTA，不改原planned快照与历史freeze。
CPU审计从GPU推理解耦：单会话resume、并行评分缓存键绑定冻结源码/contract/journal/hash，并与原规范评分逐字段一致；原外层超时保留。不得仅靠缩短日志或丢prefix让审计更快。

最高优先级始终是**可解释且公平的测量**，不是多一批模型调用或再增一个数据源。

## 9. 工作包总表

| ID | 内容 | 依赖 | 执行类型 |
|---|---|---|---|
| `W00.sync_W19.closeout` | 同步当前完成状态并封存本轮证据 | 无 | cpu_readonly |
| `W01_W04.export_isolation` | 修复结果与比较合同的导出引用边界 | W00.sync_W19.closeout | cpu_code |
| `W06_W12.visible_value_controls` | 建立可见值沿用的闭环程序对照 | W01_W04.export_isolation | cpu_then_optional_bounded_model |
| `W11.regional_baselines` | 独立训练校准与自然/极端双集合 | W00.sync_W19.closeout | data_design_then_bounded_execution |
| `W09.real_joint_frontier` | 扩展真实残余图而不重建求解器 | W01_W04.export_isolation | cpu_code_and_replay |
| `W03_W08.bounded_concurrency` | 从已完成本地串行恢复扩展有限并发 | W01_W04.export_isolation | cpu_fault_injection |
| `W10_W12.partial_evidence` | 把部分证据错误升级为可检验C2实验 | W01_W04.export_isolation（新数据/联合部分另依赖） | cpu_then_bounded_model |
| `W13.continuous_temperature` | 将已有两年日/三日预报接入连续会话 | W01_W04.export_isolation | cpu_then_bounded_data |
| `W14_W15.physical_semantics` | 完成第二过程及水文各自剩余语义门槛 | W00.sync_W19.closeout | bounded_source_audit_and_cpu |
| `W12.X09_equal_budget` | 重新冻结X09同信息及双预算条件 | W01_W04.export_isolation, W06_W12.visible_value_controls | cpu_then_optional_bounded_model |
| `W16.feedback_and_W18.shadow` | D闭环与前瞻分级扩展 | W03_W08.bounded_concurrency, W06_W12.visible_value_controls | cpu_first_optional_independent_live |
| `W17_W19.confirm_and_release` | 冻结确认并持续分级交付 | W06_W12.visible_value_controls, W11.regional_baselines, W10_W12.partial_evidence | design_then_separately_authorized_confirmation |

所有产物路径均是建议新增文件，不表示已经由本次审阅生成对应研究结果。完整接受条件见 CODEX_WORK_ITEMS.json。

### 依赖的适用范围

温度CPU连续会话不等待H15区域校准。已有捕获的部分证据分析也不等待联合可达求解；只有对应子实验使用该能力时才增加依赖。前瞻设计与已获准的独立来源捕获不等待完整D。模型、校准拟合、新下载与确认仍分别遵守有效授权、数据资格和新冻结，不用放宽研究门槛换并行。
