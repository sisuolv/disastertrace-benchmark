"""Test proposed export-copy fix in a separate module; no repository mutation."""
from pathlib import Path
from types import SimpleNamespace
import hashlib, importlib.util, json, sys
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'code'))
from disastertrace.monitoring_fixed_v1.contracts import Target
name='disastertrace.monitoring_fixed_v1._review_proposed_outcomes'
spec=importlib.util.spec_from_file_location(name,root/'proposed_outcomes.py')
m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
t=Target(target_id='test',entity='station:X',variable='visibility',units='m',output_kind='event_probability',support_kind='interval',physical_start=1000,physical_end=2000,temporal_semantics='future_physical',report_policy='review.synthetic',event_operator='lt',threshold=1000)
r=m.OutcomeRegistry([t])
x=dict(target_contract_hash=t.contract_hash,resolution_version='r1',value=1,status='mature',source_revision='s1',source_sha256='a'*64,physical_start=1000,physical_end=2000,units='m',quality_status='checked',observed_at=2000,published_at=2100,fetched_at=2200,resolved_at=2300,availability_basis='declared_archive_scenario',references=[{'asset':'original'}])
r.register(x)
checks=[]
def check(name,fn):
    try: fn(); checks.append({'name':name,'passed':True})
    except Exception as e: checks.append({'name':name,'passed':False,'error':str(e)})
def assert_equal(a,b):
    assert a==b,(a,b)
def export_value():
    y=r.export();y['payload']['records'][0]['value']=0;assert_equal(r.records[(t.contract_hash,'r1')]['value'],1)
check('export_scalar_detached',export_value)
def export_nested():
    y=r.export();y['payload']['records'][0]['references'][0]['asset']='changed';assert_equal(r.records[(t.contract_hash,'r1')]['references'][0]['asset'],'original')
check('export_nested_detached',export_nested)
def rows_nested():
    y=r.opportunity_rows([SimpleNamespace(opportunity_id='o',target=t)],{'o':'r1'});y[0]['references'][0]['asset']='changed';assert_equal(r.records[(t.contract_hash,'r1')]['references'][0]['asset'],'original')
check('opportunity_nested_detached',rows_nested)
c=m.ComparisonContract({'context':{'x':1}},{'selector':['fixed']})
def permission():
    y=c.export();y['payload']['allowed_interventions']['selector'].append('unregistered')
    try:c.validate({'context':{'x':1}},{'selector':'unregistered'})
    except ValueError:return
    raise AssertionError('unregistered intervention became allowed')
check('comparison_permissions_detached',permission)
def invariants():
    y=c.export();y['payload']['invariants']['context']['x']=2;assert_equal(c.invariants['context']['x'],1)
check('comparison_invariants_detached',invariants)
result={'scope':'Five synthetic checks on reviewer-proposed local fix; not applied to repository and not full regression','checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks),'proposed_source_sha256':hashlib.sha256((root/'proposed_outcomes.py').read_bytes()).hexdigest()}
(root/'PROPOSED_FIX_VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False));sys.exit(not all(c['passed'] for c in checks))
