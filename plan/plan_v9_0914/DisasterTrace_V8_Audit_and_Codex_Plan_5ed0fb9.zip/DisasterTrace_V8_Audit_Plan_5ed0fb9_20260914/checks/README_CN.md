# 本次局部审查的实际执行范围

运行：`python -B run_checks.py`。全部使用标准库，无网络、API、模型权重或GPU。

本目录含三个**完整生产模块副本**：outcomes.py、versions.py、event_loop.py。对应Git blob与 `5ed0fb94ae7bf235b37e7528e201b603271edffa` 完全一致，结果见 `results/SOURCE_HASH_CHECK.json`。

contracts.py仅复制了此前已核验审查包中的命名定义；当前GitHub显示父文件blob仍为8287a69d4628b1c2f9a9ff9dad85eea4e2bbc625，因此可用于该不变类的局部行为测试，但不冒充完整模块。

intervention_branch.py只包含实际 `_process` 的 policy_intervention 分支与测试包装函数。测试将该分支与完整 ComparisonContract 拼接，复现“中途不允许值、结束改回”可通过终态检查。没有加载生产AdmissionEngine整体，也没有读取52个真实会话journal，不能据此宣布实际实验已经出错。

17项检查包含3项源码哈希、14项行为检查。结果passed指观察与检查预期一致，其中“盲点”检查的预期正是复现当前限制，不代表限制已修复。4个类型/单位负测试作为同一项记录，不把它们重复加入总数。

时钟测试使用一个可观察的owner fixture；只验证批次注册、相位和重入，不证明完整事务回滚。新版transaction_fork、生产状态恢复、真实费用/物理传感器、全部502项测试均未在本次环境重跑。

Codex应将关键局部反例迁成真实引擎入口测试，并先只读核查历史受影响范围。
