"""Bounded CPU checks of selected pinned source, not a repository test rerun.

Network, GPU, model execution, raw-weather ETL and full journal scoring are not
used. Production classes use small typed synthetic fixtures. The intervention
probe composes the production handler branch with the final-state comparator;
it does not claim a full SessionCoordinator exploit or affected real sessions.
"""
from __future__ import annotations
import dataclasses
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import types

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from source.contracts import Target, Forecast, ForecastState, fingerprint
from source.outcomes import OutcomeRegistry, ComparisonContract, experiment_spec
from source.event_loop import run_clock
from source.intervention_branch import apply_intervention

# Import the exact versions.py bytes with a narrowly supplied hash dependency.
for name in ('auditrepo', 'auditrepo.providers'):
    m = types.ModuleType(name); m.__path__ = []; sys.modules[name] = m
m = types.ModuleType('auditrepo.targets'); m.canonical_hash = fingerprint
sys.modules[m.__name__] = m
spec = importlib.util.spec_from_file_location('auditrepo.providers.versions', ROOT/'source/versions.py')
versions = importlib.util.module_from_spec(spec); sys.modules[spec.name] = versions
spec.loader.exec_module(versions)

results = []
def check(name, kind, fn):
    try:
        detail = fn()
        results.append({'id': name, 'scope': kind, 'status': 'passed', 'detail': detail})
    except Exception as exc:
        results.append({'id': name, 'scope': kind, 'status': 'failed', 'error': repr(exc)})

def raises(fn, contains=''):
    try:
        fn()
    except ValueError as exc:
        assert contains in str(exc), str(exc)
        return str(exc)
    raise AssertionError('Expected rejection, but the call returned')

EXPECTED={'outcomes.py':'5c8ce9e02aa28a977991f6b047c708391d36e20d',
          'event_loop.py':'22e38a02b6508476591f6db54246b663eac0c205',
          'versions.py':'847668671020990cf44f694d9ea536e689ba8d8a'}
for filename, expected in EXPECTED.items():
    def verify_hash(filename=filename, expected=expected):
        b=(ROOT/'source'/filename).read_bytes()
        actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        assert actual==expected
        return {'bytes':len(b),'git_blob_sha1':actual}
    check('hash:'+filename,'exact_full_module_hash',verify_hash)

target=Target('t','station:S','temperature','degC','scalar','point',100,100,'future_physical','fixture.v1')

def outcome(value=-4, version='r1'):
    return dict(target_contract_hash=target.contract_hash,resolution_version=version,
        value=value,status='mature',source_revision='obs1',source_sha256='a'*64,
        physical_start=100,physical_end=100,units='degC',quality_status='valid',
        observed_at=100,published_at=None,fetched_at=200,resolved_at=201,
        availability_basis='declared_archive_scenario')

def unique_result():
    reg=OutcomeRegistry([target]); assert reg.register(outcome())
    assert reg.register(outcome()) is False
    message=raises(lambda:reg.register(outcome(-9)), 'conflict')
    assert len(reg.records)==1
    return {'duplicate_is_idempotent':True,'conflict_rejected':message}
check('outcome_same_target_conflict','full_module_with_typed_fixture',unique_result)

def outcome_versions():
    reg=OutcomeRegistry([target]); reg.register(outcome());reg.register(outcome(-5,'r2'))
    ops=[types.SimpleNamespace(opportunity_id=x,target=target) for x in ('early','late')]
    msg=raises(lambda:reg.opportunity_rows(ops,{'early':'r1','late':'r2'}),'mix resolution')
    rows=reg.opportunity_rows(ops,{'early':'r1','late':'r1'})
    assert rows[0]['value']==rows[1]['value']==-4
    return {'cross_lead_version_rejected':msg,'consistent_value':-4}
check('outcome_resolution_across_leads','full_module_with_typed_fixture',outcome_versions)

def semantic_rejections():
    rejected=[]
    for field,value in [('units','K'),('physical_end',101),('value',True),('observed_at',False)]:
        row=outcome();row[field]=value
        rejected.append(raises(lambda row=row:OutcomeRegistry([target]).register(row)))
    return {'subcases':4,'messages':rejected}
check('outcome_units_support_and_bool','full_module_with_typed_fixture',semantic_rejections)


def product(sid,issued,start,end,status='active',semantic=None):
    return dict(source_id=sid,issued_at=issued,station='KSFO',valid_start=start,
        valid_end=end,status=status,native_semantics_sha256=semantic or sid)

def choose(rows):
    return versions.current_taf(rows,station='KSFO',cutoff=30,start=50,end=60,lag_us=0)

def version_no_revive():
    old=product('older',10,0,100); new=product('newer',20,0,55)
    got=choose([new,old]);assert got['status']=='current_version_does_not_cover_target';assert got['selected_id']=='newer'
    return got
check('latest_then_coverage','full_module_with_synthetic_products',version_no_revive)

def cancel_no_revive():
    got=choose([product('older',10,0,100),product('cancel',20,None,None,'canceled')])
    assert got['status']=='canceled' and got['selected_id']=='cancel'
    return got
check('canceled_latest_does_not_revive_old','full_module_with_synthetic_products',cancel_no_revive)

def conflict():
    got=choose([product('a',20,0,100),product('b',20,0,100)])
    assert got['status']=='conflict'
    return got
check('equal_issuance_conflict','full_module_with_synthetic_products',conflict)

def aliases():
    rows=[product('b',20,0,100,semantic='same'),product('a',20,0,100,semantic='same')]
    got=choose(rows); assert got['selected_id']=='a' and len(got['source_ids'])==2
    assert got==choose(list(reversed(rows)))
    return got
check('semantic_alias_permutation','full_module_with_synthetic_products',aliases)

@dataclasses.dataclass
class Event:
    event_id: str
    time: int
    kind: str
    payload: dict
    def to_dict(self):return dataclasses.asdict(self)

class Owner:
    def __init__(self):
        self._events={};self._processed=set();self._last_time=None;self.journal=None
        self.opportunities={};self.snapshots={};self.trace=[]
    def _expiry_times(self,upcoming):return []
    def _process(self,e):self.trace.append(e.kind)
    def _invalidate(self,t):self.trace.append('invalidate')
    def _seal(self,t):self.trace.append('seal')
    def _after_seal(self,t):self.trace.append('after_seal')

PHASE={'baseline':0,'completion':1,'begin':5}
def run(owner,events,until):return run_clock(owner,events,until=until,event_order=PHASE,decode=lambda r:Event(**r))

def batch_atomic_registration():
    o=Owner();a=Event('same',10,'baseline',{'x':1});b=Event('same',10,'baseline',{'x':2})
    msg=raises(lambda:run(o,[a,b],20),'Conflicting')
    assert not o._events and not o.trace and o._last_time is None
    return {'batch_rejected_before_registration':msg}
check('clock_conflicting_duplicate_batch','full_event_loop_with_owner_fixture',batch_atomic_registration)

def order():
    o=Owner();run(o,[Event('c',10,'begin',{}),Event('b',10,'completion',{}),Event('a',10,'baseline',{})],10)
    assert o.trace==['baseline','completion','invalidate','seal','after_seal','begin']
    return {'trace':o.trace}
check('clock_same_time_phases','full_event_loop_with_owner_fixture',order)

def past():
    o=Owner();run(o,[],10)
    msg=raises(lambda:run(o,[Event('a',10,'begin',{})],11),'backdated')
    assert not o._events
    return {'message':msg}
check('clock_no_backdated_event','full_event_loop_with_owner_fixture',past)

def reentry():
    o=Owner()
    def nested(e):run(o,[],11)
    o._process=nested
    msg=raises(lambda:run(o,[Event('a',10,'baseline',{})],10),'Reentrant')
    assert not o._clock_running
    return {'message':msg,'note':'Only the reentry guard is tested; outer AdmissionEngine rollback is NOT tested.'}
check('clock_reentry_guard','full_event_loop_with_owner_fixture',reentry)


def declared_change_rejected():
    comp=ComparisonContract({'bank':'B'},{'query_limit_per_tick':[2]})
    return {'message':raises(lambda:comp.validate({'bank':'B'},{'query_limit_per_tick':3}),'Unregistered')}
check('comparison_rejects_final_undeclared_value','full_module_comparator',declared_change_rejected)

def transient_intervention():
    comp=ComparisonContract({'bank':'B'},{'query_limit_per_tick':[2]})
    owner=types.SimpleNamespace(active_interventions={'query_limit_per_tick':2},attempts=[])
    comp.validate({'bank':'B'},owner.active_interventions)
    for i,val in enumerate((3,2)):
        event=Event('intervention'+str(i),10+i,'policy_intervention',
            {'parent_checkpoint_sha256':'f'*64,'changes':{'query_limit_per_tick':val}})
        apply_intervention(owner,event)
    # This is precisely the final-state validation call used by score_admitted.
    comp.validate({'bank':'B'},owner.active_interventions)
    assert [x['changes']['query_limit_per_tick'] for x in owner.attempts]==[3,2]
    return {'reproduced':True,'declared_values':[2],'intermediate_values':[3,2],
            'final_state_accepted':True,'history_retained':True,
            'scope':'Production branch plus actual comparator; not a full journal-scoring or model-session run.'}
check('comparison_transient_intervention_blind_spot','isolated_production_branch_and_comparator',transient_intervention)


def unequal_null_behaviors():
    t=Target('risk','station:S','visibility','m','event_probability','interval',100,110,
        'future_physical','fixture.v1','lt',1000)
    f=lambda p:Forecast(t.contract_hash,'event_probability','probability',p)
    follow=ForecastState(t,'persistent_override');follow.update_baseline(f(.2),'b0',1);follow.follow(2)
    kept=ForecastState(t,'persistent_override');kept.update_baseline(f(.2),'b0',1);kept.propose(f(.2),'b0',2,8)
    rep=ForecastState(t,'persistent_override');rep.update_baseline(f(.2),'b0',1);rep.propose(f(.2),'b0',2,8)
    for s in (follow,kept,rep):s.update_baseline(f(.8),'b1',3)
    rep.propose(rep.effective(4),'b1',4,20)
    observed={'follow_at9':follow.effective(9).value,'keep_no_new_proposal_at9':kept.effective(9).value,'repropose_current_at9':rep.effective(9).value}
    assert observed=={'follow_at9':.8,'keep_no_new_proposal_at9':.8,'repropose_current_at9':.2}
    return {'values':observed,'scope':'Unchanged ForecastState class excerpt, synthetic times and values; not new weather results.'}
check('follow_keep_repropose_lifetime','unchanged_production_class_excerpt',unequal_null_behaviors)

report={'head':'5ed0fb94ae7bf235b37e7528e201b603271edffa',
        'scope':'Selected source-level synthetic CPU checks only; no complete repository test suite, archive replay, model calls, GPU or network.',
        'total':len(results),'passed':sum(x['status']=='passed' for x in results),
        'failed':sum(x['status']=='failed' for x in results),
        'checks':results}
(ROOT/'results').mkdir(exist_ok=True)
(ROOT/'results'/'CHECK_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(1 if report['failed'] else 0)
