"""Isolated definitions from unchanged contracts.py blob 8287a69d4628b1c2f9a9ff9dad85eea4e2bbc625.
Not the full module. Sourced from the earlier attached audit, then pinned against the current blob ID.
No engine or external execution dependencies are claimed.
"""
import hashlib
import json
import math
from dataclasses import asdict, dataclass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)

def fingerprint(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()

def finite(value):
    return type(value) in (int, float) and math.isfinite(value)

def timestamp(value):
    if type(value) is not int:
        raise ValueError("Timestamps must be integer UTC microseconds")

def require_fields(record, fields, label):
    if not isinstance(record, dict) or set(record) != set(fields.split()):
        raise ValueError("Unexpected or missing fields in " + label)

@dataclass(frozen=True)
class Target:
    target_id: str
    entity: str
    variable: str
    units: str
    output_kind: str
    support_kind: str
    physical_start: int
    physical_end: int
    temporal_semantics: str
    report_policy: str
    event_operator: str | None = None
    threshold: float | None = None
    release_event_at: int | None = None

    def __post_init__(self):
        if not all(
            type(v) is str and v
            for v in (self.target_id, self.entity, self.variable, self.units, self.report_policy)
        ):
            raise ValueError("Incomplete target identity")
        timestamp(self.physical_start)
        timestamp(self.physical_end)
        if self.support_kind == "point":
            valid = self.physical_start == self.physical_end
        elif self.support_kind == "interval":
            valid = self.physical_start < self.physical_end
        else:
            valid = False
        if not valid:
            raise ValueError("Invalid native physical support")
        if self.output_kind == "event_probability":
            if self.event_operator not in {"lt", "le", "gt", "ge"} or not finite(self.threshold):
                raise ValueError("Event target requires a finite native-unit predicate")
        elif (
            self.output_kind != "scalar"
            or self.threshold is not None
            or self.event_operator is not None
        ):
            raise ValueError("Scalar target has no event threshold")
        if self.temporal_semantics == "future_product_release":
            timestamp(self.release_event_at)
        elif self.temporal_semantics not in {"future_physical", "partial_window_nowcast"}:
            raise ValueError("Unknown target temporal semantics")
        if self.temporal_semantics == "partial_window_nowcast" and self.support_kind != "interval":
            raise ValueError("A point has no partially elapsed window")

    @property
    def contract_hash(self):
        row = self.to_dict()
        del row["target_id"]
        return fingerprint(row)

    @property
    def output_units(self):
        return "probability" if self.output_kind == "event_probability" else self.units

    def check_cutoff(self, cutoff):
        timestamp(cutoff)
        if self.temporal_semantics == "future_physical":
            valid = cutoff < self.physical_start
        elif self.temporal_semantics == "future_product_release":
            valid = cutoff < self.release_event_at
        else:
            valid = self.physical_start <= cutoff < self.physical_end
        if not valid:
            raise ValueError("Cutoff contradicts target semantics")

    def check_forecast(self, forecast):
        if (forecast.target_contract_hash, forecast.kind, forecast.units) != (
            self.contract_hash,
            self.output_kind,
            self.output_units,
        ):
            raise ValueError("Forecast target, kind or unit mismatch")

    def to_dict(self):
        return asdict(self)

@dataclass(frozen=True)
class Forecast:
    target_contract_hash: str
    kind: str
    units: str
    value: float

    def __post_init__(self):
        if len(self.target_contract_hash) != 64 or any(
            c not in "0123456789abcdef" for c in self.target_contract_hash
        ):
            raise ValueError("Full target hash required")
        if not finite(self.value) or not self.units:
            raise ValueError("Finite typed value required")
        if self.kind == "event_probability":
            if self.units != "probability" or not 0 <= self.value <= 1:
                raise ValueError("Invalid probability")
        elif self.kind != "scalar":
            raise ValueError("Unsupported forecast type")

    def to_dict(self):
        return asdict(self)

class ForecastState:
    """Small typed reducer; explicit event records permit offline reconstruction."""

    def __init__(self, target, protocol):
        if protocol not in {"base_bound_override", "persistent_override"}:
            raise ValueError("Unknown revision protocol")
        self.target, self.protocol = target, protocol
        self.baseline = self.override = None
        self.base_hash = self.override_base = None
        self.expires_at = None
        self.now = -(10**30)
        self.events = []

    def _advance(self, at):
        timestamp(at)
        if at < self.now:
            raise ValueError("State clock cannot go backwards")
        self.now = at

    def update_baseline(self, forecast, base_hash, at):
        self.target.check_forecast(forecast)
        if not base_hash:
            raise ValueError("Baseline content/version identity required")
        if any(
            event["kind"] == "base"
            and event["base_hash"] == base_hash
            and event["forecast"] != forecast.to_dict()
            for event in self.events
        ):
            raise ValueError("The same baseline identity cannot change its forecast")
        self._advance(at)
        closes_at = (
            self.target.release_event_at
            if self.target.temporal_semantics == "future_product_release"
            else self.target.physical_start
            if self.target.temporal_semantics == "future_physical"
            else self.target.physical_end
        )
        if at >= closes_at:
            self.events.append(
                {
                    "kind": "base_rejected",
                    "at": at,
                    "forecast": forecast.to_dict(),
                    "base_hash": base_hash,
                    "status": "invalid_target_time",
                }
            )
            return "invalid_target_time"
        if self.protocol == "base_bound_override" and self.base_hash != base_hash:
            self.override = self.override_base = self.expires_at = None
        self.baseline, self.base_hash = forecast, base_hash
        self.events.append(
            {"kind": "base", "at": at, "forecast": forecast.to_dict(), "base_hash": base_hash}
        )
        return "accepted"

    def propose(self, forecast, base_hash, at, expires_at):
        self.target.check_forecast(forecast)
        timestamp(expires_at)
        self._advance(at)
        if self.baseline is None:
            raise ValueError("No common baseline")
        known_base = any(e["kind"] == "base" and e["base_hash"] == base_hash for e in self.events)
        invalid_base = not known_base or (
            self.protocol == "base_bound_override" and base_hash != self.base_hash
        )
        try:
            self.target.check_cutoff(at)
            valid_target_time = True
        except ValueError:
            valid_target_time = False
        status = (
            "invalid_target_time"
            if not valid_target_time
            else "late"
            if at > expires_at
            else "stale_base"
            if invalid_base
            else "accepted"
        )
        if status == "accepted":
            self.override, self.override_base, self.expires_at = forecast, base_hash, expires_at
        self.events.append(
            {
                "kind": "proposal",
                "at": at,
                "forecast": forecast.to_dict(),
                "base_hash": base_hash,
                "expires_at": expires_at,
                "status": status,
            }
        )
        return status

    def follow(self, at):
        self._advance(at)
        self.override = self.override_base = self.expires_at = None
        self.events.append({"kind": "follow", "at": at})

    def effective(self, at):
        timestamp(at)
        if at < self.now:
            raise ValueError("Historical lookup requires replay")
        if self.baseline is None:
            raise ValueError("No baseline")
        return (
            self.override if self.override is not None and at <= self.expires_at else self.baseline
        )

    def to_dict(self):
        return json.loads(
            canonical(
                {"target": self.target.to_dict(), "protocol": self.protocol, "events": self.events}
            )
        )

    @classmethod
    def restore(cls, row):
        require_fields(row, "target protocol events", "state journal")
        state = cls(Target(**row["target"]), row["protocol"])
        for event in row["events"]:
            if event["kind"] in {"base", "base_rejected"}:
                status = state.update_baseline(
                    Forecast(**event["forecast"]), event["base_hash"], event["at"]
                )
                if status != event.get("status", "accepted"):
                    raise ValueError("Recorded baseline outcome differs from replay")
            elif event["kind"] == "proposal":
                status = state.propose(
                    Forecast(**event["forecast"]),
                    event["base_hash"],
                    event["at"],
                    event["expires_at"],
                )
                if status != event["status"]:
                    raise ValueError("Recorded proposal outcome differs from replay")
            elif event["kind"] == "follow":
                state.follow(event["at"])
            else:
                raise ValueError("Unknown state event")
        if state.to_dict() != row:
            raise ValueError("State replay changed record fields")
        return state

def paired_scores(opportunities, arms):
    """Strict full opportunity denominator; a missing prediction must be explicit.

    Upstream wrappers must supply their effective fallback for failed proposals.
    Missing outcomes share one mask across all arms, never per-method deletion.
    """
    ids = [r["opportunity_id"] for r in opportunities]
    if not ids or len(set(ids)) != len(ids) or not arms:
        raise ValueError("Nonempty unique opportunity registry and arms required")
    kinds = {(r["target"]["output_kind"], r["target"]["units"]) for r in opportunities}
    if len(kinds) != 1:
        raise ValueError("Do not pool unlike losses or scalar units")
    kind, _ = next(iter(kinds))
    mask = [r["outcome"] is not None for r in opportunities]
    result = {
        "registered": len(ids),
        "settled": sum(mask),
        "missing": len(ids) - sum(mask),
        "score": "brier" if kind == "event_probability" else "mae",
        "arms": {},
    }
    for name, values in arms.items():
        if set(values) != set(ids):
            raise ValueError("Every method must retain exactly all opportunities")
        losses = []
        for row, settled in zip(opportunities, mask):
            t = Target(**row["target"])
            f = Forecast(**values[row["opportunity_id"]])
            t.check_forecast(f)
            if settled:
                y = row["outcome"]
                if not finite(y) or (kind == "event_probability" and y not in (0, 1)):
                    raise ValueError("Invalid evaluation outcome")
                losses.append(
                    (f.value - y) ** 2 if kind == "event_probability" else abs(f.value - y)
                )
        result["arms"][name] = {
            "mean_loss": sum(losses) / len(losses) if losses else None,
            "loss_sum": sum(losses),
            "scored": len(losses),
        }
    return result
