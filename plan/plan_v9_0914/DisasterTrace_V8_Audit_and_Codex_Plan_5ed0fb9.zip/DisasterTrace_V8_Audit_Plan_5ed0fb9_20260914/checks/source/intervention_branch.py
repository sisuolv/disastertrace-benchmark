"""Isolated production branch, not the complete AdmissionEngine.

Body of the policy_intervention branch from admission.py at 5ed0fb94,
blob 24917aed622a8405ba53b6d9970f6f686ef14d68. Only surrounding method
name/dispatch has been supplied for local testing. No journal loading,
full controller or production data is involved.
"""


def apply_intervention(self, event):
    p, at = event.payload, event.time
    if event.kind == "policy_intervention":
        allowed = {
            "acquire",
            "predict",
            "selector_kind",
            "query_limit_per_tick",
            "per_tick_forecast_cap",
        }
        if not p.get("parent_checkpoint_sha256") or not set(p.get("changes", {})) <= allowed:
            raise ValueError("Unregistered policy branch intervention")
        self.active_interventions.update(p["changes"])
        self.attempts.append(
            {"event_id": event.event_id, "time": at, "status": "policy_intervention", **p}
        )
        return
    raise ValueError("Local harness only accepts policy_intervention")
