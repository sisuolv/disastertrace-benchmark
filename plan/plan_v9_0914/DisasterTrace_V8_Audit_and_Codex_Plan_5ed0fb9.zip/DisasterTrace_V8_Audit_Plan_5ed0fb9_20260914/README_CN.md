# 本包入口

先读 START_HERE_CODEX_CN.md，再读 AUDIT_AND_PLAN_CN.md。CODEX_BACKLOG.json 包含12个增量工作包，第一批CR00—CR04。

这是针对5ed0fb94的当前审阅与计划，不是仓库修改或新实验完成报告。当前v8与全部旧实验保留，不另起研究版本。

checks/包含本次实际执行的3项源码哈希与14项局部行为检查；不是完整502项测试，也不是52会话复算。一次局部检查有意复现终态比较盲点；passed不是宣称该盲点修复。

SOURCE_READ_MANIFEST.json列出实际读取范围、固定源码和二进制包获取失败。没有模型权重、账号凭据、私有下载token或伪造的历史数据。
