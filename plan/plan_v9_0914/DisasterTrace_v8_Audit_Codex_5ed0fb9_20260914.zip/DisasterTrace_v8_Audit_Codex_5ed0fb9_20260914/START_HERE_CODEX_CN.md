# 直接交给Codex的启动指令

请在当前 `sisuolv/disastertrace-benchmark` 的 `next-phase-v1` 工作区实际检查、修复并推进，不要只再生成一份总体计划。

## 阅读顺序

1. 仓库内适用的AGENTS.md与最新README。
2. `plans/v8_measurement_execution_20260913_01/RUN_REPORT_CN.md`、`ADAPTIVE_SCORECARD_CN.md`、`NEXT_PHASE_PLAN_CN.md`和`WORK_PACKAGE_PROGRESS_02.json`。
3. 本包`AUDIT_REPORT_CN.md`、`FINDINGS.json`、`CODEX_NEXT_PLAN_CN.md`、`TASKS.json`和`audit_probes/README_CN.md`。

本次审阅HEAD是 `5ed0fb94ae7bf235b37e7528e201b603271edffa`。若当前HEAD已变化，先逐项核查差异，不回退、不reset、不覆盖用户修改。包内review_sources是旧审阅副本，不是修复补丁，不能复制覆盖生产代码。

## 当前事实

当前已为v8，沿用W00—W19、C1/C2/C3、E/F/D/MM和X00—X09及16类总体范围。不回到旧v7/CP从头实施，不新增v9。

上一轮22探针已全部通过。本次新增13探针9通过、4失败；4个失败属于两个问题：
- unknown执行可绕过reconcile_unknown由普通settle/settle_observed释放预留；
- score_admitted只核最终active_interventions，不核初始及中途非法配置。

以上35项是哈希核对后的隔离生产定义测试，不等于完整502项回归。先用repo模式在完整package里复现，再修复、再记录green。不得为了通过而删探针、改期望、强制xfail或跳过。

## 第一批执行

按依赖执行：
`W00.audit_5ed0fb9 → W03.unknown_settlement / W04.intervention_history → W06.impact_5ed0fb9`。
并行CPU任务：`W07.visible_value_diagnostic`、`W11.split_governance`、`W19.incremental_delivery`。

然后运行 `W12.copy_closed_loop`：用新程序轨迹比较FOLLOW_LATEST、REEMIT_CURRENT、REEMIT_BASELINE。不能把旧LLM调用耗时改短后当新程序运行。

先扫描真实52条自适应、40条程序以及恢复材料是否触发问题；明确已扫描分母与0/非0/not_evaluated。合成反例不证明旧结果已错，材料不在本地也不等于触发0。

## 不再重复做的事

- W07全天程序、W10固定输入、W12的52会话5108调用已完成，不重复启动旧GPU目录。
- 4916个F输出中4915个等于可见当前值、另1个等于可见基线；这是数值等价，不证明内部复制机制。
- typed_auto_propose.v1自动提出OVERRIDE，不得说模型已经自主选择了修订动作。
- X09本轮未提交，source-only shadow不是实时预测，固定F的D回放不是完整D反馈。

## 权限与保全

CPU本地检查可先执行。没有当次明确授权，不启动GPU、付费API、训练、模型下载、大规模来源获取、未来长期运行或git push。历史12小时/4H100授权不自动续期；有明确新授权则先绑定本批范围和预算。

保留原439测试GPU冻结、502测试当前记录、所有旧模型回答、平台FAILED、原自动审计超时与补充审计。不要“修好”旧原始记录或按新解释替换它们。

预留Bay2025-02-17至02-23确认周保持不打开。当前所有已暴露日期只作开发。数据资格失败只阻塞对应支线，温度连续会话、H07物理端点、H08语义按各自门槛推进。

## 必须交付

每批给出实际代码差异、命令与返回码、测试nodeid与结果、旧资料保全hash、真实调用/费用、影响范围、负结果、阻塞项和下一条可执行操作。

最低首批交付：生产入口red/green、两个合同修复、历史影响清单、原捕获可见数值分析、新程序沿用对照、独立分割更新和最新W子任务状态。无LLM正收益也可完成验收。
