"""Verify this audit/plan package. Does not claim repository integration success."""
from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for entry in manifest['files']:
    relative=Path(entry['path'])
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Unsafe manifest path')
    p=root/relative
    b=p.read_bytes()
    if len(b)!=entry['bytes'] or hashlib.sha256(b).hexdigest()!=entry['sha256']:
        raise ValueError(f'Changed/missing file: {relative}')
report=json.loads((root/'audit_probes/SOURCE_HASH_VERIFICATION_CURRENT.json').read_text())
for item in report:
    raw=(root/'audit_probes/review_sources'/f"{item['module']}.py").read_bytes()
    git=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    if git!=item['git_blob_sha1']:
        raise ValueError(f"Source blob mismatch: {item['module']}")
data=json.loads((root/'TASKS.json').read_text())
tasks={t['id']:t for t in data['tasks']}
if len(tasks)!=data['task_count'] or len(tasks)!=len(data['tasks']):raise ValueError('Task count/identity')
visited=set(); active=set()
def visit(k):
    if k in active:raise ValueError('Cyclic task dependencies')
    if k in visited:return
    if k not in tasks:raise ValueError('Missing dependency '+k)
    active.add(k)
    for dep in tasks[k]['depends_on']:visit(dep)
    active.remove(k); visited.add(k)
for k in tasks:visit(k)
a=json.loads((root/'PLANNED_ACCEPTANCE_CASES.json').read_text())
if len(a['cases'])!=a['count'] or len({c['id'] for c in a['cases']})!=a['count']:raise ValueError('Acceptance count')
if any(c['task_id'] not in tasks or c['status']!='planned_not_executed' for c in a['cases']):raise ValueError('Acceptance scope')
suites=ET.parse(root/'audit_probes/combined_probes.xml').getroot()
if suites.tag=='testsuite':suites=[suites]
else:suites=list(suites)
counts={k:sum(int(s.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
if counts!={'tests':35,'failures':4,'errors':0,'skipped':0}:raise ValueError('Unexpected probe record')
summary={'package_integrity':'passed','manifest_files':len(manifest['files']),'source_blobs_verified':len(report),
         'task_dag':'passed','planned_tasks':len(tasks),'planned_acceptance_conditions':a['count'],
         'recorded_probe_counts':counts,'repository_suite_executed_by_verifier':False}
print(json.dumps(summary,ensure_ascii=False,indent=2))
