"""Additional synthetic contract tests at 5ed0fb9, not weather experiments.

Use DISASTERTRACE_AUDIT_MODE=repo and the production PYTHONPATH in a full checkout
before promoting any failure to an integration-level finding.
"""
import copy
import os
import pytest
from test_review_regressions import bundle, target, forecast, base_event, engine, begin, completion, sealed
if os.environ.get('DISASTERTRACE_AUDIT_MODE') == 'repo':
    from disastertrace.monitoring_fixed_v1 import admission as A, contracts as C, outcomes as O
    from disastertrace.monitoring_v1 import resources as R, journal as J
else:
    from isolated_loader import A,C,O,R,J


def unknown_ledger():
    ledger=R.BudgetLedger({'tokens':100})
    ledger.reserve('r',R.Cost(tokens=80),'t')
    ledger.bind_request('r',{'request_sha256':'a'*64,'execution_sha256':'b'*64})
    ledger.mark_unknown('r',{'reason':'sent, response not yet known'})
    return ledger

@pytest.mark.parametrize('method',['settle','settle_observed'])
def test_unknown_execution_cannot_be_zero_settled_without_reconciliation(method):
    ledger=unknown_ledger()
    with pytest.raises(ValueError):
        getattr(ledger,method)('r',R.Cost(),outcome='completed')
    assert ledger.reserved.tokens==80 and not ledger.entries['r']['settled']


def comparison_arm(path, *, initial=False, changes=()):
    spec={'invariants':{'mission':'audit-synthetic-fixed'},'interventions':{'acquire':initial}}
    with J.EventJournal(path) as j:
        e=A.AdmissionEngine([A.TypedOpportunity('o',target(),900)],
            fallbacks={'t':forecast(.05).to_dict()},experiment=spec,journal=j)
        e.run([base_event(bundle())], until=20)
        for i,(when,value) in enumerate(changes):
            # Bind an actual exported prefix, not a made-up parent hash.
            parent = e.export()["sha256"]
            e.run([A.AdmissionEvent('change-'+str(i),when,'policy_intervention',{
              'parent_checkpoint_sha256':parent,'changes':{'acquire':value}})], until=when)
        e.run([],until=900)
    return e


def result_rows():
    return [{'opportunity_id':'o','target_contract_hash':target().contract_hash,
             'value':0,'status':'mature','source_revision':'audit-measured'}]


def test_scoring_rejects_forbidden_intervention_even_if_reverted_at_end(tmp_path):
    path=tmp_path/'history.jsonl'
    comparison_arm(path,changes=[(40,True),(60,False)])
    contract=O.ComparisonContract({'mission':'audit-synthetic-fixed'},{'acquire':[False]})
    control=tmp_path/'control.jsonl'
    comparison_arm(control)
    with pytest.raises(ValueError):
        A.score_admitted(result_rows(),{'control':control,'arm':path},comparison=contract)


def test_scoring_rejects_forbidden_initial_policy_even_if_final_is_allowed(tmp_path):
    path=tmp_path/'initial.jsonl'
    comparison_arm(path,initial=True,changes=[(60,False)])
    contract=O.ComparisonContract({'mission':'audit-synthetic-fixed'},{'acquire':[False]})
    control=tmp_path/'control.jsonl'
    comparison_arm(control)
    with pytest.raises(ValueError):
        A.score_admitted(result_rows(),{'control':control,'arm':path},comparison=contract)


def test_unknown_reconciliation_requires_original_executor():
    ledger=unknown_ledger()
    with pytest.raises(ValueError):
        ledger.reconcile_unknown('r',R.Cost(tokens=8),{
            'request_sha256':'a'*64,'execution_sha256':'d'*64,
            'response_sha256':'c'*64,'observed_at':100})
    assert ledger.reserved.tokens==80


def test_correct_unknown_reconciliation_is_idempotent():
    ledger=unknown_ledger();proof={'request_sha256':'a'*64,'execution_sha256':'b'*64,
        'response_sha256':'c'*64,'observed_at':100}
    assert ledger.reconcile_unknown('r',R.Cost(tokens=8),proof)
    assert not ledger.reconcile_unknown('r',R.Cost(tokens=8),proof)
    assert ledger.spent.tokens==8 and ledger.reserved.tokens==0


def test_fully_registered_intervention_is_allowed(tmp_path):
    path=tmp_path/'valid.jsonl';comparison_arm(path,changes=[(40,True),(60,False)])
    contract=O.ComparisonContract({'mission':'audit-synthetic-fixed'},{'acquire':[False,True]})
    score=A.score_admitted(result_rows(),{'arm':path},comparison=contract)
    assert score['scores']['registered']==1


def test_invalid_transaction_does_not_partially_register_events():
    e=engine();e.run([base_event(bundle())],until=20);before=e.export()
    with pytest.raises(ValueError):
        e.run([base_event(bundle('new',40,40,.8),'new'),
               A.AdmissionEvent('bad',50,'cancel',{'call_id':'nonexistent'})],until=900)
    assert e.export()==before and 'new' not in e._events
    assert e.baselines['t']['forecast']['value']==.2


def test_transaction_journal_failure_does_not_commit_memory():
    class FailingJournal:
        records=[{'sentinel':True}]
        def append(self,*args):raise OSError('simulated durable append failure')
    e=engine();e.run([base_event(bundle())],until=20);before=e.export();e.journal=FailingJournal()
    with pytest.raises(OSError):
        e.run([base_event(bundle('new',40,40,.8),'new')],until=50)
    assert e.export()==before and e.baselines['t']['forecast']['value']==.2


def canonical_result():
    return {'target_contract_hash':target().contract_hash,'resolution_version':'audit.result.v1',
      'value':0,'status':'mature','source_revision':'report.v1','source_sha256':'d'*64,
      'physical_start':1000,'physical_end':1100,'units':'m','quality_status':'accepted',
      'observed_at':1050,'published_at':1110,'fetched_at':1120,'resolved_at':1130,
      'availability_basis':'documented_historical_release'}


def test_duplicate_canonical_result_is_idempotent():
    registry=O.OutcomeRegistry([target()]);row=canonical_result()
    assert registry.register(row);assert registry.register(row)==False
    assert len(registry.records)==1


def test_canonical_result_value_conflict_rejected():
    registry=O.OutcomeRegistry([target()]);row=canonical_result();registry.register(row)
    with pytest.raises(ValueError):registry.register({**row,'value':1})


def test_cross_lead_resolution_versions_rejected():
    registry=O.OutcomeRegistry([target()]);row=canonical_result();registry.register(row)
    registry.register({**row,'resolution_version':'audit.result.v2'})
    opportunities=[A.TypedOpportunity('o1',target(),800),A.TypedOpportunity('o2',target(),900)]
    with pytest.raises(ValueError):
        registry.opportunity_rows(opportunities,{'o1':'audit.result.v1','o2':'audit.result.v2'})


def test_journal_write_failure_disables_reuse(tmp_path):
    class BadStream:
        def write(self,*args):raise OSError('disk fault')
    with J.EventJournal(tmp_path/'j.jsonl') as journal:
        original=journal.stream;journal.stream=BadStream()
        try:
            with pytest.raises(OSError):journal.append('failed',{'a':1})
            with pytest.raises(ValueError):journal.append('later',{'a':2})
        finally:journal.stream=original
