# 本次实际执行的审计探针

审阅提交：`5ed0fb94ae7bf235b37e7528e201b603271edffa`。

## 已实际执行

- 上一轮的22项探针：本次全部通过（原来是17通过、5失败）。
- 本次新增13项：9通过、4失败。4个失败对应两个根因，不是4个不同系统缺陷。
- 两文件合并运行：35项，31通过、4失败，无错误/跳过。原始输出见 `combined_probes.txt/xml`。
- `SOURCE_HASH_VERIFICATION_CURRENT.json` 记录9个源码文件的实际Git blob SHA-1和SHA-256。

本次没有修复被测仓库，红测试是故意保留的待修复回归需求。pytest退出1在当前审阅提交上是预期审计结果，不是打包失败。

## 加载范围

`isolated_loader.py` 先校验完整源文件Git blob哈希，再用AST省略模块顶层相对导入并注入已获取生产定义。函数体和类定义不改写。包内源码来自所审阅提交，禁止把它们误当修复补丁覆盖仓库。

这是隔离的生产定义测试，不是完整仓库导入或集成测试。它不执行航空原文解码、D准备子模块、GPU模型、后端工作进程、全仓库502项测试、52条真实轨迹或上游数据重建。

## 独立重现本次结果（Linux，Python 3.11+，已安装pytest）

```bash
cd audit_probes
python isolated_loader.py
PYTHONDONTWRITEBYTECODE=1 python -m pytest -q -p no:cacheprovider \
  test_review_regressions.py test_v8_additional.py
```

## 必须在完整检出中追加的复核

将探针复制到新的独立审计目录，避免编辑冻结原包；设定实际仓库的src路径，并切换真实导入：

```bash
REPO=/absolute/path/to/disastertrace-benchmark
AUDIT=/absolute/path/to/copied/audit_probes
cd "$AUDIT"
DISASTERTRACE_AUDIT_MODE=repo PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH="$REPO/disastertrace-starter/src" \
python -m pytest -q -p no:cacheprovider \
  test_review_regressions.py test_v8_additional.py
```

`repo`模式不使用隔离加载器，也不会要求修复后的文件仍等于旧SHA。此命令是交给Codex的待执行命令，不是本次已执行记录。原502项范围必须从最新验证清单和测试路径重新收集，不能把本探针数量加到旧502上冒充全仓库通过。

## 新红测试的精确含义

1. `test_unknown_execution_cannot_be_zero_settled_without_reconciliation[settle]`
2. `test_unknown_execution_cannot_be_zero_settled_without_reconciliation[settle_observed]`

同一根因：已经标记未知执行、保留80 tokens预留的请求，可以通过普通结算入口无凭据结为0，释放预留。它说明底层API未强制未知执行的对账不变量，不证明历史模型被实际免费结算。

3. `test_scoring_rejects_forbidden_intervention_even_if_reverted_at_end`
4. `test_scoring_rejects_forbidden_initial_policy_even_if_final_is_allowed`

同一根因：允许 `acquire=False` 的比较只检查最终配置，初始或中途True后恢复False的日志被接受。测试实际写入并重放journal，每次干预使用当时真实导出的父检查点hash。测试没有实际执行资料查询，因此它证明的是比较合同检查缺口，而不是已经生成受污染天气成绩。
