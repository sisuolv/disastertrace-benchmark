"""Load hash-verified production definitions without unavailable package imports.

Only module-level relative import statements are omitted. The supplied globals
come from the corresponding fetched production modules. No engine/score/event
function body is rewritten. This is NOT a full repository import/integration run.
Program-head probes do not exercise aviation parsing or preparation submodules.
"""
from pathlib import Path
import ast
import hashlib
import json
import sys
import types

ROOT = Path(__file__).resolve().parent / 'review_sources'
EXPECTED = {
 'contracts':'8287a69d4628b1c2f9a9ff9dad85eea4e2bbc625',
 'admission':'24917aed622a8405ba53b6d9970f6f686ef14d68',
 'event_loop':'22e38a02b6508476591f6db54246b663eac0c205',
 'targets':'df3862303f5ec9b28ab4c20969b88861ed06bf74',
 'journal':'a9a96278d3ddd58c3c2658da53d5bc9a18fca4a4',
 'resources':'cc89c2abf7463265d2395eafbf38abe639f64d6d',
 'heads':'70db8a8bf6e0919615a6a71548ed8035ae97a78f',
}
EXPECTED.update(versions='847668671020990cf44f694d9ea536e689ba8d8a', outcomes='5c8ce9e02aa28a977991f6b047c708391d36e20d')
CHECKS = []
pkg=types.ModuleType('_dt_audit'); pkg.__path__=[]; sys.modules['_dt_audit']=pkg

def load(name, dependencies=None):
 p=ROOT/(name+'.py'); raw=p.read_bytes()
 sha=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 assert sha==EXPECTED[name], (name,sha,EXPECTED[name])
 tree=ast.parse(raw, filename=str(p))
 tree.body=[n for n in tree.body if not (isinstance(n,ast.ImportFrom) and n.level)]
 module=types.ModuleType('_dt_audit.'+name); module.__file__=str(p); module.__package__='_dt_audit'
 if dependencies: module.__dict__.update(dependencies)
 sys.modules[module.__name__]=module
 exec(compile(tree,str(p),'exec'),module.__dict__)
 CHECKS.append({'module':name,'bytes':len(raw),'git_blob_sha1':sha,'matches_remote_blob':True,'sha256':hashlib.sha256(raw).hexdigest()})
 return module

T=load('targets'); C=load('contracts'); R=load('resources'); E=load('event_loop')
J=load('journal', {'canonical_hash':T.canonical_hash})
# Program-head probes do not use the E label mapping; no substituted E semantics.
H=load('heads', {k:getattr(C,k) for k in ('EvidenceBundle','Forecast','Target','canonical')})
V=load('versions', {'canonical_hash':T.canonical_hash})
O=load('outcomes', {k:getattr(C,k) for k in ('canonical','fingerprint','finite','require_fields','timestamp')})
A=load('admission', {
 'latest_issuance':V.latest_issuance,
 **{k:getattr(C,k) for k in ('EvidenceBundle','Forecast','ForecastState','Target','canonical','fingerprint','paired_scores','require_fields','timestamp')},
 'run_clock':E.run_clock,'read_journal':J.read_journal,'Cost':R.Cost,
 '_unique_object':H._unique_object,'_reject_constant':H._reject_constant,'parse_response':H.parse_response,
})
if __name__=='__main__':
 print(json.dumps(CHECKS,indent=2))
