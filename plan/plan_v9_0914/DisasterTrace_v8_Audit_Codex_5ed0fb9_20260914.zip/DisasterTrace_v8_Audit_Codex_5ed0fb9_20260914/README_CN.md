# DisasterTrace v8：审计结果与Codex后续执行包

审阅提交：`5ed0fb94ae7bf235b37e7528e201b603271edffa`。

## 先看什么

- `AUDIT_REPORT_CN.md`：最新进展、上一轮修复、新问题、范围限制和结果解释。
- `CODEX_NEXT_PLAN_CN.md`：20个W子任务的具体实施、研究对照、数据门槛与执行顺序。
- `START_HERE_CODEX_CN.md`：可直接发给Codex的启动任务。
- `TASKS.json`：机器可读依赖与验收；`PLANNED_ACCEPTANCE_CASES.json`为60项计划验收条件，不是本次已运行测试。
- `audit_probes/`：9份hash一致的源码、隔离加载器、35项实际探针与原始红/绿输出。
- `FINDINGS.json`、`CURRENT_STATUS.json`、`SOURCE_READ_SCOPE.json`：发现、来源记录与验证范围。

## 结论边界

上一轮22项全部通过；新增13项9通过、4失败。合并35项31通过、4失败。4个红测试属于两个P1合同问题，不是4类真实天气错误。

这是隔离的生产定义审计，不是完整package集成测试，也没有独立重跑全部502项、6118次模型捕获或52/40真实会话。实际旧结果是否触发本次问题尚待Codex全量扫描。远端仓库未修改，没有新GPU/付费API/训练。

复现探针请看 `audit_probes/README_CN.md`；真实修复用repo模式，不把审阅源码覆盖生产。当前红测试的pytest退出1应如实保留。

## 校验包文件

```bash
python verify_package.py
```

校验器只校验本包文件哈希、源码Git blob和任务DAG/引用/计数，不调用网络、不启动模型、不将计划验收称为测试通过。验收计划执行结果需要另行记录。

本包没有重做外部文献查新；策略建议是对当前v8研究路线的结果驱动实施补丁。
