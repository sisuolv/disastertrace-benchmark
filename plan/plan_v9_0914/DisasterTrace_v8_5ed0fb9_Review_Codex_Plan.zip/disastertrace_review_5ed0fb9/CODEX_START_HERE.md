# Codex：v8 本轮增量执行入口

参考提交：`5ed0fb94ae7bf235b37e7528e201b603271edffa`。

请完整阅读 `REVIEW_AND_CODEX_PLAN_CN.md`、`specs/WORK_PACKAGE_DELTA.json`、
`specs/ACCEPTANCE_TESTS.json` 和实际工作区适用的 `AGENTS.md`。
先核当前 HEAD、脏工作区、源码快照、数据与已生效授权。不要 reset、clean 或覆盖历史结果。
保持 v8、C1/C2/C3、E/F/D/MM、X00—X09、W00—W19，不新建 v9 或另一套会话引擎。

## 第一批

实施 `W00-delta`、`W01-W04-delta` 和 `W06-W07-W12-null` 的 CPU/已有资料部分。
同步准备 `W11-next` 的数据依赖及基线审计；MM、第二过程不必等待完整D或通用多在途。

1. 先把本包源码摘录探针转换为真实模块、真实事件时钟和journal入口测试。
2. 校验干预完整历史，不允许中途越界后恢复合法最终值隐藏问题；合法注册分支仍可运行。
3. 结果成熟时间按provider、参考身份和任务语义条件核验，拒绝已知矛盾，保留未知时间资格。
4. 对52条原会话与规范结果做影响扫描，分别给 affected/unchanged/not_evaluated，允许影响为0。
5. 新增 FollowDynamic、EchoLatestBaseline、EchoCurrent；与 FrozenFrequency 并列。
   先同捕获输入数值核对，再用自身成本重跑程序会话；不可缩短旧LLM时戳来制造新实验。
6. 同值OVERRIDE不改成FOLLOW；模型没有输出显式动作时不声称其自主决定了采纳。
7. 当前已完成的TAF当前优先、共同基线比较、独立F-only、本地串行在途恢复不从零重做。

## 重要边界

本包8个探针是局部源码方法级合成测试，未证明发布成绩错误。
44条验收项是待实现规格，不是新增项目通过数。
不新增逐题人工Gold或LLM judge，不按模型赢输选择日期、不强迫修订。
不再默认重跑完整235B全天矩阵；新模型批次须有未解决的科学问题与明确资源范围。
原GPU平台FAILED、推理exit0、补充审计完成分别保留；已消费launch不重启。
当前源码与439测试冻结的原GPU实现分别复算，不用502项当前检查改写原执行身份。

## 最小交付

实际代码、生产入口回归stdout/XML、`STATUS_DELTA.json`、`SOURCE_RUNTIME_MATRIX.json`、
`INTERVENTION_HISTORY_AUDIT.json`、`OUTCOME_TIME_AUDIT.json`、`IMPACT_MANIFEST.json`、
`VISIBLE_VALUE_NULLS.json`、新程序全机会结果，以及MM/第二物理过程的下一批资料与调用白名单。
不得只复述一份计划。所有失败、未完成和负结果明确保留。
