#!/usr/bin/env python3
"""Arithmetic of published report counts only; no model or journal replay."""
import json
from pathlib import Path
r={
 'tests':{'core':485,'launch':5,'joint_analysis':6,'visible_value':6,'sum':485+5+6+6},
 'fixed_calls':{'benchmark':2*504,'compatibility':2,'actual':2*(504+1)},
 'adaptive':{'methods':13,'thresholds':2,'protocols':2,'sessions':13*2*2,
             'method_opportunities':13*2*2*216,'unique_cutoff_opportunities':432,
             'predictor':4916,'selector':192,'calls':4916+192},
 'total_actual_model_calls':2*(504+1)+4916+192,
 'reported_numeric_equivalence':{'echo_current':4915,'echo_baseline_other':1,'neither':0},
 'temperature':{'values_per_variable':51*730*20,'two_variables':2*51*730*20,
                'future_daily_pairs':730*4,'daily_probability_positions':730*4*3,
                'three_day_positions':730*2*2,'all_opportunities':730*4*3+730*2*2},
 'scope':'Independent arithmetic of report numbers; not independently recounted raw logs/data.'}
assert r['tests']['sum']==502
assert r['adaptive']['sessions']==52 and r['adaptive']['calls']==5108
assert r['adaptive']['method_opportunities']==11232
assert r['fixed_calls']['actual']==1010 and r['total_actual_model_calls']==6118
assert r['temperature']['two_variables']==1489200
assert r['temperature']['all_opportunities']==11680
Path(__file__).with_name('REPORT_ARITHMETIC.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'scope':r['scope'],'arithmetic_checks':'passed'},ensure_ascii=False))
