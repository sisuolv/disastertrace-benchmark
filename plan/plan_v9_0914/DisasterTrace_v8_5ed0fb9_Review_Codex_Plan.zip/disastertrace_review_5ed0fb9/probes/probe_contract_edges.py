#!/usr/bin/env python3
"""Read-only, synthetic, method-level probes for DisasterTrace 5ed0fb9.

Default: run inspected method/function excerpts with minimal support scaffolding.
--repo-root PATH: import the actual repository modules and invoke those methods.
This is NOT a replay of the published experiments or the 502-test suite.
No network, model, datasets, repository writes, or production-state changes.
"""
from __future__ import annotations
import argparse, dataclasses, hashlib, json, math, pathlib, sys
from types import SimpleNamespace

COMMIT = '5ed0fb94ae7bf235b37e7528e201b603271edffa'
PROVENANCE = {
 'outcomes.py': '5c8ce9e02aa28a977991f6b047c708391d36e20d',
 'admission.py': '24917aed622a8405ba53b6d9970f6f686ef14d68',
 'versions.py': '847668671020990cf44f694d9ea536e689ba8d8a',
 'contracts.py': '8287a69d4628b1c2f9a9ff9dad85eea4e2bbc625',
}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)

def fingerprint(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()

def finite(value):
    return type(value) in (int, float) and math.isfinite(value)

def timestamp(value):
    if type(value) is not int:
        raise ValueError("Timestamps must be integer UTC microseconds")

def require_fields(record, fields, label):
    if not isinstance(record, dict) or set(record) != set(fields.split()):
        raise ValueError("Unexpected or missing fields in " + label)

# These method excerpts reproduce the inspected logic; helper scaffolding is local.
OUTCOME_FIELDS = (
    "target_contract_hash resolution_version value status source_revision source_sha256 "
    "physical_start physical_end units quality_status observed_at published_at fetched_at "
    "resolved_at availability_basis"
)

class OutcomeRegistryExcerpt:
    def __init__(self, targets):
        self.targets = {target.contract_hash: target for target in targets}
        if not self.targets:
            raise ValueError("Outcome registry requires declared targets")
        self.records = {}

    def register(self, record):
        optional = {"references", "reference_kind"}
        required = {k: v for k, v in record.items() if k not in optional}
        require_fields(required, OUTCOME_FIELDS, "canonical outcome")
        if ("references" in record and not isinstance(record["references"], list)) or (
            "reference_kind" in record
            and (type(record["reference_kind"]) is not str or not record["reference_kind"])
        ):
            raise ValueError("Invalid optional outcome provenance")
        record = json.loads(canonical(record))
        target = self.targets.get(record["target_contract_hash"])
        if target is None:
            raise ValueError("Unknown outcome target")
        if (record["physical_start"], record["physical_end"], record["units"]) != (
            target.physical_start,
            target.physical_end,
            target.units,
        ):
            raise ValueError("Outcome physical support or units differ from target")
        for name in (
            "physical_start",
            "physical_end",
            "observed_at",
            "published_at",
            "fetched_at",
            "resolved_at",
        ):
            if record[name] is not None:
                timestamp(record[name])
        if record["status"] not in {"mature", "provisional", "missing"}:
            raise ValueError("Unknown outcome resolution status")
        if any(
            type(record[k]) is not str or not record[k]
            for k in ("resolution_version", "quality_status", "status")
        ):
            raise ValueError("Outcome resolution and quality required")
        value = record["value"]
        if value is not None and (
            not finite(value) or (target.output_kind == "event_probability" and value not in (0, 1))
        ):
            raise ValueError("Outcome violates target value type")
        if record["status"] == "mature" and (value is None or not record["source_revision"]):
            raise ValueError("Mature outcome requires a bound result")
        sha = record["source_sha256"]
        if record["status"] != "missing" and (
            not isinstance(sha, str)
            or len(sha) != 64
            or any(c not in "0123456789abcdef" for c in sha)
        ):
            raise ValueError("Canonical outcome needs full source hash")
        if record["availability_basis"] not in {
            "declared_archive_scenario",
            "observed_first_seen",
            "documented_historical_release",
        }:
            raise ValueError("Outcome availability basis required")
        known = [record[k] for k in ("fetched_at", "resolved_at")]
        if None not in known and known[0] > known[1]:
            raise ValueError("Resolution cannot precede local acquisition")
        key = (target.contract_hash, record["resolution_version"])
        if key in self.records:
            if self.records[key] != record:
                raise ValueError("Canonical target outcome conflict across opportunities")
            return False
        self.records[key] = record
        return True

class ComparisonContractExcerpt:
    def __init__(self, invariants, allowed_interventions):
        self.invariants = json.loads(canonical(invariants))
        self.allowed_interventions = json.loads(canonical(allowed_interventions))
        if not self.invariants or any(
            not values or not isinstance(values, list)
            for values in self.allowed_interventions.values()
        ):
            raise ValueError("Explicit comparison invariants and intervention values required")

    def validate(self, invariants, interventions):
        if invariants != self.invariants:
            raise ValueError("Common comparison contract changed")
        if set(interventions) != set(self.allowed_interventions) or any(
            interventions[key] not in values for key, values in self.allowed_interventions.items()
        ):
            raise ValueError("Unregistered experiment intervention")

# The policy_intervention branch of AdmissionEngine._process, with other
# branches omitted. It has the same inputs and statements as the source branch.
def process_intervention_excerpt(self, event):
    p, at = event.payload, event.time
    if event.kind == "policy_intervention":
        allowed = {
            "acquire", "predict", "selector_kind", "query_limit_per_tick", "per_tick_forecast_cap",
        }
        if not p.get("parent_checkpoint_sha256") or not set(p.get("changes", {})) <= allowed:
            raise ValueError("Unregistered policy branch intervention")
        self.active_interventions.update(p["changes"])
        self.attempts.append(
            {"event_id": event.event_id, "time": at, "status": "policy_intervention", **p}
        )
        return
    raise AssertionError("Only the excerpted branch is exercised")

def latest_issuance(products):
    products = list(products)
    if any(type(row.get("issued_at")) is not int for row in products):
        raise ValueError("Native version ordering requires integer issuance times")
    latest = max((row["issued_at"] for row in products), default=None)
    return ([row for row in products if row["issued_at"] == latest],
            [row for row in products if row["issued_at"] != latest])

def current_taf_excerpt(products, *, station, cutoff, start, end, lag_us=120_000_000):
    """Select a disclosed issuance in one station's TAF series before projection."""
    visible = [p for p in products if p["station"] == station and p["issued_at"] + lag_us <= cutoff]
    current, _ = latest_issuance(visible)
    if not current:
        return {"status": "no_product", "source_ids": []}
    source_ids = sorted(p["source_id"] for p in current)
    if len({p["native_semantics_sha256"] for p in current}) != 1:
        return {"status": "conflict", "source_ids": source_ids}
    selected = min(current, key=lambda p: p["source_id"])
    status = selected["status"]
    if status in {"active", "unparsed"} and not (
        selected["valid_start"] <= start < end <= selected["valid_end"]
    ):
        status = "current_version_does_not_cover_target"
    return {"status": status, "source_ids": source_ids,
            "selected_id": selected["source_id"], "issued_at": selected["issued_at"]}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo-root', type=pathlib.Path)
    p.add_argument('--output', type=pathlib.Path, required=True)
    args=p.parse_args()
    Registry,Comparison,process,version = OutcomeRegistryExcerpt,ComparisonContractExcerpt,process_intervention_excerpt,current_taf_excerpt
    target = SimpleNamespace(contract_hash='a'*64, physical_start=1_000_000_000,
       physical_end=1_000_000_000, units='degC', output_kind='scalar',
       temporal_semantics='future_physical', support_kind='point')
    mode='source_excerpt_with_scaffolding'
    if args.repo_root:
        sys.path.insert(0,str(args.repo_root/'disastertrace-starter'/'src'))
        from disastertrace.monitoring_fixed_v1.outcomes import OutcomeRegistry, ComparisonContract
        from disastertrace.monitoring_fixed_v1.admission import AdmissionEngine
        from disastertrace.monitoring_fixed_v1.contracts import Target
        from disastertrace.monitoring_v1.providers.versions import current_taf
        Registry,Comparison,process,version=OutcomeRegistry,ComparisonContract,AdmissionEngine._process,current_taf
        target=Target(target_id='synthetic',entity='station:SYNTH',variable='temperature',units='degC',
          output_kind='scalar',support_kind='point',physical_start=1_000_000_000,physical_end=1_000_000_000,
          temporal_semantics='future_physical',report_policy='synthetic_point_observation.v1')
        mode='actual_repository_methods_with_synthetic_fixtures'
    base=dict(target_contract_hash=target.contract_hash,resolution_version='r1',value=1.0,status='mature',
      source_revision='observed-r1',source_sha256='b'*64,physical_start=target.physical_start,
      physical_end=target.physical_end,units=target.units,quality_status='accepted',
      observed_at=target.physical_start,published_at=1_010_000_000,fetched_at=1_020_000_000,
      resolved_at=1_030_000_000,availability_basis='observed_first_seen',reference_kind='measurement')
    results=[]
    def attempt(name,change,desired):
        try:
            accepted=Registry([target]).register({**base,**change})
            observed='accepted' if accepted else 'duplicate'
        except Exception as exc:
            observed='rejected'; error=type(exc).__name__+': '+str(exc)
        row={'id':name,'observed':observed,'desired_for_future_live_gate':desired}
        if observed=='rejected':row['error']=error
        row['gap_observed']=observed!=desired
        results.append(row)
    attempt('O1_valid_chronology',{},'accepted')
    attempt('O2_resolution_before_fetch',{'resolved_at':1_015_000_000},'rejected')
    attempt('O3_known_measurement_not_yet_occurred',
      {'published_at':800_000_000,'fetched_at':810_000_000,'resolved_at':820_000_000},'rejected')
    attempt('O4_known_revision_published_after_fetch',{'published_at':1_050_000_000},'rejected')
    inv={'frozen':'synthetic'}; cmp=Comparison(inv,{'selector_kind':['round_robin']})
    obj=SimpleNamespace(active_interventions={'selector_kind':'round_robin'},attempts=[])
    middle_rejected=False
    for i,kind in enumerate(['batch_complete','round_robin']):
        event=SimpleNamespace(kind='policy_intervention',time=i+1,event_id=f'change-{i}',
            payload={'parent_checkpoint_sha256':'c'*64,'changes':{'selector_kind':kind}})
        try:process(obj,event)
        except ValueError:middle_rejected=True; break
    try:cmp.validate(inv,obj.active_interventions); final_accepted=True
    except ValueError:final_accepted=False
    results.append({'id':'C1_transient_unregistered_factor_then_restore',
        'intermediate_rejected':middle_rejected,'final_contract_accepted':final_accepted,
        'history':obj.attempts,'gap_observed':not middle_rejected and final_accepted,
        'scope':'method-level; not a replay of score_admitted or the published session logs'})
    try:cmp.validate(inv,{'selector_kind':'batch_complete'}); rejected=False
    except ValueError:rejected=True
    results.append({'id':'C2_final_disallowed_factor_control','rejected':rejected,'gap_observed':not rejected})
    old={'station':'KSFO','issued_at':0,'source_id':'old','native_semantics_sha256':'a',
         'status':'active','valid_start':0,'valid_end':100}
    newer={**old,'issued_at':20,'source_id':'new','native_semantics_sha256':'b','valid_start':20,'valid_end':50}
    row=version([old,newer],station='KSFO',cutoff=40,start=60,end=70,lag_us=0)
    results.append({'id':'V1_newer_noncover_does_not_revive_old','result':row,
                    'passed':row['status']=='current_version_does_not_cover_target'})
    row=version([newer,{**newer,'source_id':'mirror','native_semantics_sha256':'c'}],
        station='KSFO',cutoff=40,start=30,end=35,lag_us=0)
    results.append({'id':'V2_same_issuance_conflict_not_filename_order','result':row,'passed':row['status']=='conflict'})
    output={'commit_reference':COMMIT,'mode':mode,'scope':'Synthetic method-level probes; no datasets/models/full project suite.',
      'source_git_blob_ids':PROVENANCE,'probe_count':len(results),'results':results,
      'interpretation':'Observed acceptance gaps require full production-entry tests and an impact scan. They do not establish any published score is wrong.'}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'mode':mode,'probes':len(results),'observed_gaps':[r['id'] for r in results if r.get('gap_observed')]},ensure_ascii=False))
if __name__=='__main__':main()
