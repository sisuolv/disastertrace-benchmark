# 直接交给 Codex 的启动任务

请检查当前 `disastertrace-benchmark` / `next-phase-v1` 工作副本，并按附件实施，不要只再写计划。

审阅基准：`5ed0fb94ae7bf235b37e7528e201b603271edffa`。
若本地已有新代码或修复，先比较与复用；不要回退、reset、clean、覆盖未提交改动或自动push。

依次读：

1. 当前仓库最新 README、`plans/v8_measurement_execution_20260913_01/REVIEW_REQUEST_CN.md`、实际执行报告、分数表、`WORK_PACKAGE_PROGRESS_02.json`、`NEXT_PHASE_PLAN_CN.md`。
2. 本包 `AUDIT_REPORT_CN.md`、`CODEX_NEXT_PLAN_CN.md`、`WORK_PACKAGE_DELTA.json`。
3. 本包 `results/local_probe_results.json`：21个局部观察不是全库测试；F01是Git blob一致模块的直接反例，F02只到函数替身级，必须在真实journal入口核实。

保持当前 **v8 / W00–W19 / C1-C2-C3 / E-F-D-MM / X00–X09**。旧v7/CP/DS只是历史，不能覆盖当前进度。不要重建新的顶层引擎。

## 首批执行

`W00.refresh → W01.regressions → W05.identity / W04.trace → W06.impact → W07.echo`

- **W00.refresh**：核HEAD、本地变化、旧冻结、数据和执行范围。已完成工作不重新列planned。
- **W01.regressions**：将本包反例写成真实生产入口测试，保留red日志，不仅测试复制片段。
- **W05.identity**：修复 `execution_identity` 对 backend.execution_contract 的可变字典引用；绑定前后与恢复/dispatch都能拒绝实际配置漂移。
- **W04.trace**：检查ComparisonContract是否验证初始、每个中间生效干预和最终状态。真实journal测试中，未登记query_limit中途99再回1也应拒绝；合法登记动态策略仍允许。
- **W06.impact**：扫描原捕获与journal，列affected/unchanged/not_evaluated。不要把局部缺口扩大成旧结果全部无效，也不要直接写全部无影响。
- **W07.echo**：新增COPY_CURRENT与COPY_BASELINE连续程序对照，与FOLLOW分开；自己的程序成本重新执行。已完成的4916条可见值归因直接复用，不当新实验。

## 必须保留的事实

52个自适应会话、5108次调用和四组计分已经完成，不为跑出收益重开旧矩阵。
当前235B的4916个F回答中，4915等于可见当前值，1个等于最新基线；这不证明内部思维，也不复现selector/E行为。
当前auto-propose自动安装OVERRIDE，概率同值不能改名FOLLOW，也不能写成模型自主选择动作。
温度原生六小时极值→日/三日配对及480快照已经做了，下一步是连续会话，不再只找数据。
X09实际调用0、D是条件回放/研究假设、前瞻是source-only，分别按自己的门槛推进。

## 运行边界

本批默认本地CPU和已有本地资料，不启动GPU、付费API、海量新下载、持续外部采集或真实业务操作。旧授权时段是历史，后续有新授权时在新freeze中记账，不重开已消费launcher。缺依赖/文件时给具体阻塞，并继续可独立完成任务，不伪造外部返回、模型回答或成功回执。

保存原源码、原输入/回答/失败、原评分。改变输入需新调用；改变gate/评分的固定捕获分析另命名；重新选源的策略必须重新运行或标未评估。

## 首批交付

实际代码差异、生产入口测试及完整命令回执、旧结果影响清单、两个COPY程序与FOLLOW的新全日历对照或准确阻塞、原结果保全记录、下一批任务。区分本次新测试与仓库历史502测试，不合并不同运行计数；所有零/负结果保留。

首批结束后按详细计划并行做W11基线/数据与W13温度连续会话。W14/W15有界核准，W16应用闭环和W12.x09独立推进；核心确认依赖W12.core，不等待完整X09/D/MM/前瞻/16类。
