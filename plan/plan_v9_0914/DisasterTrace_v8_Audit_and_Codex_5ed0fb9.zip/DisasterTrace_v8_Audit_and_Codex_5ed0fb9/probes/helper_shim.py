"""Only the five exact pure helpers read from contracts.py; not the full module."""
import hashlib
import json
import math


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def fingerprint(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def timestamp(value):
    if type(value) is not int:
        raise ValueError("Timestamps must be integer UTC microseconds")


def require_fields(record, fields, label):
    if not isinstance(record, dict) or set(record) != set(fields.split()):
        raise ValueError("Unexpected or missing fields in " + label)
