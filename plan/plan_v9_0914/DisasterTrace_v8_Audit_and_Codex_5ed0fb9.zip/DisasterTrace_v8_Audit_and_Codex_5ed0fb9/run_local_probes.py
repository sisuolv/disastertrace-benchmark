#!/usr/bin/env python3
"""Read-only, no-network local audit probes for commit 5ed0fb9.

The code under local_src contains exact Git-blob-verified upstream files.
The scoring probe uses a copied function with synthetic engine/journal-loader
and arithmetic stubs. It is NOT a full production journal replay.
A 'defect_reproduced' verdict is not a passing correctness claim.
"""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'local_src'))
EXPECTED = {
 'disastertrace/monitoring_v1/targets.py':'df3862303f5ec9b28ab4c20969b88861ed06bf74',
 'disastertrace/monitoring_v1/execution.py':'07a54b0ed418049959bbbc3adbdab746419a3eec',
 'disastertrace/monitoring_v1/event_loop.py':'22e38a02b6508476591f6db54246b663eac0c205',
 'disastertrace/monitoring_v1/providers/versions.py':'847668671020990cf44f694d9ea536e689ba8d8a',
 'disastertrace/monitoring_fixed_v1/outcomes.py':'5c8ce9e02aa28a977991f6b047c708391d36e20d',
}
manifest=[]
for rel, expected in EXPECTED.items():
 b=(ROOT/'local_src'/rel).read_bytes()
 h=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 if h!=expected: raise RuntimeError(f'Unverified source: {rel}: {h}')
 manifest.append(dict(path=rel,git_blob_sha=h,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))

from disastertrace.monitoring_v1.execution import bind_execution
from disastertrace.monitoring_v1.providers.versions import current_taf, latest_issuance
from disastertrace.monitoring_v1.event_loop import run_clock

spec=importlib.util.spec_from_file_location('disastertrace.monitoring_fixed_v1.contracts', ROOT/'probes/helper_shim.py')
helpers=importlib.util.module_from_spec(spec); spec.loader.exec_module(helpers)
sys.modules[spec.name]=helpers
from disastertrace.monitoring_fixed_v1.outcomes import OutcomeRegistry, ComparisonContract

observations=[]
def note(name, condition, detail, *, defect=False, scope='exact_module_synthetic_inputs'):
 if not condition: raise AssertionError(f'Probe did not reproduce expected observation: {name}')
 observations.append(dict(id=name, verdict='defect_reproduced' if defect else 'expected_behavior_verified', scope=scope, detail=detail))
def rejected(fn):
 try: fn()
 except (ValueError,TypeError): return True
 return False

class Backend:
 def __init__(self):
  self.execution_contract={'model':'synthetic','weights':'test-sha','tokenizer':'tok','adapter':'adapter','generation':{'temperature':0},'runtime':{'mode':'local'}}
 def __call__(self,*args): raise AssertionError('Never invoke a model in this test')
b=Backend(); cfg=bind_execution({},b); frozen_control=copy.deepcopy(cfg)
shared=cfg['execution_contract']['declared'] is b.execution_contract
b.execution_contract['generation']['temperature']=0.8
accepted=not rejected(lambda:bind_execution(cfg,b))
note('ID01',shared and accepted and cfg['execution_contract']['declared']['generation']['temperature']==0.8,
 'Bound config aliases backend.execution_contract; nested mutation silently changes both and rebind accepts it.',defect=True)
note('ID02',rejected(lambda:bind_execution(frozen_control,b)), 'A separately deep-copied frozen config correctly rejects the same drift.')

# Exact native-version helper: no archive builder or full runtime invoked.
def p(sid,issued,sem='same',status='active',start=0,end=200):
 return dict(source_id=sid,issued_at=issued,native_semantics_sha256=sem,status=status,station='KAAA',valid_start=start,valid_end=end)
def select(rows,cutoff=50,start=100,end=120):
 return current_taf(rows,station='KAAA',cutoff=cutoff,start=start,end=end,lag_us=0)
note('V01',select([p('new',20),p('old',10)])['selected_id']=='new','Late array position does not let older issuance replace newer.')
note('V02',select([p('old',10),p('new',20,end=110)])['status']=='current_version_does_not_cover_target','Newest short window does not revive the older covering product.')
note('V03',select([p('old',10),p('cancel',20,status='canceled')])['status']=='canceled','New cancellation remains current.')
note('V04',select([p('z',20,sem='one'),p('a',20,sem='two')])['status']=='conflict','Same-issuance semantic conflict is not resolved by alias ordering.')
note('V05',select([p('z',20),p('a',20)])['selected_id']=='a','Equivalent same-issuance mirrors allow a stable alias.')
note('V06',select([p('old',10),p('future',60)])['selected_id']=='old','Future unavailable product is excluded.')
note('V07',rejected(lambda:latest_issuance([p('bad',True)])),'Boolean issuance is rejected.')

# Exact clock with an explicit owner/event harness, not AdmissionEngine transactions.
class Event:
 def __init__(self,event_id,time,kind,payload=None):
  self.event_id,self.time,self.kind,self.payload=event_id,time,kind,payload or {}
 def to_dict(self): return dict(event_id=self.event_id,time=self.time,kind=self.kind,payload=self.payload)
class Owner:
 def __init__(self):
  self._last_time=None;self._events={};self._processed=set();self.journal=None
  self.opportunities={'o':SimpleNamespace(opportunity_id='o',cutoff=10)};self.snapshots={};self.trace=[]
 def _expiry_times(self,upcoming): return []
 def _process(self,e): self.trace.append((e.time,e.kind))
 def _invalidate(self,t): self.trace.append((t,'invalidate'))
 def _seal(self,t):
  if t==10:self.snapshots['o']='sealed';self.trace.append((t,'seal'))
 def _after_seal(self,t):self.trace.append((t,'after_seal'))
phases={'baseline':0,'completion':1,'begin':5}
def run(o,events,end=10):return run_clock(o,events,until=end,event_order=phases,decode=lambda r:Event(**r))
o=Owner(); bad=[Event('x',5,'baseline'),Event('x',6,'baseline')]
note('C01',rejected(lambda:run(o,bad)) and not o._events,'Conflicting duplicate batch leaves no registered prefix.',scope='exact_clock_owner_harness')
o=Owner();note('C02',rejected(lambda:run(o,[Event('good',5,'baseline'),Event('bad',6,'unknown')])) and not o._events,'Invalid phase leaves no partially registered batch.',scope='exact_clock_owner_harness')
o=Owner();run(o,[Event('b',10,'begin'),Event('c',10,'completion'),Event('a',10,'baseline')]);order=[k for t,k in o.trace if t==10]
note('C03',order.index('baseline')<order.index('completion')<order.index('seal')<order.index('begin'),'Same-time baseline/completion precede seal; begin follows.',scope='exact_clock_owner_harness')
note('C04',rejected(lambda:run(o,[Event('back',10,'completion')],end=11)),'A new event at already processed boundary is rejected.',scope='exact_clock_owner_harness')
o=Owner();o._clock_running=True;note('C05',rejected(lambda:run(o,[])),'Clock reentry is rejected.',scope='exact_clock_owner_harness')

# Exact outcome/ComparisonContract module; pure helper shim and small Target harness.
class Target:
 contract_hash='a'*64;physical_start=100;physical_end=120;units='m';output_kind='event_probability'
 def to_dict(self):return {'contract_hash':self.contract_hash}
t=Target()
def outcome():return dict(target_contract_hash=t.contract_hash,resolution_version='r1',value=0,status='mature',source_revision='s',source_sha256='b'*64,physical_start=100,physical_end=120,units='m',quality_status='ok',observed_at=120,published_at=130,fetched_at=140,resolved_at=150,availability_basis='declared_archive_scenario')
r=OutcomeRegistry([t]);rec=outcome();r.register(rec)
note('O01',r.register(rec) is False,'Identical canonical outcome registration is idempotent.',scope='exact_outcomes_pure_helper_target_harness')
note('O02',rejected(lambda:r.register({**rec,'value':1})),'Conflicting value for same target and result version is rejected.',scope='exact_outcomes_pure_helper_target_harness')
note('O03',rejected(lambda:OutcomeRegistry([t]).register({**rec,'units':'km'})),'Result unit mismatch is rejected.',scope='exact_outcomes_pure_helper_target_harness')
note('O04',rejected(lambda:OutcomeRegistry([t]).register({**rec,'value':True})),'Boolean event value is rejected.',scope='exact_outcomes_pure_helper_target_harness')
r.register({**rec,'resolution_version':'r2'});ops=[SimpleNamespace(opportunity_id='o1',target=t),SimpleNamespace(opportunity_id='o2',target=t)]
note('O05',rejected(lambda:r.opportunity_rows(ops,{'o1':'r1','o2':'r2'})),'Different result versions across leads for same target are rejected.',scope='exact_outcomes_pure_helper_target_harness')

# Actual scoring function excerpt, synthetic loaded engines and collector.
# No assertion about historical journals is made by this function-level probe.
ns={'__name__':'scorer_harness','canonical':helpers.canonical,'fingerprint':helpers.fingerprint,'require_fields':helpers.require_fields}
class Loader:
 @classmethod
 def from_journal(cls,path):return path
ns['AdmissionEngine']=Loader
ns['paired_scores']=lambda rows,arms:{'reached_arithmetic':True,'n':len(rows),'arms':list(arms)}
exec(compile((ROOT/'probes/score_admitted_excerpt.py').read_text(),'upstream_score_admitted_excerpt','exec'),ns)
invariant={'dataset':'synthetic-fixed'}
comp=ComparisonContract(invariant,{'query_limit_per_tick':[1]})
engine=SimpleNamespace(contract={'schema':'test','experiment':{'invariants':invariant,'interventions':{'query_limit_per_tick':1}}},active_interventions={'query_limit_per_tick':1},protocol='base_bound_override',calls={},opportunities={'o':SimpleNamespace(target=t)},targets={'t':t},snapshots={'o':{'forecast':{'value':0.2}}},contract_hash='test',time_basis='declared_archive_scenario',attempts=[])
engine._events={
 'branch1':{'time':1,'kind':'policy_intervention','payload':{'parent_checkpoint_sha256':'p','changes':{'query_limit_per_tick':99}}},
 'branch2':{'time':2,'kind':'policy_intervention','payload':{'parent_checkpoint_sha256':'q','changes':{'query_limit_per_tick':1}}},
}
out=[dict(opportunity_id='o',target_contract_hash=t.contract_hash,value=0,status='mature',source_revision='s')]
score=ns['score_admitted'](out,{'arm':engine},comparison=comp)
note('F01',score['scores']['reached_arithmetic'],
 'An unregistered intermediate query_limit_per_tick=99 is ignored when final active_interventions returns to allowed 1.',defect=True,scope='scoring_function_excerpt_synthetic_engine_loader_no_journal_replay')
engine.active_interventions={'query_limit_per_tick':99}
note('F02',rejected(lambda:ns['score_admitted'](out,{'arm':engine},comparison=comp)),
 'The same unregistered value is rejected when it remains the final value.',scope='scoring_function_excerpt_synthetic_engine_loader_no_journal_replay')

result={'base_commit':'5ed0fb94ae7bf235b37e7528e201b603271edffa','network_used':False,'model_calls':0,'gpu_calls':0,
 'full_repo_tests_run':False,'full_historical_journals_replayed':False,'upstream_files_verified':manifest,
 'checks':observations,'check_count':len(observations),'defects_reproduced':sum(x['verdict']=='defect_reproduced' for x in observations),
 'expected_behavior_checks':sum(x['verdict']=='expected_behavior_verified' for x in observations),
 'limits':'Source identity probe is direct exact-module execution. Clock/outcome checks use declared harnesses. Scorer counterexample is function-level only, not a full engine/journal integration test; past run impact remains unassessed.'}
(ROOT/'results').mkdir(exist_ok=True)
(ROOT/'results/local_probe_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['check_count','defects_reproduced','expected_behavior_checks','model_calls','full_repo_tests_run']},indent=2))
