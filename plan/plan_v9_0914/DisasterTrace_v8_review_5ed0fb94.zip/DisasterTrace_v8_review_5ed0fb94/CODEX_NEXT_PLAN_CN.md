# DisasterTrace v8：基于 5ed0fb94 的复查与下一阶段 Codex 执行计划

审查基准：`5ed0fb94ae7bf235b37e7528e201b603271edffa`（提交时间 2026-09-14 03:04:43 UTC；纽约 2026-09-13 23:04:43）。
仓库：`sisuolv/disastertrace-benchmark`；分支：`next-phase-v1`。

本文件是后续执行规格，不是新实验完成声明。继续 v8、C1/C2/C3、E/F/D/MM、X00—X09 与 W00—W19，不另起研究版本，不重做已经完成的工作。

## 0. 先阅读什么，以及哪些结论已经变化

依次读取当前工作区的：

1. `plans/v8_measurement_execution_20260913_01/REVIEW_REQUEST_CN.md`
2. `RUN_REPORT_CN.md`、`ADAPTIVE_SCORECARD_CN.md`、`NEXT_PHASE_PLAN_CN.md`（同目录）
3. `WORK_PACKAGE_PROGRESS_02.json`、`EXECUTION_STATUS.json`、`REGRESSION_MATRIX_07.json`
4. `TEMPERATURE_DAILY_FORECAST_CN.md`、`X09_PROTOCOL_CN.md`
5. `publication/v8_measurement_20260914/README_CN.md`

不要用旧文档中的“下一步”覆盖最新执行证据。HEAD 已前进时，先做只读差异比较；不要 reset/checkout 覆盖开发工作区，也不要强行应用只针对旧函数的补丁。

| 事项 | 5ed0fb94 的证据状态 | 下一步含义 |
|---|---|---|
| W01/W02/W04/W05 | 当前登记范围的原生版本、结果唯一性、可比性和执行身份机制已实现；报告共 502 项不同相关测试 | 保留既有回归，只补本次边界及真正未覆盖的场景 |
| W03/W08 | 类型化事件事务、失败回执、本地串行 source/selector/predictor 在途恢复已实现 | 不再将“只有静止点恢复”写为当前状态；一般并发和任意远端 exactly-once 未证明 |
| W07 | 40 条全日历程序轨迹及新旧评分器对照已完成 | 不再将完成 432 机会程序首跑作为新任务 |
| W10 | 235B/8B 各 504 个固定输入正式回答，另各 1 次兼容调用 | 不再反复做 epoch/ISO 或强迫 F 改概率的提示搜索 |
| W12 | 52 个全日会话、5,108 次调用和四组独立评分完成；X09 尚无模型调用 | 使用新结果确定下一个问题，不重启原自适应批次 |
| 可见概率审计 | 4,916 个预测提议中，4,915 个等于当前状态值，余下 1 个等于最新基线；0 个同时不同于两者 | 同输入数值来源审计已经完成；缺的是新冻结的闭环程序对照 |
| W11/W17 | 五份已暴露日历，12,528 个 cutoff 机会对应 2,148 个站点物理窗口；独立过程数未知 | 补完整输入足迹隔离和训练/校准设计，不将更多 lead/threshold 当独立事件 |
| W13 | 原生六小时 max/min 与 DWD 日值/三日目标数值链完成，480 个准入快照通过 | 不再重新寻找日极值产品；接连续会话与真正补充证据 |
| W18 | 4h、34 次请求、25 个不同产品的 source-only shadow | 不是已完成在线预测；单独冻结预测和结算，不阻塞历史研究 |

## 1. 审查范围与证据等级

本次外部审查实际阅读了最新源码、报告与计划，并执行 `review_checks.py` 的 36 个原函数隔离情形。31 个是正常/保护路径控制，5 个复现 3 类边界。测试周围的 engine、ledger、backend、journal reader 使用明确的测试替身，因此不是整个项目 502 项回归，也不是完整生产 journal 集成重放。

`event_loop.py` 和 `providers/versions.py` 的完整源文件字节已与 GitHub blob SHA 核对一致。其余是读取到的原函数摘录；随附脚本的 `--repo` 可在匹配该提交的完整 checkout 上核对完整文件 SHA 与函数 AST。

外部容器无法解析下载主机，未取得完整复查 ZIP；未重放该包的两条 216 机会 journal，也未重新运行 GPU。不得把本文件中的已读结果写成外部审查已经独立重算。

分类规则：`confirmed_in_isolated_function`、`source_supported_fix`、`integration_test_required`、`design_limit`、`scientific_claim_not_established` 分别记录。本次没有证据认定现有 52 个会话的分数已经错误。

## 2. 不可改变的执行原则

保护当前 HEAD、staged/unstaged/untracked 和旧冻结文件。输出到新的唯一目录，输入只读，禁止按题择优替换旧输出。历史修复重算、旧捕获重放和新模型调用分别记账。

当前规划不增加 GPU、付费 API、模型训练、外部下载或后台任务授权。已有 12h/四卡运行时段已经结束，不能因为过去授权过就重开 launcher；有另行有效授权时按其实际额度执行，最多并发 4 张 H100，禁止自动续期。CPU 本地审计、轻量程序对照先行；涉及新拟合亦需登记范围和资源，不默认为大模型训练许可。

预留确认周 `2025-02-17` 至 `2025-02-23` 在设计冻结前保持关闭。不要为了探测正例数量先打开它。其他确认地区/日期同样执行访问日志与失败记录。

所有“通过”均指明确范围，不把代码正确、样例可读、物理语义成立、独立机制确认和 16 类全部完成混为一谈。

## 3. 本次新增的具体代码边界

### R1 / P1：异常结束时间可能早于已经观测到的实际等待

位置：`monitoring_fixed_v1/adaptive.py::TypedAviationRuntime.execute()` 的通用异常分支；同时检查 `resume_pending()` 与 `_complete_execution()` 的失败路径。

当前代码记录 `observed_wall_seconds`，但失败事件的推进量仅取配置的 `public_call_slot_ms` 或 `call_compute_cap_ms`。定向测试令实际等待为 40 秒、compute cap 为 1 秒：返回的逻辑失败时间为 1 秒。设目标截止 10 秒时，局部失败记录仍被认为及时。公开时隙 30 秒时也可能把 40 秒异常放在 30 秒。

这不是时钟数值倒退，而是将已经发生的等待缩短了；可能影响后续查询机会、截止判断和其他目标调度。费用保守预留虽已修复，时间仍是另一约束。当前捕获未被证明触发此路径。

最小修复规格：

- 先用真实 Runtime、Ledger、临时 journal 与可控单调钟，将反例转为生产入口红测试；测试不实际 sleep 40 秒。
- 明确失败分类：dispatch 前失败；dispatch 后返回异常；原请求 pending；已知完成但回执非法；持久化失败。
- actual_cost_clock 下，失败处置时间不得早于原 dispatch 至本次实际观测的已知时间下界，也不得早于 runtime 已处理时钟；已知等待不能被 compute cap 截短。
- public_schedule 的名义时隙不是额外真实等待的赦免；超时后保留超限和晚到，不能把回答挪回原 slot。
- 对跨进程 pending，用原 dispatch/first-observed receipt 和版本绑定推导累计时间；本次 poll 的局部耗时不等于总时延。尚未知的部分明确记录，不臆造已完成或零费用。
- 不把未知 compute token 等同已知 wall time。保守预留与费用最终化继续幂等。
- 主会话继续使用唯一时钟，不创建一个独立“错误时钟”。同刻顺序、精确截止和反复 resolve 另加测试。
- 先筛查已有轨迹是否存在相应状态与时间关系；只有匹配到的条目做影响重放，保留旧分数与修复后反事实。不得不加区别重跑全部 LLM。

验收：40 秒等待的异常不能产生 1 秒合法调度进展；跨截止不能获得原本已丧失的后续机会；费用与失败分母完整；既有普通完成与超 slot 回归保持。

### R2 / P2：数值有限不保证时间单位转换安全

位置：`adaptive.py::_complete_execution()`；并核 `monitoring_v1/execution.py::observe_reserved_backend()`。

`seconds=1e308` 是有限浮点数，但乘 1,000,000 后溢出；`math.ceil` 抛出 `OverflowError`。`seconds=10**400` 在 `math.isfinite` 处就可能抛错。当前类型化校验只捕获 KeyError/TypeError/ValueError；同类转换在普通 backend 观察函数中也位于有限性检查后的边界。

最小修复：统一“类型→非负/有限→单位转换→可表示性→合同范围”的检查，并将转换异常纳入相同失败最终化。保留已收到 raw、已知费用和未知标志；不要通过裁剪 duration 或 actual cost 到预算上限伪造合规。超出资源上限与不可解释的元数据是不同状态。

验收：超大浮点、超大整数、NaN、Inf、负值、布尔、字符串、elapsed<compute 及正常大/小值都有确定的拒绝或处置；不会因转换异常跳出而漏掉回执。该问题属于防御性边界，不声称实际 worker 返回过这样的时间。

### R3 / P2：X09 超大概率整数逃逸为 OverflowError

位置：`monitoring_fixed_v1/joint_targets.py::parse_joint_response()`。

401 位 JSON 整数满足 Python int 类型检查，随后 `math.isfinite` 抛出 OverflowError，而不是统一的无效概率 ValueError。有效概率、布尔、NaN、缺目标与重复 JSON key 已被定向控制确认处理正确。X09 本批没有模型调用，所以不影响本批 X09 模型分数（不存在此分数）。

最小修复：先检查概率范围或使用共享的安全数值检查器，统一异常边界；在完整 X09 scorer/worker 测试中确认异常按整个请求失败，三个目标都保留并回退，不允许仅挽救某个目标。保留原384请求冻结，新的修复/调用有新身份。

## 4. 第一批执行：修最小边界，补最关键对照，不重开大模型矩阵

### W00/W01/W19 — Baseline 与复现范围

记录实际版本、工作区、依赖、输入清单和当前任务状态。首先在已有本地完整材料中运行两个 `portable_replay_01/replay.py` 样例，核其迁移后的 216 机会分数；依据 `REGRESSION_MATRIX_07.json` 的实际命令运行相关测试，不凭空猜新的 pytest 路径。缺 fixture 时区分资料缺失与代码失败，不能计为通过或静默跳过。

随附脚本可执行：

```bash
python review_checks.py --output /tmp/dt-v8-external-probes.json
# 只对匹配 5ed0fb94 的只读完整源码副本使用：
python review_checks.py --repo /path/to/pinned_checkout --output /tmp/dt-v8-ast-checked.json
```

脚本是函数隔离检查。应另写生产入口集成用例，不把本脚本当成 502 项测试替代品。HEAD 变化导致 SHA 不匹配时停止套用旧断言，先审差异。

产物：`BASELINE.json`、`SCOPE.json`、`TEST_COMMANDS.json`、原日志、`REPRODUCE_RECEIPT.json`、`SOURCE_DIFF.json`。

### W01/W03/W05/W08 — R1/R2/R3 红绿回归与历史影响

先红测试，修复后绿测试，正常路径与失败路径同测。R1 是下一轮涉及时延/失败的会话前置；R2/R3 一并小修，避免扩成框架重写。恢复只声称已验证的本地串行边界，不追求无凭据的远端 exactly-once。

旧数据影响清单按 `unaffected_by_path / path_present_no_violation / affected_in_replay / unavailable_to_check` 分类。502 已通过测试的旧记录不修改；新测试去重计数。

产物：`FINDINGS_STATUS.json`、`FAILURE_CLOCK_ADR.md`、红绿日志、`HISTORICAL_IMPACT.json`、修复差异及新冻结。

### W07/W12 — 闭环可见值对照（最高科学优先级）

已完成的 `visible_forecast_values_consolidated_01` 是捕获输入上的数值归因，不必再当“新发现”重复做。现在需要新的真实程序会话。

先明确四种行为（不可互相改名）：

| 行为 | 输入 | 动作含义 |
|---|---|---|
| FOLLOW | 当前合法共同基线 | 清除自身 override，随专业/研究基线更新 |
| COPY_BASELINE_AS_OVERRIDE | dispatch 时 baseline.forecast.value | 按现有 typed_auto_propose 安装同值 override，仍是 override |
| COPY_CURRENT_AS_OVERRIDE | dispatch 时 state.forecast.value | 重新提出当前生效值；可能刷新 override 寿命 |
| NO_CHANGE/NO_NEW_PROPOSAL | 当前状态 | 不提交新候选，不刷新其到期；仅作协议控制，不能虚构为现有 F head 的输出动作 |

两个层次分别做：

1. **冻结输入数值等价核验**：引用原4,916条逐项分类（等当前、等基线、两者皆等、两者皆不等），保留唯一基线例外。不能将“精确相等”解释成已识别内部推理机制，也不能因此宣称重现 selector。
2. **新冻结闭环程序对照**：使用相同 data/bank、共同基线、资料权限、source预算、protocol与实际程序成本，重新运行候选、准入和状态更新。程序更快会改变后续轨迹，这本身是结果；不能将旧 LLM ledger 时间改短当作新会话。

先固定 batch/risk/coverage 中预登记的少数 selector，对比 FOLLOW、f(B)、f(B,E) 和 copy-current。两种 override 协议分开。COPY_CURRENT 应与 COPY_BASELINE 对照，避免错误把不断保留过去状态的收益写成新信息。

如需固定调用时间的算法隔离，只能另建明确的 captured-schedule replay 轨道（同一可见前缀与费用情景），不能冒充真实部署或重执行。新的算法调度与真实成本结果独立报告。

W07=72 source/公共30s，W12=48 source/实测交付，禁止直接跨批归因；新对照建立新的统一 manifest，不修改任何旧回执。

验收：所有机会保留，same-value override 与 FOLLOW 可区分；基线相关更新、过期、撤回、恰好截止、late completion、零额外证据分别测试；结果可以为零/负；全批量不是 F 上界。

产物：`COPY_CONTROL_PROTOCOL.md`、`ARMS.json`、新 program reports/journals、`COPY_CURRENT_CLOSED_LOOP.json`、分项help/harm/no-change与资源。

### W07/W19 — 推理与审计生命周期拆分

当前平台FAILED、推理exit=0、原自动审计未完成、补充审计通过，是四个不同事实。保留，不改写平台状态为成功。

后续将 GPU 推理完成/资料持久化与 CPU 审计设为独立有界阶段。审计必须按 session_id+输入/代码/结果SHA 保存可恢复完成清单；部分完成不产生 overall_pass；恢复不重推理。

并行回放缓存键至少包含 frozen verifier/source identity、journal bytes、解析/合同版本。缓存不修改已核验 engine；比较规范分数、合同、结果、准入和机会集合，而非只比较总均值。至少保留一个全13臂与原串行评分器的完整一致性控制，新优化还应加未共享同一缓存的独立子集。

明确总墙钟/任务终止逻辑；不能把 future.result(timeout) 当成取消正在运行的工作。不得用缓存过的新版代码替换旧冻结源。无需重新执行已经完成的52次推理。

产物：`AUDIT_STAGE_MANIFEST.json`、`SESSION_AUDIT_INDEX.json`、断点/故障回归、规范输出一致性表。

## 5. 第二批执行：建立能回答科学问题的数据基础

### W11/W17 — 完整输入足迹隔离与区域训练/校准

已有日历重合审计只覆盖注册E槽位、F窗口与部分TAF身份，足以否定简单独立划分，不足以认证完整purge。五份日历均为开发暴露，12,528机会不等于12,528独立样本。

新增每个机会/会话的 footprint：

- 物理目标及所有提前量/阈值别名；
- 完整 TAF 发行、有效窗、版本和镜像；
- 观测实际回看窗、派生资产祖先、共享缓存；
- 先前模型可见状态、跨目标摘要（若启用）；
- 银行训练与校准期、邻站和外部天气过程身份。

先利用元数据/身份建立连通依赖组和时间支持包络，不能一看到日期相差24h就宣布独立。24h只是下限候选；跨日TAF、三日目标和更长过程按实际支持扩大。报告72h/周级分组敏感性，但不能用少数簇的漂亮区间替代足够过程。

预留周保持未打开；不为计算这些隔离关系读取其结果。确认前冻结模型、提示、资料宇宙、selector/predictor、资源、采纳、结果版本、主要指标和停止规则。

训练/校准：Bay旧银行的跨年迁移结果原样保留。纽约/芝加哥/丹佛先从独立开发训练期构建区域或分层收缩映射；模型选择和校准使用分离验证块，不能在已评分2025结果上拟合后宣称独立改善。新区域资料可读不等于新区域概率已校准。

必须比较 B、f(B)、f(B,E)、气候态、持续性与预登记简单融合。f(B,E)的输入只包含合法资料与缺失标记，不能带隐藏E答案或未来质量修订。训练轻量映射的范围/数据/预算登记，但不要求大模型训练。

产物：`INPUT_FOOTPRINTS.jsonl`、`DEPENDENCE_COMPONENTS.json`、`SPLIT_AUDIT.json`、`TRAIN_CALIBRATION_MANIFEST.json`、候选基线与验证报告。

### W11 — 自然集与极端诊断集分轨

自然集保留连续时次、零/少正例和数据失败。另由外部事件定义及原生现象/阈值合同构建极端富集诊断集，含前后普通窗口、近阈值、所有已登记站点和未结算。不得按专业基线误差、LLM输赢或对某方法有利与否择样。

1km/5km分别命名和统计；5km不是通用浓雾判据。METAR报告事件也不是传感器无误的物理天气。一个正目标的三个提前量不能算三个独立正过程。对0正例的严重阈值，不给出“罕见灾害召回提高”的结论。

扩样门槛是合同成立、设计精度和可执行资源，不是“必须找到主动增益”。若效果接近零且区间很宽，结论为证据不足；只有预登记的等效区间与充分精度才能支持“小于有意义增益”的负结论。

### W09/W12 — C2部分证据与联合可达性

现有235B在完整资料上的E-only为47/48，单条资料为2/48；8B经常unknown。先利用已经核验的evidence_witnesses，不新增LLM裁判或逐题人工Gold。

分别输出：支持状态(当前合法E)、模型事实正确性、无依据确定性、不必要unknown、冲突、及时提交覆盖。cutoff可判定量与dispatch模型正确率分母不同，禁止直接相除或相减后称增益。

新C2实验按受支持命题的逻辑结构建立边界：存在命题有阳性见证可提前确定真；确定假必须覆盖全部注册槽位；缺失、删失跨阈值、旧版替换、冲突分别保留。全读E可更确定，但不能把该状态当未来F的唯一正确概率。

对现有真实三目标/10条见证扩展到版本及完整账本边界，而非重建solve_joint：已花、预留、在途、缓存、授权、实际完成与截止全部绑定。单目标均可达但联合不可达、共享一次帮助多个目标、低费但来不及至少三类生产入口测试。

有限小图可精确，较大图必须给可行见证与界；搜索截断/无有限合同上界时保留unknown/infinite，不声称最优。事后最优路径不放入selector输入，也不当可部署基线。

## 6. 下一轮模型调用：先消除不确定性，再决定规模

不建议立即另开同样52会话/几千调用。根据上述CPU结果，冻结一个能回答单一问题的小批次：

- 若已有证据可被简单f(B,E)利用而模型仍数值沿用：研究预测器利用与显示状态/基线的关系。任何移除数值基线的实验只作改变信息条件的诊断，不能混入共同基线主比较。
- 若固定预测器可利用不同资料，但selector没有选中：才做同预算selector比较。
- 若E部分证据错误稳定：在新的独立开发块验证逻辑能力，不用提示强制改概率。
- 若程序和模型都无信息增量：检查数据质量/时空关联并保留零/负结果，不能声称信息论不可能，也不能为制造差异扩大人为延迟。

每批命名question、hypothesis、falsifier、input/target/source hashes、模型与权重/量化、生成参数、头、调用总数、时限、预算、失败与评分规则。原235B MoE与8B训练/量化不同，不把比较归为仅参数量的因果影响。

运行时闭环查询带来的分布变化单独记录。相同seed不保证跨硬件、批处理与异步次序逐token一致；重放用原输出，新推理用新执行身份。

## 7. 并行扩展：明确采用/暂缓的工作

### W13：温度是现成第二过程候选，不重复数据准备

已有 mx2t6/mn2t6 两块、原生730起报与14,600有效时间、DWD日值、2,920未来日配对、2,920三日事件记录及480准入快照。下一步是连续会话，而不是重新从瞬时温度构造日极值。

接入规格：同一未来日/三日target跨多个起报更新；提供完整共同成员产品及预先固定的研究映射；引入截至dispatch可得的站点/邻站或其他合格补充证据；按单一clock保存查询/处理/预测。已有共同集合不得二次收费。

保持 day0 排除、UTC日界、K/摄氏度转换、同成员三日轨迹、参考期外缺失和固定阈值。日事件的不同lead/阈值和重叠三日窗口以过程/时间块分组；22/113/27正日期或8/10三日开始日不是独立过程数。文档noon与原生00UTC冲突保持披露，不平移坐标。

先CPU FOLLOW、同值OVERRIDE、copy-current、f(B/E)完整会话及临时journal评分；原生窗口验证通过后再开放模型任务。地区分位阈值只从独立训练/校准期取得。不要把这条连续会话接入写成已经证明热浪预警或16类完成。

### W14：H07物理区间门槛不降低

已有12小时MRMS/QPE及官方单位/质量码/标称1h时长。还需逐帧实际累计端点和版本可用性的产品级依据。不得用S3 Last-Modified、GRIB instant或文件名猜定全部实际支持。

合格后再与同窗预报和站点/指定产品参考配对；定义真实网格、缺帧和负码。原生图、确定性合法特征、领域工具分别计费。不得把隐藏mask当读取原图即免费拥有的事实。

达不到门槛就保持产品E或时间合同诊断；按已登记资格规则选择H01候补，不因某灾种模型分数好而换主实验。

### W15/W16：HEFS和D-sim分级推进

HEFS当前两循环、43列、697共同时间与版本E，不代表物理流量/洪水F。QINE成员、调蓄、断面、统计支持与观测映射先核准。完整HEFS已作为免费共同信息时，不收一次档案传输费再宣称获取收益。

D-sim已有纯状态、外生计划与F条件回放；12条F条件计划没有重新运行取证/预测器。可继续核同钟、容量、取消与沉没成本、读取当时生效F；完整反馈会话另立资格。保持F输入与准备偏好隔离的固定信念实验，再另列端到端资料选择变化；不声称真实减灾收益，不阻塞F/C2发布。

### W12-X09：新冻结，不重开已过期的384请求launcher

当前X09只有离线384请求/576目标位置和格式核验，没有模型结果。它不是E/F联合head，而是同信息下单目标与多目标回答范围比较。

下次至少区分：

| 轨道 | 单目标组三次请求 | 三目标一次请求 | 解释 |
|---|---|---|---|
| 每请求同上限 | 3×512 | 512 | 服务成本与批量能力，组级输出预算不同 |
| 每三目标组同总输出上限 | 3×512 | 1536 | 减少总输出空间的混淆；实际token、输入重复和硬件批处理仍不同 |

以上数字是沿用原512上限的控制规格，是否实际运行须新授权冻结。单目标调用看到相同整个上下文；新shared fixed-input不是私有运行中的免费共享。无效联合回答使全部登记目标失败/回退，不能按目标修补；E-only不进F分母。先修R3并用假响应完成所有回归，再决定小规模真实调用。

### W18/W19：前瞻与可复现发布

source-only shadow不能升级为online skill。后续真实前瞻须先固定预测目标/截止、提交回执、结果成熟规则，再有完整提交和结算；当前first_seen仅为采集器首次观察上界。它与历史机制确认并行，不要求等待未来事件才能研究。

发布分级保留：源样例、产品E、场景回放F、独立机制、物理MM/D、前瞻。16类各写actual_scope/gates而不是单一布尔全通过。轻量ZIP缺全部原始token/fixture时明确说明，提供可直接运行且不需GPU/密钥的核心journal例子。

## 8. 统一验收指标与停止规则

主F：各阈值/变量分别Brier或MAE；Brier的概率来自研究映射还是原生专业概率分别标记。包括候选、采纳、生效、help/harm/no-change、缺失及失败。保留所有机会；结果缺失使用共同掩膜；不能将未提交或0正例当表现好。

C1：固定selector的2×2；同global/shared同预测器只换selector；固定selector只换predictor。不同调用类型共享总预算并分别报告源请求、selector/predictor token和compute、实际交付。程序声明1ms与模型实测不是部署加速证据。

C2：dispatch支持、cutoff可达、实际达到分别输出；足够的过去证据不等于未来确定；有限事后见证不是前瞻oracle。

C3：父过程/保守时空块不确定性；事件富集与自然监测分表；跨lead/threshold/member不是独立样本。两三簇下不发布貌似精确的一般结论。

停止条件由预登记预算、已完成机会和precision设计决定，不以正收益、显著性或模型是否修改概率决定。确认前完整冻结，确认后不通过微调提示在同一数据上重复寻优。

## 9. 每批 Codex 必须交付

`STATUS.json` 按原 W 编号列 done/partial/blocked/skipped/not_started；`CLAIM_LEDGER.json` 对每项声明指向输入、代码、日志、评分与限制；全部命令/退出码和fixture覆盖；红绿回归与影响范围；新旧分数并列（有变化时）；实际资源费用；源/结果/代码hash；下一未解决的最小问题。

至少回答：这次新增的是工程正确性、可测量性、开发现象还是独立证据？是否发生模型调用？是否打开确认材料？是否变更历史协议？哪些任务虽然测试通过仍不具备物理/独立资格？

## 10. 推荐首批入口

先完成：基线与本地portable复现 → R1/R2/R3生产入口回归/修复 → 旧捕获影响筛查 → 新COPY_CURRENT/COPY_BASELINE/FOLLOW程序会话 → CPU审计生命周期与完整输入足迹设计。

并行准备：区域训练/校准冻结、温度连续会话规格和MRMS时间合同。暂不打开确认周、不重跑235B大矩阵、不重开X09旧launcher、不把D/MM作为核心前置。

最终目标仍是：在明确共同基线、可用信息、资源和截止条件下，区分证据支持、可达性与未来预测价值；让一个新方法的真正增量，以及零/负收益的适用边界，都能被第三方重复检验。

## 参考证据索引（全部按本文件开头的固定提交）

- [S1] `README.md`、`publication/v8_measurement_20260914/README_CN.md`：发布与复现范围。
- [S2] `plans/v8_measurement_execution_20260913_01/REVIEW_REQUEST_CN.md`、`RUN_REPORT_CN.md`：实验分母、独立审计、故障保留。
- [S3] 同目录 `ADAPTIVE_SCORECARD_CN.md`、`NEXT_PHASE_PLAN_CN.md`、`WORK_PACKAGE_PROGRESS_02.json`：分层结果、已有后续优先级和范围。
- [S4] `monitoring_fixed_v1/adaptive.py`（位于 `disastertrace-starter/src/disastertrace/`）：execute/resume_pending/_complete_execution/_failed_execution。
- [S5] `monitoring_fixed_v1/admission.py`：事务副本、原生版本、score_admitted。
- [S6] `monitoring_v1/event_loop.py`、`providers/versions.py`：预校验与当前版本优先。
- [S7] `monitoring_fixed_v1/outcomes.py`、`joint_targets.py`：结果唯一性与X09严格解析。
- [S8] `monitoring_v1/execution.py`、`spool_backend.py`：执行身份、原请求resolve和首次交付。
- [S9] 执行目录 `TEMPERATURE_DAILY_FORECAST_CN.md`、`X09_PROTOCOL_CN.md`：最新温度与联合目标范围。
- [S10] 随附 `review_results.json`、`review_checks.py`：本次实际隔离测试及限制。
