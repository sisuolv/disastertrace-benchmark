# DisasterTrace v8 外部复查与 Codex 计划

基准：5ed0fb94ae7bf235b37e7528e201b603271edffa。

- `CODEX_NEXT_PLAN_CN.md`：完整分阶段规格与验收。
- `CODEX_START_PROMPT_CN.txt`：可直接交给Codex的入口。
- `FINDINGS_CN.md`：发现、范围和不应越过的结论。
- `WORK_PACKAGES.json`：机器可读子任务、依赖和出口。
- `review_checks.py`、`review_results.json`：本次实际运行的36个原函数隔离情形。
- `source_extracts/`：从GitHub读取的完整小模块和函数摘录，不是完整仓库。

36个情形的观察均与预先设置的探针预期一致，其中5个用于复现3类局部边界，并非“36个修复后集成测试全部通过”。31个为正常/拒绝保护控制。engine、ledger、backend、journal reader使用受控替身；不可冒称执行了全部502项项目测试、原生数据重建或完整模型重放。

两份完整模块的Git blob已核对；其余函数可在匹配的只读完整checkout上追加AST核验：

```bash
python review_checks.py --output /tmp/dt-v8-review-new.json
python review_checks.py --repo /path/to/pinned_checkout --output /tmp/dt-v8-review-ast-new.json
```

容器ZIP下载因网络解析失败，未运行原仓库portable子集。当前报告中的52会话与模型指标是对仓库报告的核对，不是本次新模型实验。未修改远端、未运行GPU/付费API、未打开预留确认集。

建议优先阅读主计划第3—5节。不得将异常路径反例说成现有52个会话已经失败；先做生产入口回归和历史影响筛查。
