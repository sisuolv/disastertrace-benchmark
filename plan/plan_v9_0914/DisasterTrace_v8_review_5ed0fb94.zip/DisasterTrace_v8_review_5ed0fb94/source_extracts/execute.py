def execute(self, opportunity, call_id, started, store, ledger, source_receipts, backend):
    bundle = self.freeze_acquired(opportunity, started, store, ledger, source_receipts)
    head = "program" if backend is None else self.config.get("typed_head", "joint")
    executor = (
        "frozen_frequency.v1"
        if backend is None
        else self.config.get("executor_id", "typed_backend.v1")
    )
    self.run(
        [
            AdmissionEvent(
                call_id + "-begin",
                started,
                "begin",
                {
                    "call_id": call_id,
                    "bundle": bundle.to_dict(),
                    "head": head,
                    "executor": executor,
                },
            )
        ],
        until=started,
    )
    if call_id not in self.calls:
        raise ValueError("Controller produced an inadmissible typed begin")
    observed_start = time.perf_counter()
    if backend is None:
        raw = canonical(FrozenFrequencyPredictor(self.bank).predict(bundle).to_dict())
        details = {
            "input_tokens": 0,
            "output_tokens": 0,
            "seconds": 0.001,
            "ended_with_eos": True,
            "backend": executor,
            "timing_basis": "declared_program_latency_scenario",
        }
    else:
        messages = model_messages(bundle, head)
        ledger.bind_request(
            call_id,
            {
                "request_sha256": fingerprint(messages),
                "execution_sha256": fingerprint(self.config["execution_contract"]),
            },
        )
        from ..monitoring_v1.execution import PendingExecution

        try:
            raw, details = backend(messages[0]["content"], bundle.policy_view(), call_id)
        except PendingExecution:
            if not callable(getattr(backend, "resolve", None)):
                details = {"exception_type": "MissingOriginalTicketResolver"}
                ledger.mark_unknown(call_id, details)
                elapsed = (
                    max(
                        1,
                        self.config.get(
                            "public_call_slot_ms", self.config["call_compute_cap_ms"]
                        ),
                    )
                    * 1000
                )
                return self._failed_execution(
                    opportunity,
                    bundle,
                    call_id,
                    started,
                    started + elapsed,
                    head,
                    executor,
                    "unknown_execution",
                    None,
                    details,
                )
            raise
        except Exception as exc:  # noqa: BLE001 - record failure without a free retry.
            details = {
                "exception_type": type(exc).__name__,
                "observed_wall_seconds": time.perf_counter() - observed_start,
            }
            ledger.mark_unknown(call_id, details)
            elapsed = (
                max(
                    1,
                    self.config.get("public_call_slot_ms", self.config["call_compute_cap_ms"]),
                )
                * 1000
            )
            return self._failed_execution(
                opportunity,
                bundle,
                call_id,
                started,
                started + elapsed,
                head,
                executor,
                "unknown_execution",
                None,
                details,
            )
    return self._complete_execution(
        opportunity,
        bundle,
        call_id,
        started,
        ledger,
        head,
        executor,
        raw,
        details,
        observed_start,
    )
