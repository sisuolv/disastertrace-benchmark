HEAD_FIELDS = {
    "e_only": {"target_id", "fact_truth"},
    "f_only": {"target_id", "probability"},
    "joint": {"target_id", "fact_truth", "probability"},
}


def _scope(context, answer_target_ids, head):
    if head not in HEAD_FIELDS:
        raise ValueError("Unregistered joint output head")
    payload = {k: v for k, v in context.items() if k != "context_sha256"}
    if context.get("context_sha256") != fingerprint(payload):
        raise ValueError("Joint context hash mismatch")
    registered = {row["target"]["target_id"] for row in context["targets"]}
    if (
        not isinstance(answer_target_ids, list)
        or not answer_target_ids
        or any(not isinstance(tid, str) for tid in answer_target_ids)
        or len(set(answer_target_ids)) != len(answer_target_ids)
        or not set(answer_target_ids) <= registered
    ):
        raise ValueError("Answer scope must contain unique registered target IDs")
    return set(answer_target_ids)


def _unique_keys(pairs):
    row = {}
    for key, value in pairs:
        if key in row:
            raise ValueError("Duplicate JSON key")
        row[key] = value
    return row


def parse_joint_response(raw, context, answer_target_ids, *, head):
    expected = _scope(context, answer_target_ids, head)
    if not isinstance(raw, str):
        raise TypeError("A raw JSON response is required")
    result = json.loads(raw, object_pairs_hook=_unique_keys)
    if (
        not isinstance(result, dict)
        or set(result) != {"answers"}
        or not isinstance(result["answers"], list)
    ):
        raise ValueError("Wrong joint response envelope")
    answers = {}
    for row in result["answers"]:
        if not isinstance(row, dict) or set(row) != HEAD_FIELDS[head]:
            raise ValueError("Wrong per-target response fields")
        tid = row["target_id"]
        if not isinstance(tid, str) or tid not in expected or tid in answers:
            raise ValueError("Missing, duplicated or unrequested response target")
        if head in {"e_only", "joint"} and (
            not isinstance(row["fact_truth"], str)
            or row["fact_truth"] not in {"true", "false", "unknown", "conflict"}
        ):
            raise ValueError("Wrong factual truth type/value")
        if head in {"f_only", "joint"} and (
            type(row["probability"]) not in (int, float)
            or not math.isfinite(row["probability"])
            or not 0 <= row["probability"] <= 1
        ):
            raise ValueError("Probability must be finite and in range")
        answers[tid] = row
    if set(answers) != expected:
        raise ValueError("Every requested target must have exactly one answer")
    return answers
