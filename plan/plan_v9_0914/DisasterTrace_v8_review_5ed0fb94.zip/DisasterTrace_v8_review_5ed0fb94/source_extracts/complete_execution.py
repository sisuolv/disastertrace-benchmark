def _complete_execution(
    self,
    opportunity,
    bundle,
    call_id,
    started,
    ledger,
    head,
    executor,
    raw,
    details,
    observed_start,
):
    try:
        if (
            not isinstance(raw, str)
            or type(details["seconds"]) not in (int, float)
            or not math.isfinite(details["seconds"])
            or details["seconds"] < 0
        ):
            raise ValueError("Invalid measured backend duration or response")
        if any(
            type(details[k]) is not int or details[k] < 0
            for k in ("input_tokens", "output_tokens")
        ):
            raise ValueError("Invalid measured backend token counts")
        elapsed_seconds = details.get("elapsed_seconds", details["seconds"])
        if (
            type(elapsed_seconds) not in (int, float)
            or not math.isfinite(elapsed_seconds)
            or elapsed_seconds < details["seconds"]
        ):
            raise ValueError("Invalid elapsed delivery duration")
        duration = max(1, math.ceil(elapsed_seconds * 1_000_000))
        compute_us = max(1, math.ceil(details["seconds"] * 1_000_000))
    except (KeyError, TypeError, ValueError) as exc:
        diagnostic = {
            "error_type": type(exc).__name__,
            "observed_wall_seconds": time.perf_counter() - observed_start,
        }
        ledger.mark_unknown(call_id, diagnostic)
        elapsed = (
            max(1, self.config.get("public_call_slot_ms", self.config["call_compute_cap_ms"]))
            * 1000
        )
        return self._failed_execution(
            opportunity,
            bundle,
            call_id,
            started,
            started + elapsed,
            head,
            executor,
            "invalid_backend_response",
            raw if isinstance(raw, str) else None,
            diagnostic,
        )
    persistence = self.config.get("persistence_latency_ms", 1) * 1000
    elapsed = duration + persistence
    slot_overrun = False
    if self.config.get("isolation_mode") == "public_schedule":
        slot = self.config["public_call_slot_ms"] * 1000
        slot_overrun = elapsed > slot
        elapsed = max(elapsed, slot)
    completed, persisted = started + duration, started + elapsed
    actual = Cost(
        tokens=details["input_tokens"] + details["output_tokens"],
        compute_ms=math.ceil(compute_us / 1000),
    )
    resource_overrun = not actual.within(asdict(ledger.entries[call_id]["upper"]))
    if slot_overrun or resource_overrun:
        disposition = "slot_overrun" if slot_overrun else "resource_overrun"
        ledger.settle_observed(call_id, actual, outcome=disposition)
        return self._failed_execution(
            opportunity,
            bundle,
            call_id,
            started,
            persisted,
            head,
            executor,
            disposition,
            raw,
            details,
            actual=actual,
            completed=completed,
        )
    error, forecast, status_e = None, None, None
    try:
        if head == "program":
            forecast = Forecast(**json.loads(raw))
        else:
            answer = parse_response(raw, bundle, head)
            forecast, status_e = answer.forecast, answer.e_status
        if details.get("ended_with_eos") is not True:
            raise ValueError("Response unfinished")
    except (ValueError, TypeError, OverflowError) as exc:
        error = str(exc)
    ledger.settle(call_id, actual, outcome="completed" if error is None else "invalid_response")
    receipt = {
        "call_id": call_id,
        "bundle_hash": bundle.bundle_hash,
        "raw": raw,
        "raw_sha256": hashlib.sha256(raw.encode()).hexdigest(),
        "started_at": started,
        "completed_at": completed,
        "persisted_at": persisted,
        "expires_at": max(
            o["cutoff"]
            for o in self.opportunities.values()
            if o["target_id"] == opportunity["target_id"]
        ),
        "cost": asdict(actual),
        "ended_with_eos": details.get("ended_with_eos", False),
        "head": head,
        "executor": executor,
    }
    self.run(
        [AdmissionEvent(call_id + "-complete", persisted, "completion", receipt)],
        until=persisted,
    )
    admission = next(
        a for a in reversed(self.attempts) if a.get("event_id") == call_id + "-complete"
    )
    record = {
        "call_id": call_id,
        "opportunity_id": opportunity["opportunity_id"],
        "head": head,
        "started_at": started,
        "completed_at": completed,
        "persisted_at": persisted,
        "bundle": bundle.to_dict(),
        "receipt": receipt,
        "expected_e_from_disclosed_products": native_slot_support(bundle, at=started)["status"],
        "reported_e": status_e,
        "decision": "E_only" if head == "e_only" else "override",
        "proposed_probability": None if forecast is None else forecast.value,
        "adoption_policy": "typed_auto_propose.v1",
        "proposed_action": "OVERRIDE" if forecast is not None else None,
        "admitted_action": "OVERRIDE" if admission["status"] == "accepted" else None,
        "effective_state_after_completion": self.policy_state(
            opportunity["target_id"], persisted
        ),
        "response_error": error,
        "admission_status": admission["status"],
        "evidence_query_ids": sorted(
            a["content"]["query_id"] for a in bundle.policy_view()["assets"]
        ),
        "details": details,
        "raw": raw,
    }
    return record, persisted
