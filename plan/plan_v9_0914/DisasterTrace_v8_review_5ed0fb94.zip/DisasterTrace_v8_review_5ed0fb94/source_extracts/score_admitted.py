def score_admitted(outcomes, arms, *, comparison=None):
    engines = {name: AdmissionEngine.from_journal(path) for name, path in arms.items()}
    if not engines:
        raise ValueError("No admitted arms")
    first = next(iter(engines.values()))
    for engine in engines.values():
        invariant = lambda c: {k: v for k, v in c.items() if k not in {"experiment", "protocol"}}
        same_contract = (
            engine.contract == first.contract
            if comparison is None
            else invariant(engine.contract) == invariant(first.contract)
        )
        if not same_contract or set(engine.snapshots) != set(first.opportunities):
            raise ValueError("All arms need the same full sealed opportunity contract")
        if comparison is not None:
            experiment = engine.contract.get("experiment", {})
            comparison.validate(experiment.get("invariants"), engine.active_interventions)
            if (
                engine.protocol != first.protocol
                and "protocol" not in comparison.allowed_interventions
            ):
                raise ValueError("Revision protocol differs without a registered intervention")
        if engine.calls and {c["head"] for c in engine.calls.values()} == {"e_only"}:
            raise ValueError("E-only calls are not a forecasting arm")

    def baseline_trace(engine):
        rows = []
        for record in engine._events.values():
            if record["kind"] not in {"baseline", "baseline_withdrawal"}:
                continue
            payload = record["payload"]
            if record["kind"] == "baseline":
                view = EvidenceBundle.restore(payload["bundle"]).policy_view()
                base = view["baseline"]
                base["content"].pop("E_question", None)
                payload = {
                    "target": view["target"],
                    "baseline": base,
                    "provider_version": view["provider_version"],
                }
            rows.append({"time": record["time"], "kind": record["kind"], "payload": payload})
        return sorted(rows, key=canonical)

    common_baseline = baseline_trace(first)
    if any(baseline_trace(engine) != common_baseline for engine in engines.values()):
        raise ValueError("All arms require the same common baseline trace")
    results = {r["opportunity_id"]: r for r in outcomes}
    if len(results) != len(outcomes) or set(results) != set(first.opportunities):
        raise ValueError("Every opportunity needs an explicit outcome or missing status")
    rows, canonical_results, target_resolutions = [], {}, {}
    for oid, o in first.opportunities.items():
        outcome = results[oid]
        if "resolution_version" in outcome:
            from .outcomes import OutcomeRegistry

            validator = OutcomeRegistry(first.targets.values())
            validator.register({k: v for k, v in outcome.items() if k != "opportunity_id"})
        else:
            require_fields(
                outcome,
                "opportunity_id target_contract_hash value status source_revision",
                "outcome",
            )
        if outcome["target_contract_hash"] != o.target.contract_hash:
            raise ValueError("Outcome target mismatch")
        if outcome["status"] not in {"mature", "provisional", "missing"}:
            raise ValueError("Unknown maturity status")
        if outcome["status"] == "mature" and (
            outcome["value"] is None or not outcome["source_revision"]
        ):
            raise ValueError("Mature outcome needs value and revision")
        resolution = outcome.get("resolution_version", "legacy:" + str(outcome["source_revision"]))
        if (
            o.target.contract_hash in target_resolutions
            and target_resolutions[o.target.contract_hash] != resolution
        ):
            raise ValueError("Result resolution differs across lead times for one target")
        target_resolutions[o.target.contract_hash] = resolution
        identity = (o.target.contract_hash, resolution)
        record = {k: v for k, v in outcome.items() if k != "opportunity_id"}
        if identity in canonical_results and canonical_results[identity] != record:
            raise ValueError("Canonical target outcome conflict across opportunities")
        canonical_results[identity] = record
        rows.append(
            {
                "opportunity_id": oid,
                "target": o.target.to_dict(),
                "outcome": outcome["value"] if outcome["status"] == "mature" else None,
            }
        )
    return {
        "schema": "disastertrace.admitted_scores.v1",
        "contract_sha256": first.contract_hash,
        "time_basis": first.time_basis,
        "outcome_sha256": fingerprint(outcomes),
        "scores": paired_scores(
            rows,
            {
                name: {oid: s["forecast"] for oid, s in engine.snapshots.items()}
                for name, engine in engines.items()
            },
        ),
        "admission_statuses": {
            name: [r["status"] for r in engine.attempts] for name, engine in engines.items()
        },
    }
