#!/usr/bin/env python3
"""Offline, function-isolation probes; NOT the full repository test suite.

With --repo, verify pinned full-file Git blob identities and AST equality before
running the same probes. Without --repo, use connector-read source extracts.
The event clock and version selector files are complete, byte-hash-verified files.
Other functions are exact extracts. Their surrounding engines/backends/ledgers
are controlled doubles: this does not establish whole-system replay correctness.
"""
from __future__ import annotations
import argparse, ast, copy, hashlib, json, math, sys, types
from dataclasses import asdict, dataclass
from pathlib import Path
from types import SimpleNamespace as NS

ROOT = Path(__file__).resolve().parent
COMMIT = '5ed0fb94ae7bf235b37e7528e201b603271edffa'
SOURCES = {
 'event_loop.py': ('disastertrace-starter/src/disastertrace/monitoring_v1/event_loop.py','22e38a02b6508476591f6db54246b663eac0c205'),
 'versions.py': ('disastertrace-starter/src/disastertrace/monitoring_v1/providers/versions.py','847668671020990cf44f694d9ea536e689ba8d8a'),
 'execute.py': ('disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py','33f11c0346240c9cab6d9de7755353fb7e6a7291'),
 'complete_execution.py': ('disastertrace-starter/src/disastertrace/monitoring_fixed_v1/adaptive.py','33f11c0346240c9cab6d9de7755353fb7e6a7291'),
 'score_admitted.py': ('disastertrace-starter/src/disastertrace/monitoring_fixed_v1/admission.py','24917aed622a8405ba53b6d9970f6f686ef14d68'),
 'joint_response.py': ('disastertrace-starter/src/disastertrace/monitoring_fixed_v1/joint_targets.py','dc992e2e4202fa8375fd412ce6d943e8a27db6aa'),
}

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)
def fingerprint(x): return hashlib.sha256(canonical(x).encode()).hexdigest()
def gitblob(b): return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
def require_fields(r, fields, label):
 if not isinstance(r,dict) or set(r)!=set(fields.split()):raise ValueError(label)
def dumpnode(n): return ast.dump(n,include_attributes=False)

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path)
ap.add_argument('--output',type=Path,default=ROOT/'review_results.json')
args=ap.parse_args()
if args.output.exists():
 raise SystemExit("Use a new output path; existing review record is preserved: "+str(args.output))
verification=[]
for name,(path,sha) in SOURCES.items():
 data=(ROOT/'source_extracts'/name).read_bytes()
 item={'extract':name,'repository_path':path,'expected_git_blob':sha,'extract_sha256':hashlib.sha256(data).hexdigest()}
 if name in {'event_loop.py','versions.py'}:
  assert gitblob(data)==sha,(name,'full blob mismatch')
  item['full_file_bytes_verified']=True
 else:item['full_file_bytes_verified']=False
 if args.repo:
  raw=(args.repo/path).read_bytes()
  if gitblob(raw)!=sha:raise SystemExit('Checkout differs from audited commit: '+path)
  original={n.name:n for n in ast.walk(ast.parse(raw)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
  for n in ast.parse(data).body:
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
    assert n.name in original and dumpnode(n)==dumpnode(original[n.name]),(name,n.name,'AST mismatch')
  item['full_checkout_AST_verified']=True
 verification.append(item)

def load(name,extra=None):
 tree=ast.parse((ROOT/'source_extracts'/name).read_text())
 nodes=[n for n in tree.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
 ns={'json':json,'math':math,'hashlib':hashlib,'canonical':canonical,'fingerprint':fingerprint,'canonical_hash':fingerprint,'asdict':asdict,'__package__':'review.monitoring_fixed_v1'}
 ns.update(extra or {})
 exec(compile(ast.Module(body=nodes,type_ignores=[]),name,'exec'),ns)
 return ns

rows=[]
def probe(name,fn):
 try:
  details=fn() or {}
  rows.append({'name':name,'status':'observed_as_expected',**details})
 except Exception as exc:
  rows.append({'name':name,'status':'unexpected_harness_result','error_type':type(exc).__name__,'error':str(exc)})
def rejects(fn,kind=ValueError):
 try:fn()
 except kind:return
 raise AssertionError('Expected rejection '+kind.__name__)

@dataclass
class Ev:
 event_id:str
 time:int
 kind:str
 payload:dict
 def to_dict(self):return asdict(self)
def decode(r):
 if type(r['time']) is not int:raise ValueError('time')
 return Ev(**r)
class Owner:
 def __init__(self,last=10):
  self._last_time=last;self._events={};self._processed=set();self.snapshots={};self.opportunities={};self.log=[]
  self.journal=NS(records=[])
  self.journal.append=lambda i,r:self.journal.records.append((i,copy.deepcopy(r)))
 def _expiry_times(self,u):return []
 def _process(self,e):self.log.append(e.kind)
 def _invalidate(self,t):self.log.append('invalidate')
 def _seal(self,t):self.log.append('seal')
 def _after_seal(self,t):self.log.append('after_seal')
clock=load('event_loop.py')['run_clock'];phases={'baseline':0,'completion':1,'begin':5}
def ck(o,es,end=30):return clock(o,es,until=end,event_order=phases,decode=decode)
def atomic_past():
 o=Owner();rejects(lambda:ck(o,[Ev('a',20,'baseline',{}),Ev('bad',5,'begin',{})]));assert not o._events and not o.journal.records;ck(o,[]);assert not o.log
 return {'classification':'old_boundary_closed_in_registration'}
probe('clock_invalid_batch_no_partial_registration',atomic_past)
def duplicate_bad():
 o=Owner();rejects(lambda:ck(o,[Ev('a',20,'baseline',{}),Ev('a',20,'baseline',{'x':1})]));assert not o._events
probe('clock_conflicting_batch_duplicate_rejected',duplicate_bad)
def duplicate_good():
 o=Owner();a=Ev('a',20,'baseline',{});ck(o,[a,a]);ck(o,[a]);assert o.log.count('baseline')==1 and len(o.journal.records)==1
probe('clock_exact_duplicate_idempotent',duplicate_good)
def ordering():
 o=Owner();ck(o,[Ev('b',20,'begin',{}),Ev('c',20,'completion',{}),Ev('a',20,'baseline',{})]);assert o.log==['baseline','completion','invalidate','seal','after_seal','begin'];return {'order':o.log}
probe('clock_same_time_order',ordering)
def reentrant():
 o=Owner();o._process=lambda e:ck(o,[],30);rejects(lambda:ck(o,[Ev('a',20,'baseline',{})]));assert o._clock_running is False
probe('clock_reentry_rejected_guard_reset',reentrant)
def reverse():
 o=Owner();rejects(lambda:ck(o,[],9));assert o._last_time==10
probe('clock_reverse_boundary_rejected',reverse)

v=load('versions.py')['current_taf']
def prod(sid='a',issued=1,status='active',start=0,end=100,sem='s'):
 return {'station':'KAAA','issued_at':issued,'status':status,'valid_start':start,'valid_end':end,'native_semantics_sha256':sem,'source_id':sid}
def vers(ps):return v(ps,station='KAAA',cutoff=10,start=20,end=30,lag_us=0)
def no_revive():
 x=vers([prod(),prod('b',2,end=25,sem='b')]);assert x['status']=='current_version_does_not_cover_target' and x['selected_id']=='b'
probe('TAF_latest_noncovering_does_not_revive_old',no_revive)
def cancel():assert vers([prod(),prod('b',2,status='canceled',sem='b')])['status']=='canceled'
probe('TAF_latest_cancellation_wins',cancel)
def aliases():
 x=vers([prod('z'),prod('a')]);assert x['source_ids']==['a','z'] and x['status']=='active'
probe('TAF_equivalent_mirrors_preserved',aliases)
def conflict():assert vers([prod(),prod('b',sem='different')])['status']=='conflict'
probe('TAF_same_issue_semantic_conflict',conflict)
def future():assert vers([prod(issued=20)])['status']=='no_product'
probe('TAF_future_issuance_not_visible',future)
def boolissue():rejects(lambda:vers([prod(issued=True)]))
probe('TAF_boolean_issuance_rejected',boolissue)

# Only the score wrapper is under test; log reading and the numerical scorer are doubles.
class Bundle:
 def __init__(self,row=None):self.row=row or {'assets':[]};self.bundle_hash='b'*64
 def policy_view(self):return copy.deepcopy(self.row)
 def to_dict(self):return copy.deepcopy(self.row)
 @classmethod
 def restore(cls,row):return cls(row)
class Target:
 contract_hash='a'*64
 def to_dict(self):return {'contract_hash':self.contract_hash}
def engine(prob=.2,semantic='same',leads=1):
 t=Target();ops={f'o{i}':NS(target=t) for i in range(leads)}
 view={'target':t.to_dict(),'baseline':{'forecast':{'value':prob},'content':{'semantic':semantic,'E_question':{}},'kind':'research'},'provider_version':'mock'}
 return NS(contract={'protocol':'base_bound_override','opportunities':list(ops)},protocol='base_bound_override',snapshots={k:{'forecast':{'value':prob}} for k in ops},opportunities=ops,targets={'t':t},calls={},_events={'b':{'time':1,'kind':'baseline','payload':{'bundle':view}}},attempts=[],contract_hash='c'*64,time_basis='declared_archive_scenario')
def outcomes(leads=1):return [{'opportunity_id':f'o{i}','target_contract_hash':'a'*64,'value':0,'status':'mature','source_revision':'v1'} for i in range(leads)]
scores=load('score_admitted.py',{'AdmissionEngine':NS(from_journal=lambda p:p),'EvidenceBundle':Bundle,'require_fields':require_fields,'paired_scores':lambda rs,arms:{'rows':rs,'arms':arms}})['score_admitted']
probe('score_same_baseline_accepted',lambda:scores(outcomes(),{'a':engine(),'b':engine()}) and {})
probe('score_different_baseline_rejected',lambda:rejects(lambda:scores(outcomes(),{'a':engine(),'b':engine(.8)})))
probe('score_same_value_different_semantics_rejected',lambda:rejects(lambda:scores(outcomes(),{'a':engine(),'b':engine(semantic='different')})))
def result_conflict():
 ys=outcomes(2);ys[1]['value']=1;rejects(lambda:scores(ys,{'a':engine(leads=2)}))
probe('score_same_target_conflicting_lead_outcomes_rejected',result_conflict)
def resolution_conflict():
 ys=outcomes(2);ys[1]['source_revision']='v2';rejects(lambda:scores(ys,{'a':engine(leads=2)}))
probe('score_mixed_resolution_across_leads_rejected',resolution_conflict)
def missing():
 ys=outcomes();ys[0].update(value=None,status='missing');r=scores(ys,{'a':engine(),'b':engine()});assert r['scores']['rows'][0]['outcome'] is None
probe('score_shared_missing_outcome_retained',missing)
def eonly():
 a=engine();a.calls={'x':{'head':'e_only'}};rejects(lambda:scores(outcomes(),{'a':a}))
probe('score_E_only_not_F_arm',eonly)

# Controlled clock/backends avoid sleeping. This is a local boundary reproduction,
# not evidence that any published GPU request actually hit this error path.
class PendingExecution(Exception):pass
fake=types.ModuleType('review.monitoring_v1.execution');fake.PendingExecution=PendingExecution
sys.modules['review.monitoring_v1.execution']=fake
@dataclass
class Cost:
 requests:int=0
 bytes:int=0
 tokens:int=0
 compute_ms:int=0
 def within(self,b):return all(b.get(k) is None or val<=b[k] for k,val in asdict(self).items())
class Ledger:
 def __init__(self):self.entries={'call':{'upper':Cost(tokens=100,compute_ms=100000)}};self.actions=[]
 def bind_request(self,*a):self.actions.append(('bind_request',))
 def mark_unknown(self,c,d):self.actions.append(('unknown',copy.deepcopy(d)))
 def settle(self,c,a,**kw):self.actions.append(('settled',asdict(a),kw))
 def settle_observed(self,c,a,**kw):self.actions.append(('settled_observed',asdict(a),kw))
class Runtime:
 def __init__(self,config=None):
  self.config={'typed_head':'e_only','execution_contract':{},'call_compute_cap_ms':1000,'isolation_mode':'actual_cost_clock',**(config or {})};self.calls={};self.attempts=[];self.opportunities={'o':{'target_id':'t','cutoff':10_000_000}}
 def freeze_acquired(self,*a):return Bundle()
 def run(self,events,**kw):
  for e in events:
   if e.kind=='begin':self.calls[e.payload['call_id']]={'completed':False}
   else:self.attempts.append({'event_id':e.event_id,'status':'e_only_recorded'})
 def _failed_execution(self,o,b,c,started,at,head,executor,status,raw,details,**kw):
  self.calls.setdefault(c,{})['completed']=True
  return {'status':status,'failure_at':at,'measured':details,'raw_retained':raw is not None,'timely':at<=o['cutoff']},at
 def policy_state(self,*a):return {'mode':'follow','probability':.2}
 def _complete_execution(self,*a):return {'normal_route':True},0

base_extra={'AdmissionEvent':Ev,'model_messages':lambda b,h:[{'content':'system'}],'Cost':Cost,'parse_response':lambda *a:NS(forecast=None,e_status='supported'),'native_slot_support':lambda *a,**k:{'status':'supported'}}
def failclock(wall,mode='actual_cost_clock',slot=None):
 times=iter([100.,100.+wall]);cfg={'isolation_mode':mode}
 if slot is not None:cfg['public_call_slot_ms']=slot
 ns=load('execute.py',{**base_extra,'time':NS(perf_counter=lambda:next(times))})
 rt=Runtime(cfg);le=Ledger();o={'opportunity_id':'o','target_id':'t','cutoff':10_000_000}
 def backend(*args):raise TimeoutError('synthetic timeout')
 result,at=ns['execute'](rt,o,'call',0,None,le,[],backend)
 return rt,le,result,at

def time_shortening():
 rt,le,r,at=failclock(40.)
 assert r['measured']['observed_wall_seconds']==40 and at==1_000_000 and r['timely']
 assert any(a[0]=='unknown' for a in le.actions)
 return {'classification':'reproduced_boundary_issue','issue_id':'R1','measured_seconds':40,'logical_failure_seconds':at/1e6,'cutoff_seconds':10,'note':'Exception finalizes but ignores longer observed wall duration; no claim published runs were affected.'}
probe('exception_elapsed_can_be_shortened_actual_clock',time_shortening)
def time_public():
 _,_,r,at=failclock(40.,'public_schedule',30000);assert at==30_000_000
 return {'classification':'reproduced_boundary_issue','issue_id':'R1','measured_seconds':40,'logical_failure_seconds':30}
probe('exception_elapsed_can_be_shortened_public_slot',time_public)
def time_fast():
 _,le,r,at=failclock(.2);assert at==1_000_000 and r['status']=='unknown_execution'
probe('exception_short_timeout_has_terminal_record',time_fast)

complete=load('complete_execution.py',{**base_extra,'time':NS(perf_counter=lambda:100.)})['_complete_execution']
def complete_case(seconds,extra=None,config=None):
 rt=Runtime(config);rt.calls['call']={'completed':False};le=Ledger();o={'target_id':'t','opportunity_id':'o','cutoff':10_000_000}
 details={'seconds':seconds,'input_tokens':1,'output_tokens':1,'ended_with_eos':True,**(extra or {})}
 return complete(rt,o,Bundle(),'call',0,le,'e_only','test_executor','{"fact_truth":"true"}',details,100),le

def normal_complete():
 (r,t),le=complete_case(.001);assert r['admission_status']=='e_only_recorded' and any(x[0]=='settled' for x in le.actions)
probe('normal_completion_settles',normal_complete)
def invalid_meta(x):
 (r,t),le=complete_case(x);assert r['status']=='invalid_backend_response' and any(x[0]=='unknown' for x in le.actions)
probe('negative_duration_finalizes',lambda:invalid_meta(-1))
probe('NaN_duration_finalizes',lambda:invalid_meta(float('nan')))
probe('infinite_duration_finalizes',lambda:invalid_meta(float('inf')))
def overflows(x):
 rejects(lambda:complete_case(x),OverflowError)
 return {'classification':'reproduced_boundary_issue','issue_id':'R2','unhandled':'OverflowError','input_description':'finite float 1e308' if isinstance(x,float) else 'integer 10**400','scope':'timing validation function with controlled surrounding doubles'}
probe('finite_duration_microsecond_overflow_escapes',lambda:overflows(1e308))
probe('huge_integer_duration_overflow_escapes',lambda:overflows(10**400))
def slot_overrun():
 (r,t),le=complete_case(31,config={'isolation_mode':'public_schedule','public_call_slot_ms':30000})
 assert r['status']=='slot_overrun' and r['raw_retained'] and any(x[0]=='settled_observed' for x in le.actions)
 return {'classification':'old_normal_overrun_boundary_closed','logical_completion_seconds':t/1e6}
probe('normal_numeric_slot_overrun_retains_raw_and_cost',slot_overrun)

joint=load('joint_response.py')['parse_joint_response'];ctx={'targets':[{'target':{'target_id':'a'}},{'target':{'target_id':'b'}}]};ctx['context_sha256']=fingerprint(ctx)
def jp(p=.2):return joint(json.dumps({'answers':[{'target_id':'a','probability':p},{'target_id':'b','probability':.3}]}),ctx,['a','b'],head='f_only')
probe('joint_valid_probabilities',lambda:jp() and {})
probe('joint_boolean_probability_rejected',lambda:rejects(lambda:jp(True)))
probe('joint_nan_probability_rejected',lambda:rejects(lambda:jp(float('nan'))))
probe('joint_out_of_range_probability_rejected',lambda:rejects(lambda:jp(1.2)))
def missing_joint():rejects(lambda:joint('{"answers":[{"target_id":"a","probability":0.2}]}',ctx,['a','b'],head='f_only'))
probe('joint_missing_target_rejected',missing_joint)
def duplicate_joint():rejects(lambda:joint('{"answers":[{"target_id":"a","probability":0.2,"probability":0.3},{"target_id":"b","probability":0.4}]}',ctx,['a','b'],head='f_only'))
probe('joint_duplicate_JSON_key_rejected',duplicate_joint)
def overflow_joint():
 rejects(lambda:jp(10**400),OverflowError)
 return {'classification':'reproduced_boundary_issue','issue_id':'R3','unhandled':'OverflowError','input_description':'401-digit JSON integer; X09 has no actual model calls in reviewed batch'}
probe('joint_huge_integer_probability_overflow_escapes',overflow_joint)

result={'commit':COMMIT,'scope':'Offline original-function isolation with controlled engine/ledger/backend/log-reader doubles. Not 502 project tests; not portable-journal replay; not new model inference.','network_zip_download':'failed: container DNS resolution; no full CPU ZIP was executed','source_verification':verification,'probes':rows,'summary':{'probes':len(rows),'observed_as_expected':sum(r['status']=='observed_as_expected' for r in rows),'unexpected_harness_results':sum(r['status']!='observed_as_expected' for r in rows),'issue_ids':sorted({r['issue_id'] for r in rows if 'issue_id' in r})}}
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result['summary'],ensure_ascii=False,indent=2))
for r in rows:
 if r.get('issue_id') or r['status']!='observed_as_expected':print(r['name'],r)
if result['summary']['unexpected_harness_results']:raise SystemExit(1)
