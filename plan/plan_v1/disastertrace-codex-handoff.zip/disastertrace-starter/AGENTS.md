# DisasterTrace repository instructions

Read `DISASTERTRACE_CODEX_PLAN.md`, `IMPLEMENTATION_STATUS.md`, `DECISIONS.md`, and
`BLOCKERS.md` before editing. Create the last three if they do not exist.

The default execution target is M1: a tested offline end-to-end pipeline.
Implement incrementally on the supplied starter; do not rewrite the repository.
Preserve the user's existing changes. Do not push, publish data, or delete history.

Keep Gold and future evidence out of model requests and model-accessible tools.
Use fresh messages for every checkpoint and pass only the declared carrier.
Do not conflate issue time, effective time, and proved public availability.
Never invent source records, human reviews, model responses, or successful tests.

Add regression tests for the known scorer/runtime defects before fixing them.
Run offline tests first. Paid model APIs and model training are disabled by default.
Record actual commands, exit codes, results, blockers, and the next executable task
in `IMPLEMENTATION_STATUS.md` at every task boundary.

Distinguish implemented code, offline verification, real-data verification, human
review, and live model API verification. A skipped test is not a passed test.

If this repository already has additional user instructions, preserve and merge
this section rather than replacing them.
