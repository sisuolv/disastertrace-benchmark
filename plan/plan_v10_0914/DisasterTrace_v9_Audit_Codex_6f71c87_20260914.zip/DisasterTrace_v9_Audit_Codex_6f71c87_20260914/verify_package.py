"""Validate this delivery only; never launch repo scripts or model requests."""
from pathlib import Path
import hashlib, json, zipfile
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for row in manifest['files']:
    p=root/row['path']
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
        raise SystemExit('Mismatch: '+row['path'])
tasks=json.loads((root/'TASKS.json').read_text())['tasks']
by={t['id']:t for t in tasks}
assert len(by)==len(tasks)
seen=set(); visiting=set()
def visit(k):
    if k in visiting: raise ValueError('Cycle: '+k)
    if k in seen:return
    visiting.add(k)
    for parent in by[k]['depends_on']:
        assert parent in by
        visit(parent)
    visiting.remove(k);seen.add(k)
for k in by:visit(k)
ac=json.loads((root/'ACCEPTANCE_CASES.json').read_text())
assert len(ac['cases'])==ac['case_count']
assert all(c['status']=='not_run' and c['task_id'] in by for c in ac['cases'])
print(json.dumps({'files_verified':len(manifest['files']),'tasks':len(tasks),'planned_acceptance_cases':len(ac['cases']),'dependency_graph_acyclic':True,'model_calls':0},indent=2))
