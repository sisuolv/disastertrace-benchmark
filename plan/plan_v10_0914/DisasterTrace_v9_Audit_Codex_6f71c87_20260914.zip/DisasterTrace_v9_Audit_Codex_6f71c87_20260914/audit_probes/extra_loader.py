"""Additional hash-bound modules; calibration probes use no-TAF branches only.

The isolation loader does not provide weather feature substitutes. Tests of
calibration.predict below use candidate=None, for which no missing feature
extractor is called. Full-production import is a separate required check.
"""
from isolated_loader import load, EXPECTED, CHECKS
EXPECTED.update(
    calibration='6c5cf91e7513bd7674f558ea1f474c58168db6b4',
    regional_calibration='6236493c86c31e0f3b7c605692601146e716bbbf',
    evidence_diagnostic='40e7668e76862b4b3f61f31d5c77f6fde6d34578',
)
M = load('regional_calibration')
K = load('calibration')
D = load('evidence_diagnostic')
if __name__ == '__main__':
    import json
    print(json.dumps(CHECKS, indent=2))
