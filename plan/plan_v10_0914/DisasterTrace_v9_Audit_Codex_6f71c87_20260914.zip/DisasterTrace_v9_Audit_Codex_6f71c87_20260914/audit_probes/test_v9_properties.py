"""Scoped v9 properties and diagnostics, not additional model calls/weather cases.

The family-switch diagnostic checks what the estimator DOES, not that a switch
is scientifically desirable. It must not be counted as a failed correctness test.
A single stored E response is the only real model response read by these tests.
"""
import copy
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import pytest
from test_v8_additional import canonical_result, target, unknown_ledger

if os.environ.get('DISASTERTRACE_AUDIT_MODE') == 'repo':
    from disastertrace.monitoring_fixed_v1 import outcomes as O, contracts as C, admission as A
    from disastertrace.monitoring_v1 import resources as R, journal as J, calibration as K, regional_calibration as M
    root = Path(os.environ['DISASTERTRACE_REPO_ROOT']).resolve()
    script = root/'plans/v9_followup_execution_20260914_01/scripts/evidence_diagnostic.py'
    spec = importlib.util.spec_from_file_location('v9_e_diagnostic', script)
    D = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(D)
else:
    from isolated_loader import O, C, A, R, J
    from extra_loader import K, M, D


def bound_ledger(journal=None):
    l=R.BudgetLedger({'tokens':100}, journal=journal)
    l.reserve('r', R.Cost(tokens=80), 't')
    l.bind_request('r', {'request_sha256':'a'*64,'execution_sha256':'b'*64})
    return l


def test_elapsed_accumulates_from_original_dispatch():
    l=bound_ledger()
    for t,phase in [(1000000000,'dispatch'),(2000000000,'poll'),(3000000000,'interrupted'),(4500000001,'returned')]:
        l.record_execution_timing('r',t,phase)
    assert l.entries['r']['timing']=={'first_wall_ns':1000000000,'last_wall_ns':4500000001,'elapsed_us':3500001,'observations':4}


def test_backward_observation_rejected_without_mutation():
    l=bound_ledger();l.record_execution_timing('r',100,'dispatch');before=copy.deepcopy(l.entries)
    with pytest.raises(ValueError):l.record_execution_timing('r',99,'poll')
    assert l.entries==before


def test_repeated_dispatch_is_not_free_new_request():
    l=bound_ledger();l.record_execution_timing('r',100,'dispatch')
    with pytest.raises(ValueError):l.record_execution_timing('r',101,'dispatch')


def test_timing_requires_bound_request_and_first_dispatch():
    l=R.BudgetLedger({'tokens':100});l.reserve('r',R.Cost(tokens=80),'t')
    with pytest.raises(ValueError):l.record_execution_timing('r',100,'dispatch')
    l.bind_request('r',{'request_sha256':'a'*64,'execution_sha256':'b'*64})
    with pytest.raises(ValueError):l.record_execution_timing('r',100,'poll')


def test_timing_replays_from_durable_journal(tmp_path):
    p=tmp_path/'resources.jsonl'
    with J.EventJournal(p) as j:
        l=bound_ledger(j);l.record_execution_timing('r',100,'dispatch');l.record_execution_timing('r',1000100,'returned')
        l.settle('r',R.Cost(tokens=12))
    r=R.BudgetLedger.restore(J.read_journal(p))
    assert r.entries==l.entries and r.spent==l.spent and r.events==l.events


def test_unknown_execution_cannot_change_observation_history():
    l=unknown_ledger()
    with pytest.raises(ValueError):l.record_execution_timing('r',100,'poll')
    assert l.reserved.tokens==80


def test_outcome_export_does_not_alias_internal_records():
    r=O.OutcomeRegistry([target()]);r.register(canonical_result())
    exported=r.export();exported['payload']['records'][0]['value']=1
    assert next(iter(r.records.values()))['value']==0


def test_outcome_rows_do_not_alias_internal_records():
    r=O.OutcomeRegistry([target()]);r.register(canonical_result())
    rows=r.opportunity_rows([A.TypedOpportunity('o',target(),900)],{'o':'audit.result.v1'})
    rows[0]['value']=1
    assert next(iter(r.records.values()))['value']==0


def test_missing_result_cannot_sneak_in_a_settled_value():
    r=O.OutcomeRegistry([target()])
    with pytest.raises(ValueError):r.register({**canonical_result(),'status':'missing','value':1})


def test_huge_integer_not_accepted_as_finite_forecast():
    assert C.finite(10**10000) is False
    with pytest.raises(ValueError):C.Forecast(target().contract_hash,'event_probability','probability',10**10000)


def test_four_valued_aggregate_properties():
    # 340 combinations are cases within ONE property test, not weather samples.
    for n in range(1,5):
        for xs in itertools.product(['true','false','unknown','conflict'],repeat=n):
            expected='conflict' if 'conflict' in xs else 'true' if 'true' in xs else 'false' if set(xs)=={'false'} else 'unknown'
            assert D.aggregate(xs)==expected
            assert D.aggregate(reversed(xs))==expected


def test_empty_aggregate_rejected():
    with pytest.raises(ValueError):D.aggregate([])


def test_duplicate_json_answer_is_invalid():
    with pytest.raises(ValueError):D.parse('{"fact_truth":"true","fact_truth":"false"}', ['a'],'direct')


def test_missing_slot_and_boolean_rejected():
    for raw in ['{"slots":{"a":"false"},"fact_truth":"false"}', '{"slots":{"a":false,"b":"unknown"},"fact_truth":"unknown"}']:
        with pytest.raises(ValueError):D.parse(raw,['a','b'],'slotwise')


def reference_view(assets):
    return {'cutoff':100,'baseline':{'content':{'E_question':{'query_ids':['a','b'],'threshold_m':1000}}},'assets':assets}


def asset(q,lo=0,hi=500,lc=True,uc=True,at=10,done=20,status='disclosed_product_fact'):
    return {'available_at':at,'completed_at':done,'content':{'query_id':q,'status':status,'reports':[{'visibility':{'lower':lo,'upper':hi,'lower_closed':lc,'upper_closed':uc}}]}}


def test_unread_slot_does_not_make_existential_false():
    r=D.independent_reference(reference_view([asset('a',5000,5000)]))
    assert r=={'slots':{'a':'false','b':'unknown'},'fact_truth':'unknown'}


def test_interval_open_closed_boundary_truth():
    for hi,uc,expected in [(999,True,'true'),(1000,False,'true'),(1000,True,'unknown'),('+inf',False,'unknown')]:
        r=D.independent_reference(reference_view([asset('a',0,hi,uc=uc)]))
        assert r['slots']['a']==expected
    r=D.independent_reference(reference_view([asset('a',1000,1000),asset('b',1001,1001)]))
    assert r['fact_truth']=='false'


def test_latest_disclosed_version_replaces_old():
    r=D.independent_reference(reference_view([asset('a',500,500,at=10),asset('a',5000,5000,at=20),asset('b',5000,5000)]))
    assert r['fact_truth']=='false'


def test_future_asset_is_not_visible():
    r=D.independent_reference(reference_view([asset('a',500,500,done=101)]))
    assert r['fact_truth']=='unknown'


def test_conflicting_coexisting_report_intervals():
    r=D.independent_reference(reference_view([asset('a',500,500),asset('a',5000,5000)]))
    assert r['fact_truth']=='conflict'


def test_weighted_pav_is_monotone_and_bounded():
    b=M.fit_monotone([(0.1,1,1),(0.2,0,1),(0.5,1,1),(0.8,0,1),(0.9,1,3)])
    p=[M.apply_monotone(b,k/100) for k in range(101)]
    assert p==sorted(p) and min(p)>=0 and max(p)<=1


def test_weighted_pav_input_order_invariance():
    rows=[(0.1,1,1),(0.2,0,1),(0.9,1,3)]
    assert M.fit_monotone(rows)==M.fit_monotone(rows[::-1])


def test_weighted_pav_fractional_duplicate_views_do_not_multiply_weight():
    rows=[(0.1,1,1),(0.2,0,1)]
    doubled=[(p,y,.5) for p,y,w in rows for _ in range(2)]
    assert M.fit_monotone(rows)==M.fit_monotone(doubled)


def calibration_switch_case():
    bank={'minimum_cell_n':1,'mapping_version':'synthetic.family.diagnostic',
          'cells':{'[1000,"no_taf"]':{'n':98,'positive':19},'[1000,"pooled"]':{'n':98,'positive':19}},
          'post_calibration':{'1000':{'base':[{'lower':0,'upper':1,'value':.2}],
                                      'evidence':[{'lower':0,'upper':1,'value':.4}]}}}
    t={'threshold':1000,'physical_start':1000}
    no_evidence=K.predict(bank,t,None)
    empty=K.predict(bank,t,None,['a'],{})
    # Weather record content cannot affect feature_key in this no-TAF branch.
    missing={'a':{'status':'missing','reports':[]}}
    with_missing=K.predict(bank,t,None,['a'],missing)
    return {'scope':'synthetic estimator behavior, not observed weather impact or proof of a software error',
            'no_evidence':no_evidence,'empty_evidence':empty,'nonempty_missing_record':with_missing,
            'raw_probability':.2,'only_selected_post_calibration_family_changed':True}


def test_family_switch_diagnostic_observes_same_cell_different_mapping():
    r=calibration_switch_case()
    assert r['no_evidence']['cell_key']==r['nonempty_missing_record']['cell_key']
    assert r['no_evidence']['probability']==.2 and r['nonempty_missing_record']['probability']==.4
    assert r['no_evidence']==r['empty_evidence']


def test_real_e_response_is_preserved_and_aggregate_error_reproduced():
    p=Path(__file__).parent/'REAL_E_RESPONSE.json';b=p.read_bytes()
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()=='b24655fdaa33bf5674121810c0f976372422d110'
    raw=json.loads(b)['body']['choices'][0]['message']['content']
    qids=['routine-KSFO-2025-02-06T01:00:00Z','routine-KSJC-2025-02-06T01:00:00Z']
    original=D.parse(raw,qids,'slotwise')
    assert original['fact_truth']=='false' and D.aggregate(original['slots'].values())=='unknown'
    # A derived diagnostic is not substituted for the model's original score.
