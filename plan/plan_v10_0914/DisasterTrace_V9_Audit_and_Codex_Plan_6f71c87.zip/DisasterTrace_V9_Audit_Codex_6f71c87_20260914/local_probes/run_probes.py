"""Offline audit probes: exact sources plus a dependency-isolated no-TAF path.
No network, GPU, model, repository mutation, or historical-score rerun.
"""
import ast
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import random
import sys
import types

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'source'
EXPECTED = {
    'regional_calibration.py': '6236493c86c31e0f3b7c605692601146e716bbbf',
    'selection.py': 'c79decdbee12db2e2e4ae70dfb2a70d3174c37dd',
    'evidence_diagnostic.py': '40e7668e76862b4b3f61f31d5c77f6fde6d34578',
    'calibration.py': '6c5cf91e7513bd7674f558ea1f474c58168db6b4',
}
source_rows = []
for name, expected in EXPECTED.items():
    b = (SRC/name).read_bytes()
    blob = hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    assert blob == expected, (name, blob)
    source_rows.append({'file':name,'bytes':len(b),'blob_sha1':blob,'expected':expected,
                        'exact':True,'sha256':hashlib.sha256(b).hexdigest()})

pkg=types.ModuleType('audit_src'); pkg.__path__=[str(SRC)]; sys.modules['audit_src']=pkg
def load(name):
    spec=importlib.util.spec_from_file_location('audit_src.'+name,SRC/(name+'.py'))
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod);return mod
E=load('evidence_diagnostic'); C=load('regional_calibration'); S=load('selection')
# Remove ONLY the unneeded evidence import for the candidate=None branch. Helpers
# are intentionally absent: an unexpected call fails rather than inventing facts.
tree=ast.parse((SRC/'calibration.py').read_text())
tree.body=[n for n in tree.body if not (isinstance(n,ast.ImportFrom) and n.module=='evidence')]
ns={'__name__':'audit_src.calibration_no_taf_probe','__package__':'audit_src'}
exec(compile(tree,str(SRC/'calibration.py'),'exec'),ns)

results=[]
def record(name, details, interpretation='expected_contract'):
    results.append({'name':name,'observed':details,'interpretation':interpretation})
def raises(call):
    try: call()
    except (ValueError,TypeError): return True
    return False

n=0
for k in range(1,5):
    for v in itertools.product(sorted(E.TRUTH), repeat=k):
        expected='conflict' if any(x=='conflict' for x in v) else 'true' if any(x=='true' for x in v) else 'false' if set(v)=={'false'} else 'unknown'
        assert E.aggregate(v)==expected
        n+=1
record('E_aggregate_exhaustive_bounded',{'input_combinations':n,'all_match_declared_conflict_first_rule':True})
assert raises(lambda:E.aggregate([])) and raises(lambda:E.aggregate(['bad']))
record('E_empty_and_bad_state_rejected',True)

def view(assets,ids=('q0',),cutoff=20):
    return {'baseline':{'content':{'E_question':{'query_ids':list(ids),'threshold_m':1000}}},'assets':assets,'cutoff':cutoff}
def asset(lo,hi,lc=True,uc=True,q='q0',available=1,completed=2,status='disclosed_product_fact'):
    return {'available_at':available,'completed_at':completed,'content':{'query_id':q,'status':status,'reports':[{'visibility':{'lower':lo,'upper':hi,'lower_closed':lc,'upper_closed':uc}}]}}
for title,args,answer in [
    ('strict_upper_open',(0,1000,True,False),'true'),
    ('strict_upper_closed',(0,1000,True,True),'unknown'),
    ('at_threshold_point',(1000,1000,True,True),'false'),
    ('right_censored',(1000,'+inf',True,False),'false')]:
    actual=E.independent_reference(view([asset(*args)]))['fact_truth']; assert actual==answer
    record('E_'+title,actual)
actual=E.independent_reference(view([asset(2000,2000)],ids=('q0','q1')))
assert actual['fact_truth']=='unknown' and actual['slots']=={'q0':'false','q1':'unknown'}
record('E_negative_witness_does_not_close_unread_slot',actual)
assert E.independent_reference(view([asset(0,100,completed=30)]))['fact_truth']=='unknown'
record('E_future_completion_not_visible',True)
assert E.independent_reference(view([asset(500,500),asset(2000,2000,available=5,completed=6)]))['fact_truth']=='false'
record('E_newer_disclosed_version_replaces_old',True)
assert E.independent_reference(view([asset(500,500),asset(2000,2000)]))['fact_truth']=='conflict'
record('E_same_version_inconsistency_not_vacuous_truth',True)
assert raises(lambda:E.parse('{"fact_truth":"true","fact_truth":"false"}', ['q0'],'direct'))
record('E_duplicate_JSON_key_rejected',True)
raw='{"slots":{"q0":"false","q1":"unknown"},"fact_truth":"false"}'
parsed=E.parse(raw,['q0','q1'],'slotwise')
reduced=E.aggregate(parsed['slots'].values())
assert parsed['fact_truth']=='false' and reduced=='unknown'
record('E_semantically_inconsistent_answer_retained_for_scoring',{'model_fact_truth':parsed['fact_truth'],'reducer_from_model_slots':reduced},'intentional_diagnostic_not_parser_bug')

kwargs={'query_handles':['q0','q1'],'target_handles':['t0'],'forecast_cap':1}
assert S.parse_selection('{"query_order":["q0"],"forecast_handles":["t0"]}',**kwargs)['query_order']==['q0']
assert raises(lambda:S.parse_selection('{"query_order":["q0","q0"],"forecast_handles":["t0"]}',**kwargs))
record('selector_valid_and_duplicate_handles',True)
raw='{"query_order":["q0"],"query_order":["q1"],"forecast_handles":["t0"]}'
actual=S.parse_selection(raw,**kwargs)
assert actual['query_order']==['q1']
record('selector_duplicate_JSON_key_silently_accepted',actual,'confirmed_local_parser_hardening_gap_no_historical_incidence_claim')

rng=random.Random(14)
for _ in range(40):
    rows=[(rng.choice([0.02,0.1,0.3,0.8]),rng.choice([0,1]),rng.choice([0.5,1,2])) for _ in range(60)]
    blocks=C.fit_monotone(rows); vals=[C.apply_monotone(blocks,x/100) for x in range(101)]
    assert vals==sorted(vals) and all(0<=v<=1 for v in vals)
record('PAV_monotonicity_and_probability_range',{'synthetic_fits':40,'grid_per_fit':101})
coarse=C.fit_monotone([(0.1,0,1)]*100)
fine=C.fit_monotone([(0.1+i*1e-12,0,1) for i in range(100)])
coarse_p=C.apply_monotone(coarse,0.1); fine_p=C.apply_monotone(fine,0.1)
assert math.isclose(coarse_p,1/102) and math.isclose(fine_p,1/3)
record('PAV_per_distinct_probability_prior_sensitivity',{'100_identical_negative_samples':coarse_p,'100_tiny_distinct_negative_probabilities':fine_p},'documented_estimator_design_sensitivity_not_test_leak_or_arithmetic_bug')

bank={'minimum_cell_n':20,'mapping_version':'synthetic_probe',
      'cells':{'[1000,"no_taf"]':{'n':98,'positive':9},'[1000,"pooled"]':{'n':98,'positive':9}},
      'post_calibration':{'1000':{'base':[{'lower':0,'upper':1,'value':0.1}],
                                       'evidence':[{'lower':0,'upper':1,'value':0.4}]}}}
target={'threshold':1000,'physical_start':1000000000}
p0=ns['predict'](bank,target,None)
p1=ns['predict'](bank,target,None,['q0'],{'q0':{'status':'missing'}})
assert p0['cell_key']==p1['cell_key'] and p0['n']==p1['n'] and p0['probability']!=p1['probability']
record('same_raw_cell_different_postcalibration_family',{'without_query':p0,'with_nonempty_missing_query':p1},'synthetic_no_TAF_path_isolation; not_evidence_of_real_data_influence; not_asserting_missingness_is_uninformative')

summary={'commit':'6f71c8799ff69439a18f645e63b8c966ca21eec4',
         'scope':'three full stdlib modules; calibration no-TAF path dependency import omitted; all input fixtures synthetic',
         'full_repository_tests_run':False,'historical_runs_recomputed':False,'model_calls':0,'network_calls':0,
         'source_hashes':source_rows,'probe_groups':len(results),'results':results}
(ROOT/'SOURCE_HASH_CHECK.json').write_text(json.dumps(source_rows,indent=2)+'\n')
(ROOT/'PROBE_RESULTS.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source_hashes_match':len(source_rows),'probe_groups':len(results),'findings':[r for r in results if r['interpretation']!='expected_contract']},ensure_ascii=False,indent=2))
