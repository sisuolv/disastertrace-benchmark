#!/usr/bin/env python3
"""Test the real temperature auditor on synthetic complete/incomplete filesystem trees.
No production data is altered and no model is called. Transport read/publish only
are substituted. All tested source bytes are verified against the Git blob.
"""
import argparse,contextlib,hashlib,importlib.util,io,json,shutil,sys,tempfile,types
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group(required=True)
 g.add_argument('--repo',type=Path);g.add_argument('--source',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 if a.output.exists():raise FileExistsError(a.output)
 src=a.source or a.repo/'plans/v9_followup_execution_20260914_01/scripts/analyze_temperature_fullcalendar.py'
 b=src.read_bytes();h=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 if h!='db5b07402a77da93a95b59ff317c0f34d3cacaf6':raise ValueError('Source changed; review diff before interpreting this test')
 def write(path,row):
  path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(row))
 def publish(path,row):
  with path.open('x') as f:json.dump(row,f)
 for name in ['disastertrace','disastertrace.monitoring_v1']:
  m=types.ModuleType(name);m.__path__=[];sys.modules[name]=m
 spool=types.ModuleType('disastertrace.monitoring_v1.spool_backend');spool.publish=publish;spool.read=lambda p:json.loads(p.read_text());sys.modules[spool.__name__]=spool
 spec=importlib.util.spec_from_file_location('temperature_auditor_under_test',src);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 rows=[]
 with tempfile.TemporaryDirectory(prefix='dt-v9-completeness-') as temp:
  root=Path(temp);base=root/'template'
  arms=[k+'__'+p for k in ['follow','copy_latest','copy_current','first_issue_hold'] for p in ['base_bound_override','persistent_override']]
  months=[f'{y}-{mo:02d}' for y in [2017,2018] for mo in range(1,13)]
  write(base/'COMPLETE.json',{'programs':[{'case':month,'arm':arm,'exit_code':0} for month in months for arm in arms]})
  for month in months:
   folder=base/month;oid=month+'-o';row={'opportunity_id':oid,'target':{'target_id':month+'-t'},'event':'hot_day','probability':0.2}
   write(folder/'POLICY.json',{'rows':[row]});write(folder/'OUTCOMES.json',[{'opportunity_id':oid,'value':0}])
   write(folder/'SCORES.json',{'scores':{'arms':{arm:{'mean_loss':0.04} for arm in arms}}})
   for arm in arms:write(folder/arm/'SNAPSHOTS.json',{oid:{'forecast':{'value':0.2}}})
  for mode in ['intact','missing_month','missing_arm','wrong_score']:
   data=root/mode;shutil.copytree(base,data)
   if mode=='missing_month':shutil.rmtree(data/'2018-12')
   if mode=='missing_arm':shutil.rmtree(data/'2018-12'/'copy_current__persistent_override')
   if mode=='wrong_score':
    f=data/'2018-12'/'copy_current__persistent_override'/'SNAPSHOTS.json';v=json.loads(f.read_text());v['2018-12-o']['forecast']['value']=0.9;write(f,v)
   m.DATA=data;m.OUT=root/(mode+'-out');caught=None
   with contextlib.redirect_stdout(io.StringIO()):
    try:m.main()
    except Exception as exc:caught=type(exc).__name__
   v=json.loads((m.OUT/'VALIDATION.json').read_text()) if (m.OUT/'VALIDATION.json').exists() else None
   observed_months=len(list(data.glob('20??-??')));observed_arms=len(list(data.glob('20??-??/*__*override')))
   if mode=='intact':assert caught is None and v['passed'] and observed_arms==192
   elif mode=='wrong_score':assert caught=='AssertionError' and v is None
   else:assert caught is None and v['passed'] and (observed_months!=v['windows'] or observed_arms!=v['sessions'])
   rows.append({'case':mode,'category':'reproduced_completeness_boundary' if mode.startswith('missing') else 'control',
    'actual_months':observed_months,'actual_arm_directories':observed_arms,'exception':caught,
    'reported_passed':None if v is None else v['passed'],'reported_months':None if v is None else v['windows'],
    'reported_sessions':None if v is None else v['sessions'],'check_assertion_passed':True})
 a.output.write_text(json.dumps({'commit':'6f71c8799ff69439a18f645e63b8c966ca21eec4','source_git_blob':h,
  'scope':'synthetic complete/incomplete 24-month filesystem, production auditor main; not an audit of real 192 trajectories',
  'checks':rows,'count':len(rows)},indent=2)+'\n');print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
