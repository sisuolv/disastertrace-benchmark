#!/usr/bin/env python3
"""Offline source-level checks for DisasterTrace 6f71c879.

Runs exact Git-blob-verified modules. HTTP, credentials, spool publication,
clock and lifecycle ledger are test doubles. ApiBudget uses real local files
and fcntl; this does NOT exercise AFS or the complete session/journal runtime.
No network or paid model call is performed.

python review_checks.py --repo /path/to/checkout --output NEW_RESULTS.json
or: --source-dir /directory/containing/the/four/source/modules
"""
from __future__ import annotations
import argparse, contextlib, hashlib, importlib.util, io, json, os, sys, tempfile, types
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError

EXPECTED = {
 'api_capture.py':'9dead639a11b7d4f1f9de6c6e2a253a5665be93c',
 'calibration.py':'6c5cf91e7513bd7674f558ea1f474c58168db6b4',
 'regional_calibration.py':'6236493c86c31e0f3b7c605692601146e716bbbf',
 'lifecycle.py':'d6a0956bb6c32bafdbff9a7b610720e8616cd50c',
}

def main():
 p=argparse.ArgumentParser(description=__doc__)
 g=p.add_mutually_exclusive_group(required=True)
 g.add_argument('--repo',type=Path);g.add_argument('--source-dir',type=Path)
 p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 if a.output.exists(): raise FileExistsError('Preserve prior audit output')
 root=a.source_dir or a.repo/'disastertrace-starter/src/disastertrace/monitoring_v1'
 source=[]
 for name,want in EXPECTED.items():
  raw=(root/name).read_bytes();got=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
  if got!=want: raise ValueError(f'{name}: source changed; inspect diff, do not label as reviewed commit')
  source.append({'file':name,'git_blob':got,'sha256':hashlib.sha256(raw).hexdigest()})
 package=types.ModuleType('dt_review_modules');package.__path__=[str(root)];sys.modules[package.__name__]=package
 # Only unrelated transport primitives are replaced. The code under test is unchanged.
 spool=types.ModuleType('dt_review_modules.spool_backend')
 def publish(path,payload):
  with Path(path).open('x') as f:json.dump(payload,f,allow_nan=False)
 spool.publish=publish;spool.read=lambda path:json.loads(Path(path).read_text())
 sys.modules[spool.__name__]=spool
 ev=types.ModuleType('dt_review_modules.evidence')
 def unavailable(*args,**kw):raise AssertionError('This test must not call a weather feature extractor')
 ev.evidence_features=ev.taf_features=unavailable;sys.modules[ev.__name__]=ev
 def load(name):
  s=importlib.util.spec_from_file_location('dt_review_modules.'+name,root/(name+'.py'))
  m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);return m
 api=load('api_capture');reg=load('regional_calibration');cal=load('calibration');life=load('lifecycle')
 results=[]
 def case(name,category,fn):
  try:
   details=fn();results.append({'name':name,'category':category,'check_passed':True,'observation':details})
  except Exception as e:
   results.append({'name':name,'category':category,'check_passed':False,'error':type(e).__name__+': '+str(e)})
 def budget(path,limit=100000000,max_calls=10):
  path.write_text(json.dumps({'limit_nanodollars':limit,'max_calls':max_calls,'calls':{}}))
  return api.ApiBudget(path)
 def rejected(fn,exc=ValueError):
  try:fn()
  except exc:return True
  raise AssertionError('Expected rejection')
 with tempfile.TemporaryDirectory(prefix='dt-v9-review-') as td:
  d=Path(td);key=d/'dummy.key';key.write_text('LOCAL_TEST_VALUE_NOT_A_REAL_KEY')
  os.environ['DISASTERTRACE_DEEPSEEK_KEY_FILE']=str(key)
  def ledger_ok():
   b=budget(d/'normal.json');b.transact('a',100);b.transact('a',actual=40)
   state=spool.read(b.path);assert state['calls']['a']['actual']==40
   return {'reserved':100,'settled':40}
  case('api_budget_reserve_and_settle','positive_control',ledger_ok)
  def duplicate():
   b=budget(d/'dup.json');b.transact('a',100);rejected(lambda:b.transact('a',100));return {'duplicate_rejected':True}
  case('api_budget_duplicate','protective_control',duplicate)
  def hardlimit():
   b=budget(d/'limit.json',100);b.transact('a',80);rejected(lambda:b.transact('b',21));return {'over_limit_rejected':True}
  case('api_budget_limit','protective_control',hardlimit)
  def unknown():
   b=budget(d/'unknown.json',100);b.transact('a',80);b.transact('a',outcome='unknown')
   rejected(lambda:b.transact('b',21));return {'unknown_reserve_retained':80}
  case('api_budget_unknown_retention','protective_control',unknown)
  def overrun():
   b=budget(d/'overrun.json');b.transact('a',10);b.transact('a',actual=11)
   rejected(lambda:b.transact('b',1));assert spool.read(b.path)['calls']['a']['actual']==11
   return {'actual_not_clipped':11,'further_call_rejected':True}
  case('api_budget_overrun','protective_control',overrun)
  def boolean_fee():
   b=budget(d/'bool.json');rejected(lambda:b.transact('a',True));b.transact('a',1)
   rejected(lambda:b.transact('a',actual=True));return {'boolean_rejected':True}
  case('api_budget_boolean','protective_control',boolean_fee)
  def lock_retry():
   b=budget(d/'lock.json');calls=[]
   def flock(*args):
    calls.append(1)
    if len(calls)<3:raise BlockingIOError('simulated AFS contention')
   with patch.object(api.fcntl,'flock',flock),patch.object(api.time,'sleep',lambda s:None):b.transact('a',10)
   assert len(calls)==3;return {'local_lock_attempts':3,'network_calls':0}
  case('bounded_local_lock_retry','positive_control',lock_retry)
  base_response={'model':'test-provider','usage':{'prompt_tokens':10,'completion_tokens':3},
      'choices':[{'message':{'content':'{"fact_truth":"unknown"}'},'finish_reason':'stop'}]}
  class Response:
   status=200
   def __init__(self,body):self.body=body
   def __enter__(self):return self
   def __exit__(self,*args):return False
   def read(self,n):return self.body[:n]
  def capture_case(label,body=None,opener_error=None,fail_transactions=False):
   path=d/label;b=budget(d/(label+'.budget.json'));original=b.transact
   if fail_transactions:
    def transact(call_id,reserve=None,**kw):
     if reserve is None:raise TimeoutError('simulated persistent local ledger lock')
     return original(call_id,reserve,**kw)
    b.transact=transact
   count=[]
   class Opener:
    def open(self,*args,**kwargs):
     count.append(1)
     if opener_error is not None:raise opener_error
     return Response(body if body is not None else json.dumps(base_response).encode())
   caught=None;answer=None
   with patch.object(api,'build_opener',lambda *a:Opener()):
    try:answer=api.capture([{'role':'user','content':'test'}],'deepseek-flash','c',path,b)
    except Exception as e:caught=type(e).__name__
   return {'http_attempts':len(count),'exception':caught,'response_body_exists':(path/'RESPONSE.body').exists(),
    'response_json_exists':(path/'RESPONSE.json').exists(),'failure_json_exists':(path/'FAILURE.json').exists(),
    'ledger_status':spool.read(b.path)['calls']['c']['status'],'return_value':answer}
  def success():
   r=capture_case('success');assert r['http_attempts']==1 and r['ledger_status']=='settled' and r['response_body_exists']
   r.pop('return_value');return r
  case('capture_success_persists_before_return','positive_control',success)
  def malformed():
   r=capture_case('malformed',b'{not json');assert r['http_attempts']==1 and r['ledger_status']=='unknown' and r['failure_json_exists'] and r['response_body_exists']
   r.pop('return_value');return r
  case('capture_malformed_json_preserved','protective_control',malformed)
  def error_http():
   e=HTTPError('https://not-requested.invalid',503,'test',{},io.BytesIO(b'provider unavailable'))
   r=capture_case('http_error',opener_error=e);assert r['failure_json_exists'] and r['ledger_status']=='unknown' and r['http_attempts']==1
   r.pop('return_value');return r
  case('capture_http_error_no_retry','protective_control',error_http)
  def double_lock():
   r=capture_case('double_lock',fail_transactions=True)
   assert r['response_body_exists'] and r['response_json_exists'] and not r['failure_json_exists'] and r['exception']=='TimeoutError' and r['ledger_status']=='reserved'
   r.pop('return_value');return r
  case('failure_record_blocked_by_second_ledger_failure','reproduced_boundary',double_lock)
  def broken_error_body():
   class BrokenHTTPError(HTTPError):
    def read(self,*args):raise OSError('simulated error-body read failure')
   r=capture_case('broken_error_body',opener_error=BrokenHTTPError('https://not-requested.invalid',503,'test',{},None))
   assert r['exception']=='OSError' and not r['failure_json_exists'] and r['ledger_status']=='reserved' and r['http_attempts']==1
   r.pop('return_value');return r
  case('failure_record_blocked_by_http_error_body_read','reproduced_boundary',broken_error_body)
  def reconcile_limit():
   b=budget(d/'reconcile.json');b.transact('a',100);b.transact('a',outcome='unknown');rejected(lambda:b.transact('a',actual=50))
   return {'unknown_to_settled_currently_rejected':True,'classification':'documented_design_limit_not_a_score_failure'}
  case('unknown_fee_reconciliation_missing','design_limit',reconcile_limit)
 # No weather extractor is called: no-TAF branch deliberately isolates mapping-family behavior.
 bank={'minimum_cell_n':20,'cells':{'[1000,"no_taf"]':{'n':98,'positive':9},'[1000,"pooled"]':{'n':98,'positive':9}},
       'mapping_version':'synthetic','post_calibration':{'1000':{'base':[{'lower':0,'upper':1,'value':0.2}],
       'evidence':[{'lower':0,'upper':1,'value':0.6}]}}}
 target={'threshold':1000}
 def calibrator_switch():
  a=cal.predict(bank,target,None)
  b=cal.predict(bank,target,None,['q'],{'q':{'status':'missing','reports':[]}})
  assert a['cell_key']==b['cell_key'] and a['probability']==0.2 and b['probability']==0.6
  return {'same_cell_key':a['cell_key'],'base_probability':0.2,'evidence_probability':0.6,
          'classification':'design/attribution control, not proof of erroneous historical scores'}
 case('calibrator_switch_without_feature_cell_change','attribution_control',calibrator_switch)
 def no_post_cal():
  b={k:v for k,v in bank.items() if k!='post_calibration'}
  assert cal.predict(b,target,None)['probability']==cal.predict(b,target,None,['q'],{'q':{}})['probability']==0.1
  return {'raw_probability_invariant':0.1}
 case('same_cell_without_post_calibration','positive_control',no_post_cal)
 def empty_disclosed():
  assert cal.predict(bank,target,None,[],{})['probability']==0.2;return {'empty_dict_uses_base_calibrator':True}
 case('empty_disclosure_calibration','positive_control',empty_disclosed)
 def pav():
  blocks=reg.fit_monotone([(0.1,1,1),(0.2,0,1),(0.9,1,1)])
  vals=[reg.apply_monotone(blocks,k/100) for k in range(101)]
  assert vals==sorted(vals) and all(0<=v<=1 for v in vals)
  return {'tested_grid_points':101,'monotone':True,'bounded':True}
 case('weighted_pav_monotonicity','positive_control',pav)
 for label,rows in [('no_rows',[]),('negative_weight',[(0.5,1,-1)]),('bad_probability',[(1.5,1,1)])]:
  case('pav_reject_'+label,'protective_control',lambda rows=rows: {'rejected':rejected(lambda:reg.fit_monotone(rows))})
 def life_measured():
  class Ledger:
   entries={'c':{}}
   def record_execution_timing(self,c,ns,kind):
    if not hasattr(self,'first'):self.first=ns
    self.entries[c]['timing']={'elapsed_us':(ns-self.first)//1000}
  ledger=Ledger()
  with patch.object(life.time,'time_ns',side_effect=[0,40_000_000_000]):
   raw,details=life.invoke(lambda:('x',{'seconds':1,'elapsed_seconds':1}),(),'c',ledger,policy='lifecycle_wall_v1')
  assert details['elapsed_seconds']==40 and details['seconds']==1
  return {'delivery_seconds':40,'backend_seconds_retained':1}
 case('lifecycle_wall_extends_backend_elapsed','positive_control',life_measured)
 def life_error():
  class Ledger:
   entries={'c':{}}
   def record_execution_timing(self,c,ns,kind):
    if not hasattr(self,'first'):self.first=ns
    self.entries[c]['timing']={'elapsed_us':(ns-self.first)//1000}
  ledger=Ledger()
  def fail():raise TimeoutError('test')
  with patch.object(life.time,'time_ns',side_effect=[0,40_000_000_000]):rejected(lambda:life.invoke(fail,(),'c',ledger,policy='lifecycle_wall_v1'),TimeoutError)
  assert life.elapsed_us(ledger,'c')==40_000_000;return {'interrupted_wait_us':40_000_000}
 case('lifecycle_records_interrupted_wait','protective_control',life_error)
 report={'commit':'6f71c8799ff69439a18f645e63b8c966ca21eec4','scope':'exact full modules; fake HTTP/spool primitives/clock/ledger; no full pipeline, no AFS, no upstream downloads, no API or GPU',
         'source_verification':source,'checks':results,'count':len(results),'all_check_assertions_passed':all(x['check_passed'] for x in results),
         'reproduced_boundaries':sum(x['category']=='reproduced_boundary' and x['check_passed'] for x in results),
         'note':'A passing assertion on a reproduced boundary means the undesirable behavior was reproduced; it is not a system acceptance test.'}
 a.output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'checks':len(results),'check_assertions_passed':sum(x['check_passed'] for x in results),'reproduced_boundary_cases':report['reproduced_boundaries']},indent=2))
 for x in results:
  if not x['check_passed']:print(x)
 if not report['all_check_assertions_passed']:raise SystemExit(1)
if __name__=='__main__':main()
