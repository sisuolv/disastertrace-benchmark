"""Local audit namespace; not an upstream module."""
