"""Bounded CPU audit of exact modules; all weather fixtures here are synthetic."""
import copy
import itertools
import json
import math
import unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import evidence_diagnostic as diag
from disastertrace.monitoring_v1 import calibration as cal
from disastertrace.monitoring_v1.regional_calibration import fit_monotone,apply_monotone
from disastertrace.monitoring_v1.process_split import process_components,chronological_roles
from disastertrace.monitoring_v1.support import Interval,classify,EvidenceFact,public_support
from disastertrace.monitoring_v1.evidence import report_fact_status,exists_report_support

def product(lo=0,hi=500,lc=True,uc=True,status='disclosed_product_fact'):
 return {'status':status,'reference_kind':'product_label','support_assumption':'product_exact',
 'visible_information_scope':'policy_after_query','reports':[{'visibility':{'lower':lo,'upper':hi,'lower_closed':lc,'upper_closed':uc}}]}
def asset(qid,lo,hi,at=10,completed=11,uc=True,status='disclosed_product_fact'):
 return {'available_at':at,'completed_at':completed,'content':{'query_id':qid,**product(lo,hi,uc=uc,status=status)}}
def view(assets,qids=('a','b'),cutoff=100):
 return {'cutoff':cutoff,'baseline':{'content':{'E_question':{'threshold_m':1000,'query_ids':list(qids)}}},'assets':assets}
def row(oid,start,end,assets=()):
 return {'opportunity_id':oid,'footprint_start':start,'footprint_end':end,'native_versions':list(assets)}
class ETests(unittest.TestCase):
 def test_01_truth_table(self):
  for n in range(1,5):
   for values in itertools.product(('true','false','unknown','conflict'),repeat=n):
    expected='conflict' if any(v=='conflict' for v in values) else 'true' if any(v=='true' for v in values) else 'false' if set(values)=={'false'} else 'unknown'
    self.assertEqual(diag.aggregate(values),expected)
 def test_02_partial_false_is_unknown(self):self.assertEqual(diag.aggregate(['false','unknown']),'unknown')
 def test_03_partial_true_is_true(self):self.assertEqual(diag.aggregate(['true','unknown']),'true')
 def test_04_conflict_priority_is_declared(self):self.assertEqual(diag.aggregate(['true','conflict']),'conflict')
 def test_05_open_endpoint(self):
  self.assertEqual(diag.independent_reference(view([asset('a',0,1000,uc=False)]))['fact_truth'],'true')
 def test_06_closed_endpoint(self):
  self.assertEqual(diag.independent_reference(view([asset('a',0,1000)]))['fact_truth'],'unknown')
 def test_07_newer_missing_does_not_revive_old(self):
  v=view([asset('a',0,100),asset('a',0,100,at=20,completed=21,status='missing')])
  self.assertEqual(diag.independent_reference(v)['fact_truth'],'unknown')
 def test_08_late_completion_not_visible(self):
  self.assertEqual(diag.independent_reference(view([asset('a',0,100,completed=101)]))['fact_truth'],'unknown')
 def test_09_same_time_conflict(self):
  v=view([asset('a',0,100),asset('a',5000,5000)])
  self.assertEqual(diag.independent_reference(v)['fact_truth'],'conflict')
 def test_10_parser_preserves_wrong_aggregate(self):
  raw='{"fact_truth":"false","slots":{"a":"false","b":"unknown"}}'
  parsed=diag.parse(raw,['a','b'],'slotwise')
  self.assertEqual(parsed['fact_truth'],'false')
  self.assertNotEqual(parsed['fact_truth'],diag.aggregate(parsed['slots'].values()))
 def test_11_duplicate_keys_rejected(self):
  with self.assertRaises(ValueError):diag.parse('{"fact_truth":"false","fact_truth":"true"}',['a'],'direct')
 def test_12_missing_slot_rejected(self):
  with self.assertRaises(ValueError):diag.parse('{"fact_truth":"unknown","slots":{"a":"false"}}',['a','b'],'slotwise')
 def test_13_bool_truth_rejected(self):
  with self.assertRaises(ValueError):diag.parse('{"fact_truth":true}',['a'],'direct')
 def test_14_reference_is_read_only(self):
  v=view([asset('a',0,50)]);old=copy.deepcopy(v);diag.independent_reference(v);self.assertEqual(old,v)
 def test_15_cross_reducer_intervals(self):
  samples=[(0,500,True),(0,1000,True),(0,1000,False),(1000,2000,True),(5000,'+inf',True)]
  mapping={'supported':'true','refuted':'false','undetermined':'unknown','inconsistent':'conflict'}
  for a,b in itertools.product(samples,repeat=2):
   products={k:product(lo,hi,uc=uc) for k,(lo,hi,uc) in zip(('a','b'),(a,b))}
   v=view([asset(k,lo,hi,uc=uc) for k,(lo,hi,uc) in zip(('a','b'),(a,b))])
   self.assertEqual(mapping[exists_report_support(['a','b'],products,1000)],diag.independent_reference(v)['fact_truth'])
class PAVTests(unittest.TestCase):
 def test_16_analytic_separate(self):self.assertEqual([r['value'] for r in fit_monotone([(.1,0,1),(.9,1,1)])],[1/3,2/3])
 def test_17_analytic_pool(self):self.assertEqual(fit_monotone([(.1,1,1),(.9,0,1)])[0]['value'],.5)
 def test_18_order_invariance(self):
  a=[(.1,0,.5),(.1,1,1),(.6,0,2),(.9,1,3)];self.assertEqual(fit_monotone(a),fit_monotone(a[::-1]))
 def test_19_weight_repetition(self):self.assertEqual(fit_monotone([(.1,1,3),(.9,0,2)]),fit_monotone([(.1,1,1)]*3+[(.9,0,1)]*2))
 def test_20_monotonic_map(self):
  blocks=fit_monotone([(.1,1,2),(.2,0,1),(.5,1,3),(.8,0,2),(.9,1,5)])
  ps=[apply_monotone(blocks,k/100) for k in range(101)]
  self.assertEqual(ps,sorted(ps));self.assertTrue(all(0<=v<=1 for v in ps))
 def test_21_invalid_weight_rejected(self):
  for w in (0,-1,math.inf,math.nan):
   with self.assertRaises(ValueError):fit_monotone([(.2,1,w)])
 def test_22_prior_mass_probe(self):
  # Reproduces the documented per-unique-probability prior; not a forecast experiment.
  a=fit_monotone([(.1,0,1)]*100)
  b=fit_monotone([(.1+i*1e-6,0,1) for i in range(100)])
  self.assertAlmostEqual(a[0]['value'],1/102)
  self.assertTrue(all(abs(r['value']-1/3)<1e-12 for r in b))
class SplitTests(unittest.TestCase):
 def test_23_overlap_transitive(self):
  g=process_components([row('a',0,5),row('b',4,8),row('c',7,10)])
  self.assertEqual(len(set(g.values())),1)
 def test_24_touching_half_open_separate(self):self.assertEqual(len(set(process_components([row('a',0,5),row('b',5,10)]).values())),2)
 def test_25_shared_asset_joins_distance(self):self.assertEqual(len(set(process_components([row('a',0,5,['x']),row('b',100,110,['x'])]).values())),1)
 def test_26_gap_merges(self):self.assertEqual(len(set(process_components([row('a',0,5),row('b',8,10)],gap_us=4).values())),1)
 def test_27_duplicate_ids_rejected(self):
  with self.assertRaises(ValueError):process_components([row('a',0,5),row('a',8,10)])
 def test_28_invalid_footprint_rejected(self):
  with self.assertRaises(ValueError):process_components([row('a',8,2)])
 def test_29_role_whole_window_required(self):
  a=chronological_roles([row('a',0,5),row('b',4,7),row('c',8,10)],{'fit':(0,5),'cal':(8,10)})
  self.assertEqual(a,{'a':'fit','b':'purged','c':'cal'})
 def test_30_role_shared_version_rejected(self):
  with self.assertRaises(ValueError):chronological_roles([row('a',0,5,['x']),row('c',8,10,['x'])],{'fit':(0,5),'cal':(8,10)})
 def test_31_role_interval_overlap_rejected(self):
  with self.assertRaises(ValueError):chronological_roles([] ,{'fit':(0,5),'cal':(4,10)})
class CalibrationAttributionTests(unittest.TestCase):
 @staticmethod
 def bank():
  return {'minimum_cell_n':20,'mapping_version':'synthetic_probe','cells':{'[1000,"no_taf"]':{'positive':9,'n':98},'[1000,"pooled"]':{'positive':9,'n':98}},'post_calibration':{'1000':{'base':[{'lower':0,'upper':1,'value':.02}],'evidence':[{'lower':0,'upper':1,'value':.2}]}}}
 def test_32_family_switch_without_raw_key_change(self):
  b=self.bank();t={'threshold':1000};p=cal.predict(b,t,None);q=cal.predict(b,t,None,['a'],{'a':product(status='missing')})
  self.assertEqual(p['cell_key'],q['cell_key']);self.assertEqual((p['probability'],q['probability']),(.02,.2))
 def test_33_missing_taf_erases_evidence_content(self):
  b=self.bank();t={'threshold':1000}
  p=cal.predict(b,t,None,['a'],{'a':product(0,100)})
  q=cal.predict(b,t,None,['a'],{'a':product(10000,10000)})
  self.assertEqual(p,q)
 def test_34_same_family_removes_switch_probe(self):
  b=self.bank();b['post_calibration']['1000']['evidence']=copy.deepcopy(b['post_calibration']['1000']['base']);t={'threshold':1000}
  self.assertEqual(cal.predict(b,t,None)['probability'],cal.predict(b,t,None,['a'],{'a':product(status='missing')})['probability'])
 def test_35_evidence_content_enters_qualified_taf_key(self):
  t={'threshold':1000,'physical_start':3_600_000_000}
  c={'issued_at':0,'projection':{'segments':[{'prevailing':[{'visibility':Interval(10000,10000).to_dict()}],'conditional':[]}]}}
  self.assertNotEqual(cal.feature_key(t,c,['a'],{'a':product(0,100)}),cal.feature_key(t,c,['a'],{'a':product(10000,10000)}))
if __name__=='__main__':unittest.main(verbosity=2)
