"""One exact repository capture recheck; no network and no new model execution."""
from pathlib import Path
import json, hashlib, sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'source'))
import evidence_diagnostic as e
D=R/'real_example';D.mkdir(exist_ok=True)
qid='routine-KJFK-2025-01-07T02:00:00Z';other='routine-KLGA-2025-01-07T02:00:00Z'
rawreport='KJFK 070251Z 35021G32KT 10SM FEW020 OVC100 M03/M09 A2965 RMK AO2 PK WND 35032/0249 SLP040 60000 T10331094 53005'
report={'archive_station':'JFK','archive_valid':'2025-01-07 02:51','decoded':True,'observation_time':1736218260000000,'quality_flags':[],'raw':rawreport,'slot_start':1736215200000000,'source_id':'metar-routine-KJFK','source_line':76,'station':'KJFK','temperature_c':-3,'visibility':{'lower':16093.44,'lower_closed':True,'upper':16093.44,'upper_closed':True},'weather':[]}
content={'query_id':qid,'reference_kind':'product_label','reports':[report],'status':'disclosed_product_fact','support_assumption':'product_exact','support_rule_version':'native_metar_interval.v1','visible_information_scope':'policy_after_query'}
asset={'asset_id':qid,'available_at':1736219100000000,'completed_at':1736219101000000,'content':content,'missingness':'disclosed_product_fact','raw':rawreport,'source_revision':'8e15524a23eb1adb94b53392c25bf0525a417da61f789f62cccb9d71a46caa09','support_rule_version':'native_metar_interval.v1'}
view={'cutoff':1736222400000000,'baseline':{'content':{'E_question':{'predicate':'any_registered_neighbor_slot_below_threshold','query_ids':[qid,other],'threshold_m':5000}}},'assets':[asset]}
request={'call_id':'b4036fdf4376bfe616b406a6','messages':e.messages(view,'focused_slots','slotwise')}
rawanswer='{\n  "slots": {\n    "routine-KJFK-2025-01-07T02:00:00Z": "false",\n    "routine-KLGA-2025-01-07T02:00:00Z": "unknown"\n  },\n  "fact_truth": "false"\n}'
response={'body':{'choices':[{'finish_reason':'stop','index':0,'logprobs':None,'message':{'content':rawanswer,'role':'assistant'}}],'created':1789381098,'id':'486c5884-2779-47b3-bb89-45917b7d4621','model':'deepseek-v4-pro','object':'chat.completion','system_fingerprint':'a307abda487cd1b463329ccb945ce396','usage':{'completion_tokens':67,'prompt_cache_hit_tokens':768,'prompt_cache_miss_tokens':8,'prompt_tokens':776,'prompt_tokens_details':{'cached_tokens':768},'total_tokens':843}},'elapsed_seconds':1.4343765992671251,'http_status':200,'original_body_sha256':'6f180f5f7b04292d8e805c0aab0e3ef3101aaabfa954b93c9d1aa1ad57f4909c','peak_tariff_cost_upper_nanodollars':1289640,'provider_compute_seconds':None,'redaction_applied':False}
verifications=[]
for name,obj,expected in [('POLICY.json',request,'5e1273468326acec1ce9fa1afe943773bdcd3196'),('RESPONSE.json',response,'60f83d72481a61cc6da38994ece97f5dcada6172')]:
 b=(json.dumps(obj,sort_keys=True)+'\n').encode();p=D/name;p.write_bytes(b)
 got=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();print(name,got==expected,got)
 verifications.append({'path':name,'actual_blob_sha':got,'expected_blob_sha':expected,'match':got==expected})
assert all(r['match'] for r in verifications)
ans=e.parse(rawanswer,[qid,other],'slotwise');ref=e.independent_reference(view)
result={'scope':'one captured real response; not a replay of the complete E02 batch','call_id':request['call_id'],'model':'deepseek-v4-pro','git_blob_checks':verifications,'reference':ref,'answer':ans,'all_slots_correct':ans['slots']==ref['slots'],'reported_final_correct':ans['fact_truth']==ref['fact_truth'],'self_consistent':ans['fact_truth']==e.aggregate(ans['slots'].values()),'new_model_calls':0,'actual_reference_scope':'disclosed native report labels only; no eventual weather outcome used'}
(R/'results/REAL_EXAMPLE_RECHECK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
