from pathlib import Path
import json,sys,hashlib
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'source'))
from disastertrace.monitoring_v1.regional_calibration import fit_monotone
from disastertrace.monitoring_v1.calibration import predict
from disastertrace.monitoring_v1.process_split import chronological_roles
flat=fit_monotone([(.1,0,1)]*100)
spread=fit_monotone([(.1+i*1e-6,0,1) for i in range(100)])
bank={'minimum_cell_n':20,'mapping_version':'synthetic_probe','cells':{'[1000,"no_taf"]':{'positive':9,'n':98},'[1000,"pooled"]':{'positive':9,'n':98}},'post_calibration':{'1000':{'base':[{'lower':0,'upper':1,'value':.02}],'evidence':[{'lower':0,'upper':1,'value':.2}]}}}
t={'threshold':1000}
a=predict(bank,t,None);b=predict(bank,t,None,['q'],{'q':{'status':'missing'}})
rows=[{'opportunity_id':'a','footprint_start':9,'footprint_end':3,'native_versions':[]}]
res={'all_examples_synthetic':True,'not_recalculated_real_trajectory_scores':True,
'family_switch':{'base':a,'disclosed_missing':b,'same_raw_cell':a['cell_key']==b['cell_key'],'interpretation':'Numerical change includes post-calibrator-family selection. Missingness/acquisition status can itself be informative; this is not proof of no information or leakage.'},
'prior_mass':{'n':100,'positive':0,'same_raw_score_unique_cells':1,'same_raw_score_probability':flat[0]['value'],'distinct_nearby_raw_scores_unique_cells':100,'distinct_raw_scores_probability':spread[0]['value'],'laplace_pseudocount_total_same':2,'laplace_pseudocount_total_distinct':200,'interpretation':'The documented regularizer depends on count of distinct raw scores. This is not a failure of PAV; do not replace evaluated banks retrospectively.'},
'input_validation_boundary':{'function':'chronological_roles','malformed_interval':rows[0],'observed_assignment':chronological_roles(rows,{'fit':(0,10)}),'scope':'direct helper call only; production manifest validates valid target/cutoff and process_components rejects reversed interval. No current split contamination demonstrated.'}}
(R/'results/DESIGN_DIAGNOSTICS.json').write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n')
summary={'reviewed_commit':'6f71c8799ff69439a18f645e63b8c966ca21eec4','unit_tests':{'run':35,'passed':35,'failed':0,'errors':0,'skipped':0,'log':'local_tests.log','scope':'exact local source modules; synthetic fixture tests, including 340 enumerated truth vectors and 25 interval pairs within two tests'},'real_examples_rechecked':1,'repo_reported_suite_tests':616,'repo_reported_suite_executed_here':False,'source_files_git_sha_verified':7,'model_calls_made_here':0,'scientific_downloads_made_here':0,'full_model_batch_replayed_here':False,'zip_source_download':'not obtained: GitHub text connector rejects binary and container network/download attempts did not retrieve it','transcription_note':'One inequality was initially transcribed incorrectly; Git SHA verification caught it before tests. Corrected local copy matches the upstream Git blob exactly; no repository change.'}
(R/'results/LOCAL_VALIDATION.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(res,indent=2,ensure_ascii=False))
