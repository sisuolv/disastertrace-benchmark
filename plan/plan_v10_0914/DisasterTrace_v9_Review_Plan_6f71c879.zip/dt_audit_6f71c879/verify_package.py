"""Verify the delivered local review bundle; does not access any network."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
m=json.loads((R/'MANIFEST.json').read_text())
for item in m['files']:
 p=R/item['path']
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
  raise SystemExit('Integrity mismatch: '+item['path'])
print('Verified',len(m['files']),'files; this is not a full repository replay.')
