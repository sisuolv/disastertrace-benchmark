"""Attribution probes, not regression failures or new model experiments."""
import copy
import json
from pathlib import Path
from reviewer_tests import calibration_fixture, predict, feature_key, report, Interval, e

ROOT = Path(__file__).resolve().parent

def main():
    t,c,b = calibration_fixture()
    empty = predict(b,t,c)
    missing = {'a':report(None,'missing')}
    read_missing = predict(b,t,c,['a'],missing)
    no_post = copy.deepcopy(b);no_post.pop('post_calibration')
    p1={'id':'P1','kind':'synthetic_attribution_probe','question':'Can a missing query change p through calibrator choice alone?',
        'without_query':empty,'missing_query':read_missing,
        'same_selected_raw_cell':empty['cell_key']==read_missing['cell_key'],
        'raw_probabilities':[predict(no_post,t,c)['probability'],predict(no_post,t,c,['a'],missing)['probability']],
        'statement':'Missing content leaves the report fact unknown. A nonempty disclosed dict changes the post-calibration family even when the raw cell remains identical. This is a design attribution confound, not proof that archived gains are wrong.'}
    low = {'a':report(Interval(200,200))}
    high = {'a':report(Interval(2000,2000))}
    p2={'id':'P2','kind':'synthetic_scope_probe','question':'Can different observation content affect a no-TAF fallback?',
        'low':predict(b,t,None,['a'],low),'high':predict(b,t,None,['a'],high),
        'low_key':feature_key(t,None,['a'],low),'high_key':feature_key(t,None,['a'],high),
        'statement':'For candidate=None the key omits evidence content. This is the current frequency predictor scope, not evidence that an LLM cannot use observations.'}
    raw='{"slots":{"routine-KSFO-2025-02-06T01:00:00Z":"false","routine-KSJC-2025-02-06T01:00:00Z":"unknown"},"fact_truth":"false"}'
    answer=e.parse(raw,['routine-KSFO-2025-02-06T01:00:00Z','routine-KSJC-2025-02-06T01:00:00Z'],'slotwise')
    p3={'id':'P3','kind':'existing_response_content_recheck','original_call_id':'1079e059c870ec9994df3f67',
        'source':'plans/v9_followup_execution_20260914_01/api_evidence_02/captures/deepseek-v4-pro/1079e059c870ec9994df3f67/RESPONSE.json',
        'source_git_blob':'b24655fdaa33bf5674121810c0f976372422d110',
        'scope':'Recheck of the fetched response content with source policy; not a replay of the HTTP receipt or every E02 response.',
        'parsed_answer':answer,'computed_aggregate':e.aggregate(answer['slots'].values()),
        'original_score_replaced':False,'new_model_call':False}
    result={'commit':'6f71c8799ff69439a18f645e63b8c966ca21eec4','probes':[p1,p2,p3],
            'counterexamples_do_not_prove_published_scoring_corruption':True}
    (ROOT/'PROBE_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
