"""Narrow offline tests on five exact Git blobs; never launches project scripts."""
import copy
import itertools
import json
import math
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))
from disastertrace.monitoring_v1.support import Interval, classify, EvidenceFact, public_support
from disastertrace.monitoring_v1.evidence import exists_report_support, sufficient_recipes
from disastertrace.monitoring_v1.calibration import predict, feature_key
from disastertrace.monitoring_v1.regional_calibration import fit_monotone, apply_monotone
import evidence_diagnostic as e

COUNTS = {}


def report(interval=None, status='disclosed_product_fact'):
    return {'status':status, 'reference_kind':'product_label', 'support_assumption':'product_exact',
            'visible_information_scope':'policy_after_query',
            'reports':([] if status != 'disclosed_product_fact' else [{'visibility': None if interval is None else interval.to_dict()}])}


def view(assets=(), ids=('a','b'), threshold=1000):
    return {'cutoff':100, 'baseline':{'content':{'E_question':{'query_ids':list(ids),'threshold_m':threshold}}},
            'assets':list(assets)}


def asset(qid, interval, available=10, completed=20, status='disclosed_product_fact'):
    return {'available_at':available, 'completed_at':completed,
            'content':{'query_id':qid, **report(interval,status)}}


def calibration_fixture():
    target={'threshold':1000, 'physical_start':3600_000_000}
    candidate={'issued_at':0, 'projection':{'segments':[{'prevailing':[{'visibility':Interval(10000,10000).to_dict()}], 'conditional':[]}]}}
    basekey=feature_key(target,candidate)
    bank={'minimum_cell_n':20,'mapping_version':'review_synthetic.v1',
          'cells':{basekey:{'n':98,'positive':9},'[1000,"pooled"]':{'n':98,'positive':9},'[1000,"no_taf"]':{'n':98,'positive':9}},
          'post_calibration':{'1000':{'base':[{'lower':0,'upper':1,'value':0.1}],
                                    'evidence':[{'lower':0,'upper':1,'value':0.35}]}}}
    return target,candidate,bank


class IntervalTests(unittest.TestCase):
    def test_01_strict_threshold(self):
        self.assertEqual(classify(Interval(0,1000,True,False),'lt',1000),'supported')
    def test_02_closed_threshold(self):
        self.assertEqual(classify(Interval(0,1000),'lt',1000),'undetermined')
    def test_03_equal_point_refutes_lt(self):
        self.assertEqual(classify(Interval(1000,1000),'lt',1000),'refuted')
    def test_04_open_lower_proves_gt(self):
        self.assertEqual(classify(Interval(1000,math.inf,False,False),'gt',1000),'supported')
    def test_05_empty_intersection(self):
        self.assertIsNone(Interval(0,1,True,False).intersect(Interval(1,2)))
    def test_06_invalid_interval(self):
        for args in [(2,1),(0,0,False,True),(math.nan,1)]:
            with self.assertRaises(ValueError): Interval(*args)
    def test_07_reference_classify_crosscheck(self):
        mapping={'supported':'true','refuted':'false','undetermined':'unknown'}
        tested=0
        for lo,hi in itertools.combinations_with_replacement([0,500,1000,2000],2):
            for lc,uc in itertools.product([False,True],repeat=2):
                if lo==hi and not(lc and uc): continue
                interval=Interval(lo,hi,lc,uc)
                for threshold in [500,1000,1500]:
                    output=e.independent_reference(view([asset('a',interval)],ids=('a',),threshold=threshold))
                    self.assertEqual(output['fact_truth'], mapping[classify(interval,'lt',threshold)])
                    tested+=1
        COUNTS['interval_predicate_cases']=tested
    def test_08_expired_revision_no_resurrection(self):
        def fact(version,interval,expires=None):
            return EvidenceFact('a',version,1,'visibility','m',interval,'product_label','product_exact','policy','v1',expires)
        got=public_support([fact(0,Interval(20,20)),fact(1,Interval(50,50),5)],'visibility','m',Interval(0,math.inf),10)
        self.assertEqual(got,Interval(0,math.inf))


class EvidenceTests(unittest.TestCase):
    def test_09_partial_negative_not_refutation(self):
        self.assertEqual(exists_report_support(['a','b'],{'a':report(Interval(2000,2000))},1000),'undetermined')
    def test_10_single_positive_witness(self):
        self.assertEqual(exists_report_support(['a','b'],{'a':report(Interval(500,500))},1000),'supported')
    def test_11_complete_negative(self):
        self.assertEqual(exists_report_support(['a','b'],{q:report(Interval(2000,2000)) for q in ['a','b']},1000),'refuted')
    def test_12_missing_not_false(self):
        self.assertEqual(exists_report_support(['a'],{'a':report(None,'missing')},1000),'undetermined')
    def test_13_conflict_policy_priority(self):
        self.assertEqual(e.aggregate(['true','conflict']),'conflict')
    def test_14_aggregate_all_combinations(self):
        mp={'true':report(Interval(10,10)),'false':report(Interval(2000,2000)),
            'unknown':report(None,'missing'),'conflict':report(None,'inconsistent_same_slot_facts')}
        trans={'supported':'true','refuted':'false','undetermined':'unknown','inconsistent':'conflict'}
        tested=0
        for states in itertools.product(sorted(e.TRUTH),repeat=3):
            ids=['a','b','c']; disclosed={qid:mp[s] for qid,s in zip(ids,states)}
            self.assertEqual(e.aggregate(states),trans[exists_report_support(ids,disclosed,1000)])
            tested+=1
        COUNTS['three_slot_combinations']=tested
    def test_15_recipes_positive(self):
        self.assertEqual(sufficient_recipes(['a','b'],{'a':report(Interval(10,10)),'b':report(Interval(2000,2000))},1000),(frozenset({'a'}),))
    def test_16_recipes_negative(self):
        self.assertEqual(sufficient_recipes(['a','b'],{q:report(Interval(2000,2000)) for q in ['a','b']},1000),(frozenset({'a','b'}),))
    def test_17_reference_current_version(self):
        got=e.independent_reference(view([asset('a',Interval(100,100)),asset('a',Interval(2000,2000),30,40)],ids=('a',)))
        self.assertEqual(got['fact_truth'],'false')
    def test_18_reference_late_not_disclosed(self):
        self.assertEqual(e.independent_reference(view([asset('a',Interval(10,10),10,101)],ids=('a',)))['fact_truth'],'unknown')
    def test_19_reference_same_time_conflict(self):
        got=e.independent_reference(view([asset('a',Interval(100,100)),asset('a',Interval(2000,2000))],ids=('a',)))
        self.assertEqual(got['fact_truth'],'conflict')
    def test_20_reference_missing_current_no_old_fallback(self):
        got=e.independent_reference(view([asset('a',Interval(100,100)),asset('a',None,30,40,'missing')],ids=('a',)))
        self.assertEqual(got['fact_truth'],'unknown')
    def test_21_response_reject_duplicate_keys(self):
        with self.assertRaises(ValueError): e.parse('{"fact_truth":"true","fact_truth":"false"}', ['a'],'direct')
    def test_22_response_reject_bool(self):
        with self.assertRaises(ValueError): e.parse('{"fact_truth":false}', ['a'],'direct')
    def test_23_response_reject_missing_slot(self):
        with self.assertRaises(ValueError): e.parse('{"slots":{"a":"false"},"fact_truth":"false"}', ['a','b'],'slotwise')
    def test_24_response_preserve_semantic_error(self):
        # Parsing accepts legal fields; independent evaluation must count the error.
        raw='{"slots":{"a":"false","b":"unknown"},"fact_truth":"false"}'
        answer=e.parse(raw,['a','b'],'slotwise')
        self.assertNotEqual(answer['fact_truth'],e.aggregate(answer['slots'].values()))
    def test_25_empty_reference_rejected(self):
        with self.assertRaises(ValueError):e.aggregate([])


class CalibrationTests(unittest.TestCase):
    def test_26_monotone_pav(self):
        blocks=fit_monotone([(0.1,1,1),(0.3,0,1),(0.9,1,1)])
        values=[apply_monotone(blocks,k/100) for k in range(101)]
        self.assertEqual(values,sorted(values))
    def test_27_order_invariant(self):
        rows=[(.1,1,1),(.1,0,1),(.6,1,1),(.9,0,1)]
        self.assertEqual(fit_monotone(rows),fit_monotone(list(reversed(rows))))
    def test_28_weight_split_invariant(self):
        self.assertEqual(fit_monotone([(.2,1,2)]),fit_monotone([(.2,1,1),(.2,1,1)]))
    def test_29_empty_calibration_rejected(self):
        with self.assertRaises(ValueError):fit_monotone([])
    def test_30_bad_row_rejected(self):
        for row in [(float('nan'),1,1),(.1,2,1),(.1,1,0),(2,1,1)]:
            with self.assertRaises(ValueError):fit_monotone([row])
    def test_31_calibration_prob_bounds(self):
        blocks=fit_monotone([(.1,0,2),(.9,1,2)])
        for p in [0,.3,1]: self.assertTrue(0<=apply_monotone(blocks,p)<=1)
    def test_32_empty_disclosure_equivalent(self):
        target,candidate,bank=calibration_fixture()
        self.assertEqual(predict(bank,target,candidate),predict(bank,target,candidate,['a'],{}))
    def test_33_sparse_cell_fallback_recorded(self):
        target,candidate,bank=calibration_fixture()
        visible={'a':report(Interval(500,500))}
        out=predict(bank,target,candidate,['a'],visible)
        self.assertEqual(out['cell_key'],feature_key(target,candidate))
    def test_34_horizon_negative_rejected(self):
        target,candidate,_=calibration_fixture();candidate['issued_at']=target['physical_start']+1
        with self.assertRaises(ValueError):feature_key(target,candidate)


if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    with (ROOT/'REVIEWER_TESTS.log').open('w') as log:
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    receipt={'schema':'reviewer.narrow_cpu_tests.v1','commit':'6f71c8799ff69439a18f645e63b8c966ca21eec4',
             'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
             'skipped':len(result.skipped),'passed':result.wasSuccessful(),'subcase_counts':COUNTS,
             'scope':'Five complete Git-blob-verified modules, synthetic Python fixtures; not production session/journal/source replay.',
             'network_calls':0,'model_calls':0,'gpu_jobs':0,'repository_modified':False}
    (ROOT/'REVIEWER_TEST_RESULTS.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
    sys.exit(not result.wasSuccessful())
