"""Read-only, direct-import checks against four hash-verified repository modules.

The weather inputs are synthetic; the used Denver bank parameters were copied
from the published BANK.json at the reviewed commit. This is NOT a full-bank,
full-calendar, original-journal or model rerun. Counterexample checks deliberately
assert the observed behavior so the review can be reproduced without changing it.
"""
from __future__ import annotations
import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'exact_source'))
from disastertrace.monitoring_v1.calibration import predict, feature_key
from disastertrace.monitoring_v1.regional_calibration import fit_monotone, apply_monotone
from disastertrace.monitoring_v1.evidence import exists_report_support
from disastertrace.monitoring_v1.support import Interval, EvidenceFact, classify, public_support

COMMIT = '6f71c8799ff69439a18f645e63b8c966ca21eec4'
EXPECTED = {
    'regional_calibration.py': '6236493c86c31e0f3b7c605692601146e716bbbf',
    'calibration.py': '6c5cf91e7513bd7674f558ea1f474c58168db6b4',
    'evidence.py': 'd921c845ac6689131944271c34a1f462deb5fb9b',
    'support.py': 'd43b56c98aa3e59c4c1d17f72a503941b604698d',
}

def verify_sources():
    checks=[]
    for name,expected in EXPECTED.items():
        data=(ROOT/'exact_source/disastertrace/monitoring_v1'/name).read_bytes()
        actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        if actual!=expected:
            raise RuntimeError(f'Original source identity mismatch: {name}')
        checks.append({'file':name,'bytes':len(data),'git_blob_sha1':actual,'exact_match':True})
    return checks

def block(lo, hi, p):
    return {'lower':lo,'upper':hi,'value':p}

def denver_subset():
    # Only feature cells used by the synthetic cases, all with published values.
    cells={}
    for threshold,pooled_pos in ((1000,1),(5000,8)):
        stem=[threshold,'0-3','no_low','no_low',False]
        for key,n,pos in ((stem,589,0),(stem+[1,0,0,1],18,0),([threshold,'pooled'],1209,pooled_pos)):
            cells[json.dumps(key,separators=(',',':'))]={'n':n,'positive':pos}
    return {
      'minimum_cell_n':20,'mapping_version':'regional_dec2024_frequency_pav.v1',
      'cells':cells,
      'post_calibration':{
        '1000':{
          'base':[block(.0016515276630883566,.0021141649048625794,.009375),block(.01020408163265306,.01020408163265306,.03333333333333333),block(.05405405405405406,.05405405405405406,.07692307692307693)],
          'evidence':[block(.0016515276630883566,.0021141649048625794,.014545454545454582),block(.0021413276231263384,.0021413276231263384,.0204081632653061),block(.01020408163265306,.01020408163265306,.044776119402985086),block(.010638297872340425,.010638297872340425,.10344827586206899),block(.05405405405405406,.05405405405405406,.10344827586206899),block(.05555555555555555,.05555555555555555,.18749999999999997)]},
        '5000':{
          'base':[block(.001692047377326565,.001692047377326565,.005952380952380952),block(.004228329809725159,.004228329809725159,.006993006993006993),block(.007431874483897605,.02040816326530612,.05128205128205128),block(.037037037037037035,.037037037037037035,.07692307692307693)],
          'evidence':[block(.001692047377326565,.00423728813559322,.015772870662460595),block(.007431874483897605,.02040816326530612,.06382978723404258),block(.02127659574468085,.02127659574468085,.10344827586206899),block(.037037037037037035,.037037037037037035,.10344827586206899),block(.04,.04,.18749999999999997)]}}}

def candidate():
    return {'issued_at':0,'projection':{'segments':[{
      'prevailing':[{'visibility':{'lower':10000,'upper':10000,'lower_closed':True,'upper_closed':True}}],
      'conditional':[]}]}}

def target(threshold):
    return {'physical_start':2*3600_000_000,'threshold':threshold}

def fact(lo, hi, upper_closed=True):
    return {'status':'disclosed_product_fact','reference_kind':'product_label',
            'support_assumption':'product_exact','visible_information_scope':'policy_after_query',
            'reports':[{'visibility':{'lower':lo,'upper':hi,'lower_closed':True,'upper_closed':upper_closed}}]}

def main():
    sources=verify_sources()
    bank=denver_subset()
    fixture={'source_commit':COMMIT,'source_path':'plans/v9_followup_execution_20260914_01/reports/regional_baselines_01/denver/BANK.json',
             'source_git_blob_sha1':'bef1f970650fd3dc1c2d35beeeb32c611f76296a',
             'scope':'Relevant published parameter subset; not the complete original bank. Weather input is synthetic.',
             'bank_subset':bank,'candidate':candidate()}
    (ROOT/'fixtures/denver_parameter_subset.json').write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n')
    findings=[]
    p1=predict(bank,target(1000),candidate())
    p5=predict(bank,target(5000),candidate())
    assert p1['probability']>p5['probability']
    findings.append({'id':'V01','kind':'counterexample_reproduced','title':'Independently calibrated nested thresholds cross',
                     'p_visibility_lt_1000':p1,'p_visibility_lt_5000':p5,
                     'gap':p1['probability']-p5['probability'],
                     'scope':'Same synthetic semantic input and published mapping cells. Full real-calendar frequency not measured.'})
    for threshold in (1000,5000):
        before=predict(bank,target(threshold),candidate(),['q1'])
        after=predict(bank,target(threshold),candidate(),['q1'],{'q1':{'status':'missing'}})
        assert before['cell_key']==after['cell_key'] and before['n']==after['n']==589
        assert before['probability']!=after['probability']
        findings.append({'id':f'V02-{threshold}','kind':'mechanism_reproduced',
             'title':'Base-cell fallback changes probability through a different post-calibrator',
             'threshold':threshold,'raw_probability':1/591,'before':before,'after_missing_query':after,
             'scope':'Missingness can be informative. This demonstrates a confound to decompose, not proof the calibration choice is invalid.'})
    before=predict(bank,target(1000),candidate(),['q1'])
    after=predict(bank,target(1000),candidate(),['q1'],{'unregistered':{'status':'missing'}})
    assert before['cell_key']==after['cell_key'] and before['probability']!=after['probability']
    findings.append({'id':'V03','kind':'callee_boundary_reproduced','title':'Nonempty but irrelevant disclosure switches calibrator',
                     'before':before,'after':after,'scope':'Direct callee boundary only; current provider reachability not established. Audit before treating as executed-impact finding.'})
    controls=[]
    cases=[
      ('C01_positive_witness_and_unread',{'a':fact(100,500)},'supported'),
      ('C02_negative_and_unread',{'a':fact(5000,8000)},'undetermined'),
      ('C03_all_negative',{'a':fact(5000,8000),'b':fact(6000,7000)},'refuted'),
      ('C04_conflict_priority',{'a':fact(100,500),'b':{'status':'inconsistent_same_slot_facts'}},'inconsistent')]
    for name,data,expected in cases:
        actual=exists_report_support(['a','b'],data,1000)
        assert actual==expected
        controls.append({'id':name,'passed':True,'observed':actual})
    assert classify(Interval(0,1000,True,False),'lt',1000)=='supported'
    assert classify(Interval(0,1000,True,True),'lt',1000)=='undetermined'
    controls.append({'id':'C05_open_closed_threshold','passed':True})
    hidden=EvidenceFact('a',0,0,'visibility','m',Interval(0,500),'evaluator_label','annotation_reference','evaluator','test.v1')
    visible=public_support([hidden],'visibility','m',Interval(0,math.inf),1)
    assert visible==Interval(0,math.inf)
    controls.append({'id':'C06_hidden_label_not_public_support','passed':True})
    blocks=fit_monotone([(0.1,0,1),(0.2,1,1),(0.3,0,1),(0.4,1,1)])
    vals=[apply_monotone(blocks,x/100) for x in range(101)]
    assert all(a<=b for a,b in zip(vals,vals[1:]))
    controls.append({'id':'C07_within_score_monotonicity','passed':True,'scope':'Does not imply coherence across separately fitted event thresholds.'})
    record={'commit':COMMIT,'source_identity':sources,'findings':findings,'positive_controls':controls,
            'executed_checks':len(findings)+len(controls),
            'scope':'Direct imports of four original hash-verified modules. Synthetic inputs plus published Denver parameter subset. No original-journal, whole-bank/calendar, model or repository-suite rerun.'}
    (ROOT/'results/review_checks.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(record,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
