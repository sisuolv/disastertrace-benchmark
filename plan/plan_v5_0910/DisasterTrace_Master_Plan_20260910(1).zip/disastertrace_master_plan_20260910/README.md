# DisasterTrace 后续总计划包｜2026-09-10

**先看 `DisasterTrace_Master_Plan_CN.md`，交给代码代理时同时提供 `CODEX_FIRST_SPRINT_CN.md`。**

本包整合多灾种58来源目录、旧代码审查、预测/主动获取计划。最终范围不再限制为气旋和洪水；它们只是最早能复用旧工程的集成样例。广覆盖资料接入、短窗口在线捕获与共享内核并行推进。

## 文件导航

| 文件 | 用途 |
|---|---|
| `DisasterTrace_Master_Plan_CN.md` | 科研定位、三层产品、数据路线、代码、M0–M7、实验、风险和发布 |
| `CODEX_FIRST_SPRINT_CN.md` | 首轮边界、最小实现、跨灾种fixture、测试和交付 |
| `Source_Implementation_Registry_58.json` | 原58条目保留，增加队列、候选角色、权限和首批取数建议 |
| `SOURCE_QUEUE.md` | 三个并行队列的人类可读表 |
| `Hazard_Taxonomy_22.json` | 19＋3拟议研究分类、来源和任务语义门槛 |
| `Additional_Validation_Dependencies.json` | USGS观测、NDBC波浪观测候选，不算入原58来源 |
| `Implementation_Backlog.json` | 31工单、依赖、交付与验收 |
| `BACKLOG_OVERVIEW.md` | 工单的简表 |
| `Master_Config_Template.yaml` | 未来配置设计示例，不是当前可执行CLI配置 |
| `PROVENANCE.json` | 原输入哈希、当前读取范围、新查官方文档与未执行事项 |
| `PLAN_VALIDATION.json` | **本包计划文件**结构和引用一致性校验，不是benchmark测试 |
| `MANIFEST.sha256` | 包内文件完整性 |
| `inputs/` | 继承目录、原registry、上一版计划与审查原件 |

## 使用顺序

阅读总计划→核对本地工作树→执行首轮离线范围→对合格采集器填写明确网络scope→独立验收数据与任务→授权模型小试→扩量并冻结正式评测。

旧计划与新计划不同的范围在总计划第0节明确说明。原源目录中的数量是对应版本/网页记录；本轮没有重新统计58来源或下载全量数据。新容量、队列和预算只是计划，source的真实资格一律保持未取得/待测试。

## 执行边界

本次聊天仅创建本包文档和配置，并验证JSON/YAML/源ID/依赖图/哈希等计划层内容。没有修改用户仓库/Notion，没有运行数据采集、模型、GEE或GPU，也没有部署定时任务。模板全为offline、外部开关关闭；不得将模板或旧自主窗口误当执行授权。
