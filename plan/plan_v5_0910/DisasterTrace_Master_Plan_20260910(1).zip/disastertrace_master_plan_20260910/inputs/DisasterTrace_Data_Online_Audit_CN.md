# DisasterTrace 当前数据契约审查与在线接入规格

审查日期：2026-09-09。本文包含**实际代码审查、8 个离线对象探针，以及待实施设计**，三者分别标识。

## 0. 范围与结论

- GitHub 默认 `main`：`a23f73adadcbec077b9fcf2aecf8f45dfa4fe061`，早期审查快照。
- 本次核心审查 `next-phase-v1`：`36082c42a93e11f67d274d8000c87cd1dc098d74`。
- 实际读取核心 contract/compiler/protocol/scoring、source acquisition/cohort loader，以及通用 models/evidence/policies/runner/adapters、部分 automated/dynamic 和项目依赖。
- 未访问用户未推送工作树，未重跑完整测试或模型实验，未连接 GEE 项目、下载新灾害数据、调用付费模型、修改仓库或 Notion。
- README 引用的 `artifacts/p7_forecast_task_v1/execution_v1` 在本次 Contents 请求返回 404；因此没有把阅读源码等同于完整执行包或全量样本复核。

**结论：现有格式适合冻结的 Text Core，但不能直接承担多灾种、异步多模态、持续预测修订和滚动在线数据评测。应复用已有组件，新增独立契约，不能只替换数据文件或在旧 JSON 中增加字段。**

尤其不能把原型与主实测协议混用。原型已经有图像、时间门控、增量状态和 Actual/Masked/Edited/Oracle；当前原生 `forecast_task` 仍是累计 NHC 公告、固定字段、单目标历史与引用核验。

## 1. 已有代码与新要求的对应

| 要求 | 实际代码 | 判断 |
|---|---|---|
| 原始来源保留、哈希、行号追溯 | `forecast_source/pipeline.py`、`forecast_task/compiler.py::load_sources/_support` | 有可复用的实现；不代表本次重新验证所有历史产物 |
| 公开输入与 Gold 分离 | `forecast_task/compiler.py` public/private，`protocol.request` 仅接 public | 现有原生路径已建立 |
| 显式可见资料与实际错误历史 | `forecast_task/protocol.py` | 已建立累计证据条件，不是增量-only |
| 图片传输 | `adapters.py::_image_part`、`policies.py::_render_artifacts` | 通用原型有真实图片 content；原生路径未接入 |
| 历史可见性上界门控 | `evidence.py::EvidenceGate` | 原型有；原生编译器 available_at 留空、按 issued 排序 |
| 增量输入与四臂 | `policies.py::structured_state_policy`、`runner.py::CarrierTransform` | 原型有；不能当作已验收多模态主实验 |
| 多灾种、多个空间目标 | 旧 `Episode.storm_id` 必填；原生 query 按 storm/valid_at | 需要新事件/目标契约与跨目标同场景状态 |
| 概率预测与事后验证 | `forecast_task/contract.py` + `scoring.py` | 未实现该语义：当前核对公告陈述，不对未来观测评分 |
| 联网取得资料 | `forecast_source/pipeline.py::acquire` | 已有固定历史 URL 的有界 HTTP 获取 |
| 持续发现、更新追踪、在线冻结 | 当前固定 source selection 和 cohort loader | 尚未形成通用滚动接入流程 |
| GEE | 本次检查的核心路径与 pyproject 未发现接入 | 需要新增适配器与独立集成验收 |

## 2. 按重要性排列的代码发现

### F1 / P0：当前 forecast 是“读取发布预报”，不是“预测未来结果”

`forecast_task/contract.py` 固定：

```python
FIELDS = ("latitude", "longitude", "max_sustained_wind")
STATUSES = ("numeric", "DISSIPATED", "ABSORBED", "not_stated")
```

SCHEMA 所有对象采用 `additionalProperties=False`，`parse_answer` 对顶层键作精确集合比较；SYSTEM 明确不输出 actions 或额外字段。`scoring.score_one` 把模型值与公告参考值逐字段相等比较。

所以不能直接加入 flood_depth / burned_area / event_probability，也不能把单位 `KT` 改成 `m` 后沿用同一任务名。应保留 `forecast_task_v1`，新增 evidence-claim 与 model-prediction 两种明确任务类型；状态未知和预测不确定性不能等同。

### F2 / P0：当前时间与交付实现不足以证明严格历史在线可用性

`compiler.compile_sources` 中：
- `available_at` 和 `initialization_at` 显式为 None；
- 按同一 storm 的 `issued_at` 排序，发行时刻重复直接拒绝；
- delivery_step/elapsed 从该顺序派生；
- 目标集合取所有选定公告的未来时刻并集，再按当前前缀算答案。

这适合原有受控回放，但跨提供方同刻发布、独立送达时间、晚到观测、产品更正、真实在线目标注册均需独立契约。离线从全部公告构造查询分布，不等于在线提前注册目标。

不要改写旧 available_at。新对象分别保留 observation/valid time、发行/生产时间、版本首次捕获、历史可用性证据和每分支送达。

### F3 / P0：一目标一 episode 的历史不能直接测“后来才问 C”

`compile_sources` 根据单个 `{storm_id, valid_at, measurement_kind}` 生成 `episode_id`。`protocol.request` 要求该目标的精确历史前缀。

新协议应改为一个事件场景 episode 下包含多个 `query_id`，每个 query 的目标有效时间固定，模型共享该场景内自己的状态。具体未来查询不提前给压缩策略；公开查询范围和类型可以预先声明。

### F4 / P0：通用原型字段存在，但存在数据迁移风险

对原样 `models.py` 的 8 个离线探针见 `probe_results.json`。源 Git blob 与仓库返回一致：`7e7726f153f65ff335bcb316fe46738422b60ca9`。环境 Python 3.13.5 / Pydantic 2.13.4。

| 探针 | 本环境实际行为 | 影响 |
|---|---|---|
| 额外顶层 retrieved_at/source_product_id | model_validate 后被丢弃 | 新字段必须正式声明或放入明确受控的 metadata；不能误以为存住了 |
| valid_to 早于 valid_from | 接受 | Artifact 未校验这对有效时间的顺序 |
| available_at=null | 拒绝 | 无法直接表达完全未知历史可用性 |
| 不传 sha256 | 接受 | 类型对象自身不强制完整性；来源管线的额外哈希检查仍有效 |
| KEEP 携带 V2 来源 | 仍保留 V1 | KEEP 会直接跳过支持刷新 |
| 同值 UPDATE 携带 V2 | 更新为 V2 | 现有代码不是完全不能换源；应明确操作语义和支持-only 分项 |
| UPDATE 携带 region/span | SlotState 只留 artifact ID | 原 commit 仍保存引用，不能说整个日志丢失；但后续状态载体不保留完整定位 |
| 无时区 issued_at | 拒绝 | 现有时区校验正常生效 |

这些是旧通用原型的对象级行为，不证明过去原生实验分数错误。新模型建议严格禁止未知顶层字段、校验时间和有限数值、保存完整 typed EvidenceReference；迁移测试应显式检查 round-trip 字段保留。

### F5 / P1：图片支持不能等同于遥感数据支持

通用 `adapters._image_part` 真正编码图片，但只将 `.png` 识别为 PNG，其他后缀均按 JPEG。`policies._render_artifacts` 把 image 之外的内容作为文本读取。

GeoTIFF/GRIB/NetCDF/SAR 多波段不能直接塞进此路径。应分开 raw scientific asset 与 model-view image，固定波段、单位、显示变换、CRS、仿射变换、分辨率、区域、无效值和图例。区域引用必须绑定具体图片哈希和变换版本。

早期适配器还包含宽泛异常重试和宽松 JSON 提取；不能直接替换冻结原生严格协议。模型每次尝试应先记录请求，响应先保存再解析，未知提交不静默重发。资料 GET 的重试则可采用独立、明确、可记录的幂等策略。

### F6 / P1：有联网采集，但没有通用在线数据生命周期

`forecast_source.pipeline` 固定两个历史风暴和公告范围，记录 intent、HTTP 状态、ETag/Last-Modified/Date 等头、raw bytes、hash、retrieved_at；`forecast_cohort.loader` 固定 6 storm × 6 公告，还要求 available_at 为 None。

这是良好的可追溯有界采集，不是动态发现最新事件/版本。不要删除旧固定范围保护。新增 registry/provider config，产生新采集 scope 和 append-only capture 记录。

### F7 / P1：版本关系、修订义务与预测增益需分离

原生 `_transition` 主要用 first/not_stated/no_new_coverage/terminal/changed_wind/unchanged_wind。通用 ObligationSheet 有 required_updates、preserve、unknown，但无独立的 must_recheck / must_refresh_support 类型字段。

新协议应区分语义改值、同值换源、复核后不变和未知。未来概率不使用逐题唯一“正确概率”Gold，也不能仅因某区域地图变化就强制其余所有地点概率不变。预测结果用后续 outcome，状态修订用可见证据参考，二者分别评分。

## 3. 建议的数据契约：8 类对象，非一个无限膨胀 JSON

以下是**待实现规格**，不是当前已有类型。元数据可用 JSONL，较大表格用 Parquet；源影像保留原格式，模型视图 PNG/JPEG，空间对象可用 GeoJSON/GeoPackage。存储格式不是核心创新，语义和版本隔离才是。

| 对象 | 最小关键字段 |
|---|---|
| ArtifactSnapshot | schema_version, artifact_id, provider, source_product_id, native_version, content_sha256, role, modality, raw_uri, media_type, origin, product_scope, variable, measurement_kind, unit, times, spatial_ref, lineage, license_ref |
| CaptureRecord | capture_id, artifact_id, query/request hash, requested_at, received_at, discovered_at, first_seen_content_at, HTTP/provider metadata, status, error, adapter_version |
| DeliveryEvent | delivery_id, episode_id, branch_id, checkpoint_id, artifact_id, delivered_at, delivery_kind；重复送达不是重复内容 |
| QueryTarget | query_id, event_context, hazard_types, product_scope, region_id, variable, unit, operator/threshold, valid_instant 或 valid_interval, task_kind, outcome_definition_id |
| EpisodeCheckpoint | episode_id, event_group_id, checkpoint_id, as_of, query_ids, branch_id, access_mode, permitted_history/budget；模型公开投影不含未来查询或私有 Gold |
| ModelCommitPrediction | run/slot/checkpoint/query_id, as_of, submitted_at, previous_prediction_id, distribution, state_operations, full supporting_refs, raw_request/response hashes, model/processor config |
| StateReferenceObligation | evaluator-only，按合法交付资料算事实/来源，change_values/refresh_support/recheck/preserve/remain_unknown，固定规则版本 |
| OutcomeRecord | evaluator-only，query_id, resolution_status, valid_time, value/label, verification_artifact_id, resolved_at, verification_version, quality/uncertainty；pending/missing/disputed 不等于否定事件 |

### 不可变内容与可变送达分开

ArtifactSnapshot 的身份由来源身份、版本和实际内容绑定。相同 provider item ID 被提供方修订时产生新 snapshot；相同内容重复获取可以复用内容，但保留 CaptureRecord。相同旧图被重新交付必须再写一条 DeliveryEvent，不能被内容去重抹掉。

正式数据 manifest 固定 snapshot、query、delivery、render、compiler、scorer、split 和配置哈希。实际图像、空间选择和派生对象追踪 parent IDs，不能只保存一个可能变化的远程 URL。

### 新查询类型建议

- `published_claim`：核对来源在当时声称什么，继承 Text Core 的用途；
- `evidence_state`：多模态证据支持的空间/规则状态；
- `future_outcome_binary` / `future_outcome_numeric`：模型自身预测未来结果；
- 各类型采用独立输出/参考/评分版本，不合并为一套 exact-match。

## 4. 在线能力应分成三种运行方式

### 4.1 Online capture：持续采集，不等于持续评分

`discover → acquire → validate → snapshot → register`。

先按来源配置、AOI、产品类型、时间窗口和数量/字节预算查询；获取原始内容和元数据，验证 MIME/结构/身份，保存不可变内容，再登记。发现 item ID 的时间不证明其后来导出的内容版本在那时已存在，应单独记录捕获到实际版本的时间。

轮询器可使用增量游标和重叠回扫捕捉晚到/更正；遇到空集合、限流、失败、缺凭据应产生明确状态，不把旧缓存静默称为最新。周期性刷新需要实际调度系统，不由本次聊天自动启动。

### 4.2 Frozen replay：在线取得的数据，冻结后公平评测

同一轮所有模型读取同一冻结 registry/snapshot，而不是在各自运行时重新查询 latest。离线回放禁网仍应重建相同输入和参考。滚动发布新版本，不改旧测试和旧失败。

### 4.3 Prospective prediction：先提交预测，再解析未来结果

在固定未来目标注册后，合法捕获和送达证据，封存模型预测及实际提交时间；目标时刻过去后独立取得验证资料并追加 OutcomeRecord。

真实前瞻运行要求提交发生在目标开始之前。历史受控回放的虚拟检查点不能冒充真实提前提交；两种模式明确分栏。二元任务保留未发生事件和缺测记录，目标选择不能使用事后结果。

## 5. GEE 接入要求与建议来源

官方文档本次重新读取，但**没有使用用户 EE 凭据执行查询**。

| 来源 | 最小用途 | 接入检查 |
|---|---|---|
| `NOAA/GFS0P25` | 对同一未来有效时刻比较不同发布周期的格点预报 | 官方要求结合 creation_time/forecast_time；注册初始化与目标时间，核查单位与累计降雨窗口 |
| `NASA/GPM_L3/IMERG_V07` | 降水估计与产品修订轨迹 | provisional 会被更新产品替换；不能仅凭观测日期回放早期信息 |
| `COPERNICUS/S1_GRD` | 洪水等变化的原始 SAR 证据候选 | 固定轨道/模式/极化/显示变换；日更新不等于目标地点每天观测 |
| `NASA/LANCE/NOAA20_VIIRS/C2` | 活动火点/热异常的在线证据 | 是 daily NRT 栅格；质量与 acquisition time 按产品解释，不能直接当完整火场范围真值 |
| USGS Event API / GeoJSON | 新地震事件发现及产品更正证据 | `updatedafter` 用于更新查询，不自动重建历史状态；是否有 superseded 内容需按具体 API 和响应核查 |
| 现有 NHC acquisition | 公告基线 | 把固定 scope 与新 provider 配置隔离；扩源不修改旧验收包 |

### GEE 不能代替版本账本

最关键的例子是 IMERG：官方目录明确说明临时产品会被后续版本替换。观测发生在 t 之前，不意味着当前查到的这一版数据在 t 之前已可用。

严格历史轨应使用带可靠 availability bounds 的具体 snapshot；无证据者留空、隔离为受控回放。前瞻采集从现在起保存内容版本，才有机会逐步积累可验证的历史。

对 GEE 至少保存 collection/item ID、所有有意义的产品时间、查询参数、实际选择的 item 列表、波段及单位、投影/scale/transform、mask/聚合/渲染配置、导出状态、导出内容哈希及父输入。派生合成影像的所有输入都要经过时间门控，不能混进未来场景。

GEE 官方提供云端影像处理和导出，但通常需要已注册且开启 API 的 Cloud project 与合法认证。本地 CCI 可用 Python API 调用；不能假设用户的计算节点已能联网、已认证或具有配额。凭据走环境/已有认证，不写入仓库、资料包或 manifest。

建议先做一个 GFS 小 AOI 的可追溯快照，再做一个 S1/VIIRS 多模态案例，不先下载全球资料。资料新鲜度按实际捕获的产品时间与可用性报告，不以目录页面的最大日期保证局部数据完整。

## 6. 给 Codex 的最小实施顺序

本节是可执行工作拆分，**不是本次已经执行**。

### P0：新严格契约与回归

1. 先记录实际 HEAD、工作树、分支和保护数据清单；若比本审查更新，重新做差异表。
2. 保留 `forecast_task`、旧 schema/version、old Gold/outputs/scores。
3. 新建一个共享 `evidence_registry` 或等价包；不要把旧提案的多个模块名全部建成重复内核。
4. 定义上面的不可变 snapshot、capture、delivery、target、prediction、outcome；禁止未知顶层字段和 NaN/Infinity，明确 timezone、interval、unit、probability constraints。
5. 完整保留 span/region/transform 引用；明确同值刷新支持与改值操作。

验收：旧 Text Core 回归不变；本报告的迁移反例在新 schema 中获得预期处理。

### P1：在线资料接入与冻结

1. 抽出有界 provider 接口：`discover(config, cursor)`、`acquire(candidate)`、`normalize(capture)`、`freeze(selection)`。
2. 新实现 NHC configurable provider 和 optional GEE provider；另一个灾种优先 USGS 版本证据或 VIIRS，不默认进入全部灾害。
3. 实现不可变保存、content version 去重、访问日志、游标、重试上限、AOI/数量/字节预算、缺凭据/空结果/超配额状态。
4. 在线 smoke test 明确单独开关，默认离线 fixtures，不自动启动收费服务和大型导出。

验收：同一内容重复采集不改旧 snapshot；同 ID 内容变化产生新版本；两次运行共享冻结列表；断网可回放。

### P2：事件级多目标与多模态投影

1. 一个 episode 持有同事件多个 query，支持后轮新增具体地点，而不是为每个 query 启动全新独立场景。
2. Full-evidence / Streaming / budgeted retrieval 明确访问权限；工具和缓存都通过同一时间门控。
3. 原始科学数据、模型可读图片和私有 Gold 分离。记录真实多模态请求，不能只传路径字符串。
4. 通用原型的 gate/policy/carrier transform 可复用，但补齐同前缀、无关编辑/长度匹配、错误恢复与逐次持久化。

验收：图片内容、尺寸、时间元数据和引用变换都能核对；不泄漏未来查询/答案/正确区域。

### P3：预测与结果解析

1. 一个固定未来目标上反复生成概率或数值预测，分别保存 as_of 和 submitted_at；早于目标时刻的真实提交才称前瞻预测。
2. 后续结果只进入 evaluator-side OutcomeRecord；解析规则、缺测、争议、修订政策预先冻结。
3. 状态按可见证据参考评分；预测按结果评分；没有逐题唯一 gold probability。
4. 比较保留旧预测、专业预测直接使用、完整重算、版本检索与状态维护。按提前量、事件和实际完整成本报告。

验收：延迟证据只改变该分支可见状态，不改变同一物理 outcome；pending 不按 false；结果修订产生新 verification version，不覆盖旧报表。

## 7. 必测反例清单

| 类别 | 必须能发现/正确处理的情况 |
|---|---|
| Schema | 未声明字段不静默丢弃；时间顺序错误；NaN/Infinity；概率超 [0,1]；非法 unit/target |
| Online revision | 同 item ID 修订内容；相同观测时刻有多个生产版本；晚到记录；304/限流/失败与可确认返回 |
| As-of | 观测早但版本晚；预报有效时间在未来但发布已合法；派生图含未来输入；缓存/工具绕过门控 |
| Delivery | 同一旧内容重复送达；多来源同刻发行；delay/withhold 分支独立 Gold；不修改原文时间 |
| Multimodal | GeoTIFF 不伪装 JPEG；正确 MIME；图像分辨率/CRS/图例/无效值；模型只见允许精度 |
| State | KEEP 同值刷新；完整 span/region 持久化；后轮 C 查询；语义错误不被 Gold 修正 |
| Prediction | 固定 T 的不同发行预测；专业预报与模型预测分开；提交晚于 T；验证尚未发生或缺测 |
| Fairness | 共享实际输入图像/派生题同组；所有计划模型机会保留；未解析 outcome 与预测失败分别报告 |

## 8. 复现本次对象探针

```bash
python probe_existing_models.py \
  /path/to/disastertrace-benchmark/disastertrace-starter/src/disastertrace/models.py \
  --output /tmp/disastertrace-model-probes.json
```

需要 Pydantic v2。脚本先核对源 Git blob；若代码已变化会停止，避免把旧预期套到新版本。它只读一份源码，构造合成对象，不读数据集、不联网、不调用模型、不修改仓库。8 个 observation_matches=true 表示观察与本次代码行为一致，不表示发现的问题已修复，也不表示完整项目测试通过。

## 9. 依据入口

### 实际读取的固定源码

固定前缀：`https://github.com/sisuolv/disastertrace-benchmark/blob/36082c42a93e11f67d274d8000c87cd1dc098d74/`

- `disastertrace-starter/src/disastertrace/forecast_task/contract.py`
- `disastertrace-starter/src/disastertrace/forecast_task/compiler.py`
- `disastertrace-starter/src/disastertrace/forecast_task/protocol.py`
- `disastertrace-starter/src/disastertrace/forecast_task/scoring.py`
- `disastertrace-starter/src/disastertrace/forecast_source/pipeline.py`（1–220 行）
- `disastertrace-starter/src/disastertrace/forecast_cohort/loader.py`
- `disastertrace-starter/src/disastertrace/models.py`
- `disastertrace-starter/src/disastertrace/evidence.py`
- `disastertrace-starter/src/disastertrace/policies.py`
- `disastertrace-starter/src/disastertrace/runner.py`（1–190 行）
- `disastertrace-starter/src/disastertrace/adapters.py`
- `disastertrace-starter/src/disastertrace/automated/dynamic.py`（1–160 行）
- `disastertrace-starter/pyproject.toml`

### 本次核查的官方在线产品/接口文档

- GFS：https://developers.google.com/earth-engine/datasets/catalog/NOAA_GFS0P25
- IMERG：https://developers.google.com/earth-engine/datasets/catalog/NASA_GPM_L3_IMERG_V07
- Sentinel-1：https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S1_GRD
- VIIRS：https://developers.google.com/earth-engine/datasets/catalog/NASA_LANCE_NOAA20_VIIRS_C2
- EE authentication：https://developers.google.com/earth-engine/guides/auth
- EE image export：https://developers.google.com/earth-engine/guides/exporting_images
- USGS event API：https://earthquake.usgs.gov/fdsnws/event/1/

官方入口存在不等于用户环境已认证、指定历史版本完整或本次已经完成 live integration。上述新设计均需按验收顺序另行实现。
