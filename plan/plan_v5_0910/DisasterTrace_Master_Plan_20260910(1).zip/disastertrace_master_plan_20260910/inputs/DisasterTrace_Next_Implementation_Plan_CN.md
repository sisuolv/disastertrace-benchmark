# DisasterTrace：基于现有代码的下一阶段实施计划

编制日期：2026-09-10  
性质：研究与实现规格；不是已经完成的功能、数据采集、模型实验或运行授权。  
代码基线：`sisuolv/disastertrace-benchmark`，`next-phase-v1@36082c42a93e11f67d274d8000c87cd1dc098d74`。  
本次重新读取的远端分支：`main@a23f73adadcbec077b9fcf2aecf8f45dfa4fe061`，`next-phase-v1@36082c42…`。不覆盖未推送代码。

## 0. 先确定唯一主线

保留已有 Text Core 的原始资料、契约、得分与验收记录；新增一个共享的 `active_forecast/` 任务内核。

**目标链条：真实图文证据 → 固定未来目标 → 状态与预测修订 → 主动补查/等待/停止 → 截止前提交 → 后续独立结果验证。**

这不是要求一次做完全灾种平台。实施分两步：

1. 用已有气旋开发来源及 NHC 图文/GIS、事后 best track 打通仪器。多模态在这一阶段进入，不后置为装饰。
2. 用 NWPS/HEFS、USGS 水位和可核查阈值构建洪水迁移，检验信息获取与研究准备窗口的价值。

online 捕获和模型研究分离：采集器完成安全与快照验收、且获得独立采集授权后，可以开始积累新版本；不必等全部模型实验结束。模型运行、GEE 计算/导出、训练与付费调用均不因本计划自动获得授权。

### 三条评价轨，共用一个内核

| 轨道 | 输入和执行 | 主要用途 |
|---|---|---|
| Frozen passive replay | 固定版本、固定逐轮证据；Full-evidence 与增量访问分别配置 | 验证资料、Gold、图像与预测结果管线 |
| Active replay | 同一个合法候选目录、相同资源与时间政策；Agent 自选查询、等待和提交 | 测信息选择及及时性的附加价值 |
| Prospective capture/evaluation | 真实捕获新版本；结果揭晓前封存预测，之后独立解析 outcome | 提供前瞻证据；不声称自动消除污染 |

完整资料重算不是作弊，而是重要参照；全信息特权、免费查看全部结果或事后选择最有用资料的条件单列诊断，不混入同预算排行榜。

## 1. 本次核对的代码事实，以及要保留什么

代码事实依据 [C1–C9]；下表右列为新增建议。

| 已有入口 | 实际行为 | 下一阶段处理 |
|---|---|---|
| `forecast_source/pipeline.py::acquire` | 固定来源范围；请求意图、响应头、原始字节、哈希和结果记录；末尾封存 | 复用采集原则，另建 provider 接口；不解除旧 scope/heldout 保护 |
| `forecast_task/compiler.py::compile_sources` | 单风暴按 issued_at 排序；available_at 留空；同发行时刻拒绝；每个目标独立 episode | 旧版不动。新增事件场景、多 query、真实可用性与有序交付记录 |
| `forecast_task/protocol.py::request` | 三种方法读取相同累计编号文本，历史属于同一目标 | 新版将 Full-evidence、增量无回查、有预算回查分开 |
| `models.py` | 有 Artifact、Checkpoint、StateLedger 与 span/region 引用；状态落盘仅留 artifact ID；KEEP 跳过更新 | 新增严格 v2 类型、完整引用保留和支持刷新语义；不破坏旧 ABI |
| `runner.py::EpisodeRunner.run` | 遍历固定检查点，每步一次模型生成；主要轨迹在循环结束后写出 | 新版事件/动作驱动，逐步持久日志、真实提交状态和单轨失败隔离 |
| `interventions.py` | 主要通过集合控制可见资料；StaleVersionReplay 移除新版并替换父版 | 替换与重放分别定义。重放必须保留“再次送达”事件，不被集合差消掉 |
| `forecast_task` 参考与评分 | 核对已发布预报陈述，而非未来观测 | 保留 claim scorer；另外实现 prediction/outcome scorer |

### 特别重要的两个代码问题

**A. 旧图重放不是集合里有没有旧图。**

现有 runner 使用 `delivered_ids - previous_delivered` 计算新到达。一份旧资料再次出现时，内容没有变化，但交付行为确实发生；集合差无法完整表达。新格式必须将内容实体与送达事件分开。

**B. REQUEST_EVIDENCE 输出不等于执行了查询。**

通用原型有 action/requested_evidence 字段，但目前 runner 仍按预定检查点运行。新版需要真正实现工具请求、查询结果、预算扣减、时间推进和下一次模型调用之间的闭环。

### 状态记录不能直接当最新现场状态

远端 `CURRENT_PHASE.md` 与 `RESULTS_20260909.md` 标注的是 2026-09-08 20:31 UTC 的历史状态；其中“运行中”不证明现在仍有作业运行。较晚上传汇报与此 pointer 是不同快照。首先在用户本地核查 HEAD、工作树、未推送变更及可核实的运行记录，不能重启历史 controller。2026-09-09 已结束的自主窗口不作为新的授权。[C2]

## 2. 数据选择：先做两个可闭环的数据包

这里没有一份现成数据集能直接提供所有信息。需要组合“当时输入、专业基线、空间关系、最终验证”，并记录各自角色。以下产品性质经官方文档核查；目标数量和组合是本计划的建议。

### A. TC-Bridge：气旋图文与预测修订

| 数据 | 用途 | 严格边界 |
|---|---|---|
| NHC Forecast/Advisory；适用时加入 Discussion | 发行时已有的预报、解释及版本来源 | 保存原始字节与每版时间，不混入事后 TCR 全文 |
| NHC 原生地图及可匹配 GIS：forecast track / wind radii 等 | 空间事实、图文状态任务、可查询的视觉证据 | 风圈、路径锥和风概率分别定义。官方数据重绘不称官方原图；逐版本核查可用性 |
| GFS `NOAA/GFS0P25`，按需要选小区域和固定变量 | 额外环境证据与更新来源 | creation_time 与 forecast_time 分开；GFS 网格风不等于气旋最大持续风 |
| NHC HURDAT2 / best-track 数据及冻结版本 | 未来位置/强度的 outcome 参考 | 只进验证侧；是事后分析估计，不是无误差直接观测 |

NHC 的官方验证将预报位置、强度与事后 best track 对照；best track 常用六小时间隔。正式发行时间与名义初始化时间不同，因此提前量从实际实验截止或提交时刻计算，不能直接使用名义 lead 字段。[D1–D3]

#### 首批任务

**TC-S（资料状态）**：指定地点在某份明确产品/有效时刻的空间关系；旧版本替代、同值换源及后续新增地点查询。Gold 为已发布资料的含义。

**TC-F（真实预测桥接）**：固定未来六小时时刻 T，预测中心位置或最大持续风。T 根据预先固定的时刻表和当轮公开事件身份选取，不根据未来是否登陆或是否产生大误差选择。先支持点预测和 MAE/球面距离；概率型目标在相应专业概率/校准基线可用后加入。

两类任务共享资料，不混合分数。一个是读对资料，另一个是预测结果；原生图片上的预报范围不是未来实际受灾范围的 Gold。

#### 候选选择

先从既有 development 来源中核查 3 个事件、10–20 组图文版本对。Francine、Ida、Helene 可以作为待核查候选，但不保证每组图文、GIS 和验证资料都匹配。先读取保护清单；不可因为某场著名灾害资料丰富就跨过既有 heldout。

扩展生命周期时按预先规定的发行区间/阶段规则选，不以模型得分筛选。阶段诊断可以使用事后生命周期标签做分层，但这类选样必须标注 retrospective diagnostic，不能冒充自然前瞻抽样。

#### 保持真正的多模态问题

对状态子集，检查同文字不同合法图会改变参考、同图不同必要文字条件也会改变参考；必要性只相对于本任务声明的输入。对预测子集，图是否带来真实预测增益需要实验，不因为文字消融分数低就预先认定视觉不可替代。完整数值/几何表示是强对照，不能故意删掉关键数字来抬高图像方法。

### B. Flood-Window：水位阈值与及时准备

| 数据 | 用途 | 接入前必须核查 |
|---|---|---|
| NWPS Application API | 官方水文预报、位置、洪水分类阈值等 | 常规接口不提供完整历史数据，crest/low history 是例外；不能查询任意往年预报版本 |
| NWPS HEFS API | 集合、分位数与概率基线候选 | 实验服务，当前只提供约 10 天数据；站点和时段覆盖不保证，应前瞻保存 |
| USGS Water Data for the Nation APIs | 站点水位/流量观测、质量标记、监测位置元数据 | 固定 API 版本、站点与参数、单位、基准和观测解析政策 |
| USGS Real-Time Flood Impact（RT-FI） | 与水文站关联的已测量参考高度和对象描述 | 只是阈值/潜在影响语义，不等于道路已关闭、设施损坏或实际损失 |
| GFS 降水 / IMERG | 可选上游环境证据、降雨空间图 | 固定累计区间、处理版本和合法可用时间；不是水位验证标签 |

NWPS 常规接口与 HEFS 滚动服务不是长期历史预报档案。[D7] USGS 于 2026-09-04 发布现代 Water Data API v1；新适配器优先按已核查的 v1 schema 编写，不把旧 WaterServices 设为唯一入口。[D8]

#### 推荐第一个洪水目标

对同一站点 s，预先规定未来窗口 [T0,T1]、参考高度 h* 和采样政策，预测：

`Y = 1{该窗口内有效采样水位的最大值 >= h*}`。

必须明确这是观测采样定义的超阈事件，不声称一定捕获采样间短暂极值。若窗口数据不足，不能输出负例，应进入 `outcome_missing` 或 `pending`。最初也可以仅做固定时刻水位点预测，以减小聚合复杂度。

若采用 RT-FI，某些点本身是低于实际淹水高度的早期参考点。任务名称应写成“超过该参考高度”，而不是自动写成“该道路实际被淹”。站点、测量高度、垂直基准与版本必须一致。[D9]

选择 2 个流域、5–10 个同时满足观测/预报/阈值条件的站点作为覆盖审查目标，不是已确认站点。多站共享一个天气过程不算多个独立灾害。

#### 三个可能阻断入选的条件

1. 只有流量预报，没有与水位阈值相容的水位产品：不要直接比较。优先换站点/变量；rating curve 转换须另行固定有效版本、误差与依据。
2. 没有完整历史预报周期：不能用今天的预报或事后重分析补造历史。选择有真实档案的子集，或积累前瞻版本。
3. 阈值或站点基准历史发生变化：冻结适用版本。现今 RT-FI 记录若用于过去窗口，只能作为明确的 retrospective task metadata，不能声称当时公众已获得该信息。

### C. 暂缓接入的部分

Sentinel-1 `COPERNICUS/S1_GRD` 可用于洪水空间证据诊断，但目标地区不保证在短准备窗口内有新观测；不能把它设为每条小时级站点任务的强制输入。[D10]

SpaceNet 8 适合后续验证图像/既有洪水标签的处理链，不是连续预报版本或真实五轮演变档案。双时相不伪装长序列；建筑/道路淹水标签不等于业务关闭或损失真值。[D11]

山火、地震、热浪、干旱和滑坡不列为首轮必须完成；先证明同一个协议可以从气旋迁移到洪水，而不是每种灾害各做一个无法比较的问答集。

## 3. 统一数据对象：不要继续给旧 JSON 任意加字段

新增严格类型，建议 `extra='forbid'`、时间带时区、缺失有明确语义。旧 schema/旧解析器保留；迁移必须生成新版本和映射，不改写旧字节。

### 3.1 公共证据与采集对象

**ArtifactSnapshot**

- schema_version, artifact_id, provider, product_id, provider_version, content_sha256。
- observed_interval（如适用）、valid_interval（目标时间）、issued_at、model_initialization_at（如适用）。
- historical_availability：可为空，或者 lower/upper/basis 的有据区间。
- first_seen_content_at：我们首次取得这一内容版本的时间，不是首次见到 URL 的时间。
- modality、media_type、raw_uri、public_view_uri、public_view_sha256。
- 空间范围、CRS、变量、单位、无效值/质量政策。
- 关系：derived_from、supersedes、same_content_as、describes。共享父源不等于独立证据。

**CaptureRecord**

- request_id、开始/完成时刻、请求参数、响应状态、provider 元数据、内容哈希、错误与重试序号。
- 任何临时签名 URL、token 和凭据不得写入可共享计划或公开 manifest。
- 内容相同可以去重储存，但每次捕获记录保留。相同 URL 内容变化生成新 snapshot。

**DeliveryEvent**

- event_id、episode_id、branch_id、seq、artifact_id、delivered_at、delivery_kind。
- old replay 即使复用同一内容也有新 event_id；去重不得吞掉送达行为。
- 同时刻多资料用稳定 seq 作确定性重建，不能把排序顺序隐式解释为来源权威。

### 3.2 任务、模型与验证对象

**QueryTarget**

- query_id、event_context、region/site、task_kind、variable、measurement_kind、unit、threshold（可空）、fixed_valid_interval。
- `task_kind = published_claim | evidence_state | future_outcome`。
- 发布/观测/预测/再分析有不同角色；来源更晚不自动替代另一个产品。

**Episode**

- 一个事件场景、多 query、公开起点、固定检查时刻、目标时刻、决策截止 D、访问模式、成本模型版本、split_group。
- 后续查询的范围和类型可事先声明；具体 C 查询和答案不能在压缩前泄漏。

**ModelCommit / PredictionRecord**

- 原始响应哈希、解析状态、完整 evidence refs（artifact+span/region+role）。
- 值修改和支持刷新分离；机械执行 ADD/UPDATE/RETRACT/REFRESH_SUPPORT 不替模型补语义。
- query_id、as_of、submitted_at、输入快照哈希、previous_prediction_id。
- 点预测/分位数/概率为判别联合类型，禁止同时输出互相矛盾的形式；概率有限且位于 [0,1]。
- 实验逻辑提交时间与真实 UTC 完成时间分别保存，不回填或回拨。

**OutcomeRecord（私有）**

- query_id、verification_value/distribution、单位、来源与版本、observed_interval、resolved_at、quality、status。
- `pending/resolved/missing/disputed` 分开；没有标签不是负例，模型缺答也不等于 outcome 缺测。
- 更正 outcome 时新增版本和重算记录，不能覆盖原预测或旧结算结果。

**DecisionSpec / DecisionRecord**

- 公开研究动作、截止时间、C/L 网格、迟到与缺失规则、成本模型性质。
- 一开始只做公开简化准备决策，不声称真实撤离、关港或减损最优性。

**StateReference / TransitionObligation（私有）**

- 当轮合法已交付证据下的事实、来源刷新、应变/保持/未知。
- 不能给模型每轮未来概率指定唯一 Gold；未来预测由 proper score 等结果评价。

## 4. 时间与 online 的五条强制规则

### 4.1 未来有效时刻不等于泄漏

可以在今天使用今天合法发布、预测明天的预报。因此不得写成“所有 evidence.valid_at <= now”。

合法性检查针对**该内容版本的可用时间**；观测材料还需检查观测发生时间及处理版本；预报材料允许 valid_at 在未来。所有工具、索引、缓存和派生父输入均执行同一门控。

### 4.2 三种回放身份分开

- historical_strict：有据历史可用区间上界不晚于检查点；否则不准入此轨。
- controlled_replay：依据声明的模拟送达规则；可以复用历史资料，但不称真实公众信息状态。
- prospective_capture：每个内容版本按首次实际捕获与提交时刻记录；first_seen 是保守可用记录，不追溯宣称更早已看见。

### 4.3 GEE 不是不可变版本仓库

GFS 保存发行周期与目标时间；IMERG 会以新版替换临时产品。因此必须冻结实际选择的 item 列表、content/status、导出结果、派生 lineage 和配置。[D4–D5]

对 GFS 的降水累计窗先编写 interval/deaccumulation 测试，不能把重叠累计量逐步相加。其部分波段从 2025-01-15 才开始，2019–2024 事件只能选实际存在且定义相同的变量。[D4]

### 4.4 被动回放不等于主动查询

被动轨固定 feed；主动轨固定可见目录与成本，策略决定实际读取。目录不得透露未来版本名、未来记录数、是否发生或结果标签。某产品下一次预定发布节奏可以公开，实际未来内容不可以。

### 4.5 在线采集与模型运行解耦

新增 adapter 接口建议：

`discover(scope, cursor) -> candidates`  
`acquire(candidate, limits) -> CaptureRecord + raw snapshot`  
`normalize(snapshot) -> typed metadata + public views`  
`freeze(selection, policy) -> immutable bundle`

首次只实现 NHC 与离线 fixture。GEE/NWPS/USGS 适配在小范围预检后加入。discover 必须有回扫窗口处理晚到和更正；不能只靠递增观测时间游标漏掉旧观测的新版。

真正后台定时运行由用户环境的调度器负责部署，本次未部署任何计划任务。失败、空响应、限流和部分页都需要日志；不可将“没有获取成功”当作“没有灾害”。

## 5. 主动任务环境：只先实现四个动作

| 动作 | 输入 | 环境行为 |
|---|---|---|
| GET_EVIDENCE | provider/product/scope/variable/as_of，或已知 artifact ID | 合法目录内查询/取回；记录请求、读取内容、费用与延迟 |
| WAIT | until 或受限时间步 | 逻辑时钟前进，只有届时已公开且本分支允许的资料可以被查询 |
| SUBMIT_FORECAST | query_id、预测、完整支持 | 追加封存；不自动知道对错、不回写上一版 |
| COMMIT_DECISION | query_id、公开研究动作 | 保存承诺时刻，按预先规定的截止/成本规则评价 |

更新状态可以与动作共同提交，避免再产生一个平行框架。首次不开放任意 shell、无限网页浏览、改写文件或自由执行 GIS 脚本。

### 时钟规范

历史主动回放采用显式的离散事件/延迟模型。分别保存：产品发布/开放时间、工具服务延迟、模型逻辑成本、实际 wall-clock。模拟延迟是实验条件，不伪称历史网络时延。另设 measured-runtime 模式记录真实推理耗时。

一个查询在提交时冻结当时可选的响应版本；完成后不能偷偷换成过程中刚发布的 latest。若要采用“完成时读取”模式，应另行声明并全方法一致。

不能任意规定“一次 LLM 调用消耗一小时”。先报告相同查询/计算预算；工具延迟与截止窗口做多个预设条件的敏感性分析。某个方法更强不能只由于其免费拿到更多资料。

### 截止与缺失

评测检查点读取最后已封存的预测，不自动追加一轮免费模型回答。D 后提交可用于后续预测诊断，但不能追回已错过的准备窗口。

未提交预测：原始状态保留 missing。报告有效提交覆盖和固定计划交付情况；需要计算完整系统决策成本时，使用预先公开、所有方法一致的 fallback（例如冻结专业基线决策），并单独报告 fallback 次数。不得把缺答默默伪造成模型概率 0，也不得只保留成功提交样本获得虚高分。

### 持久化与失败隔离

每一步顺序：`intent -> dispatched -> response_raw -> parsed/invalid -> state_applied -> checkpoint`。原始响应先保存再解析；无效响应不得导致丢失此前轨迹。已提交但结果未知保留 unknown，不静默重新生成。单场景失败只影响本轨，其他独立场景继续；旧已验收失败不重写。

## 6. 代码布局建议：一个共享的新任务包

以下路径为建议，尚未声称存在；本地先做差异检查，若已有等价模块则合并复用。

```text
disastertrace-starter/src/disastertrace/active_forecast/
  contracts.py            # 新证据、交付、查询、预测、outcome、decision 类型
  storage.py              # 内容寻址快照、追加日志与安全恢复
  availability.py         # 历史区间/受控回放/前瞻可用性，所有工具统一门控
  lineage.py              # 派生、替代与重复关系，不做自动物理因果图
  providers/
    base.py
    nhc.py
    gee.py                # 可选依赖；不是所有用户安装的强依赖
    nwps.py
    usgs.py
  views.py                # 文本、地图、曲线/栅格视图与实际输入记录
  compiler.py             # 事件级 episode、多 query、固定目标
  reference.py            # 私有事实与更新义务
  environment.py          # 四动作、逻辑时间、预算与截止
  journal.py              # 调用状态机与逐轨迹隔离
  outcome.py              # HURDAT2/USGS 验证，独立角色与更正版本
  scoring.py              # 状态、预测、时效与研究价值分别出分
  baselines.py            # 固定专业、固定顺序、版本检索、主动策略
  interventions.py        # delay/withhold/replay/correction/null
  analysis.py             # 事件分组、配对、时间/成本曲线
```

配置放在 `configs/active_forecast/`，测试放在 `tests/active_forecast/`，新运行写入独立 work 目录。不得复制多个科学内核分别命名 `revision_task/multimodal/mm_trace` 再重复修改；旧冻结模块按其原任务继续存在。

最初只需要 contracts/storage/availability、NHC fixture、compiler/reference/outcome 和最小离线演示；不要一次创建全部空壳后宣称完成。

## 7. 里程碑、交付与进入条件

不以日历时长保证完成，以 gate 为准；在线采集在 M1 安全通过且获授权后可与后续研究并行。

### M0：确认现场与冻结研究范围

交付：`BASELINE_LOCK.json`、`CODE_REUSE_MAP.md`、`TASK_CARD_DRAFT.md`、protected 来源列表。

工作：确认实际 HEAD/工作树/未推送文件；区分远端历史 pointer 与本地新报告；读取已有验收与来源限制；只创建新版本文档，不改旧科学档案。

验收：能明确回答旧任务是什么、新任务多测什么、哪些文件不能改、初始目标是什么。没有模型/GPU/历史 controller 重启。

### M1：严格契约与真实资料可行性

交付：新 schema、fixture、`DATA_FEASIBILITY.csv`、一个内容快照+重复交付例子、数据角色与时间清单。

候选审查：3 个既有 development 事件、10–20 组 NHC 图文版本对；另调查少量 NWPS/USGS 站点元数据与保留范围。具体在线取数先有独立 scope（provider、事件/站点、字节/区域上限、费用限制）。

验收：至少一条图文可以对齐，模型视图可读；未知可用性不会伪填；每个字段 round-trip 保留；旧保护集和原始哈希不变；缺项有排除记录。

### M2：被动多模态与未来结果的端到端演示

交付：一个 TC-S/TC-F 场景，多个固定 query 和检查点、私有状态参考、HURDAT outcome fixture、确定性程序对照、可重建报告。

验收：同一个输入能分别评价来源状态和未来预测；读取官方预报与自主预测是不同输出。图文语义互补子集存在；数值/几何等价强参照保留。当前步骤不依赖付费模型即可验证编译与评分。

### M3：主动查询、等待与截止状态机

交付：四动作接口、时钟、预算、日志、请求/响应门控、单轨失败隔离、replay与替换区别测试。

验收：至少一组场景存在合理的查询/等待/停止权衡；跨 D 的结果不能补写及时决策；重复资料保留交付但不成为独立观测；future metadata/索引/缓存均不泄漏。

### M4：一个 VLM 的仪器预检与最小模型矩阵

先预检原子读图、完整输入、实际抽取事实与正确视觉事实诊断；不把旧 Qwen3-8B 文本成绩转成视觉模型成绩。模型/processor/模板/图像预算/输出契约固定，选择适配好的后端而非单纯追求最新名称。

建议第一个仪器矩阵：12 个场景 × 3 个策略（固定顺序、版本过滤、主动选择）× 1 个后端 × 1 次重复 = 36 条轨迹。**不是 36 个模型调用**。可先设每轨至多 8 次证据请求与明确决策调用上限，所有内部摘要和工具解释也计入预算；这些仅为待校准的启动上限。

无 LLM 专业基线与程序规则并行出表。正确视觉事实、全免费信息等特权条件单列。此小矩阵只用于检验仪器，不用于一般模型排名。

验收：真实输入图片被记录；正常轨无私有答案；失败都保留；能将读图、版本选择、预测修订与迟到分开解释。

### M5：洪水迁移与小型前瞻结果

用相同 action/schema/evaluator 更换数据 adapter 和 target spec，而不是再造一个洪水平台。审核站点映射、变量、阈值与测量基准；选择有效连续观测且有适用预报的站点。

前瞻目录按预先规定的区域、时间和事件准入采集，不只保留最终受灾窗口。先封存预测后取得结果；尚未解析为 pending，不为了按时出表伪填标签。模拟截止和准备成本明确写成研究条件；没有领域依据不声称真实减损。

验收：至少能展示同一信息策略在两个灾种上的适用性与限制；成功和负结果全部保留。若没有匹配历史预报，公开报告这个限制，不用最终分析补作早期输入。

### M6：冻结正式实验与论文证据

方法、数据政策、图像处理、阈值、预算、缺失处理、分组与主指标在 dev 冻结。正式独立事件数量根据资料质量与事件级变异确定，不把 pilot 个数当统计保证。

同场风暴、相关流域过程、同张全域图、父源派生、相邻瓦片和 twin 必须按共享结构同组。共享关系导致大组时如实记录，并分别说明事件泛化/来源泛化的划分目标，不靠拆散共享资料扩大样本。

在相同信息与资源约束下检验：主动查询是否有收益；版本/lineage是否减少重复计证；deadline是否改变策略排序；哪些情况专业基线已经足够。不要要求所有模型必须失败才“通过”。

## 8. 必要基线与指标

### 基线按同一权限组比较

1. 直接使用当前合法的专业预报。点预测评 MAE/位置误差；有集合/概率时才按该变量验证概率。
2. 专业预报加轻量统计校准/组合。校准数据仅训练/dev，不能从 test outcome 拟合误差分布。
3. 同一 VLM + 固定来源顺序、无主动选择。
4. 同一 VLM + 目标/时间/版本过滤检索。
5. 同一 VLM + 状态与来源依赖记录 + 主动查询/停止。

初期可先完成 1、3、4、5，概率校准在足够独立开发资料后加入。不要将专业点预测随意解释成 0/1 概率并据此贬低基线。未来适配 BLF-style/PostTime-style 只能明确称思想借鉴，未运行原代码不得称作者复现。

### 三层主结果

**资料层**：值/状态、时间/版本/定位、来源刷新、非相关事实误改、合理未知。

**预测层**：数值 MAE/位置误差；概率 Brier 等既有评分；按固定目标、提前量、事件组报告校准与覆盖。Brier = (p-y)^2；对尚未解析 outcome 不评分。

**时效与研究价值层**：截止前有效提交、查询/计算成本、等待与恢复、相同 C/L 下相对专业基线的研究决策损失。

最简研究损失可用 `loss(a,y)=C*a+L*y*(1-a)`，其中 a 表示截止前有效准备。它假设准备避免所建模的损失部分，不是现实减损保证；应公开该假设并做多组参数敏感性分析。先使用公共确定性规则将 p 映射为动作，减少将复杂语言行动规范混入首版主分。

### 归因注意

- 新证据后的概率变化不要求每次都更接近已实现 y，结论看独立事件汇总。
- 空间事实的局部影响可以有可计算 Gold，但真实天气概率有远程/上游依赖，不能只因为 B 在图外就硬性要求 p_B 不变。
- 同源图可能有新的可读空间信息；只有内容等价重复子集才检验不应额外计证，不能把所有派生视图一律当无价值。
- 两分支事实 Gold 随各自信息开放变化，未来物理 outcome 不随 delay 改变。
- 行动之后现实过程若本可受行动影响，本 benchmark 只使用公开模拟损失模型，不声称有实际干预后果反事实真值。
- 主动策略访问集合不同是被测结果，但目录/预算/工具能力和时间规则应一致。

## 9. 首轮必须写的测试

| 测试 | 通过标准 |
|---|---|
| 新字段 round-trip / 未知字段 | 声明字段不丢；未声明字段报错；不靠 metadata 隐藏关键契约 |
| 时间与区间 | 有时区、区间有效；unknown availability 可表达；issued/observed/valid/first_seen 不混用 |
| 未来预报合法输入 | 已发布的未来预报可访问；未来才发布的同观测版本被拒绝 |
| 同时刻多源 | 不因为 issued_at 相同报错或产生无声明优先级 |
| 重复交付 | 相同内容两次送达产生两个 DeliveryEvent；只去重存储不去重行为 |
| scoped supersedes | A 产品新版不覆盖另一变量/时段；记录多父来源与明确替代 |
| 同值换源与引用定位 | 值保持但引用刷新；span/region 跨轮保留 |
| 新目标 C | 事件级历史可支持后续查询；未来具体查询不提前出现在提示 |
| 公私隔离 | outcome/private masks/正确影响集合不可从模型路径、检索、缓存或目录取得 |
| GFS 降水累计 | 重叠累计窗不重复加；跨reset、缺步、不同bandcoverage有明确处理 |
| 异步查询 | 请求时冻结响应版本；结果在声明延迟后交付；无完成时偷换latest |
| 截止与失败 | D后提交不算及时；日志先于解析；一个轨迹失败不终止其他轨迹 |
| unknown submission | 已dispatch结果未知不静默重试；状态按预定恢复规则推进 |
| Outcome缺失/更正 | 缺测不为0；更正留版本；预测不被改写 |
| 洪水基准 | station/variable/unit/datum/threshold版本匹配，stage/flow不互换 |
| 统计划分 | 同源/相邻/共享artifact/twin同组，未触碰protected答案 |

## 10. 给下一次 Codex 的起点

**第一轮只做 M0–M1，加一个 M2 的离线最小样例。**

读现有代码和新规格，先输出差异清单；在独立分支/目录完成严格类型、快照与交付日志、NHC fixture 导入、私有 outcome fixture、最小编译和评分。建立上述最关键的不变量测试。

输出：修改文件列表、现有回归影响、实际运行的测试与结果、未完成部分、候选数据缺口、下一批网络采集的明确 scope。不要用模拟响应声称跑了真实模型，不依据旧授权启动 GPU/付费 API，不下载全量数据或读取受保护结果。

## 11. 本计划最终应支持的论文证据

目标不是证明一个复杂系统一定优于专业预报，而是查明：

- 在什么信息缺口和时间约束下，主动获取能够提高截止前预测质量？
- 哪些重复、版本错配与错误历史会损害概率与及时性，而不只是引用分数？
- 更多计算何时有收益，何时只是错过窗口？
- 相同机制能否从气旋迁移到水文阈值任务？

可证伪的预期比“新增很多模块”更重要。若强专业/统计基线低成本解决，就报告其优势；若图不可读或资料不相容，先修数据；若后续输入已重述全部历史，不宣称记忆必要；若缺少业务验证，只报告研究决策模型下的价值。

## 12. 来源与核查范围

### 本次重新读取的代码（固定 commit）

仓库根：`https://github.com/sisuolv/disastertrace-benchmark/tree/36082c42a93e11f67d274d8000c87cd1dc098d74`

- [C1] GitHub branches API：`https://api.github.com/repos/sisuolv/disastertrace-benchmark/branches?per_page=100`。
- [C2] `disastertrace-starter/CURRENT_PHASE.md`；`RESULTS_20260909.md`，两者为历史状态。
- [C3] `disastertrace-starter/src/disastertrace/forecast_task/compiler.py`，读取 152–280 行。
- [C4] `disastertrace-starter/src/disastertrace/forecast_task/protocol.py`，读取 1–77 行。
- [C5] `disastertrace-starter/src/disastertrace/models.py`，读取 42–208 行。
- [C6] `disastertrace-starter/src/disastertrace/runner.py`，读取 15–200 行。
- [C7] `disastertrace-starter/src/disastertrace/interventions.py`，读取完整文件。
- [C8] `disastertrace-starter/src/disastertrace/forecast_source/pipeline.py`，读取 147–230 行。
- [C9] 上一轮审查中的 `forecast_task/contract.py`、`forecast_task/scoring.py`、`evidence.py`、`policies.py` 和 `adapters.py`；本轮没有重新跑这些模块或对象级探针。

### 官方数据与接口文档（2026-09-10 检索）

- [D1] NHC GIS：<https://www.nhc.noaa.gov/gis/>；可读官方镜像 <https://prod-east-nhc.woc.noaa.gov/gis/>。
- [D2] NHC 数据档案/HURDAT2：<https://www.nhc.noaa.gov/data/index.php>。
- [D3] NHC verification：<https://www.nhc.noaa.gov/verification/verify2.shtml>。官方检索摘录可读；一次直接打开返回 403，不据此判断数据不存在。
- [D4] GFS GEE 数据卡：<https://developers.google.com/earth-engine/datasets/catalog/NOAA_GFS0P25>。
- [D5] GPM IMERG GEE 数据卡：<https://developers.google.com/earth-engine/datasets/catalog/NASA_GPM_L3_IMERG_V07>。
- [D6] GEE 认证/Cloud project：<https://developers.google.com/earth-engine/guides/auth>。
- [D7] NWPS/HEFS 服务范围：<https://api.water.noaa.gov/about/api>。
- [D8] USGS WDFN API 与 v1 说明：<https://api.waterdata.usgs.gov/>；<https://waterdata.usgs.gov/blog/api-v1-release/>。
- [D9] USGS RT-FI：<https://waterdata.usgs.gov/blog/api-flood-impact/>；<https://www.usgs.gov/tools/real-time-flood-impact-map>。
- [D10] Sentinel-1 数据卡：<https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S1_GRD>。
- [D11] SpaceNet 8 官方仓库：<https://github.com/SpaceNetChallenge/SpaceNet8>。

### 继承的研究约束

此前总体汇报与多模态方案：保留 Text Core、图文必要性、公私参考隔离、真实历史状态、不按未来结果伪造送达、旧分数冻结、按事件/共享来源划分、无 LLM judge 主评分。此前方案中的 12/60/576/960 等不同预算不自动拼接为当前已批准实验。

**本次仅代码/文档读取与计划编制。没有修改 GitHub/Notion，没有访问用户 GEE 项目，没有下载新实验数据，没有启动模型、GPU、训练或自动定时采集。**
