"""Validate this planning bundle, not the DisasterTrace implementation.

Usage: python validate_plan.py [--write-report]
Uses the standard library. YAML checks run when PyYAML is available; otherwise
that check is explicitly reported as skipped rather than treated as passed.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parent

def load(name: str) -> Any:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))

def validate() -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    def check(name: str, passed: bool, detail: Any = None) -> None:
        checks.append({"name": name, "status": "passed" if passed else "failed", "detail": detail})

    original = load("inputs/DisasterTrace_Dataset_Registry_58_Sources.json")
    planned = load("Source_Implementation_Registry_58.json")
    hazards = load("Hazard_Taxonomy_22.json")["categories"]
    tickets = load("Implementation_Backlog.json")["tickets"]
    src = {row["id"]: row for row in planned["datasets"]}
    ids = set(src)
    expected = {f"DS{i:02d}" for i in range(1, 59)}
    check("58_unique_source_ids", len(src) == len(planned["datasets"]) == 58 and ids == expected)
    check("all_original_registry_fields_preserved", all(
        all(src[row["id"]].get(key) == val for key, val in row.items())
        for row in original["datasets"]
    ))
    check("all_sources_remain_planning_only", all(
        not row["implementation_plan"]["enabled"]
        and not row["implementation_plan"]["ingestion_implemented"]
        and not row["implementation_plan"]["forecast_ready"]
        and not row["implementation_plan"]["active_ready"]
        for row in src.values()
    ))
    waves = {w: sum(r["implementation_plan"]["wave"] == w for r in src.values()) for w in "ABC"}
    check("wave_partition_complete", sum(waves.values()) == 58 and waves == planned["wave_counts"], waves)
    hids = {h["id"] for h in hazards}
    check("22_unique_hazard_labels", len(hazards) == len(hids) == 22)
    check("hazard_scope_19_plus_3", sum(h["scope"] == "met_hydro_climate" for h in hazards) == 19
          and sum(h["scope"] == "weather_related_extension" for h in hazards) == 3)
    check("hazard_source_references_resolve", all(set(h["source_ids"]) <= ids for h in hazards))
    check("source_hazard_references_resolve", all(set(r["implementation_plan"]["hazard_taxonomy_refs"]) <= hids for r in src.values()))
    check("bidirectional_hazard_source_mapping", all(
        (r["id"] in h["source_ids"]) == (h["id"] in r["implementation_plan"]["hazard_taxonomy_refs"])
        for r in src.values() for h in hazards
    ))
    aux = load("Additional_Validation_Dependencies.json")
    check("additional_dependencies_not_counted_as_58", len(aux) == 2 and all(not a["counts_as_original_58"] for a in aux))
    by_id = {t["id"]: t for t in tickets}
    check("31_unique_planned_tickets", len(by_id) == len(tickets) == 31 and all(t["status"] == "planned" for t in tickets))
    check("ticket_dependencies_resolve", all(
        set(t["depends_on"] + t.get("optional_dependencies", [])) <= set(by_id) for t in tickets
    ))
    visiting: set[str] = set()
    done: set[str] = set()
    def visit(tid: str) -> bool:
        if tid in visiting:
            return False
        if tid in done:
            return True
        visiting.add(tid)
        t = by_id[tid]
        for dep in t["depends_on"] + t.get("optional_dependencies", []):
            if dep not in by_id or not visit(dep):
                return False
        visiting.remove(tid)
        done.add(tid)
        return True
    check("ticket_graph_acyclic", all(visit(tid) for tid in by_id))
    p = load("PROVENANCE.json")
    check("inherited_source_hashes_match", all(
        hashlib.sha256((ROOT / s["file"]).read_bytes()).hexdigest() == s["sha256"] for s in p["local_sources"]
    ))
    main = (ROOT / "DisasterTrace_Master_Plan_CN.md").read_text(encoding="utf-8")
    check("master_has_all_sections_0_to_17", all(f"## {i}." in main for i in range(18)))
    check("first_sprint_and_queue_exist", all((ROOT / n).is_file() for n in (
        "CODEX_FIRST_SPRINT_CN.md", "SOURCE_QUEUE.md", "BACKLOG_OVERVIEW.md", "Master_Config_Template.yaml")))
    try:
        import yaml  # optional; do not install dependencies while validating
    except ImportError:
        checks.append({"name": "yaml_parse_and_safety", "status": "skipped", "detail": "PyYAML not installed"})
    else:
        cfg = yaml.safe_load((ROOT / "Master_Config_Template.yaml").read_text(encoding="utf-8"))
        exe = cfg["execution"]
        check("yaml_parse_and_safety", exe["offline"] is True and all(v is False for k, v in exe.items() if k != "offline"))
        pilot = cfg["pilot_not_authorized"]
        count = pilot["scenarios"] * pilot["strategies"] * pilot["model_backends"] * pilot["repeats"]
        check("pilot_arithmetic", count == pilot["trajectory_count"] == 72
              and count * pilot["max_total_llm_calls_per_trajectory"] == pilot["max_total_llm_calls"] == 864
              and count * pilot["max_tool_reads_per_trajectory"] == pilot["max_total_tool_reads"] == 576)
        check("default_external_resource_caps_zero", cfg["source_inputs"]["max_download_bytes"] == 0
              and cfg["source_inputs"]["max_gee_export_tasks"] == 0 and cfg["source_inputs"]["max_gee_pixels"] == 0)

    result = {
        "validation_scope": "planning_bundle_only_not_benchmark_code_data_or_model_tests",
        "all_executed_checks_passed": all(c["status"] != "failed" for c in checks),
        "check_count": len(checks),
        "passed": sum(c["status"] == "passed" for c in checks),
        "failed": sum(c["status"] == "failed" for c in checks),
        "skipped": sum(c["status"] == "skipped" for c in checks),
        "checks": checks,
    }
    return result

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write-report", action="store_true", help="Write PLAN_VALIDATION.json (changes package checksum).")
    args = parser.parse_args()
    try:
        report = validate()
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f"Planning bundle validation error: {exc}", file=sys.stderr)
        return 2
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.write_report:
        (ROOT / "PLAN_VALIDATION.json").write_text(text, encoding="utf-8")
    print(text)
    return 0 if report["all_executed_checks_passed"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
