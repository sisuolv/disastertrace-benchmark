"""Offline review of exact source bodies, not a full repository execution.

Relative imports are not executed. Selected functions are compiled from the AST
of hash-verified complete modules and wired only to verified dependency bodies.
Native aviation parsers are deliberately NOT supplied: tests involving feature
vectors use candidate=None and explicit claims. No parser or engine is mocked.
"""
import ast
import copy
import datetime as dt
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import random
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'source'
EXPECTED = {
 'temperature_postprocess.py':'1ca9ae6ce50540829344b0a73a79a7d82b3e645e',
 'feature_tasks.py':'4226d87ef5d18d1acc495f59141c6a1307ec88f9',
 'native_feature_forecast.py':'36b7923bb3ac3cb5e16055dbf75588fe7f4136cf',
 'regional_calibration_v2.py':'570658377052493448586f3306fc3f420e1e6d7c',
 'support.py':'d43b56c98aa3e59c4c1d17f72a503941b604698d',
 'evidence.py':'d921c845ac6689131944271c34a1f462deb5fb9b',
 'targets.py':'df3862303f5ec9b28ab4c20969b88861ed06bf74',
 'common.py':'31ed9e5f3cceabda9d9553b28be89ed1858bfc9f',
}
for name, expected in EXPECTED.items():
    b=(SOURCE/name).read_bytes()
    observed=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    if observed != expected:
        raise RuntimeError(f'Exact upstream source mismatch: {name}: {observed}')

def module(name):
    spec=importlib.util.spec_from_file_location('review_'+name,SOURCE/(name+'.py'))
    obj=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=obj
    spec.loader.exec_module(obj)
    return obj

def functions(name, names, deps):
    tree=ast.parse((SOURCE/(name+'.py')).read_text())
    selected=[n for n in tree.body if isinstance(n,(ast.FunctionDef, ast.AsyncFunctionDef)) and n.name in names]
    assert {n.name for n in selected}==set(names)
    ns=dict(deps)
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(SOURCE/(name+'.py')),'exec'),ns)
    return ns

TP=module('temperature_postprocess')
SUP=module('support')
RC=module('regional_calibration_v2')
COM=module('common')
E=functions('evidence',['interval_from_dict'],{'math':math,'Interval':SUP.Interval})
N=functions('native_feature_forecast',['validate_claims','feature_vector','predict_features'],
 {'math':math,'datetime':dt.datetime,'timezone':dt.timezone,'HOUR':3600000000,
  'FEATURE_VERSION':'native_h15_features.v1','interval_from_dict':E['interval_from_dict']})
F=functions('feature_tasks',['temperature_ensemble_probability','parse_features','output_json','parse_temperature'],
 {'math':math,'datetime':dt.datetime,'timezone':dt.timezone,'strict_json':COM.strict_json,
  'validate_claims':N['validate_claims']})
DAY=TP.DAY
START=round(dt.datetime(2018,1,2,tzinfo=dt.timezone.utc).timestamp()*1e6)

def row(days=1,variable='daily_max_2m_temperature',operator='ge',threshold=30):
    products=[]
    for i in range(days):
        products.append({'target_date':(dt.date(2018,1,2)+dt.timedelta(days=i)).isoformat(),
           'day_index':i+1,'forecast_min_members_C':[-2,1,2,3],
           'forecast_max_members_C':[29,30,31,32]})
    return {'target':{'units':'C','physical_start':START,'physical_end':START+days*DAY,
      'variable':variable,'event_operator':operator,'threshold':threshold},'cutoff':START-1,
      'common':{'daily_products':products}}

def claim(lo=1000.,hi=1000.,lc=True,uc=True):
    return {'visibility':{'lower':lo,'upper':hi,'lower_closed':lc,'upper_closed':uc},
      'temperature_c':0.,'dewpoint_c':-1.}

def features(claims,mode='values',at=START-3600000000,obs=None):
    obs=at-3600000000 if obs is None else obs
    disclosed={q:{'status':'disclosed_product_fact','reports':[{'observation_time':obs}]} for q in claims}
    return N['feature_vector']({'entity':'KAAA','physical_start':START,'physical_end':START+3600000000},
       None,['q'],disclosed,at=at,mode=mode,claims=claims)

class ValidBehavior(unittest.TestCase):
    def test_native_source_hashes(self): self.assertEqual(len(EXPECTED),8)
    def test_daily_ge_endpoint(self):
        r=row(); self.assertEqual(TP.event_probability(r),.75)
        self.assertEqual(F['temperature_ensemble_probability'](r),.75)
    def test_daily_lt_endpoint(self):
        r=row(operator='lt'); self.assertEqual(TP.event_probability(r),.25)
        self.assertEqual(F['temperature_ensemble_probability'](r),.25)
    def test_minimum_temperature(self):
        r=row(variable='daily_min_2m_temperature',operator='lt',threshold=0)
        self.assertEqual(TP.event_probability(r),.25)
        self.assertEqual(F['temperature_ensemble_probability'](r),.25)
    def test_joint_not_product_of_marginals(self):
        r=row(3,'min_of_3_daily_max_2m_temperature')
        for p in r['common']['daily_products']: p['forecast_max_members_C']=[31,31,29,29]
        self.assertEqual(TP.event_probability(r),.5)
        self.assertEqual(F['temperature_ensemble_probability'](r),.5)
        self.assertNotEqual(TP.event_probability(r),.5**3)
    def test_joint_changes_with_member_alignment(self):
        r=row(3,'min_of_3_daily_max_2m_temperature')
        for p in r['common']['daily_products']: p['forecast_max_members_C']=[31,31,29,29]
        r['common']['daily_products'][1]['forecast_max_members_C']=[29,29,31,31]
        self.assertEqual(TP.event_probability(r),0)
        self.assertEqual(F['temperature_ensemble_probability'](r),0)
    def test_day0_rejected(self):
        r=row();r['common']['daily_products'][0]['day_index']=0
        for f in [TP.event_probability,F['temperature_ensemble_probability']]:
            with self.assertRaises(ValueError):f(r)
    def test_empty_members_rejected(self):
        r=row();r['common']['daily_products'][0]['forecast_max_members_C']=[]
        for f in [TP.event_probability,F['temperature_ensemble_probability']]:
            with self.assertRaises(ValueError):f(r)
    def test_nan_member_rejected(self):
        r=row();r['common']['daily_products'][0]['forecast_max_members_C'][0]=math.nan
        for f in [TP.event_probability,F['temperature_ensemble_probability']]:
            with self.assertRaises(ValueError):f(r)
    def test_mismatched_joint_members_rejected(self):
        r=row(3,'min_of_3_daily_max_2m_temperature')
        r['common']['daily_products'][0]['forecast_max_members_C'].pop()
        for f in [TP.event_probability,F['temperature_ensemble_probability']]:
            with self.assertRaises(ValueError):f(r)
    def test_future_cutoff_rejected(self):
        r=row();r['cutoff']=START
        for f in [TP.event_probability,F['temperature_ensemble_probability']]:
            with self.assertRaises(ValueError):f(r)
    def test_unqualified_variable_rejected(self):
        r=row(variable='wind_speed')
        for f in [TP.event_probability,F['temperature_ensemble_probability']]:
            with self.assertRaises(ValueError):f(r)
    def test_ecc_preserves_ranks_when_no_repair(self):
        p=row()['common']['daily_products'];before=copy.deepcopy(p)
        bank={'min':{'a':-10,'b':0,'log_c':0,'log_d':-20},
              'max':{'a':10,'b':0,'log_c':0,'log_d':-20}}
        new,trace=TP.ecc_products(p,bank)
        self.assertEqual(p,before);self.assertEqual(trace['minmax_projections'],0)
        for field in ['forecast_min_members_C','forecast_max_members_C']:
            self.assertEqual(sorted(range(4),key=lambda i:p[0][field][i]),
                             sorted(range(4),key=lambda i:new[0][field][i]))
    def test_ecc_minmax_repair_is_counted(self):
        p=row()['common']['daily_products']
        bank={'min':{'a':10,'b':0,'log_c':0,'log_d':-20},
              'max':{'a':-10,'b':0,'log_c':0,'log_d':-20}}
        new,t=TP.ecc_products(p,bank)
        self.assertEqual(t['minmax_projections'],4)
        self.assertTrue(all(a<=b for a,b in zip(new[0]['forecast_min_members_C'],new[0]['forecast_max_members_C'])))
    def test_fixed_total_prior_not_per_cell(self):
        same=RC.fit_fixed_prior([(.1,0,1)]*100)
        distinct=RC.fit_fixed_prior([(.1+i*1e-8,0,1) for i in range(100)])
        self.assertAlmostEqual(same[0]['value'],1/102)
        for b in distinct:self.assertAlmostEqual(b['value'],1/102)
    def test_weight_splitting_invariant(self):
        a=RC.fit_fixed_prior([(.1,1,1),(.2,0,1)])
        b=RC.fit_fixed_prior([(.1,1,.5),(.1,1,.5),(.2,0,1)])
        self.assertEqual(a,b)
    def test_cdf_rejects_different_information(self):
        with self.assertRaises(ValueError):RC.coherent_cdf([.8,.2],['a','b'])
    def test_cdf_repairs_crossing(self):self.assertEqual(RC.coherent_cdf([.8,.2],['a','a']),[.5,.5])
    def test_cdf_identity(self):self.assertEqual(RC.coherent_cdf([.2,.8],['a','a']),[.2,.8])
    def test_json_duplicate_rejected(self):
        with self.assertRaises(ValueError):F['parse_temperature']('{"probability":0.1,"probability":0.2}')
    def test_json_nan_rejected(self):
        with self.assertRaises(ValueError):F['parse_temperature']('{"probability":NaN}')
    def test_json_boolean_rejected(self):
        with self.assertRaises(ValueError):F['parse_temperature']('{"probability":true}')
    def test_whole_fence_accepted(self):
        self.assertEqual(F['parse_temperature']('```json\n{"probability":0.5}\n```'),(.5,{'whole_json_fence':True}))
    def test_visibility_negative_rejected(self):
        with self.assertRaises(ValueError):N['validate_claims']({'q':claim(-1,1)},{'q':None})
    def test_empty_interval_rejected(self):
        with self.assertRaises(ValueError):N['validate_claims']({'q':claim(1,1,False,True)},{'q':None})
    def test_censored_upper_accepted(self):N['validate_claims']({'q':claim(1000,'+inf',False,False)},{'q':None})
    def test_future_observation_rejected(self):
        with self.assertRaises(ValueError):features({'q':claim()},obs=START)
    def test_common_ignores_supplement(self):
        self.assertEqual(features({'q':claim(1,1)},'common'),features({'q':claim(5000,5000)},'common'))
    def test_mask_age_ignores_numeric_values(self):
        self.assertEqual(features({'q':claim(1,1)},'mask_age'),features({'q':claim(5000,5000)},'mask_age'))
    def test_values_uses_numeric_values(self):
        self.assertNotEqual(features({'q':claim(1,1)}),features({'q':claim(5000,5000)}))
    def test_values_can_use_evidence_without_taf(self):
        x=features({'q':claim(1,1)});y=features({'q':claim(5000,5000)})
        bank={'feature_version':'native_h15_features.v1','mapping_version':'review_synthetic',
          'feature_names':['slot0_visibility_lower_log'],'mean':[0.],'scale':[1.],
          'coefficients':[[-1.],[0.],[1.]],'intercepts':[0.,0.,0.]}
        p,q=N['predict_features'](bank,x),N['predict_features'](bank,y)
        self.assertNotEqual(p['1000'],q['1000'])
        self.assertTrue(0<=p['1000']<=p['5000']<=1)

class RegressionGaps(unittest.TestCase):
    def test_temperature_noon_window_must_be_rejected(self):
        r=row();r['target']['physical_start']+=DAY//2;r['target']['physical_end']+=DAY//2
        with self.assertRaises(ValueError):F['temperature_ensemble_probability'](r)
    def test_temperature_duplicate_day_must_be_rejected(self):
        r=row();dup=copy.deepcopy(r['common']['daily_products'][0]);dup['forecast_max_members_C']=[35]*4
        r['common']['daily_products'].append(dup)
        with self.assertRaises(ValueError):F['temperature_ensemble_probability'](r)
    def test_temperature_nonfinite_threshold_must_be_rejected(self):
        r=row(threshold=math.nan)
        with self.assertRaises(ValueError):F['temperature_ensemble_probability'](r)
    def test_infinite_visibility_lower_must_be_rejected(self):
        payload={'slots':{'q':claim('+inf','+inf',True,True)}}
        with self.assertRaises(ValueError):F['parse_features'](json.dumps(payload),['q'])

def run():
    suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    with (ROOT/'results/local_tests.log').open('w') as f:
        runner=unittest.TextTestRunner(stream=f,verbosity=2)
        result=runner.run(suite)
    report={'commit':'1fd6821fef15b26898a57c74d4715714f33ea779',
      'scope':'Exact-source function/module tests. No native aviation parser, FormalSession, cloud job, full capsule or full repository test execution.',
      'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
      'passed':result.testsRun-len(result.failures)-len(result.errors),
      'failure_ids':[t.id() for t,_ in result.failures],
      'sources':[{ 'file':n,'git_blob_sha1':sha,'sha256':hashlib.sha256((SOURCE/n).read_bytes()).hexdigest() }for n,sha in EXPECTED.items()]}
    (ROOT/'results/LOCAL_VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return result
if __name__=='__main__':
    result = run()
    raise SystemExit(0 if result.wasSuccessful() else 1)
