"""Offline, synthetic probes of source pinned to 1fd6821.

No network, API, model, data download, or repository write is performed.
Two stdlib-only source modules execute in full. One temperature function is
compiled unchanged from the AST of the third module; unrelated parser imports
are not loaded. These are NOT the repository's full tests or real-data audits.
"""
from __future__ import annotations
import ast
import copy
import hashlib
import importlib.util
import json
import math
from datetime import datetime, timezone, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PINS = {
    'temperature_postprocess.py': '1ca9ae6ce50540829344b0a73a79a7d82b3e645e',
    'regional_calibration_v2.py': '570658377052493448586f3306fc3f420e1e6d7c',
    'feature_tasks.py': '4226d87ef5d18d1acc495f59141c6a1307ec88f9',
}
source_checks = []
for name, expected in PINS.items():
    b = (ROOT / 'source' / name).read_bytes()
    git_blob = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
    assert git_blob == expected, (name, git_blob, expected)
    source_checks.append({'file': name, 'git_blob': git_blob,
                          'sha256': hashlib.sha256(b).hexdigest(), 'verified': True})

def module(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'source' / (name + '.py'))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

post = module('temperature_postprocess')
cal = module('regional_calibration_v2')
tree = ast.parse((ROOT / 'source' / 'feature_tasks.py').read_text())
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                and n.name == 'temperature_ensemble_probability')
namespace = {'datetime': datetime, 'timezone': timezone, 'math': math}
exec(compile(ast.Module(body=[function], type_ignores=[]), 'feature_tasks.py:isolated', 'exec'), namespace)
older = namespace['temperature_ensemble_probability']
checks = []

def record(name, fn, kind='expected_behavior'):
    try:
        detail = fn()
        checks.append({'name': name, 'status': 'observed_as_asserted', 'kind': kind,
                       'detail': detail})
    except Exception as exc:
        checks.append({'name': name, 'status': 'probe_failed', 'kind': kind,
                       'error': type(exc).__name__ + ': ' + str(exc)})

def require_reject(fn):
    try:
        value = fn()
    except (ValueError, KeyError) as exc:
        return {'rejected': True, 'error': type(exc).__name__, 'message': str(exc)}
    raise AssertionError(f'Expected rejection, got {value!r}')

BASE = datetime(2025, 1, 2, tzinfo=timezone.utc)
START = int(BASE.timestamp() * 1_000_000)
DAY = post.DAY

def row(days=1, variable='daily_max_2m_temperature', threshold=30.0, operator='ge'):
    products=[]
    for i in range(days):
        products.append({'target_date': (BASE + timedelta(days=i)).date().isoformat(),
                         'day_index': i+1, 'forecast_min_members_C': [10.0, 11.0],
                         'forecast_max_members_C': [30.0, 29.0]})
    return {'target': {'units': 'C', 'physical_start': START, 'physical_end': START+days*DAY,
                       'variable': variable, 'event_operator': operator, 'threshold': threshold},
            'cutoff': START-3_600_000_000, 'common': {'daily_products': products}}

def exact_daily():
    r=row(); a,b=older(r),post.event_probability(r)
    assert a == b == 0.5
    return {'old': a,'new': b}
record('same exact daily threshold uses ge correctly', exact_daily)

def negative_min():
    r=row(variable='daily_min_2m_temperature', threshold=0, operator='lt')
    r['common']['daily_products'][0]['forecast_min_members_C']=[-1.0,0.0]
    a,b=older(r),post.event_probability(r)
    assert a==b==0.5
    return {'old':a,'new':b}
record('negative Celsius and strict frost boundary', negative_min)

def same_member():
    r=row(3,'min_of_3_daily_max_2m_temperature')
    for p,values in zip(r['common']['daily_products'], [[31.,29.],[29.,31.],[31.,29.]]):
        p['forecast_max_members_C']=values
    a,b=older(r),post.event_probability(r)
    assert a==b==0
    return {'same_member':b,'invalid_product_of_marginals':0.5**3}
record('three-day probability retains member trajectories', same_member)

def max_ice():
    r=row(3,'max_of_3_daily_max_2m_temperature',0,'lt')
    for p in r['common']['daily_products']:
        p['forecast_max_members_C']=[-1.,1.]
    assert older(r)==post.event_probability(r)==0.5
    return {'probability':0.5}
record('three-day ice uses max over the same member', max_ice)

def midnight_mismatch():
    r=row()
    r['target']['physical_start']+=12*3_600_000_000
    r['target']['physical_end']+=12*3_600_000_000
    p=older(r); rejection=require_reject(lambda:post.event_probability(r))
    assert p==0.5
    return {'older_accepts_midday_to_midday_with_calendar_day_array':p,'new':rejection}
record('non-UTC-midnight target accepted only by older helper', midnight_mismatch,'validation_gap')

def duplicate_date():
    r=row(); duplicate=copy.deepcopy(r['common']['daily_products'][0]);duplicate['forecast_max_members_C']=[40.,40.]
    r['common']['daily_products'].append(duplicate)
    p=older(r);rejection=require_reject(lambda:post.event_probability(r))
    assert p==1.0
    return {'older_silently_uses_last_duplicate':p,'new':rejection}
record('conflicting duplicate date accepted only by older helper',duplicate_date,'validation_gap')

def nan_threshold():
    r=row(threshold=float('nan'));p=older(r);rej=require_reject(lambda:post.event_probability(r))
    assert p==0.0
    return {'older_returns_numeric_zero_for_nan_threshold':p,'new':rej}
record('NaN target threshold accepted only by older helper',nan_threshold,'validation_gap')

def common_reject_mutator(mutate):
    r=row(3,'min_of_3_daily_max_2m_temperature');mutate(r)
    return {'older':require_reject(lambda:older(r)), 'new':require_reject(lambda:post.event_probability(r))}
record('day0 rejected by both',lambda:common_reject_mutator(lambda r:r['common']['daily_products'][0].update(day_index=0)))
record('incomplete same-member arrays rejected by both',lambda:common_reject_mutator(lambda r:r['common']['daily_products'][1].update(forecast_max_members_C=[31.])))
record('nonfinite member rejected by both',lambda:common_reject_mutator(lambda r:r['common']['daily_products'][0].update(forecast_max_members_C=[31.,float('nan')])))
record('cutoff at future support start rejected by both',lambda:common_reject_mutator(lambda r:r.update(cutoff=r['target']['physical_start'])))
record('missing target day rejected by both',lambda:common_reject_mutator(lambda r:r['common']['daily_products'].pop()))

def fixed_prior():
    a=cal.fit_fixed_prior([(0.1,0,1.) for _ in range(100)])
    b=cal.fit_fixed_prior([(0.1+i*1e-12,0,1.) for i in range(100)])
    assert all(math.isclose(x['value'],1/102,rel_tol=1e-12) for x in a+b)
    return {'identical_probability':a[0]['value'],'tiny_distinct_probabilities':b[0]['value'],
            'prior_mass':2,'n':100}
record('fixed total prior avoids per-distinct-probability inflation',fixed_prior)
record('empty calibration rejected',lambda:require_reject(lambda:cal.fit_fixed_prior([])))
record('negative observation weight rejected',lambda:require_reject(lambda:cal.fit_fixed_prior([(.1,0,-1)])))

def projection():
    result=cal.coherent_cdf([.8,.2],['same','same']);assert result==[.5,.5]
    return result
record('coherent CDF pools reversed nested thresholds',projection)

def stable_projection():
    p=[.1,.3,.9];assert cal.coherent_cdf(p,['x']*3)==p;return p
record('ordered CDF preserved',stable_projection)
record('different information identities rejected',lambda:require_reject(lambda:cal.coherent_cdf([.2,.3],['A','B'])))
record('nonfinite CDF prediction rejected',lambda:require_reject(lambda:cal.coherent_cdf([.2,float('nan')],['A','A'])))

def ecc_unchanged():
    products=row()['common']['daily_products'];before=copy.deepcopy(products)
    bank={'min':{'a':-20,'b':1,'log_c':0,'log_d':0},'max':{'a':20,'b':1,'log_c':0,'log_d':0}}
    out,trace=post.ecc_products(products,bank)
    assert products==before and trace['minmax_projections']==0
    assert out[0]['forecast_max_members_C'][0]>out[0]['forecast_max_members_C'][1]
    return {'input_immutable':True,'trace':trace}
record('ECC preserves source arrays and untied ranks before repair',ecc_unchanged)

def ecc_repair():
    products=row()['common']['daily_products']
    bank={'min':{'a':20,'b':0,'log_c':0,'log_d':0},'max':{'a':0,'b':0,'log_c':0,'log_d':0}}
    out,trace=post.ecc_products(products,bank)
    assert trace['minmax_projections']==2
    assert out[0]['forecast_min_members_C']==out[0]['forecast_max_members_C']
    return {'trace':trace,'min':out[0]['forecast_min_members_C'],'max':out[0]['forecast_max_members_C'],
            'interpretation':'declared projection, not a bug; final marginals no longer the unprojected Gaussians'}
record('declared min/max projection changes marginals visibly',ecc_repair,'declared_design_diagnostic')

result={'commit':'1fd6821fef15b26898a57c74d4715714f33ea779','scope':'synthetic local source probes; not end-to-end repository or historical dataset replay',
        'source_checks':source_checks,'behavior_checks':checks,
        'counts':{'source_hash_checks':len(source_checks),'behavior_checks':len(checks),
                  'probe_failures':sum(c['status']=='probe_failed' for c in checks)},
        'qualification':'observed_as_asserted includes reproduction of known-invalid input acceptance; it is not a claim all production behavior is correct'}
(ROOT/'CHECK_RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps(result['counts']))
for c in checks:
    print(c['status'],c['kind'],c['name'])
if result['counts']['probe_failures']:
    raise SystemExit(1)
