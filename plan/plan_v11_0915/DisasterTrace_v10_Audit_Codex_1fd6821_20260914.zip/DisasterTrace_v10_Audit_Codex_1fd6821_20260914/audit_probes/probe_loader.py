"""Hash-bound review loader. Set DT_REPO_ROOT for normal production-package imports.

Default mode loads complete fetched definitions and removes only top-level
relative imports; the exercised dependencies come from their matching production
files. Native METAR/TAF parsing is deliberately unavailable and will fail if a
probe tries to use it. No tested function body is rewritten. This mode is NOT
full package integration, journal replay, or an independent weather truth source.
"""
import ast
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import types

SHA='1fd6821fef15b26898a57c74d4715714f33ea779'
ROOT=Path(__file__).resolve().parent/'sources'
EXPECTED={
 'adoption':'3dba7f144254d51392682577488b8b525ea28261',
 'temperature_postprocess':'1ca9ae6ce50540829344b0a73a79a7d82b3e645e',
 'regional_calibration_v2':'570658377052493448586f3306fc3f420e1e6d7c',
 'support':'d43b56c98aa3e59c4c1d17f72a503941b604698d',
 'evidence':'d921c845ac6689131944271c34a1f462deb5fb9b',
 'native_feature_forecast':'36b7923bb3ac3cb5e16055dbf75588fe7f4136cf',
 'feature_tasks':'4226d87ef5d18d1acc495f59141c6a1307ec88f9',
 'common':'31ed9e5f3cceabda9d9553b28be89ed1858bfc9f',
}
CHECKS=[]
def load(name, dependencies=None):
    path=ROOT/(name+'.py');data=path.read_bytes()
    blob=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
    if blob != EXPECTED[name]: raise RuntimeError(f'Frozen source mismatch: {name}')
    CHECKS.append({'name':name,'git_blob_sha1':blob,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'matched':True})
    tree=ast.parse(data,filename=str(path))
    tree.body=[x for x in tree.body if not(isinstance(x,ast.ImportFrom) and x.level)]
    mod=types.ModuleType('_v10_review_'+name); mod.__file__=str(path)
    if dependencies: mod.__dict__.update(dependencies)
    sys.modules[mod.__name__]=mod
    exec(compile(tree,str(path),'exec'),mod.__dict__)
    return mod

def unavailable(*args,**kwargs):
    raise RuntimeError('Native parser not exercised by this scoped reviewer; use DT_REPO_ROOT')

if os.getenv('DT_REPO_ROOT'):
    sys.path.insert(0,str(Path(os.environ['DT_REPO_ROOT'])/'disastertrace-starter/src'))
    S=importlib.import_module('disastertrace.monitoring_v1.support')
    E=importlib.import_module('disastertrace.monitoring_v1.evidence')
    N=importlib.import_module('disastertrace.monitoring_v1.native_feature_forecast')
    F=importlib.import_module('disastertrace.monitoring_v1.feature_tasks')
    T=importlib.import_module('disastertrace.monitoring_v1.temperature_postprocess')
    C=importlib.import_module('disastertrace.monitoring_v1.regional_calibration_v2')
    A=importlib.import_module('disastertrace.monitoring_fixed_v1.adoption')
    MODE='production_package'
else:
    S=load('support')
    E=load('evidence',{'Interval':S.Interval,'classify':S.classify})
    N=load('native_feature_forecast',{'interval_from_dict':E.interval_from_dict,'taf_features':E.taf_features,'parse_metar':unavailable,'parse_taf':unavailable})
    J=load('common')
    F=load('feature_tasks',{'strict_json':J.strict_json,'validate_claims':N.validate_claims})
    T=load('temperature_postprocess'); C=load('regional_calibration_v2'); A=load('adoption')
    MODE='isolated_hash_bound_definitions'
if __name__=='__main__':
    print(json.dumps({'commit':SHA,'mode':MODE,'files':CHECKS},indent=2))
