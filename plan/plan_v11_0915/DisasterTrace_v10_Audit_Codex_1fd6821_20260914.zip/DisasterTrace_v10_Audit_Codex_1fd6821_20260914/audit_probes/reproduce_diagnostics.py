"""Print the exact boundary behavior without claiming historical impact."""
import copy,json
from pathlib import Path
from probe_loader import F,N,S,E,T,MODE,SHA
from test_v10_controls import row,product,claim,feature_inputs,DAY
out={'commit':SHA,'execution_mode':MODE,'synthetic_only':True,'historical_impact':'not_scanned'}
r=row();r['target']['physical_start']+=DAY//2;r['target']['physical_end']+=DAY//2
out['noon_window']={'input':r,'feature_tasks_probability':F.temperature_ensemble_probability(r)}
try:T.event_probability(r)
except Exception as e:out['noon_window']['postprocess_result']=type(e).__name__+': '+str(e)
r=row();r['common']['daily_products'].append(product(values=(35.,35.)))
p1=F.temperature_ensemble_probability(r);r['common']['daily_products'].reverse();p2=F.temperature_ensemble_probability(r)
out['conflicting_duplicate_dates']={'forward_probability':p1,'reversed_probability':p2,'postprocess_rejects':True}
payload={'slots':{'q':claim('+inf','+inf',True,True)}}
out['infinite_lower']={'input':payload,'parsed':F.parse_features(json.dumps(payload),['q'])[0],
                      'finite_physical_values_in_interval':False}
t,d,at=feature_inputs();a,b=claim(0,1000,True,True),claim(0,1000,True,False)
out['endpoint_feature_collision']={'support_closed':S.classify(E.interval_from_dict(a['visibility']),'lt',1000),
 'support_open':S.classify(E.interval_from_dict(b['visibility']),'lt',1000),
 'same_feature_vector':N.feature_vector(t,None,['q'],d,at=at,claims={'q':a})==N.feature_vector(t,None,['q'],d,at=at,claims={'q':b}),
 'classification':'representation limitation, not a failed score calculation','native_occurrence_in_current_thresholds':'unverified'}
Path(__file__).with_name('DIAGNOSTICS.json').write_text(json.dumps(out,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps(out,indent=2,ensure_ascii=False,allow_nan=False))
