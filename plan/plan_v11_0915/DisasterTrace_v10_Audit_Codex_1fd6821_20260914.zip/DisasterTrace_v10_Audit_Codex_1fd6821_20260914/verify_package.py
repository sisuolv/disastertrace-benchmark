"""Verify delivery integrity and task DAG, using only the standard library."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
actual={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts}
if actual!=manifest['files']:raise SystemExit('Package file inventory or hashes differ')
tasks=json.loads((root/'TASKS.json').read_text())['tasks']; by={t['id']:t for t in tasks}
if len(by)!=len(tasks):raise SystemExit('Duplicate task id')
seen=set();active=set()
def visit(i):
    if i in active:raise SystemExit('Dependency cycle')
    if i in seen:return
    if i not in by:raise SystemExit('Missing task dependency '+i)
    active.add(i)
    for d in by[i]['depends_on']:visit(d)
    active.remove(i);seen.add(i)
for i in by:visit(i)
print(json.dumps({'integrity':'passed','tasks':len(tasks),'acceptance_requirements':len(json.loads((root/'ACCEPTANCE_CASES.json').read_text())),'scientific_validation':False},ensure_ascii=False))
