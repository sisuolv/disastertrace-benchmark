"""Read-only checks of two exact upstream modules on synthetic fixtures.
No network, model, dataset download, or upstream project test suite is executed.
"""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
import math
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def module(name):
    path=ROOT/'source'/f'{name}.py'
    spec=importlib.util.spec_from_file_location(name,path)
    obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj)
    return obj
c=module('regional_calibration_v2');t=module('temperature_postprocess')
checks=[]
def run(name,fn):
    try:
        detail=fn()
        checks.append({'id':name,'passed':True,'details':detail})
    except Exception as e:
        checks.append({'id':name,'passed':False,'error':repr(e)})

def rejection(fn):
    try: fn()
    except (ValueError,TypeError): return {'rejected':True}
    raise AssertionError('invalid fixture not rejected')

def check_cdf():
    result=c.coherent_cdf([.8,.2,.7],['identical']*3)
    assert result==[.5,.5,.7]
    return {'input':[.8,.2,.7],'output':result}
run('C01_isotonic_projection',check_cdf)
run('C02_distinct_information_rejected',lambda:rejection(lambda:c.coherent_cdf([.8,.2],['A','B'])))
run('C03_nan_rejected',lambda:rejection(lambda:c.coherent_cdf([float('nan'),.2],['A','A'])))
run('C04_boolean_probability_rejected',lambda:rejection(lambda:c.coherent_cdf([True,.2],['A','A'])))
def cdf_invariant():
    x=[0,.1,.6,1];assert c.coherent_cdf(x,['A']*4)==x
    return {'unchanged':True}
run('C05_valid_cdf_unchanged',cdf_invariant)
def weight_split():
    a=c.fit_fixed_prior([(.1,0,1),(.8,1,1)])
    b=c.fit_fixed_prior([(.1,0,.5),(.1,0,.5),(.8,1,.25),(.8,1,.75)])
    assert a==b
    return {'equal_after_weight_split':True,'mapping':a}
run('C06_fixed_total_prior_weight_split',weight_split)
start=int(datetime(2018,7,1,tzinfo=timezone.utc).timestamp()*1e6)
products=[{'target_date':f'2018-07-0{d+1}','day_index':d+1,
           'forecast_min_members_C':[10,10], 'forecast_max_members_C':row}
          for d,row in enumerate(([31,29],[29,31],[31,29]))]
row={'cutoff':start-1,'target':{'units':'C','physical_start':start,'physical_end':start+3*t.DAY,
     'variable':'min_of_3_daily_max_2m_temperature','event_operator':'ge','threshold':30},
     'common':{'daily_products':products}}
def joint():
    p=t.event_probability(row)
    marg=math.prod(sum(v>=30 for v in q['forecast_max_members_C'])/2 for q in products)
    assert p==0 and marg==.125
    return {'same_member_three_day':p,'incorrect_independent_marginal_product':marg}
run('T01_same_member_joint',joint)
def permute():
    r=copy.deepcopy(row)
    for p in r['common']['daily_products']:
        for f in ['forecast_min_members_C','forecast_max_members_C']:p[f].reverse()
    assert t.event_probability(r)==t.event_probability(row)
    return {'invariant_under_common_member_permutation':True}
run('T02_member_permutation',permute)
run('T03_missing_target_day_rejected',lambda:rejection(lambda:t.event_probability(row,products=products[:2])))
def day0():
    ps=copy.deepcopy(products);ps[0]['day_index']=0
    return rejection(lambda:t.validate_products(ps))
run('T04_day0_rejected',day0)
def nonfinite():
    ps=copy.deepcopy(products);ps[0]['forecast_max_members_C'][0]=float('inf')
    return rejection(lambda:t.validate_products(ps))
run('T05_nonfinite_members_rejected',nonfinite)
def late():
    r=copy.deepcopy(row);r['cutoff']=start
    return rejection(lambda:t.event_probability(r))
run('T06_cutoff_at_target_start_rejected',late)
def crossing():
    ps=copy.deepcopy(products)
    bank={'min':{'a':30,'b':0,'log_c':-3,'log_d':-3},
          'max':{'a':10,'b':0,'log_c':-3,'log_d':-3}}
    out,trace=t.ecc_products(ps,bank)
    assert ps==products and trace['minmax_projections']==6
    assert all(lo<=hi for q in out for lo,hi in zip(q['forecast_min_members_C'],q['forecast_max_members_C']))
    assert not trace['joint_calibration_guarantee']
    return {'minmax_projections':trace['minmax_projections'],'inputs_unchanged':True,'joint_calibration_guarantee':False}
run('T07_minmax_projection_recorded',crossing)
# Arithmetic only: independently reproduce quantities reported in v10, not raw scores.
arithmetic={'model_answers':2016+212+212+288+84,
 'total_attempts_including_compatibility':2016+212+212+288+84+15,
 'seasonal_registered_opportunities':12*3*7*24*2,
 'seasonal_first_day_trajectories':12*2*9,
 'seasonal_first_day_method_rows':12*2*9*3*24,
 'all_seasons_5km_values_information_gain':.038827-.033218,
 'all_seasons_5km_common_backend_gain_vs_follow':.043130-.036448,
 'all_seasons_5km_values_allread_gain_vs_follow':.043130-.033218,
 'three_no_event_blocks_mean_gain':(.004947+.003043+.003722)/3,
 'event_date_block_gain':-.010882}
assert arithmetic['model_answers']==2812
assert arithmetic['seasonal_registered_opportunities']==12096
result={'scope':'two exact Git-blob-matched upstream modules; synthetic input tests only',
        'commit':'1fd6821fef15b26898a57c74d4715714f33ea779','tests':checks,
        'tests_passed':sum(x['passed'] for x in checks),'tests_total':len(checks),
        'reported_number_arithmetic':arithmetic,'full_project_tests_run':False,
        'full_data_replayed':False,'models_called':0}
(ROOT/'diagnostics'/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
if not all(x['passed'] for x in checks):raise SystemExit(1)
