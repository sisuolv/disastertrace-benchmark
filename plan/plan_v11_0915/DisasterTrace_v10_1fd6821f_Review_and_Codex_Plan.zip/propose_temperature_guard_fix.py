"""Create/test a local-only candidate contract guard patch; never touches GitHub."""
import ast,copy,difflib,json,math
from pathlib import Path
from datetime import datetime,timezone
import reviewer_checks as r
root=Path(__file__).resolve().parent
path=root/'source/feature_tasks.py';old=path.read_text()
new=old.replace('from .native_feature_forecast import validate_claims\n','from .native_feature_forecast import validate_claims\nfrom .temperature_postprocess import validate_products\n')
new=new.replace('''    day_us = 86400_000_000
    if (
        target["units"] != "C"
        or target["physical_start"] <= row["cutoff"]
        or (target["physical_end"] - target["physical_start"]) % day_us
    ):
        raise ValueError("Temperature requires an absolute future UTC-day support")
    products = {p["target_date"]: p for p in common["daily_products"]}
''','''    day_us = 86400_000_000
    start, end, cutoff = target["physical_start"], target["physical_end"], row["cutoff"]
    if (
        target["units"] != "C"
        or any(type(t) is not int for t in (start, end, cutoff))
        or start % day_us
        or end % day_us
        or end <= start
        or cutoff >= start
    ):
        raise ValueError("Temperature requires an absolute future UTC-day support")
    validate_products(common["daily_products"])
    products = {p["target_date"]: p for p in common["daily_products"]}
''')
new=new.replace('''    if operator not in {"ge", "lt"}:
        raise ValueError("Unqualified temperature event endpoint")
''','''    if (
        operator not in {"ge", "lt"}
        or type(threshold) not in (int, float)
        or not math.isfinite(threshold)
    ):
        raise ValueError("Unqualified temperature event endpoint")
''')
assert new!=old
out=root/'proposed';out.mkdir(exist_ok=True);(out/'feature_tasks.py').write_text(new)
repo='disastertrace-starter/src/disastertrace/monitoring_v1/feature_tasks.py'
(root/'temperature_contract_guard.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+repo,tofile='b/'+repo)))
node=next(n for n in ast.parse(new).body if isinstance(n,ast.FunctionDef) and n.name=='temperature_ensemble_probability')
ns={'math':math,'datetime':datetime,'timezone':timezone,'validate_products':r.temp.validate_products}
exec(compile(ast.Module(body=[node],type_ignores=[]),'proposed/feature_tasks.py','exec'),ns)
f=ns['temperature_ensemble_probability'];valid=0
for variable,n in [('daily_max_2m_temperature',1),('daily_min_2m_temperature',1),('min_of_3_daily_max_2m_temperature',3),('max_of_3_daily_max_2m_temperature',3)]:
 for op in ['ge','lt']:
  for threshold in [-10,0,30]:
   row=r.row(n,variable,threshold,op)
   assert f(row)==r.legacy_temp(row)==r.temp.event_probability(row);valid+=1
bad=[]
a=r.row();a['target']['physical_start']+=r.DAY//2;a['target']['physical_end']+=r.DAY//2;bad.append(a)
bad.append(r.row(threshold=math.nan));bad.append(r.row(threshold=True))
a=r.row();a['common']['daily_products']*=2;bad.append(a)
a=r.row();a['common']['daily_products'][0]['day_index']=True;bad.append(a)
a=r.row();a['cutoff']=float(a['cutoff']);bad.append(a)
for x in bad:
 try:f(x)
 except ValueError:pass
 else:raise AssertionError('Candidate guard accepted invalid input')
(root/'CANDIDATE_FIX_VALIDATION.json').write_text(json.dumps({'passed':True,'valid_cases_unchanged':valid,'invalid_cases_rejected':len(bad),'scope':'local-only candidate; function AST plus real shared validate_products; complete module import and repository regressions not run','repository_modified':False,'model_calls':0},indent=2))
print((root/'CANDIDATE_FIX_VALIDATION.json').read_text())
