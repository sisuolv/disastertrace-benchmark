"""Offline reviewer checks; not the repository's complete test suite.

Three pure modules are imported in full. The exact temperature function AST from
feature_tasks.py is compiled alone; its parser/model dependencies are NOT stubbed
or represented as tested. No network, model, cloud, or historical launcher runs.
"""
from __future__ import annotations
import ast
import copy
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import statistics
import unittest
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parent
BIND=json.loads((ROOT/'SOURCE_BINDINGS.json').read_text())
for item in BIND['files']:
    b=(ROOT/item['local_path']).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==item['git_blob_expected']

def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/'source'/f'{name}.py')
    obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj

temp=module('temperature_postprocess')
cal=module('regional_calibration_v2')
schedule=module('forecast_schedule')
source_path=ROOT/'source/feature_tasks.py'
tree=ast.parse(source_path.read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='temperature_ensemble_probability')
ns={'math':math,'datetime':datetime,'timezone':timezone}
exec(compile(ast.Module(body=[node],type_ignores=[]),str(source_path),'exec'),ns)
legacy_temp=ns['temperature_ensemble_probability']
DAY=temp.DAY
T=int(datetime(2025,1,2,tzinfo=timezone.utc).timestamp()*1e6)

def row(n=1,variable='daily_max_2m_temperature',threshold=30,operator='ge'):
    products=[]
    for i in range(n):
        products.append({'target_date':datetime.fromtimestamp((T+i*DAY)/1e6,timezone.utc).date().isoformat(),
                         'day_index':i+1,'forecast_min_members_C':[-2,2],
                         'forecast_max_members_C':[31,29]})
    return {'cutoff':T-1000000,'target':{'units':'C','physical_start':T,'physical_end':T+n*DAY,
           'variable':variable,'event_operator':operator,'threshold':threshold},'common':{'daily_products':products}}

class TemperatureChecks(unittest.TestCase):
    def test_day_probability_and_matching_implementations(self):
        r=row();self.assertEqual(temp.event_probability(r),.5);self.assertEqual(legacy_temp(r),.5)
    def test_frost_negative_values(self):
        self.assertEqual(temp.event_probability(row(variable='daily_min_2m_temperature',threshold=0,operator='lt')),.5)
    def test_equal_threshold_uses_declared_operator(self):
        r=row();r['common']['daily_products'][0]['forecast_max_members_C']=[30,30]
        self.assertEqual(temp.event_probability(r),1);r['target']['event_operator']='lt';self.assertEqual(temp.event_probability(r),0)
    def test_heat_joint_not_marginal_product(self):
        r=row(3,'min_of_3_daily_max_2m_temperature');self.assertEqual(temp.event_probability(r),.5)
        self.assertNotEqual(temp.event_probability(r),.5**3)
    def test_ice_joint_same_member(self):
        r=row(3,'max_of_3_daily_max_2m_temperature',0,'lt')
        for p in r['common']['daily_products']:p['forecast_max_members_C']=[-1,1]
        self.assertEqual(temp.event_probability(r),.5)
    def test_common_member_permutation_preserves_event(self):
        r=row(3,'min_of_3_daily_max_2m_temperature');expected=temp.event_probability(r)
        for p in r['common']['daily_products']:
            p['forecast_max_members_C'].reverse();p['forecast_min_members_C'].reverse()
        self.assertEqual(temp.event_probability(r),expected)
    def test_strict_non_midnight_rejected(self):
        r=row();r['target']['physical_start']+=DAY//2;r['target']['physical_end']+=DAY//2
        with self.assertRaises(ValueError):temp.event_probability(r)
    def test_cutoff_at_start_rejected(self):
        r=row();r['cutoff']=T
        with self.assertRaises(ValueError):temp.event_probability(r)
    def test_day0_rejected(self):
        r=row();r['common']['daily_products'][0]['day_index']=0
        with self.assertRaises(ValueError):temp.event_probability(r)
    def test_duplicate_dates_rejected(self):
        r=row();r['common']['daily_products']*=2
        with self.assertRaises(ValueError):temp.event_probability(r)
    def test_member_dimension_rejected(self):
        r=row();r['common']['daily_products'][0]['forecast_min_members_C']=[1]
        with self.assertRaises(ValueError):temp.event_probability(r)
    def test_nan_member_rejected(self):
        r=row();r['common']['daily_products'][0]['forecast_max_members_C'][0]=math.nan
        with self.assertRaises(ValueError):temp.event_probability(r)
    def test_bool_member_rejected(self):
        r=row();r['common']['daily_products'][0]['forecast_max_members_C'][0]=True
        with self.assertRaises(ValueError):temp.event_probability(r)
    def test_nan_threshold_rejected(self):
        with self.assertRaises(ValueError):temp.event_probability(row(threshold=math.nan))
    def test_wrong_duration_rejected(self):
        with self.assertRaises(ValueError):temp.event_probability(row(2,'min_of_3_daily_max_2m_temperature'))
    def test_missing_day_rejected(self):
        r=row(3,'min_of_3_daily_max_2m_temperature');r['common']['daily_products'].pop()
        with self.assertRaises(ValueError):temp.event_probability(r)
    def test_units_rejected(self):
        r=row();r['target']['units']='K'
        with self.assertRaises(ValueError):temp.event_probability(r)

class ECCChecks(unittest.TestCase):
    def base(self):
        p=row()['common']['daily_products'];p[0]['forecast_min_members_C']=[-20,-10,-15];p[0]['forecast_max_members_C']=[10,20,15]
        b={k:{'a':0.,'b':1.,'log_c':-2.,'log_d':-2.} for k in ['min','max']}
        return p,b
    def test_input_immutable(self):
        p,b=self.base();original=copy.deepcopy(p);temp.ecc_products(p,b);self.assertEqual(p,original)
    def test_raw_rank_order_preserved_before_any_repair(self):
        p,b=self.base();new,trace=temp.ecc_products(p,b);self.assertEqual(trace['minmax_projections'],0)
        for f in ['forecast_min_members_C','forecast_max_members_C']:
            rank=lambda v:sorted(range(len(v)),key=lambda i:(v[i],i))
            self.assertEqual(rank(p[0][f]),rank(new[0][f]))
    def test_quantiles_match_distribution_without_repair(self):
        p,b=self.base();out,tr=temp.ecc_products(p,b)
        original=p[0]['forecast_max_members_C'];dist=statistics.NormalDist(statistics.fmean(original),math.sqrt(math.exp(-2)+math.exp(-2)*statistics.pvariance(original)))
        self.assertEqual(sorted(out[0]['forecast_max_members_C']),[dist.inv_cdf((i+.5)/3) for i in range(3)])
    def test_minmax_projection_reported(self):
        p,b=self.base();b['min']['a']=100.;b['max']['a']=-100.
        out,tr=temp.ecc_products(p,b);self.assertEqual(tr['minmax_projections'],3)
        self.assertEqual(out[0]['forecast_min_members_C'],out[0]['forecast_max_members_C'])
    def test_ties_deterministic_and_no_calibration_guarantee(self):
        p,b=self.base();p[0]['forecast_min_members_C']=[-10]*3
        a,ta=temp.ecc_products(p,b);z,tz=temp.ecc_products(p,b)
        self.assertEqual(a,z);self.assertFalse(ta['joint_calibration_guarantee'])

class CalibrationChecks(unittest.TestCase):
    def test_cdf_identity(self):self.assertEqual(cal.coherent_cdf([.1,.4],['x','x']),[.1,.4])
    def test_cdf_projection(self):self.assertEqual(cal.coherent_cdf([.8,.2],['x','x']),[.5,.5])
    def test_information_mismatch_rejected(self):
        with self.assertRaises(ValueError):cal.coherent_cdf([.8,.2],['x','y'])
    def test_nonprobability_rejected(self):
        for bad in [True,math.nan,math.inf,-.1,1.1]:
            with self.subTest(bad=str(bad)),self.assertRaises(ValueError):cal.coherent_cdf([bad,.2],['x','x'])
    def test_prior_order_invariance(self):
        r=[(.1,0,1),(.2,1,1),(.3,0,1)];self.assertEqual(cal.fit_fixed_prior(r),cal.fit_fixed_prior(list(reversed(r))))
    def test_prior_weight_split_invariance(self):
        a=cal.fit_fixed_prior([(.1,0,1),(.7,1,1)]);b=cal.fit_fixed_prior([(.1,0,.5),(.1,0,.5),(.7,1,1)])
        self.assertEqual(a,b)
    def test_empty_fit_rejected(self):
        with self.assertRaises(ValueError):cal.fit_fixed_prior([])

class ScheduleChecks(unittest.TestCase):
    def config(self):return {'forecast_schedule':{'kind':'public_serial_slots.v1','lead_seconds':120,'spacing_seconds':30},'session_runtime':'typed_admission_v1','admission_semantics':'measurement.v3','gate':False,'per_tick_forecast_cap':3,'wakeup_seconds':3600,'seed':7}
    def active(self):return [{'cutoff':1000000000,'opportunity_id':k,'irrelevant_evidence':i} for i,k in enumerate(['c','a','b'])]
    def test_slots_before_cutoff(self):
        vals=schedule.public_slots(self.active(),self.config(),lambda s,x,k:k)
        self.assertEqual(vals,{'a':880000000,'b':910000000,'c':940000000})
    def test_order_and_evidence_invariance(self):
        a=self.active();original=schedule.public_slots(a,self.config(),lambda s,x,k:k)
        a.reverse()
        for r in a:r['irrelevant_evidence']='changed'
        self.assertEqual(original,schedule.public_slots(a,self.config(),lambda s,x,k:k))
    def test_bad_capacity_rejected(self):
        c=self.config();c['per_tick_forecast_cap']=5
        with self.assertRaises(ValueError):schedule.validate_schedule(c)
    def test_gate_rejected(self):
        c=self.config();c['gate']=True
        with self.assertRaises(ValueError):schedule.validate_schedule(c)
    def test_mixed_cutoffs_rejected(self):
        a=self.active();a[0]['cutoff']+=1
        with self.assertRaises(ValueError):schedule.public_slots(a,self.config(),lambda s,x,k:k)

def capture_call(fn,r):
    try:return {'status':'returned','value':fn(r)}
    except Exception as e:return {'status':'rejected','exception':type(e).__name__,'message':str(e)}

def probes():
    noon=row();noon['target']['physical_start']+=DAY//2;noon['target']['physical_end']+=DAY//2
    nan=row(threshold=math.nan)
    dup=row();other=copy.deepcopy(dup['common']['daily_products'][0]);other['forecast_max_members_C']=[40,40];dup['common']['daily_products'].append(other)
    boolean=row();boolean['common']['daily_products'][0]['day_index']=True
    out=[]
    for name,r in [('non_midnight_24h_window',noon),('NaN_threshold',nan),('duplicate_date',dup),('boolean_day_index',boolean)]:
        result={'case':name,'feature_tasks_function':capture_call(legacy_temp,r),'postprocess_function':capture_call(temp.event_probability,r)}
        if name=='duplicate_date':
            changed=copy.deepcopy(r);changed['common']['daily_products'].reverse();result['feature_tasks_reversed_order']=capture_call(legacy_temp,changed)
        out.append(result)
    assert out[0]['feature_tasks_function']['status']=='returned' and out[0]['postprocess_function']['status']=='rejected'
    assert out[1]['feature_tasks_function']['value']==0.0 and out[1]['postprocess_function']['status']=='rejected'
    assert out[2]['feature_tasks_function']['value']!=out[2]['feature_tasks_reversed_order']['value']
    assert out[3]['feature_tasks_function']['status']=='returned' and out[3]['postprocess_function']['status']=='rejected'
    (ROOT/'BEHAVIOR_PROBES.json').write_text(json.dumps({'scope':'synthetic malformed inputs to real functions; not evidence of affected published runs','probes':out},indent=2))

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    with (ROOT/'TESTS.log').open('w') as f:
        result=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
    report={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),
        'passed':result.wasSuccessful(),'scope':'reviewer-authored CPU regression checks, not repository suite; 3 modules fully imported and 1 exact function AST; synthetic data only',
        'fully_imported':['temperature_postprocess.py','regional_calibration_v2.py','forecast_schedule.py'],
        'exact_ast_function':['feature_tasks.temperature_ensemble_probability'],'model_calls':0,'cloud_jobs':0,'private_raw_data_replayed':False}
    (ROOT/'TEST_RESULTS.json').write_text(json.dumps(report,indent=2));probes();print(json.dumps(report,indent=2))
    print((ROOT/'BEHAVIOR_PROBES.json').read_text())
    raise SystemExit(not result.wasSuccessful())
