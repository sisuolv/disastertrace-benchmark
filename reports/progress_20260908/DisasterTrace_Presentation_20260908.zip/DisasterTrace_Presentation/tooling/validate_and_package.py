"""Validate the reporting artifacts and create a self-contained sharing ZIP."""

import csv
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import re
import zipfile

import pymupdf

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/'report_data.json').read_text())


def main():
    rows=[]
    def add(stage,model,method,n,valid,correct):
        assert 0 <= correct <= valid <= n
        rows.append(dict(stage=stage,model=model,method=method,planned=n,received=n,
                         contract_valid=valid,all_correct=correct,all_correct_fraction=round(correct/n,8)))
    for method,entry in D['early_runs']['P1']['methods'].items():
        add('P1','deepseek-v4-flash',method,30,entry['counts']['valid'],entry['counts']['all_correct'])
    for cell in D['early_runs']['T6']['cell_counts']:
        arm,method=cell['cell_id'].split('__')
        correct=D['early_runs']['T6']['metrics'][cell['cell_id']]['all_correct_checkpoints']['numerator']
        add('T6_'+arm,'deepseek-v4-flash',method,30,cell['schema_valid'],correct)
    for stage in ['P2_v1','P2_v2']:
        for method,entry in D['early_runs'][stage]['methods'].items():
            c=entry['counts'];add(stage,'deepseek-v4-flash',method,c['checkpoints'],c['schema_valid'],c['all_correct'])
    for stage in ['P3','P4','revision_chain','irrelevant_scope','late_stale_replay']:
        for method,c in D['measured'][stage]['methods'].items():
            add(stage,'Qwen3-8B',method,c['checkpoints'],c['schema_valid'],c['all_correct'])
    assert len(rows)==33
    assert sum(r['received'] for r in rows)==3600
    with (ROOT/'RUN_RESULTS.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

    broken=[]
    for path in ROOT.glob('*.md'):
        for target in re.findall(r'\]\(([^)]+)\)',path.read_text()):
            if target.startswith(('https://','http://','#')):continue
            p=Path(target.split('#')[0])
            if not p.is_absolute():p=path.parent/p
            if not p.exists():broken.append({'file':path.name,'target':target})
    assert not broken,broken

    doc=pymupdf.open(ROOT/'DisasterTrace_Progress_20260908.pdf')
    assert len(doc)==24
    assert all(page.get_text().strip() for page in doc)
    assert str(D['p6_status']['parsed_records']) in doc[15].get_text().replace(',','')
    for i in [0,8,10,15,20]:
        doc[i].get_pixmap(matrix=pymupdf.Matrix(1.5,1.5)).save(ROOT/'preview'/f'pdf_page_{i+1:02d}.png')
    receipt={
        'status':'passed','snapshot_utc':D['snapshot_utc'],
        'csv_rows':len(rows),'completed_response_inventory':3600,
        'pooled_ability_score_reported':False,'local_markdown_links_valid':True,
        'pdf_pages':24,'pdf_pages_with_extractable_text':24,
        'actual_pdf_pages_rasterized':[1,9,11,16,21],
        'powerpoint_or_libreoffice_rendered':False,
        'report_creation_model_calls':0,'report_creation_gpu_jobs':0,
    }
    (ROOT/'evidence/package_validation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    packages=['python-pptx','reportlab','matplotlib','Pillow','numpy','fonttools','pymupdf']
    (ROOT/'tooling/requirements.txt').write_text('\n'.join(f'{p}=={version(p)}' for p in packages)+'\n')
    selected=[p for p in ROOT.iterdir() if p.is_file() and p.suffix in ['.md','.json','.csv','.pptx','.pdf']]
    for directory in ['charts','evidence','tooling']:
        selected.extend(p for p in (ROOT/directory).iterdir() if p.is_file())
    selected.extend(ROOT/'fonts'/n for n in ['NotoSansSC-Regular.ttf','NotoSansSC-Bold.ttf','OFL.txt'])
    selected.append(ROOT/'preview/contact_sheet.jpg')
    manifest={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
              for p in sorted(set(selected))}
    zip_path=ROOT/'DisasterTrace_Presentation_20260908.zip'
    with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for rel in manifest:z.write(ROOT/rel,arcname='DisasterTrace_Presentation/'+rel)
        z.writestr('DisasterTrace_Presentation/CONTENTS_SHA256.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None
        for rel,entry in manifest.items():
            assert hashlib.sha256(z.read('DisasterTrace_Presentation/'+rel)).hexdigest()==entry['sha256']
    print(json.dumps({'package':str(zip_path),'members':len(manifest)+1,'bytes':zip_path.stat().st_size,
                      'snapshot_utc':D['snapshot_utc'],'status':'passed'}))


if __name__=='__main__':main()
