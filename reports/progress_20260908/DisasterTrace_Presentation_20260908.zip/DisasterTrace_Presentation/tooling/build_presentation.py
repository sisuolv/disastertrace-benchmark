"""Build an editable deck, charts and a PDF/PNG preview from a shared scene."""

from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Inches, Pt
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

from content import SLIDES, REFERENCES

ROOT = Path(__file__).resolve().parents[1]
D = json.loads((ROOT / 'report_data.json').read_text())
PROJECT = Path(D['project_root'])
W, H = 1600, 900
BG, INK, TEAL, RUST, MUTED, RULE = '#F5F3ED', '#19313C', '#147D78', '#C45F43', '#627077', '#D7DEDB'
GOLD, WHITE, PALE = '#B58A2B', '#FFFFFF', '#E5EFEB'
COLORS = [TEAL, '#375A77', RUST]
METHODS = D['method_order']
METHOD_LABELS = ['snapshot', 'structured_state', 'answer_history']
FONTS = {False: ROOT / 'fonts/NotoSansSC-Regular.ttf', True: ROOT / 'fonts/NotoSansSC-Bold.ttf'}
STAMP = D['snapshot_utc'].replace('T', ' ').replace('+00:00', ' UTC')
SCENES = []


@lru_cache(maxsize=128)
def font(size, bold=False):
    return ImageFont.truetype(str(FONTS[bold]), int(size))


def wrapped(text, width, size, bold=False):
    result = []
    face = font(size, bold)
    for paragraph in text.split('\n'):
        line = ''
        for char in paragraph:
            if line and face.getlength(line + char) > width:
                result.append(line.rstrip())
                line = char.lstrip()
            else:
                line += char
        result.append(line.rstrip())
    return result


class Scene:
    def __init__(self, meta, index):
        self.meta, self.index, self.items = meta, index, []
        self.rect(0, 0, W, H, BG)
        self.rect(0, 0, 15, H, TEAL)
        if meta['kind'] != 'cover':
            self.text(70, 32, 1450, 30, 'DISASTERTRACE  /  RESEARCH PROGRESS  /  2026.09', 18, TEAL, True)
            title_size = 46 if len(meta['title']) < 34 else 41
            self.text(70, 91, 1460, 118, meta['title'], title_size, INK, True)
            self.text(70, 211, 1460, 68, meta['subtitle'], 25, MUTED)
        self.rect(70, 810, 1460, 2, RULE)
        self.text(70, 835, 960, 35, f"{meta['refs']}  |  证据索引见讲稿", 18, MUTED)
        self.text(1040, 835, 420, 35, STAMP, 17, MUTED)
        self.text(1480, 832, 65, 40, f'{index:02d}', 25, TEAL, True)

    def rect(self, x, y, w, h, fill, line=None, radius=False):
        self.items.append(dict(type='rect', x=x, y=y, w=w, h=h, fill=fill, line=line, radius=radius))

    def text(self, x, y, w, h, text, size=31, color=INK, bold=False, align='left'):
        lines = wrapped(str(text), w, size, bold)
        line_h = size * 1.32
        if len(lines) * line_h > h + 2:
            raise ValueError(f'Slide {self.index}: text overflows: {text!r}; lines={len(lines)}, box={h}')
        self.items.append(dict(type='text', x=x, y=y, w=w, h=h, text=str(text), lines=lines,
                               size=size, color=color, bold=bold, align=align, line_h=line_h))

    def image(self, x, y, w, h, path):
        self.items.append(dict(type='image', x=x, y=y, w=w, h=h, path=str(path)))

    def card(self, x, y, w, h, tag, title, body, accent=TEAL, title_size=34, body_size=28):
        self.rect(x, y, w, h, WHITE)
        self.rect(x, y, 6, h, accent)
        self.text(x+25, y+20, w-50, 42, tag, 21, accent, True)
        self.text(x+25, y+77, w-50, 103, title, title_size, INK, True)
        self.text(x+25, y+196, w-50, h-204, body, body_size, MUTED)

    def band(self, text, y=736, color=TEAL, fill=PALE, size=28):
        self.rect(70, y, 1460, 60, fill)
        self.text(89, y+11, 1420, 46, text, size, color, True)

    def table(self, headers, rows, x=70, y=292, widths=None, row_h=65, size=27):
        widths = widths or [1460 / len(headers)] * len(headers)
        offset = x
        for header, width in zip(headers, widths):
            self.rect(offset, y, width, row_h, INK)
            self.text(offset+15, y+12, width-30, row_h-12, header, size-1, WHITE, True)
            offset += width
        for ri, row in enumerate(rows):
            offset = x
            for ci, (value, width) in enumerate(zip(row, widths)):
                self.rect(offset, y+(ri+1)*row_h, width, row_h-1, WHITE if ri%2==0 else '#ECEFEA')
                self.text(offset+15, y+(ri+1)*row_h+12, width-30, row_h-12, value, size, TEAL if ci==0 else INK, ci==0)
                offset += width


def savefig(fig, name):
    for suffix in ['png', 'svg', 'pdf']:
        fig.savefig(ROOT / 'charts' / f'{name}.{suffix}', dpi=180, bbox_inches='tight', facecolor=BG)
    plt.close(fig)


def charts():
    for file in FONTS.values():
        font_manager.fontManager.addfont(str(file))
    family = font_manager.FontProperties(fname=FONTS[False]).get_name()
    plt.rcParams.update({'font.family': family, 'font.size': 14, 'axes.unicode_minus': False,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'axes.spines.left': False, 'axes.edgecolor': RULE,
                         'text.color': INK, 'axes.labelcolor': INK, 'xtick.color': MUTED,
                         'ytick.color': MUTED, 'figure.facecolor': BG, 'axes.facecolor': BG})
    fig, axes = plt.subplots(1, 2, figsize=(14, 4.7))
    for ax, key, title in zip(axes, ['schema_valid', 'all_correct'], ['输出契约合法率', '完整正确率']):
        x = np.arange(3)
        for offset, phase, color, label in [(-.19, 'P3', RUST, 'P3 自由输出'), (.19, 'P4', TEAL, 'P4 结构约束')]:
            values = [D['measured'][phase]['methods'][m][key] for m in METHODS]
            bars = ax.bar(x+offset, np.array(values)/180*100, .34, color=color, label=label, zorder=3)
            for b, val in zip(bars, values):
                ax.text(b.get_x()+b.get_width()/2, b.get_height()+2, f'{val}/180', ha='center', fontsize=12)
        ax.set_xticks(x, ['snapshot', 'structured\nstate', 'answer\nhistory'])
        ax.set_ylim(0, 118); ax.set_yticks([0,25,50,75,100], ['0%','25%','50%','75%','100%'])
        ax.set_title(title, loc='left', fontsize=19, pad=15)
        ax.grid(axis='y', color=RULE, zorder=0)
        ax.tick_params(axis='both', length=0)
    axes[0].legend(loc='upper left', bbox_to_anchor=(0, -0.2), ncol=2, frameon=False, fontsize=13)
    fig.subplots_adjust(wspace=.22, bottom=.22)
    savefig(fig, 'p3_p4')

    cmap = LinearSegmentedColormap.from_list('weather_teal', ['#F0E5D0', '#D9E8DF', '#75AAA0', '#146B69'])
    labels = ['P4 基础任务', 'P5 修订链', 'P5 无关作用域', 'P5 旧记录重放']
    phases = ['P4', 'revision_chain', 'irrelevant_scope', 'late_stale_replay']
    vals = np.array([[D['measured'][p]['methods'][m]['all_correct'] for m in METHODS] for p in phases])
    fig, ax = plt.subplots(figsize=(13.5, 4.3))
    im = ax.imshow(vals/180*100, cmap=cmap, vmin=0, vmax=100, aspect='auto')
    ax.set_xticks(range(3), METHOD_LABELS, fontsize=16)
    ax.xaxis.tick_top(); ax.tick_params(axis='both', length=0, pad=15)
    ax.set_yticks(range(4), labels, fontsize=16)
    for i in range(4):
        for j in range(3):
            ax.text(j, i, f'{vals[i,j]}/180   ·   {vals[i,j]/180*100:.2f}%', ha='center', va='center', color=WHITE, fontsize=17)
    for spine in ax.spines.values(): spine.set_visible(False)
    ax.set_xticks(np.arange(-.5,3,1), minor=True); ax.set_yticks(np.arange(-.5,4,1), minor=True)
    ax.grid(which='minor', color=BG, linewidth=5); ax.tick_params(which='minor', length=0)
    cbar = fig.colorbar(im, ax=ax, fraction=.024, pad=.03)
    cbar.set_ticks([0,50,100], labels=['0%','50%','100%']); cbar.outline.set_visible(False)
    savefig(fig, 'p5_scores')

    names = {
        'superseded_same_value': '同值旧版本', 'unknown_record_id': '未知记录 ID',
        'wrong_valid_window_or_measurement_kind': '错误有效窗口 / 测量类型',
        'wrong_variable_or_unit': '错误变量 / 单位', 'superseded_different_value': '异值旧版本',
        'out_of_bounds_line': '越界行号', 'wrong_entity': '错误实体',
    }
    items = sorted(D['citation_taxonomy'].items(), key=lambda kv:-kv[1])
    fig, ax = plt.subplots(figsize=(13, 4.4))
    values = [v for k,v in items]
    bars=ax.barh(np.arange(7), values, color=[TEAL]+[MUTED]*6, height=.65)
    ax.set_yticks(np.arange(7), [names[k] for k,v in items], fontsize=15)
    for b,val in zip(bars,values):
        ax.text(val+1.5,b.get_y()+b.get_height()/2,f'{val}  ({val/230*100:.2f}%)',va='center',fontsize=14)
    ax.set_xlim(0,139);ax.invert_yaxis();ax.set_xticks([0,25,50,75,100,125])
    ax.set_xlabel('纯引用错误字段数；合计 230',fontsize=14)
    ax.grid(axis='x',color=RULE,zorder=0);ax.set_axisbelow(True);ax.tick_params(length=0)
    savefig(fig,'citation_taxonomy')


def completed_rows():
    er = D['early_runs']
    p1full = sum(v['metrics']['all_correct_checkpoints']['numerator'] for v in er['P1']['methods'].values())
    rows = [['P1', 'DeepSeek', '公告轨 / 4,096', '90', '68', str(p1full)]]
    for arm, short in [('legacy_4096','旧说明 4,096'),('explicit_4096','明确说明 4,096'),('explicit_8192','明确说明 8,192')]:
        cells = [v for v in er['T6']['cell_counts'] if v['cell_id'].startswith(arm+'__')]
        valid = sum(v['schema_valid'] for v in cells)
        full = sum(v['all_correct_checkpoints']['numerator'] for k,v in er['T6']['metrics'].items() if k.startswith(arm+'__'))
        rows.append(['T6', 'DeepSeek', short, '90', str(valid), str(full)])
    for phase in ['P2_v1','P2_v2']:
        obj = er[phase]
        rows.append([phase.replace('_',' '),'DeepSeek','受控任务 / 18 ep.','270',str(obj['contract_valid']),str(obj['all_correct'])])
    for phase,label in [('P3','平衡 / 自由输出'),('P4','平衡 / 结构约束')]:
        obj=D['measured'][phase]
        rows.append([phase,'Qwen3-8B',label,'540',str(obj['contract_valid']),str(obj['all_correct'])])
    for f,label in [('revision_chain','修订链'),('irrelevant_scope','无关作用域'),('late_stale_replay','旧记录重放')]:
        obj=D['measured'][f]
        rows.append(['P5','Qwen3-8B',label,'540',str(obj['contract_valid']),str(obj['all_correct'])])
    return rows


def build_scene(meta, index):
    s=Scene(meta,index); kind=meta['kind']
    if kind=='cover':
        s.rect(1100,0,500,810,INK)
        for y in range(75,760,85):s.rect(1140,y,410,2,'#3B535C')
        s.text(77,78,960,60,meta['kicker'],28,TEAL,True)
        s.text(70,217,1030,157,'DisasterTrace',104,INK,True)
        s.text(78,418,950,165,'天气证据更新中的\nLLM 可靠性评测',52,INK,True)
        s.text(80,655,960,90,'从运行结果出发，解释每一次迭代',33,MUTED)
        s.text(1140,161,395,75,'P5  已完成',43,WHITE,True)
        s.text(1140,260,390,160,'1,620 条真实回答\n83.95% 完整正确',31,WHITE)
        s.text(1140,463,395,75,'P6  运行中',43,'#85C7BB',True)
        s.text(1140,563,385,150,'2,160 槽位\n配对重复实验',31,WHITE)
    elif kind=='overview':
        s.card(70,292,465,356,'已完成 · P5','1,620 条回答','三因素压力评测\n全部契约合法\n1,360 条完整正确')
        s.card(558,292,465,356,'已发现 · P6 归因','230 处纯引用错误','其中 109 处为同值旧版本\n值正确仍可能引用失效',RUST)
        s.card(1046,292,484,356,'正在运行 · P6','2,160 个机会','base / scope × 2 repeats\n统一完整 H100 配对执行',GOLD)
        s.band('独立气象来源仍为 3 个风暴；生成变体、方法与重复不增加事件数。')
    elif kind=='task':
        s.table(['任务族','关键变化','要检查的行为'],[
            ['U1 局部更新','只 PATCH 部分字段','更新目标；保留其余；刷新引用'],
            ['U2 同窗口修订','修订 / 其他窗口 / 旧版重放','区分事实键；保持当前版本'],
            ['U3 支持恢复','目标证据暂缺，之后交付','unknown → known；有据才回答'],
        ],widths=[310,440,710],row_h=84,size=29)
        s.text(80,655,1450,67,'3 来源 × 3 任务族 × 2 case × 2 branch = 36 episode；每条 5 个 checkpoint',30,INK,True)
        s.band('初始值来自真实 NHC；后续更新与交付是明确标注的受控构造。')
    elif kind=='methods':
        s.table(['方法','公共证据','额外载体'],[
            ['snapshot','截至当前的累计记录','无历史答案'],
            ['structured_state','同一累计记录','上一份结构合法的完整答案'],
            ['answer_history','同一累计记录','此前全部结构合法答案'],
        ],widths=[390,430,640],row_h=91,size=29)
        s.text(80,688,1440,46,'合法但错误的答案原样传播；无效答案计失败，不能用 Gold 修复载体。',29,MUTED)
        s.band('当前比较的是显式答案载体，不直接识别模型内部长期记忆。')
    elif kind=='pipeline':
        nodes=[('受控事件','私有编译器','得到逐检查点 Gold'),('公开文本','独立 public oracle','验证输入可推出答案'),('真实回答','严格 scorer','值 / 状态 / 引用 / 动作'),('原始记录','独立 auditor','CPU 重算与身份核对')]
        for j,(tag,title,body) in enumerate(nodes):
            x=70+j*370;s.rect(x,321,350,304,WHITE)
            s.text(x+20,344,310,42,tag,24,TEAL,True)
            s.text(x+20,415,310,112,title,34,INK,True)
            s.text(x+20,549,310,65,body,24,MUTED)
        s.text(82,659,1430,71,'known：正确数值 + 当前版本来源；unknown：null + 空引用；失败保留原分母。',30,INK)
        s.band('不新增逐题人工标注，不使用 LLM judge；仍需检查共同语义假设。')
    elif kind=='timeline':
        items=[('P1 → T6','输出交付失败','校准公共说明与 token 上限'),('P2 v1 → v2','契约仍有歧义','统一输出契约；270/270 全对'),('P3 → P4','平衡任务仍受格式干扰','独立建立结构约束轨'),('P5','合法后仍有语义错误','三因素压力；定位来源错误'),('P6 离线','分差解释有混杂','曝光审计、简单基线、错误归因'),('P6 实测','可靠性仍需重复验证','同硬件、配对种子、两次重复')]
        for j,(tag,title,body) in enumerate(items):
            x=70+(j%3)*497;y=288+(j//3)*224
            s.rect(x,y,466,204,WHITE);s.text(x+21,y+15,424,47,tag,29,TEAL,True)
            s.text(x+21,y+69,424,45,title,29,INK,True)
            s.text(x+21,y+131,424,67,body,25,MUTED)
        s.band('新协议回答新问题；不同版本的分数不能画成模型能力单调上升曲线。')
    elif kind=='calibration':
        s.text(76,292,1450,63,'P1：90 个回答，68 个合法；22 个失败中 20 个达到输出上限。',31,INK,True)
        t6=D['early_runs']['T6'];rows=[]
        for arm, label in [('legacy_4096','原说明 / 4096'),('explicit_4096','明确说明 / 4096'),('explicit_8192','明确说明 / 8192')]:
            cells={c['cell_id']:c for c in t6['cell_counts']}
            rows.append([label]+[f"{cells[arm+'__'+m]['schema_valid']}/30" for m in METHODS])
        s.table(['T6 条件','snapshot','structured_state','answer_history'],rows,y=380,widths=[410,280,395,375],row_h=74,size=26)
        s.band('每条件 90 条，三条件共 270 条；8,192 是预定格式门槛下的共同选择。')
    elif kind=='p2':
        a,b=D['early_runs']['P2_v1'],D['early_runs']['P2_v2']
        s.table(['条件','收到 / 计划','契约合法','完整正确'],[
            ['P2 v1','270 / 270',f"{a['contract_valid']} / 270",f"{a['all_correct']} / 270"],
            ['P2 v2','270 / 270',f"{b['contract_valid']} / 270",f"{b['all_correct']} / 270"],
        ],widths=[350,370,370,370],row_h=92,size=32)
        s.text(89,607,1420,98,'变化：共同输出说明明确 state / action / record_id / ASSERT 行引用。\n结果：小型受控矩阵全对，下一轮需要平衡情形与扩展模型覆盖。',30,INK)
        s.band('v1 的 6 个无效回答 + 3 处引用错误 → 8 个错误 checkpoint，不能直接相加。')
    elif kind=='chart':
        if meta['chart']=='citation_taxonomy':
            s.image(125,280,1370,444,ROOT/'charts/citation_taxonomy.png')
            s.band('109 / 230 = 47.39% 为同值旧版本；29 个动作错误与风速错误重叠。')
        elif meta['chart']=='p5_scores':
            s.image(80,288,1430,414,ROOT/'charts/p5_scores.png')
            s.band('P5 合计 1,360 / 1,620 = 83.95%；scope 下 snapshot 与结构状态只差 1 题。')
        else:
            s.image(80,275,1430,430,ROOT/'charts/p3_p4.png')
            s.band('P4 全部格式合法，仍有 15 处值/状态错误 + 39 处引用错误。')
    elif kind=='stress':
        items=[('01 / revision_chain','修订链','增加中间修订\n30 个 episode 从 c2 暴露\n6 个无新增压力保留'),('02 / irrelevant_scope','无关作用域','其他实体 / 有效窗口\n36 个 episode 从 c2 暴露\n目标 Gold 不变'),('03 / late_stale_replay','旧记录重放','旧记录更晚送达\n36 个 episode 到 c4 暴露\n旧版本不恢复权威性')]
        for j,(tag,title,body) in enumerate(items):s.card(70+j*497,297,466,385,tag,title,body,[TEAL,RUST,GOLD][j],34,26)
        s.band('三组各 540 条，共 1,620；保留完整 8,192 输出预算，不截断后混入结果。')
    elif kind=='example':
        s.rect(70,295,697,325,WHITE);s.rect(795,295,735,325,WHITE)
        s.text(100,322,630,48,'实际模型回答',28,RUST,True)
        s.text(823,322,670,48,'当前正确依据',28,TEAL,True)
        s.text(100,392,630,118,'60 mph',80,INK,True);s.text(825,392,660,118,'60 mph',80,INK,True)
        s.text(100,530,630,72,'record-62dacf3b…  /  line 2\n已被替代的同值旧版本',25,RUST)
        s.text(825,530,660,72,'record-0db797c9…  /  line 2\n当前权威版本',25,TEAL)
        s.text(95,655,1430,53,'数值评分：正确。当前版本来源评分：错误。',36,INK,True)
        s.band('记录 ID 为展示缩写；完整 ID 和原始样例出处保留在详细文档中。')
    elif kind=='solver':
        s.table(['公开程序策略','Base','Revision','Scope','Stale'],[
            ['initial_only','90','90','90','90'],
            ['scope_blind_last_delivered','132','132','78','138'],
            ['latest_issued_per_key','180','180','180','180'],
            ['public_oracle','180','180','180','180'],
        ],widths=[610,210,220,210,210],row_h=77,size=27)
        s.band('每格 /180。当前域限制为合法线性版本链；复杂图推理必要性尚未建立。')
    elif kind=='paired':
        s.rect(70,289,1460,78,INK)
        s.text(100,307,1400,54,'2 conditions × 36 episode × 5 checkpoint × 3 methods × 2 repeats = 2,160',31,WHITE,True)
        s.card(70,396,704,294,'配对设计','base  ↔  scope level 4','同硬件、同设置、条件间匹配 seed\n条件顺序平衡；载体分别演化',TEAL,35,27)
        s.card(802,396,728,294,'可靠性指标','单次正确  →  全程稳定','保留双向变化与四种成对结局\nepisode success / pass^2 / 来源与重复范围',RUST,35,26)
        s.band('432 条运行轨迹，1,080 对条件机会；2 次重复不等于更多独立风暴。')
    elif kind=='status':
        saved=D['p6_status'].get('parsed_records',0)
        s.text(83,298,1440,65,STAMP,32,MUTED)
        s.text(75,391,1150,126,f'{saved:,} / 2,160',87,TEAL,True)
        s.text(1118,416,391,72,f'{saved/2160*100:.1f}% 已保存',34,INK,True)
        s.rect(80,544,1440,28,RULE);s.rect(80,544,1440*min(saved/2160,1),28,TEAL)
        s.text(83,608,1420,94,'作业 pt-gxxtikov · 一张完整 H100 · 已安排自动审计与 CPU 后处理\n离线正确/无效对照共 4,320 条程序回答，单独用于软件验证。',29,INK)
        s.band('此页不报告 P6 临时能力分数；保存完成仍需最终作业状态与独立验收。')
    elif kind=='forecast':
        s.card(70,294,465,394,'已准备的来源范围','最多 12 份正文','Francine 005–010\nIda 009–014\n双解析；不一致自动隔离',TEAL,34,28)
        s.card(558,294,465,394,'下一版核心查询','同一绝对有效时刻','哪份可见公告明确覆盖？\n预报值 / 单位是什么？\n当前依据在哪些原文行？',RUST,32,28)
        s.card(1046,294,484,394,'保持时间与任务边界','分开记录四种时间','issued / valid / retrieved\n受控 delivery 另行记录\n历史首次公开时间不编造',GOLD,32,26)
        s.band('模型使用官方已发布预报；新的 forecast-claim 任务尚待离线构建与验收。')
    elif kind=='roadmap':
        rows=[['1','P6 收尾','完整报告、双向配对、pass^2、CPU 迁移验收'],['2','原生预报轨','双解析准入 → 同绝对时刻任务 → 独立 Gold / scorer'],['3','载体表示对照','同一保存答案的 JSON / 文本；信息可逆、长度可测'],['4','同协议第二模型','先固定任务与预算，再做实际后端和硬件预检'],['5','扩展独立来源','扩大开发事件；冻结后再测全部受保护 heldout 范围']]
        s.table(['顺序','交付物','完成门槛'],rows,widths=[120,400,940],row_h=71,size=26)
        s.band('优先增加结论的可解释性与来源覆盖；新增模板数不等于新增独立事件。')
    elif kind=='limitations':
        s.table(['已经支持','仍需验证'],[
            ['自动评分与可复查的真实采集闭环','真实原文的自动 Gold 语义与歧义处理'],
            ['格式合法后仍有值和当前引用错误','配对重复后的稳定程度与来源差异'],
            ['受控天气记录中的显式状态维护','真实预报、多事件、多模型外部有效性'],
            ['不同答案载体下的描述性差异','等信息 / 等长度表示与内部记忆机制'],
        ],widths=[740,720],row_h=83,size=27)
        s.band('定位：研究中的动态天气证据 benchmark；广域极端天气排行榜尚未建立。')
    elif kind=='closing':
        lines=[('01','已建立评测闭环','自动 Gold、真实采集、固定分母与离线重算。'),('02','已找到明确失败模式','P5 全部契约合法，仍有 90 处值错与 230 处引用错。'),('03','下一轮有可检验目标','配对可靠性 → 官方预报版本 → 同协议模型与来源扩展。')]
        for j,(tag,title,body) in enumerate(lines):
            y=298+j*145;s.text(81,y,116,80,tag,58,TEAL,True)
            s.text(234,y+1,1270,68,title,41,INK,True);s.text(236,y+72,1270,60,body,29,MUTED)
    elif kind=='appendix_runs':
        s.table(['阶段','模型','任务 / 条件','收到','合法','全对'],completed_rows(),y=278,
                widths=[170,235,460,180,190,225],row_h=40,size=22)
        s.text(83,772,1430,32,'P1 为 90 回答 / 91 尝试；P6 2,160 槽位正在运行，未纳入已完成表。',21,MUTED)
    elif kind=='appendix_metrics':
        s.table(['指标','严格含义'],[
            ['契约合法','原任务结构与数值契约通过；仍可能内容错误'],
            ['完整正确 checkpoint','四字段状态、值、当前引用与动作全部正确'],
            ['episode success','单次 episode 的 5 个 checkpoint 全部正确'],
            ['pass^2（R=2）','同一条件 / 方法 / episode 的两次运行都全程成功'],
            ['错误守恒','90 + 230 = 320 字段错误；落在 260 个错误 checkpoint'],
        ],widths=[470,990],row_h=72,size=27)
        s.band('c0 的 324/324 全对单独披露；c1–c4 的 1,036/1,296 不替换主分母。')
    elif kind=='appendix_audit':
        s.table(['材料','已记录的完成证据'],[
            ['P5 实际运行','3 个 ACP 作业成功；9 个 collect / report / verify 子进程退出 0'],
            ['P5 输出约束','432,742 个 final/EOS token 重放，无 grammar 违规'],
            ['P4/P5 CPU 迁移','屏蔽原资料、权重与网络；无需 Torch / vLLM 重建报告'],
            ['P6 离线程序验收','正确 2,160；无效对照 1,728 全对 + 432 无效保留'],
            ['GitHub 已发布 P5','私有 next-phase-v1；dd5ee358f970；P6 本地记录更新'],
        ],widths=[385,1075],row_h=72,size=26)
        s.band('测试执行含重叠，不累加成独立测试或模型样本；未声称 GitHub Actions 已运行。')
    elif kind=='appendix_related':
        s.table(['参考','采纳的设计方向'],[
            ['ALCE','将数值正确与引用支持分开测量'],
            ['CheckList','最小功能、不变量与方向性测试；纯程序性质验证'],
            ['tau-bench','整条 episode 成功率与多次运行 pass^k'],
            ['RULER / MemoryAgentBench','区分长度、信息预算与增量观察协议'],
            ['STATE-Bench / STALE','显式状态、来源版本与历史载体的边界'],
            ['ExtremeWeatherBench / NHC','独立天气事件；预报目标与观测、来源时间分开'],
        ],widths=[520,940],row_h=62,size=26)
        s.band('本轮为提供方案中的设计参考；不等同于下载、运行或复现全部上游 benchmark。')
    else:
        raise ValueError(kind)
    return s


def render_png(scene, output):
    im=Image.new('RGB',(W,H),BG);draw=ImageDraw.Draw(im)
    for e in scene.items:
        x,y,w,h=e['x'],e['y'],e['w'],e['h']
        if e['type']=='rect':draw.rectangle((x,y,x+w,y+h),fill=e['fill'],outline=e['line'])
        elif e['type']=='image':
            img=Image.open(e['path']).convert('RGB').resize((round(w),round(h)),Image.Resampling.LANCZOS)
            im.paste(img,(round(x),round(y)))
        else:
            for j,line in enumerate(e['lines']):
                draw.text((x,y+j*e['line_h']),line,font=font(e['size'],e['bold']),fill=e['color'],anchor='lt')
    im.save(output)


def render_pdf(scenes, path):
    for bold,p in FONTS.items():pdfmetrics.registerFont(TTFont('NotoBold' if bold else 'NotoRegular',str(p)))
    c=canvas.Canvas(str(path),pagesize=(960,540))
    c.setTitle('DisasterTrace - 研究进展与迭代逻辑');c.setAuthor('DisasterTrace project')
    for s in scenes:
        c.saveState();c.scale(.6,.6)
        for e in s.items:
            x,y,w,h=e['x'],e['y'],e['w'],e['h']
            if e['type']=='rect':
                c.setFillColor(e['fill']);c.rect(x,H-y-h,w,h,stroke=0,fill=1)
            elif e['type']=='image':c.drawImage(e['path'],x,H-y-h,w,h,mask='auto')
            else:
                name='NotoBold' if e['bold'] else 'NotoRegular'
                c.setFont(name,e['size']);c.setFillColor(e['color'])
                ascent=pdfmetrics.getAscent(name)/1000*e['size']
                for j,line in enumerate(e['lines']):c.drawString(x,H-y-ascent-j*e['line_h'],line)
        c.restoreState();c.showPage()
    c.save()


def rgb(value):return RGBColor.from_string(value.lstrip('#'))


def render_pptx(scenes,path):
    p=Presentation();p.slide_width=Inches(13.333333);p.slide_height=Inches(7.5)
    p.core_properties.title='DisasterTrace：最新进展与迭代逻辑'
    p.core_properties.subject='天气证据更新中的 LLM 可靠性评测'
    p.core_properties.author='DisasterTrace project'
    px=lambda n: Inches(n/120)
    for s in scenes:
        slide=p.slides.add_slide(p.slide_layouts[6])
        for e in s.items:
            x,y,w,h=[px(e[k]) for k in ['x','y','w','h']]
            if e['type']=='rect':
                sh=slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,x,y,w,h)
                sh.fill.solid();sh.fill.fore_color.rgb=rgb(e['fill']);sh.line.fill.background()
            elif e['type']=='image':slide.shapes.add_picture(e['path'],x,y,width=w,height=h)
            else:
                sh=slide.shapes.add_textbox(x,y,w,h);tf=sh.text_frame
                tf.clear();tf.word_wrap=False;tf.margin_left=0;tf.margin_right=0;tf.margin_top=0;tf.margin_bottom=0
                tf.vertical_anchor=MSO_ANCHOR.TOP
                for j,line in enumerate(e['lines']):
                    para=tf.paragraphs[0] if j==0 else tf.add_paragraph()
                    para.space_before=Pt(0);para.space_after=Pt(0);para.line_spacing=Pt(e['line_h']*.6)
                    run=para.add_run();run.text=line
                    run.font.name='Noto Sans SC';run.font.size=Pt(e['size']*.6);run.font.bold=e['bold'];run.font.color.rgb=rgb(e['color'])
                    rpr=run._r.get_or_add_rPr();ea=OxmlElement('a:ea');ea.set('typeface','Noto Sans SC');rpr.append(ea)
        text=s.meta['notes']+'\n\n状态快照：'+STAMP+'\n建议时长：'+str(s.meta['seconds'])+' 秒\n证据：'+s.meta['refs']
        slide.notes_slide.notes_text_frame.text=text
    p.save(path)


def validate(scenes,pptx_path):
    issues=[]
    for s in scenes:
        for e in s.items:
            if min(e['x'],e['y'],e['w'],e['h'])<0 or e['x']+e['w']>W+.1 or e['y']+e['h']>H+.1:
                issues.append({'slide':s.index,'issue':'out_of_bounds','element':e['type']})
    with zipfile.ZipFile(pptx_path) as z:
        from lxml import etree
        xmls=[n for n in z.namelist() if n.endswith('.xml')]
        for n in xmls:etree.fromstring(z.read(n))
        assert len([n for n in z.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')])==len(scenes)
    reopened=Presentation(pptx_path)
    assert len(reopened.slides)==len(scenes)
    assert all(sl.has_notes_slide for sl in reopened.slides)
    corpus=''.join(e['text'] for s in scenes for e in s.items if e['type']=='text')
    from fontTools.ttLib import TTFont as FTFont
    cmap=FTFont(FONTS[False]).getBestCmap()
    missing=sorted(set(ch for ch in corpus if not ch.isspace() and ord(ch) not in cmap))
    if missing:issues.append({'issue':'missing_glyphs','characters':missing})
    assert not issues,issues
    (ROOT/'evidence/presentation_validation.json').write_text(json.dumps({
        'status':'passed','slide_count':len(scenes),'main_slides':20,'appendix_slides':4,
        'planned_speaking_seconds':sum(s.meta['seconds'] for s in scenes),
        'checks':['data conservation and exact table assertions','all XML parses','PPTX reopens',
                  'all slides have notes','all elements within canvas','CJK font glyph coverage'],
        'rendering_note':'PNG and PDF are rendered from the same scene using Pillow/ReportLab; no PowerPoint/LibreOffice rendering was performed.',
        'snapshot_utc':D['snapshot_utc'],
    },ensure_ascii=False,indent=2)+'\n')


def write_speaker_notes(scenes):
    lines=['# DisasterTrace 汇报讲稿','',f'状态快照：{STAMP}。20 页主讲 + 4 页附录，建议约 18–20 分钟。',
           '', '本讲稿同时嵌入 PowerPoint 备注。各阶段以实际结果和冻结协议为准；P6 正在运行。','']
    elapsed=0
    for s in scenes:
        seconds=s.meta['seconds']
        lines += [f"## {s.index:02d}｜{s.meta['title']}",'',
                  f'建议时长：{seconds} 秒；主讲累计 {elapsed//60:02d}:{elapsed%60:02d}。' if seconds else '附录：按提问选讲。','',s.meta['notes'],'',
                  f"证据：{s.meta['refs']}。",'']
        elapsed+=seconds
    lines += ['## 证据索引','', '机器报告的数据与 SHA-256 清单另见 `report_data.json` 和 `evidence/source_index.json`。','']
    for key,(title,relative) in REFERENCES.items():
        path=(PROJECT/relative).resolve()
        lines.append(f'- {key}：[{title}]({path})')
    (ROOT/'SPEAKER_NOTES.md').write_text('\n'.join(lines)+'\n')


def main():
    charts()
    for i,meta in enumerate(deepcopy(SLIDES),1):
        scene=build_scene(meta,i);SCENES.append(scene)
        render_png(scene,ROOT/'preview'/f'slide_{i:02d}.png')
    render_pdf(SCENES,ROOT/'DisasterTrace_Progress_20260908.pdf')
    render_pptx(SCENES,ROOT/'DisasterTrace_Progress_20260908.pptx')
    validate(SCENES,ROOT/'DisasterTrace_Progress_20260908.pptx')
    write_speaker_notes(SCENES)
    thumbs=Image.new('RGB',(1200, int(np.ceil(len(SCENES)/3))*240),'#DCE1DC')
    for i,s in enumerate(SCENES):
        im=Image.open(ROOT/'preview'/f'slide_{s.index:02d}.png').resize((384,216),Image.Resampling.LANCZOS)
        thumbs.paste(im,(8+(i%3)*400,8+(i//3)*240))
    thumbs.save(ROOT/'preview/contact_sheet.jpg',quality=90)
    print(json.dumps({'slides':len(SCENES),'snapshot':STAMP,'status':'built_and_validated'}))


if __name__=='__main__':main()
