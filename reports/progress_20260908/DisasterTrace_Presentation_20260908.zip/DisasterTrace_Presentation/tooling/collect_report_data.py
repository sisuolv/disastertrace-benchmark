"""Read existing evidence and create a timestamped reporting snapshot only."""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

from content import REFERENCES

OUT = Path(__file__).resolve().parents[1]
REPO = Path('/mnt/afs/260010168/extreme_weather_benchmark/development/disastertrace-next')
PROJECT = REPO / 'disastertrace-starter'
SOURCES = []


def read(path):
    path = Path(path)
    raw = path.read_bytes()
    SOURCES.append({'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
    return json.loads(raw) if path.suffix == '.json' else raw.decode('utf-8')


def report(label, relative):
    obj = read(PROJECT / relative)
    methods = {}
    for method, entry in obj['methods'].items():
        c = entry['counts']
        methods[method] = {k: c[k] for k in [
            'checkpoints', 'all_correct', 'schema_valid', 'known', 'known_value_correct',
            'known_grounded_correct', 'unknown', 'unknown_correct', 'action_correct',
        ]}
        assert c['all_correct'] <= c['schema_valid'] <= c['checkpoints']
    return {
        'phase': label, 'source': str(PROJECT / relative), 'planned': obj['planned'],
        'received': obj['received'], 'complete': obj['complete'],
        'execution_id': obj['execution_id'], 'methods': methods,
        'field_errors': dict(Counter(x['reason'] for x in obj['errors']['fields'])),
        'action_errors': len(obj['errors']['actions']),
        'all_correct': sum(m['all_correct'] for m in methods.values()),
        'contract_valid': sum(m['schema_valid'] for m in methods.values()),
        'format_screens_passed': sum(c['passed'] for c in obj['reliability']['cells']),
        'format_screens_total': len(obj['reliability']['cells']),
    }


def main():
    measured = {
        'P3': report('P3', 'artifacts/p3_local_balanced_v1/model_report/report.json'),
        'P4': report('P4', 'artifacts/p4_constrained_output_v1/model_report/report.json'),
    }
    factors = ['revision_chain', 'irrelevant_scope', 'late_stale_replay']
    for factor in factors:
        measured[factor] = report(factor, f'artifacts/p5_stress_level4_v1/units/{factor}/model_report/report.json')
    conservation = read(PROJECT / 'artifacts/p6_offline_v1/posthoc_final/conservation.json')
    shortcuts = read(PROJECT / 'artifacts/p6_offline_v1/posthoc_final/shortcut_scores.json')
    c = conservation['counts']
    assert sum(measured[f]['all_correct'] for f in factors) == c['all_correct'] == 1360
    assert sum(measured[f]['received'] for f in factors) == c['received'] == 1620
    assert sum(conservation['citation_only_primary'].values()) == c['citation_only_errors'] == 230
    assert c['value_status_errors'] + c['citation_only_errors'] == c['field_errors'] == 320
    assert c['action_errors'] == c['action_errors_overlapping_wind'] == 29
    assert c['incorrect_checkpoints'] + c['all_correct'] == c['planned_responses']
    for f in factors:
        assert measured[f]['complete'] and measured[f]['contract_valid'] == 540
    expected = {
        'P3': [75, 68, 50], 'P4': [167, 178, 145],
        'revision_chain': [150, 164, 135], 'irrelevant_scope': [155, 154, 135],
        'late_stale_replay': [163, 172, 132],
    }
    order = ['snapshot', 'structured_state', 'answer_history']
    for phase, values in expected.items():
        assert [measured[phase]['methods'][m]['all_correct'] for m in order] == values

    p1 = read(PROJECT / 'work/p1-deepseek-background-continuation-v1/report/report.json')
    t6 = read(PROJECT / 'artifacts/t6_deepseek_calibration_v1/runtime/report/report.json')
    early = {
        'P1': {
            'received': p1['provider_call_accounting']['benchmark_response_count'],
            'attempts': p1['provider_call_accounting']['cumulative_provider_calls_admitted'],
            'methods': {m: {'counts': v['v2']['counts'], 'metrics': v['v2']['metrics'],
                           'status_counts': v['status_counts']} for m, v in p1['methods'].items()},
        },
        'T6': {
            'received': t6['received'], 'selected_output_tokens': t6['selected_output_tokens'],
            'cell_counts': t6['cell_counts'],
            'metrics': {key: cell['metrics'] for key, cell in t6['cells'].items()},
        },
    }
    for label, directory in [('P2_v1', 'p2_deepseek_development_v1'), ('P2_v2', 'p2_deepseek_output_contract_v2')]:
        obj = read(PROJECT / f'artifacts/{directory}/runtime/report/report.json')
        early[label] = {
            'received': obj['received'], 'planned': obj['planned'], 'complete': obj['complete'],
            'methods': {m: {'counts': v['counts'], 'metrics': v['metrics']} for m, v in obj['methods'].items()},
            'all_correct': sum(v['counts']['all_correct'] for v in obj['methods'].values()),
            'contract_valid': sum(v['counts']['schema_valid'] for v in obj['methods'].values()),
        }
    assert early['P2_v1']['all_correct'] == 262
    assert early['P2_v2']['all_correct'] == 270
    assert early['P2_v1']['contract_valid'] == 264
    assert early['T6']['selected_output_tokens'] == 8192

    live = PROJECT / 'artifacts/p6_live_v1'
    status_cmd = ['python3', str(live / 'status.py')]
    status = json.loads(subprocess.check_output(status_cmd, cwd=PROJECT, text=True))
    at = datetime.now(timezone.utc).isoformat(timespec='seconds')
    optional = {}
    for key, path in {
        'finalization': live / 'finalization_001/result.json',
        'worker_result': live / 'acp/model/worker_result.json',
        'model_report': live / 'reports/model/report.json',
    }.items():
        optional[key] = {'exists': path.exists(), 'path': str(path)}
        if path.exists():
            obj = read(path)
            optional[key]['top_level_keys'] = list(obj)
            optional[key]['summary'] = {k: obj[k] for k in ['status', 'complete', 'planned', 'received', 'exit_code'] if k in obj}
    publication = read(REPO / 'review-outputs/p5-publication-20260908/publication_receipt.json')
    source_bundle = PROJECT / 'artifacts/nhc_forecast_source_v1'
    source_json_files = [str(p.relative_to(source_bundle)) for p in sorted(source_bundle.rglob('*.json'))]
    documents = [
        'CURRENT_PHASE.md', 'README_P6_OFFLINE_V1.md', 'REVIEW_FOR_CHATGPT_PRO_P5.md',
        'docs/P2_CONTROLLED_SEMANTICS_V1.md', 'docs/p6/UPSTREAM_REUSE.md',
        'docs/p6/SOLVER_EQUIVALENCE.md', 'docs/p6/MEASUREMENT_PROTOCOL.md',
        'docs/p6/CLAIM_AUDIT.md', 'artifacts/p5_stress_level4_v1/MODEL_FINDINGS.md',
        'README_P1_DEEPSEEK.md', 'README_T6_CALIBRATION_V1.md',
        'README_P2_DEEPSEEK_V1.md', 'README_P2_DEEPSEEK_OUTPUT_CONTRACT_V2.md',
        'artifacts/p6_offline_v1/actual_examples/EXAMPLES.md',
        'artifacts/p6_live_v1/CONTINUE.md', 'artifacts/p6_live_v1/NEXT_RESEARCH_PLAN.md',
        'artifacts/nhc_forecast_source_v1/PROTOCOL.md',
    ]
    for rel in documents:
        read(PROJECT / rel)
    seen = {entry['path'] for entry in SOURCES}
    for _, rel in REFERENCES.values():
        path = (PROJECT / rel).resolve()
        if str(path) not in seen:
            read(path)
            seen.add(str(path))
    read(PROJECT / 'artifacts/p6_live_v1/execution_live_02/execution.json')
    read(PROJECT / 'artifacts/nhc_forecast_source_v1/SOURCE_SCOPE.json')
    read(REPO / 'plans/INTEGRATED_P6_PLAN_V1.md')
    data = {
        'schema': 'disastertrace_presentation_snapshot_v1', 'snapshot_utc': at,
        'project_root': str(PROJECT), 'method_order': order, 'measured': measured,
        'early_runs': early,
        'p5_counts': c, 'citation_taxonomy': conservation['citation_only_primary'],
        'exposure_slices': conservation['exposure_slices'],
        'first_exposure_episodes': conservation['first_exposure_episodes'],
        'shortcuts': shortcuts, 'p6_status': status, 'p6_optional_artifacts': optional,
        'p6_status_command': status_cmd, 'nhc_source_json_inventory': source_json_files,
        'publication': {k: publication[k] for k in [
            'status', 'repository', 'branch', 'commit', 'commit_url', 'private', 'verified_at', 'hosted_ci_run',
        ]},
        'scope': 'Read-only reporting; no model generation or experiment finalization.',
    }
    (OUT / 'report_data.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'evidence/source_index.json').write_text(json.dumps({
        'snapshot_utc': at, 'files': SOURCES,
        'note': 'Hashes identify the evidence read for this report; they do not replace scientific audit.',
    }, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'evidence/p6_status_snapshot.json').write_text(json.dumps({'snapshot_utc': at, **status}, indent=2) + '\n')
    print(json.dumps({'snapshot_utc': at, 'p5_all_correct': c['all_correct'],
                      'p6_saved': status.get('parsed_records'), 'sources': len(SOURCES)}))


if __name__ == '__main__':
    main()
