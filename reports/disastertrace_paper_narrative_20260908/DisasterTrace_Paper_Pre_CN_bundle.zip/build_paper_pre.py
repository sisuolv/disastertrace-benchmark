"""Render the whole-benchmark argument as a vector Chinese presentation."""

import hashlib
import importlib.util
import json
from pathlib import Path

from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PRIOR = ROOT / "reports/progress_20260908_p6_complete"
PDF = OUT / "DisasterTrace_Paper_Pre_CN.pdf"
MD = OUT / "DisasterTrace_Paper_Storyline_CN.md"
FACTS = json.loads((OUT / "evidence/snapshot.json").read_text())


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


base = load_module("disastertrace_slide_primitives", PRIOR / "pdf_v1/build_pdf.py")
Slide = base.Slide
INK, TEAL, RUST, MUTED = base.INK, base.TEAL, base.RUST, base.MUTED
WHITE, PALE, RULE, BG = base.WHITE, base.PALE, base.RULE, base.BG
W, H = base.W, base.H


def slide(title, subtitle, source, appendix=False):
    return Slide(title, subtitle, source, appendix=appendix)


def arrow(s, x1, y1, x2, y2, color=MUTED):
    s.line(x1, y1, x2, y2, color, 1.8)
    if x1 == x2:
        sign = 1 if y2 > y1 else -1
        s.line(x2 - 5, y2 - sign * 7, x2, y2, color, 1.8)
        s.line(x2 + 5, y2 - sign * 7, x2, y2, color, 1.8)
    else:
        sign = 1 if x2 > x1 else -1
        s.line(x2 - sign * 7, y2 - 5, x2, y2, color, 1.8)
        s.line(x2 - sign * 7, y2 + 5, x2, y2, color, 1.8)


def panel(s, x, y, w, h, title, body, accent=TEAL, size=22):
    s.rect(x, y, w, h, WHITE)
    s.rect(x, y, w, 5, accent)
    s.text(x + 20, y + 20, w - 40, 74, title, 25, accent, True)
    s.text(x + 20, y + 98, w - 40, h - 112, body, size, INK)


def cover():
    s = Slide("DisasterTrace：动态天气证据中的持续可靠性", cover=True,
              source="论文式叙事 · 18 页主讲 / 4 页附录 · 证据快照 2026-09-08 16:51 UTC")
    s.text(64, 47, 1120, 29, "DISASTERTRACE  /  RESEARCH QUESTION → DESIGN → EVIDENCE", 18, TEAL, True)
    s.text(61, 117, 1120, 100, "DisasterTrace", 68, INK, True)
    s.text(64, 249, 1120, 123, "动态天气证据中的\nLLM 状态与来源追踪", 44, INK, True)
    s.text(67, 409, 1100, 75, "当资料持续更新，模型能否持续给出\n与目标相匹配、并由当前来源支持的答案？", 27, MUTED)
    for x, head, body in [(64, "内容", "数值与状态是否正确"), (456, "来源", "依据是否对准目标与版本"),
                          (848, "过程", "能否整段并重复成功")]:
        s.rect(x, 540, 368, 116, WHITE)
        s.text(x + 20, 555, 330, 41, head, 29, TEAL, True)
        s.text(x + 20, 608, 330, 35, body, 21, INK)


def motivation():
    s = slide("天气资料连续发布，查询目标需要保持明确", "发行时刻与目标有效时刻不同；模型需要对齐同一个问题。",
              "动机依据：NHC 官方预报原文与已实现任务；不评价实际天气预测误差")
    s.rect(64, 205, 1152, 73, PALE)
    s.text(84, 223, 1110, 43, "固定问题：这个风暴在指定未来时刻，最新明确陈述支持什么？", 26, TEAL, True)
    for x, title, body in [
        (64, "连续公告", "相同机构\n不同发行时刻\n逐步交付给模型"),
        (456, "目标对齐", "相同风暴\n相同绝对有效时刻\n相同变量与测量种类"),
        (848, "更新行为", "有新覆盖时更新\n缺少支持时留空\n其他目标保持区分"),
    ]:
        panel(s, x, 316, 368, 266, title, body, size=23)
    s.band("因此，评测单位需要包含证据变化的过程。")


def example():
    s = slide("同一个正确数字，可以对应不同的证据行为", "教学示例：R2 明确替代 R1；两个版本对目标 A 都写 60 mph。",
              "本页为规则教学示意；不是官方记录、真实模型回答或新增 benchmark 样本")
    s.rect(64, 205, 1152, 67, PALE)
    s.text(83, 221, 1114, 42, "材料：R1 / A / 60  →  R2 / A / 60；随后出现另一个目标 B / 100", 24, TEAL, True)
    panel(s, 64, 310, 368, 282, "答案 60 + 引用 R2", "内容正确\n目标匹配\n当前来源正确", TEAL, 25)
    panel(s, 456, 310, 368, 282, "答案 60 + 引用 R1", "内容正确\n旧记录仍有字面支持\n当前版本选择失败", RUST, 25)
    panel(s, 848, 310, 368, 282, "答案 100 + 引用 B", "文本中确有这个数值\n但不属于目标 A\n作用域或数值错误", RUST, 25)
    s.band("只核对数值，无法区分前两种行为。")


def related():
    s = slide("相关研究提供基础，本文明确具体测量组合", "知识更新、过期状态、引用与重复可靠性均已有直接研究。",
              "R1 ALCE；R2 LongMemEval；R3 StateMemBench；R4 STALE；R5 tau-bench；R6 EWB")
    s.table(["研究方向", "相关工作", "已有基础", "本项目的具体落点"], [
        ["天气事件验证", "Extreme Weather Bench", "事件、预报与观测", "天气资料使用与目标时间"],
        ["答案与引用", "ALCE", "内容与引用分层", "可定位引用及当前版本"],
        ["知识与状态更新", "LongMemEval\nStateMemBench / STALE", "时间、更新、过期状态", "同对象、同有效时间的修订"],
        ["重复可靠性", "tau-bench", "跨重复成功表现", "完整更新轨迹的重复成功"],
    ], [196, 304, 278, 374], y=211, row_h=74, size=19, header_size=19)
    s.band("贡献候选：将目标时间、当前来源与多轮可靠性组织成可复算任务。", size=21)


def questions():
    s = slide("三个研究问题决定任务与实验", "每个问题都有对应证据；原生模型结论仍需完成采集与核验。",
              "本文按论文结构重组已有工作；不声称所有问题均为早期预注册假设")
    entries = [
        ("RQ1", "内容正确是否代表证据使用正确？", "同一字段分母上，分开值/状态、字面支持和当前来源。"),
        ("RQ2", "无关信息加入后，模型能否持续可靠？", "配对条件、三种历史配置、完整轨迹与两次重复。"),
        ("RQ3", "测量要求能否在官方原文上成立？", "先验证目标对齐与公开可解性，再获取原生模型证据。"),
    ]
    for i, (label, title, body) in enumerate(entries):
        y = 209 + i * 132
        s.rect(64, y, 1152, 114, WHITE)
        s.text(86, y + 25, 133, 58, label, 34, TEAL, True)
        s.text(250, y + 15, 932, 41, title, 27, INK, True)
        s.text(250, y + 65, 932, 39, body, 21, MUTED)
    s.band("接下来先定义统一的输入、答案和评分对象。")


def formal_task():
    s = slide("统一接口：目标、可见证据、历史与可核验答案", "查询键明确对象、有效时间、变量、测量种类与单位。",
              "任务语义：受控显式修订 / 原生最新明确覆盖；各自政策分别冻结")
    for i, (head, body) in enumerate([
        ("目标 q", "哪个对象、哪个时间、哪个变量"),
        ("证据 E_t", "仅截至当前已经交付的材料"),
        ("历史 H_t", "按声明配置附加模型自己的回答"),
    ]):
        y = 207 + i * 93
        s.rect(64, y, 447, 76, WHITE)
        s.text(82, y + 11, 120, 34, head, 23, TEAL, True)
        s.text(82, y + 46, 409, 28, body, 19, INK)
        arrow(s, 512, y + 38, 571, 338)
    s.rect(577, 268, 221, 141, PALE)
    s.text(597, 293, 181, 42, "LLM", 31, TEAL, True, "center")
    s.text(597, 350, 181, 35, "公开任务规则", 21, INK, align="center")
    arrow(s, 799, 338, 880, 338)
    s.rect(887, 246, 329, 184, WHITE)
    s.text(908, 266, 286, 41, "实际回答", 27, TEAL, True)
    s.text(908, 321, 286, 95, "状态 + 数值\n来源记录 + 定位", 24, INK)
    s.line(64, 492, 1216, 492, RULE)
    s.text(64, 513, 286, 65, "评测侧独立计算参考\nGold 不进入模型请求", 20, MUTED)
    s.rect(381, 510, 401, 88, WHITE)
    s.text(398, 524, 365, 62, "resolve(E_t, q, 公开政策)\n得到参考状态与支持来源", 21, INK)
    arrow(s, 783, 553, 880, 553)
    arrow(s, 1051, 431, 1051, 506)
    s.rect(887, 510, 329, 88, PALE)
    s.text(908, 530, 286, 54, "确定性评分与错误分解", 23, TEAL, True)
    s.band("历史来自实际模型输出；语义错误不会被参考答案修正。", size=22)


def two_tracks():
    s = slide("受控诊断与官方原文承担互补的验证任务", "统一问题与测量框架，分别保留材料、语义和结果。",
              "证据：受控任务协议 / NHC 原生 forecast-claim 协议")
    panel(s, 64, 211, 559, 383, "受控更新诊断", "为什么需要：明确控制应变与不应变\n\n局部更新、作用域、同值修订、支持恢复\n真实来源初值 + 明确生成的后续变化\n\n提供：可解释的模型行为诊断", TEAL, 22)
    panel(s, 657, 211, 559, 383, "官方预报原文", "为什么需要：检验自然资料中的对应结构\n\n真实发行顺序、时效网格、覆盖缺口\n完整官方文本 + 原生终止陈述\n\n提供：现实材料上的任务与后续模型证据", RUST, 22)
    s.band("受控实验的诊断清晰度，与原生资料的现实约束共同构成 benchmark。", size=21)


def automatic():
    s = slide("自动评分建立在明确语义与独立验证上", "无需新增逐题人工标注，意味着先限定可自动验证的任务范围。",
              "Gold compiler / public resolver / scorer 各有职责；不使用 LLM judge 作为主评分")
    nodes = [
        (64, 212, "01 保存与准入", "原始资料、来源、哈希\n解析歧义留在隔离记录"),
        (456, 212, "02 编译与公开求解", "编译参考答案\n从可见文本独立重求"),
        (848, 212, "03 程序对照", "正确策略与错误捷径\n无效、缺失均保留机会"),
        (64, 417, "04 冻结模型执行", "题目、方法、预算与身份\n实际历史逐轮构造请求"),
        (456, 417, "05 评分与归因", "内容、目标、版本、定位\n检查点及完整轨迹"),
        (848, 417, "06 独立重建", "从原始捕获恢复请求\n复算完整分母与结果"),
    ]
    for x, y, title, body in nodes:
        s.rect(x, y, 368, 172, WHITE)
        s.text(x + 18, y + 18, 332, 39, title, 25, TEAL, True)
        s.text(x + 18, y + 81, 332, 76, body, 21, INK)
    for y in (298, 503):
        arrow(s, 433, y, 453, y)
        arrow(s, 825, y, 845, y)
    s.band("程序一致性增强可复核性；任务政策及适用范围仍需研究者审查。", size=21)


def methods():
    s = slide("三种历史配置比较模型如何使用已有答案", "所有配置都能重新读取截至当前累计交付的原始证据。",
              "受控主实验方法契约；原生方法的无效/缺失历史处理按自己的协议冻结")
    s.table(["输入配置", "累计原始证据", "额外模型历史"], [
        ["仅证据\nsnapshot", "全部可见", "不附加历史答案"],
        ["上轮状态\nstructured_state", "全部可见", "上一份结构合法的完整模型答案"],
        ["全部历史\nanswer_history", "全部可见", "此前全部结构合法的模型答案"],
    ], [306, 250, 596], y=209, row_h=87, size=22, header_size=21)
    s.text(81, 579, 1110, 30, "真实语义错误原样传递；配置差异同时涉及信息量、表示、长度和错误携带。", 20, MUTED)
    s.band("这些是实验条件；当前比较不隔离模型内部的单一记忆机制。", size=22)


def experiment():
    s = slide("实验按研究问题组织，结果按证据层级报告", "统一研究主线，不把不同材料和阶段合成一个总分。",
              "受控已验收：Qwen3-8B BF16 / H100 / thinking / structure-only；原生实测待验收")
    panel(s, 64, 210, 660, 292, "RQ1 / RQ2：已验收的受控模型实验",
          "36 基础 episode × 5 检查点\n× 2 条件 × 3 方法 × 2 重复 = 2,160 回答\n\n固定 Qwen3-8B；仅 3 个独立来源组", TEAL, 23)
    panel(s, 756, 210, 460, 292, "RQ3：官方原文任务验证",
          "12 公告 → 46 目标 → 257 查询\n九种程序策略已完成\n\n1,542 个模型机会正在采集", RUST, 23)
    s.text(83, 540, 1115, 63, "结构约束用于单独测量形式交付可靠时的语义表现；\n参考答案不参与解码，格式合法仍可能内容或引用错误。", 22, INK)
    s.band("先解释测量对象，再解释分数；回答数不等于独立天气事件数。", size=22)


def result_citations():
    s = slide("发现一：值正确仍会掩盖版本追踪失败", "同一字段分母：8,640 个机会，避免把不同粒度的差额混为一谈。",
              "已验收受控全量归因；真实例子来自固定顺序首条 superseded_same_value")
    for y, label, num, color in [(249, "值 / 状态正确", 8517, TEAL),
                                 (349, "含当前引用正确", 8258, RUST)]:
        rate = num / 8640
        s.text(64, y - 41, 555, 36, f"{label}   {num:,}/8,640", 22, INK)
        s.rect(64, y, 656, 29, RULE)
        s.rect(64, y, 656 * rate, 29, color)
        s.text(64, y + 36, 657, 46, f"{rate:.1%}", 29, color, True, "right")
    s.text(64, 419, 656, 28, "条形长度从 0% 起；两个指标使用相同字段分母。", 17, MUTED)
    for y, n, label, color in [(207, "123", "值或状态错误", INK), (288, "259", "值对但引用错", TEAL),
                                (369, "116", "其中：同值旧来源", RUST)]:
        s.text(790, y, 135, 57, n, 38, color, True)
        s.text(938, y + 14, 263, 35, label, 22, INK)
    s.rect(64, 480, 1152, 120, WHITE)
    s.text(82, 495, 1108, 34, "真实模型例子：答案和参考都为 60 mph，模型仍引用已被替代的旧记录。", 23, INK, True)
    s.text(82, 545, 1108, 50, "记录存在、定位合法、目标匹配、数值有字面支持；失败是当前来源选择。", 22, MUTED)
    s.band("RQ1：内容正确与来源版本正确，在实测中确实可以分离。")


def reliability():
    s = slide("发现二：单点高分不等于重复整段可靠", "同一个上轮状态方法；每个指标直接计算实际成功事件。",
              "受控已验收结果；pass^2 = 两次均整段成功，非 pass@2 或单点准确率平方")
    rows = [
        ("检查点全对", "分母：每条件 360 次回答", 349, 319, 360),
        ("五轮全对", "分母：每条件 72 条轨迹", 64, 43, 72),
        ("两次均五轮全对", "分母：每条件 36 个 episode", 30, 15, 36),
    ]
    for i, (title, unit, left, right, total) in enumerate(rows):
        x = 64 + 392 * i
        s.rect(x, 211, 368, 385, WHITE)
        s.text(x + 18, 228, 331, 37, title, 25, INK, True)
        s.text(x + 18, 277, 331, 29, unit, 18, MUTED)
        floor, height = 532, 166
        s.line(x + 34, floor, x + 334, floor, RULE)
        for j, (value, col, label) in enumerate([(left, TEAL, "基础"), (right, RUST, "干扰")]):
            xx = x + 72 + j * 148
            hh = height * value / total
            s.rect(xx, floor - hh, 72, hh, col)
            s.text(xx - 28, floor - hh - 43, 128, 38, f"{100*value/total:.1f}%", 24, col, True, "center")
            s.text(xx - 29, 546, 130, 32, f"{label} {value}/{total}", 19, INK, align="center")
    s.band("RQ2：96.9% → 88.6% 的单点表现，对应 83.3% → 41.7% 的重复整段成功。", size=20)


def method_findings():
    s = slide("历史配置表现不同，机制解释需要额外控制", "曝光后配对每方法 216 对；保留改善和退化两个方向。",
              "受控已验收方法表与配对表；后续载体受先前回答影响，是闭环比较")
    s.table(["方法", "基础全对 /360", "干扰全对 /360", "仅基础对\n曝光后 /216", "仅干扰对\n曝光后 /216"], [
        ["仅证据", "340，94.4%", "309，85.8%", "45", "14"],
        ["上轮状态", "349，96.9%", "319，88.6%", "37", "7"],
        ["全部历史", "279，77.5%", "265，73.6%", "38", "24"],
    ], [190, 247, 247, 234, 234], y=211, row_h=72, size=22, header_size=19)
    s.text(81, 525, 1120, 78, "干扰前 c0/c1：432 对请求与最终文本相同，且两边都正确。\n上轮状态在当前设置中最高；长度、信息量与历史错误尚未单独隔离。", 22, INK)
    s.band("RQ2：当前支持条件性的配置比较；表示形式的因果解释需要匹配实验。", size=21)


def native_example():
    s = slide("官方原文提供真实的时间对齐与覆盖变化", "固定目标：Francine / 2024-09-10 18:00 UTC / 最大持续风速。",
              "官方来源例子 + 原生程序诊断；不是原生模型成绩")
    for x, title, value, detail in [
        (64, "公告 005 / 09-09 21:00", "75 KT", "明确覆盖目标"),
        (456, "公告 006 / 09-10 03:00", "无明确目标行", "本任务保留此前明确陈述"),
        (848, "公告 007 / 09-10 09:00", "70 KT", "新的同目标明确预报"),
    ]:
        s.rect(x, 211, 368, 178, WHITE)
        s.text(x + 18, 226, 332, 29, title, 19, MUTED)
        s.text(x + 18, 277, 332, 47, value, 32, TEAL, True)
        s.text(x + 18, 345, 332, 30, detail, 20, INK)
    s.text(76, 404, 1128, 58, "最新明确覆盖是已发布陈述的选择政策；它不证明被省略的旧预报在业务上仍然有效。", 21, MUTED)
    for x, value, label in [(64, "1,542 / 1,542", "公开求解器：完整正确"),
                             (456, "606 / 1,542", "错用相对时效：完整正确"),
                             (848, "72 / 1,542", "选最后一行：完整正确")]:
        s.rect(x, 484, 368, 116, PALE)
        s.text(x + 18, 496, 332, 46, value, 29, TEAL, True)
        s.text(x + 18, 558, 332, 32, label, 20, INK)
    s.band("RQ3 已有证据：自然资料可构成可解、有区分度的任务；模型验证进行中。", size=20)


def progress():
    s = slide("整体进展：测量已成立，原生模型证据正在补齐", "按 benchmark 的组成部分定位成熟度，而非按开发编号逐项汇报。",
              "状态快照：2026-09-08 16:51 UTC；四个本地保存的作业观察均为 RUNNING")
    s.table(["组成部分", "完成度", "可以支持的表述"], [
        ["来源与两类任务", "已建立", "受控更新 + 官方原文，范围与语义明确"],
        ["公开求解与确定性评分", "已验证", "可解性、失败分类与固定分母可复算"],
        ["受控模型实验", "已独立验收", "2,160 实际回答；内容、引用与轨迹分析"],
        ["原生任务程序验证", "已离线验收", "257 查询、九种程序对照"],
        ["原生模型采集", "四 worker 运行中", "CPU 与 H100 预检已过；模型成绩待验收"],
    ], [321, 239, 592], y=207, row_h=62, size=20, header_size=20)
    s.band("当前是有实证支撑的研究型 benchmark 原型；外推验证继续补充。", size=21)


def contributions():
    s = slide("贡献落在任务、测量与实证，并明确适用范围", "贡献表述与已有证据匹配；论文新颖性仍需完整近邻比较。",
              "目前：受控 3 个来源组 / 原生 2 个风暴 / 一个匹配受控模型 / 两次重复")
    for x, title, color, rows in [
        (64, "已有证据支持的贡献", TEAL, [
            ("任务", "显式目标、版本与交付语义\n受控诊断和官方原文任务"),
            ("测量", "内容、当前来源、连续可靠分层\n自动参考、公开求解、独立重建"),
            ("实证", "值正确仍可引用旧版本\n局部高分仍可对应较低整段成功"),
        ]),
        (656, "当前结论的适用边界", RUST, [
            ("模型与事件", "来源较少，模型比较尚不充分\n不能把回答数当独立事件数"),
            ("任务效度", "政策明确但范围有限\n不是实际预报技巧或业务价值验证"),
            ("机制解释", "历史信息量、长度和错误共同变化\n纯表示与内部机制尚未隔离"),
        ]),
    ]:
        s.text(x, 208, 560, 44, title, 27, color, True)
        for i, (head, body) in enumerate(rows):
            y = 276 + 109 * i
            s.rect(x, y, 560, 95, WHITE)
            s.text(x + 18, y + 16, 120, 37, head, 23, color, True)
            s.text(x + 154, y + 15, 385, 73, body, 21, INK)
    s.band("重点是明确测到了什么，以及还有哪些结论需要新的证据。", size=22)


def next_work():
    s = slide("后续实验逐一解决尚未回答的问题", "从已有结果的限制出发安排工作，保持每一步的研究目的清楚。",
              "后续研究路线；本次仅制作文档，不提交新 GPU 作业或模型请求")
    panel(s, 64, 210, 368, 387, "1 / 原生模型核验",
          "问题：受控发现是否在\n自然资料中出现？\n\n完成当前采集与独立重算\n分别报告值、引用、轨迹\n保留缺失和失败机会", TEAL, 22)
    panel(s, 456, 210, 368, 387, "2 / 匹配载体实验",
          "问题：配置差异来自\n哪些因素？\n\n固定证据与同一保存前缀\n保持信息与已有错误相同\n分别控制表示及 token 长度", TEAL, 22)
    panel(s, 848, 210, 368, 387, "3 / 匹配模型与事件",
          "问题：结论能外推\n到什么范围？\n\n同协议加入第二模型\n预定规则扩展独立事件\n再设计跨灾种或多模态任务", RUST, 22)
    s.band("新的工作应增加可解释的研究证据；GPU 并行只解决已定义矩阵的计算速度。", size=20)


def closing():
    s = slide("同时测量内容、当前依据与连续表现", "DisasterTrace 将持续更新的天气证据使用转化为可执行的评测。",
              "主结论范围：已验收受控实测；官方原文任务已验证，原生模型证据待验收")
    for x, title, body in [(64, "内容", "状态与数值是否正确"),
                            (456, "当前依据", "来源是否对准目标与版本"),
                            (848, "连续表现", "整段更新是否反复成功")]:
        s.rect(x, 220, 368, 183, PALE)
        s.text(x + 20, 247, 328, 60, title, 38, TEAL, True, "center")
        s.text(x + 20, 332, 328, 41, body, 23, INK, align="center")
    s.text(84, 451, 1110, 94, "当前实测表明，这三个层面并不等价。\n两个互补任务为诊断失败与验证自然资料中的表现提供共同框架。", 29, INK, True)
    s.band("下一项关键证据：原生模型结果，以及更多模型和独立事件上的匹配验证。", size=21)


def appendices():
    s = slide("附录 A：早期资产与开发阶段如何归入整体", "阶段编号用于追溯；主讲中的论证由研究问题组织。",
              "原总体方案、来源审查、历史验收；不将继承任务或软件对照视为动态模型成绩", True)
    s.table(["资产或阶段", "研究中的作用", "边界"], [
        ["DisasterBench / CyPortQA", "继承规划适配、题型与原文入口", "230 规划任务；48 模板 profile 非 QA 数"],
        ["NHC cohort / P1 / T6", "来源划分、服务交付与预算校准", "不同矩阵不能组成统一排行榜"],
        ["P2 / P3 / P4", "受控语义；自由/结构约束分轨", "不等于训练提升或旧答案修复"],
        ["P5 / P6", "固定压力；配对、重复、来源归因", "受控后续变化明确由程序构造"],
        ["原生 task / live", "自然资料任务、程序验证、模型采集", "工程验收与模型成绩分别标注"],
    ], [310, 394, 448], y=208, row_h=67, size=18, header_size=19)

    s = slide("附录 B：受控主实验的完整方法结果", "不同可靠性指标使用不同分母；当前只含三个独立来源组。",
              "受控已验收分数；原始作业后处理失败保留，独立 CPU 审阅完成重建", True)
    rows = []
    cn = {"snapshot": "仅证据", "structured_state": "上轮状态", "answer_history": "全部历史"}
    for r in FACTS["p6"]["methods"]:
        rows.append(["基础" if r["condition"] == "base" else "干扰", cn[r["method"]],
                     str(r["repeat_0_correct"]), str(r["repeat_1_correct"]),
                     f"{r['checkpoint_correct']}/360", f"{r['trajectory_correct']}/72",
                     f"{r['both_repeats_correct']}/36"])
    s.table(["条件", "方法", "R0 /180", "R1 /180", "检查点全对", "五轮全对", "两次均全对"],
            rows, [110, 174, 115, 115, 226, 206, 206], y=209, row_h=51, size=20, header_size=17)
    s.text(78, 586, 1115, 33, "完整正确：1,861/2,160；字段错误 382，错误回答 299，43 个动作错误与字段错误重叠。", 19, MUTED)

    s = slide("附录 C：常见质疑与当前可回答的范围", "将测量目标、领域意义和因果解释分别说清楚。",
              "完整答辩稿：DisasterTrace_Paper_Storyline_CN.md 第七节", True)
    s.table(["问题", "当前回答"], [
        ["程序能满分，为何评测 LLM？", "程序证明公开可解，并提供参照。研究测量 LLM 使用资料时的可靠性；\n不据此推荐用 LLM 替代可用的专用解析器。"],
        ["为什么数字对却扣引用分？", "当前来源是公开任务要求；同时报告数值与引用分数。\n旧来源有字面支持，不等于满足任务的当前版本要求。"],
        ["天气领域贡献是什么？", "原生时间网格、目标有效时刻、风速/阵风、覆盖和终止状态。\n受控部分也含通用状态追踪；跨领域显示对照尚待补充。"],
        ["结构化历史是否更优？", "当前配置中上轮状态最高，但信息、长度与历史错误同时变化。\n需要相同前缀和证据的匹配对照，再讨论表示或机制。"],
    ], [391, 761], y=210, row_h=79, size=18, header_size=20)

    s = slide("附录 D：参考与证据入口", "本次核对原始论文页面及摘要；既有方案提供实现核查记录。",
              "网页快照与哈希：evidence/literature；本地来源与执行状态：evidence/snapshot.json", True)
    refs = [
        ("R1 / ALCE", "答案正确性与引用质量", "aclanthology.org/2023.emnlp-main.398"),
        ("R2 / LongMemEval", "知识更新、时间推理与拒答", "arxiv.org/abs/2410.10813"),
        ("R3 / StateMemBench", "当前与被替代状态", "arxiv.org/abs/2608.19652v1"),
        ("R4 / STALE", "过期记忆与后续行为", "arxiv.org/abs/2605.06527v1"),
        ("R5 / tau-bench", "重复可靠性", "arxiv.org/abs/2406.12045"),
        ("R6 / Extreme Weather Bench", "高影响天气事件验证", "arxiv.org/abs/2605.01126"),
    ]
    s.table(["文献", "在本叙事中的作用", "原始入口"], refs,
            [362, 335, 455], y=208, row_h=53, size=17, header_size=19)
    s.text(77, 594, 1120, 29, "完整逻辑、逐页讲稿、转场、限制及阶段映射均在配套 Markdown 中。", 19, MUTED)


def render():
    c = canvas.Canvas(str(PDF), pagesize=(W, H), pageCompression=1)
    c.setTitle("DisasterTrace：动态天气证据中的 LLM 状态与来源追踪评测")
    c.setAuthor("DisasterTrace")
    c.setSubject("论文式研究叙事：背景、近邻研究、任务、设计、实验、贡献与限制")
    c.setCreator("DisasterTrace research presentation / ReportLab")
    for s in base.SLIDES:
        key = f"slide_{s.number:02d}"
        c.bookmarkPage(key)
        c.addOutlineEntry(f"{s.number:02d}  {s.title}", key, 0, False)
        for e in s.items:
            if e["kind"] == "rect":
                c.setFillColor(HexColor(e["fill"]))
                c.setStrokeColor(HexColor(e["stroke"] or e["fill"]))
                c.rect(e["x"], H-e["y"]-e["h"], e["w"], e["h"], fill=1, stroke=bool(e["stroke"]))
            elif e["kind"] == "line":
                c.setStrokeColor(HexColor(e["color"]))
                c.setLineWidth(e["width"])
                c.line(e["x1"], H-e["y1"], e["x2"], H-e["y2"])
            else:
                assert e["kind"] == "text"
                face = base.font(e["bold"])
                c.setFont(face, e["size"])
                c.setFillColor(HexColor(e["color"]))
                ascent = pdfmetrics.getAscent(face) / 1000 * e["size"]
                for i, line in enumerate(e["lines"]):
                    width = pdfmetrics.stringWidth(line, face, e["size"])
                    x = e["x"] + (e["w"]-width)*{"left": 0, "center": .5, "right": 1}[e["align"]]
                    c.drawString(x, H-e["y"]-ascent-i*e["leading"], line)
        c.showPage()
    c.save()


def main():
    for name in ("Regular", "Bold"):
        pdfmetrics.registerFont(TTFont("Noto"+name, str(base.FONTS / f"NotoSansSC-{name}.ttf")))
    for relative, expected in FACTS["files"].items():
        assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected, relative
    assert FACTS["p6"]["counts"]["fields"] == 8640
    assert FACTS["p6"]["counts"]["grounded_correct"] == 8258
    assert 8640 - 123 == 8517 and 8517 - 259 == 8258
    for builder in (cover, motivation, example, related, questions, formal_task, two_tracks,
                    automatic, methods, experiment, result_citations, reliability, method_findings,
                    native_example, progress, contributions, next_work, closing, appendices):
        builder()
    assert len(base.SLIDES) == 22 and sum(not s.appendix for s in base.SLIDES) == 18
    render()
    (OUT / "slide_manifest.json").write_text(json.dumps([
        {"number": s.number, "title": s.title, "appendix": s.appendix, "items": s.items}
        for s in base.SLIDES], ensure_ascii=False, indent=2) + "\n")
    inputs = [MD, Path(__file__), OUT / "evidence/snapshot.json",
              OUT / "evidence/literature/references.json", PRIOR / "pdf_v1/build_pdf.py",
              PRIOR / "pdf_v1/validate_pdf.py", PRIOR / "evidence/presentation_data.json"]
    (OUT / "evidence/build_inputs.json").write_text(json.dumps({
        "inputs": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
        "research_source_files_verified": len(FACTS["files"]),
        "model_calls": 0, "gpu_jobs": 0,
    }, indent=2) + "\n")
    validator = load_module("disastertrace_slide_validator", PRIOR / "pdf_v1/validate_pdf.py")
    validator.validate(OUT, PDF.name)


if __name__ == "__main__":
    main()
