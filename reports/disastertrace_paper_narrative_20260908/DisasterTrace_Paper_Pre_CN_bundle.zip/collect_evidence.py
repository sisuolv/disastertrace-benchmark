"""Snapshot evidence for the presentation; never dispatch benchmark work."""

import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

from bs4 import BeautifulSoup


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
REPO = ROOT / "development/disastertrace-next/disastertrace-starter"
PRIOR = ROOT / "reports/progress_20260908_p6_complete"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def snapshot():
    evidence = OUT / "evidence"
    evidence.mkdir(parents=True, exist_ok=True)
    destination = evidence / "snapshot.json"
    if destination.exists():
        raise FileExistsError("Keep the first evidence snapshot; use a new report version.")
    paths = [
        REPO.parent / "INTEGRATED_BENCHMARK_PLAN.md",
        REPO.parent / "SOURCE_REVIEW.md",
        REPO / "README_AUTOMATED.md",
        REPO / "README_COHORT.md",
        REPO / "README_CONTROLLED_V1.md",
        REPO / "artifacts/p6_live_v1/FINDINGS.md",
        REPO / "artifacts/p7_forecast_task_v1/FINDINGS.md",
        REPO / "artifacts/p7_forecast_task_v1/PROTOCOL.md",
        REPO / "artifacts/p7_forecast_task_v1/OFFLINE_ACCEPTANCE.json",
        REPO / "artifacts/p7_forecast_live_v1/CPU_ACCEPTANCE.json",
        REPO / "artifacts/p7_forecast_live_v1/PREFLIGHT_ACCEPTANCE.json",
        REPO / "artifacts/p7_forecast_live_v1/acp_live_01/phase.json",
        PRIOR / "evidence/presentation_data.json",
        PRIOR / "pdf_v2_p7_offline/p7_data.json",
        PRIOR / "detailed_report_v1/evidence/p6_actual_error.json",
        PRIOR / "detailed_report_v1/evidence/report_facts.json",
        *sorted((ROOT / "plan/plan_v3").glob("*.md")),
    ]
    workers = []
    status_dir = REPO / "artifacts/p7_forecast_live_v1/finalization_01/status"
    for worker in range(4):
        path = sorted(status_dir.glob(f"*-{worker}.json"))[-1]
        receipt = json.loads(path.read_text())
        job = json.loads(receipt["stdout"])
        assert receipt["exit_code"] == 0
        workers.append({"worker": worker, "observed_at": receipt["at"],
                        "state": job["state"], "job_id": job["name"],
                        "source": str(path.relative_to(ROOT))})
        paths.append(path)
    data = {"snapshot_at_utc": datetime.now(timezone.utc).isoformat(),
            "scope": "Whole benchmark argument; accepted controlled results and native task, plus a time-stamped native execution status.",
            "p6": json.loads((PRIOR / "evidence/presentation_data.json").read_text()),
            "native": json.loads((PRIOR / "pdf_v2_p7_offline/p7_data.json").read_text()),
            "actual_error": json.loads((PRIOR / "detailed_report_v1/evidence/p6_actual_error.json").read_text()),
            "history": json.loads((PRIOR / "detailed_report_v1/evidence/report_facts.json").read_text())["historical_results"],
            "native_workers": workers,
            "native_cpu": {key: value for key, value in json.loads((REPO / "artifacts/p7_forecast_live_v1/CPU_ACCEPTANCE.json").read_text()).items()
                           if key in {"status", "at", "model_calls", "core_tests_exit_code", "backend_tests_exit_code", "portable_review_exit_code", "diagnostics"}},
            "native_final_findings_present": (REPO / "artifacts/p7_forecast_live_v1/FINDINGS.md").exists(),
            "report_model_calls": 0, "report_gpu_jobs": 0,
            "files": {str(path.relative_to(ROOT)): digest(path.read_bytes()) for path in paths}}
    preflight = json.loads((REPO / "artifacts/p7_forecast_live_v1/PREFLIGHT_ACCEPTANCE.json").read_text())
    data["native_preflight"] = {key: preflight["result"][key] for key in
                                ["status", "finished_at", "generate_disabled", "model_calls", "gpu_model_loaded"]}
    assert data["p6"]["counts"]["checkpoints"] == 2160
    assert data["p6"]["counts"]["all_correct"] == 1861
    assert data["native_cpu"]["status"] == data["native_preflight"]["status"] == "passed"
    assert data["native_preflight"]["model_calls"] == 0
    assert not data["native_final_findings_present"]
    destination.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"snapshot": data["snapshot_at_utc"], "bound_files": len(paths),
                      "native_workers": [w["state"] for w in workers]}, ensure_ascii=False))


REFERENCES = [
    ("R1_ALCE", "https://aclanthology.org/2023.emnlp-main.398/"),
    ("R2_LongMemEval", "https://arxiv.org/abs/2410.10813"),
    ("R3_StateMemBench", "https://arxiv.org/abs/2608.19652v1"),
    ("R4_STALE", "https://arxiv.org/abs/2605.06527v1"),
    ("R5_tau_bench", "https://arxiv.org/abs/2406.12045"),
    ("R6_ExtremeWeatherBench", "https://arxiv.org/abs/2605.01126"),
]


def reference(item):
    key, url = item
    record = {"id": key, "url": url, "checked_at_utc": datetime.now(timezone.utc).isoformat(),
              "reading_scope": "Primary landing page title and abstract only; no reproduction or full-paper audit."}
    try:
        request = Request(url, headers={"User-Agent": "DisasterTrace-research-reference-check/1.0"})
        with urlopen(request, timeout=25) as response:
            raw = response.read(2_000_001)
            if len(raw) > 2_000_000:
                raise ValueError("Reference page exceeds snapshot size cap")
            record["http_status"] = response.status
            record["resolved_url"] = response.url
        soup = BeautifulSoup(raw, "html.parser")
        title = soup.find("meta", attrs={"name": "citation_title"})
        record["title"] = title.get("content") if title else soup.title.get_text(" ", strip=True)
        abstract = soup.find("blockquote", class_="abstract") or soup.find("div", class_="acl-abstract")
        record["abstract"] = abstract.get_text(" ", strip=True) if abstract else ""
        record["status"] = "abstract_read" if record["abstract"] else "landing_page_only"
        record["sha256"] = digest(raw)
        (OUT / "evidence/literature" / (key + ".html")).write_bytes(raw)
    except Exception as exc:
        record["status"] = "unavailable"
        record["error"] = type(exc).__name__ + ": " + str(exc)
    return record


if __name__ == "__main__":
    snapshot()
    (OUT / "evidence/literature").mkdir(exist_ok=True)
    with ThreadPoolExecutor(max_workers=4) as pool:
        references = list(pool.map(reference, REFERENCES))
    (OUT / "evidence/literature/references.json").write_text(json.dumps(references, ensure_ascii=False, indent=2) + "\n")
    for item in references:
        print(json.dumps(item, ensure_ascii=False))
