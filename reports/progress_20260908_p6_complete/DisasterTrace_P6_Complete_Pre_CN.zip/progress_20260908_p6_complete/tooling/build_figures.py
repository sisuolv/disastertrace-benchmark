"""Rebuild presentation tables and figures from accepted, read-only reports."""

import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numpy as np


OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parents[1]
REPO = ROOT / "development/disastertrace-next/disastertrace-starter"
METHODS = ("snapshot", "structured_state", "answer_history")
LABELS = ("Snapshot", "Structured state", "Answer history")
CONDITIONS = ("base", "irrelevant_scope")
INK, TEAL, ORANGE, GREY = "#19343b", "#087e83", "#d16a37", "#bec9cb"


def read(relative):
    return json.loads((REPO / relative).read_text())


def dump(relative, value):
    (OUT / relative).write_text(json.dumps(value, indent=2) + "\n")


def save(fig, stem):
    for suffix in ("png", "svg", "pdf"):
        fig.savefig(OUT / "figures" / f"{stem}.{suffix}", dpi=190, bbox_inches="tight")
    plt.close(fig)


def verify_source_hashes():
    hashes = json.loads((OUT / "evidence/read_source_hashes.json").read_text())
    for relative, expected in hashes.items():
        assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected, relative
    return len(hashes)


def extract():
    verify_source_hashes()
    scores = read("artifacts/p6_live_v1/reports/model_review_v2/scores.json")
    attribution = read("artifacts/p6_live_v1/analysis/summary.json")
    acceptance = read("artifacts/p6_live_v1/COMPLETED_ACCEPTANCE.json")
    rows = []
    for condition in CONDITIONS:
        for method in METHODS:
            cells = sorted(
                [c for c in scores["cells"] if (c["condition"], c["method"]) == (condition, method)],
                key=lambda c: c["repeat"],
            )
            trajectories = [t for t in scores["trajectory_errors"]
                            if (t["condition"], t["method"]) == (condition, method)]
            episodes = [e for e in scores["episode_reliability"]
                        if (e["condition"], e["method"]) == (condition, method)]
            assert len(cells) == 2 and len(trajectories) == 72 and len(episodes) == 36
            assert all(e["repeats"] == 2 and not e["incomplete"] for e in episodes)
            assert all(t["all_responses_received"] for t in trajectories)
            row = {
                "condition": condition, "method": method,
                "repeat_0_correct": cells[0]["counts"]["all_correct"],
                "repeat_1_correct": cells[1]["counts"]["all_correct"],
                "checkpoint_correct": sum(c["counts"]["all_correct"] for c in cells),
                "checkpoint_total": sum(c["counts"]["checkpoints"] for c in cells),
                "trajectory_correct": sum(t["all_checkpoints_correct"] for t in trajectories),
                "trajectory_total": len(trajectories),
                "both_repeats_correct": sum(e["successes"] == 2 for e in episodes),
                "episode_total": len(episodes),
            }
            assert row["checkpoint_total"] == 360
            rows.append(row)
    assert sum(r["checkpoint_correct"] for r in rows) == scores["counts"]["all_correct"] == 1861
    assert sum(r["checkpoint_total"] for r in rows) == 2160
    assert scores["counts"]["schema_valid"] == 2160
    assert scores["complete"] and acceptance["model_matrix_complete"]
    assert len(scores["paired_changes"]) == 1080
    paired = []
    for method in METHODS:
        for exposure in ("before_first_exposure", "exposed"):
            pairs = [p for p in scores["paired_changes"]
                     if p["method"] == method and p["exposure_status"] == exposure]
            counts = Counter(p["outcome"] for p in pairs)
            paired.append({"method": method, "exposure": exposure, "total": len(pairs),
                           **{k: counts[k] for k in
                              ("both_correct", "base_only", "condition_only", "both_wrong")}})
            assert len(pairs) == (144 if exposure == "before_first_exposure" else 216)
            if exposure == "before_first_exposure":
                assert counts == {"both_correct": 144}
    assert sum(attribution["primary_error_categories"].values()) == 382
    assert attribution["counts"]["citation_only_errors"] == 259
    assert scores["counts"]["fields"] == 8640
    assert acceptance["model_job_state"] == "FAILED" and acceptance["cpu_recovery_passed"]
    assert len(acceptance["files"]) == 9434

    source_report = read("artifacts/nhc_forecast_source_v1/review_v1/report.json")
    products = read("artifacts/nhc_forecast_source_v1/review_v1/products.json")
    pairs = read("artifacts/nhc_forecast_source_v1/review_v1/revision_pairs.json")
    canonical = read("artifacts/nhc_forecast_source_v1/review_v1/canonical.json")
    source = {k: source_report[k] for k in (
        "planned_bodies", "received_bodies", "admitted_bodies", "quarantined_bodies",
        "forecast_rows", "independent_storm_sources", "same_valid_revision_pairs",
        "wind_changed_pairs", "model_generations", "new_human_gold_annotations", "llm_judge")}
    source["terminal_rows"] = sum(r["terminal_status"] is not None
                                  for p in products for r in p["forecasts"])
    source["wind_unchanged_pairs"] = sum(p["wind_change_kt"] == 0 for p in pairs)
    source["terminal_involved_pairs"] = sum(p["wind_change_kt"] is None for p in pairs)
    assert (source["terminal_rows"], source["wind_unchanged_pairs"], source["terminal_involved_pairs"]) == (9, 24, 2)
    assert len(products) == 12 and sum(len(p["forecasts"]) for p in products) == 95
    assert len(pairs) == 49 and source["model_generations"] == 0

    target = "2024-09-10T18:00:00+00:00"
    example = {"storm_id": "AL062024", "storm_name": "Francine", "valid_at": target,
               "selection": "First revision pair in frozen revision_pairs.json; include intervening advisory 006.",
               "model_evaluation_run": False, "products": []}
    assert pairs[0]["valid_at"] == target and pairs[0]["storm_id"] == example["storm_id"]
    for number in (5, 6, 7):
        p = next(p for p in products if p["storm_id"] == "AL062024" and p["advisory_number"] == number)
        sid = f"al062024-fstadv-{number:03d}"
        raw_relative = f"artifacts/nhc_forecast_source_v1/acquisition/{sid}/body.html"
        raw = (REPO / raw_relative).read_bytes()
        c = canonical[sid]
        assert hashlib.sha256(raw).hexdigest() == c["raw_sha256"]
        matching = [r for r in p["forecasts"] if r["valid_at"] == target]
        assert len(matching) == (0 if number == 6 else 1)
        # Include all forecast rows for the intervening product to substantiate absence.
        shown_rows = matching if matching else p["forecasts"]
        line_numbers = {5, p["issue_line"]}
        for r in shown_rows:
            line_numbers.add(r["forecast_line"])
            if r["wind_line"] is not None:
                line_numbers.add(r["wind_line"])
        excerpts = []
        for line in sorted(line_numbers):
            mapping = next(m for m in c["line_map"] if m["canonical_line"] == line)
            span = raw[mapping["raw_byte_start"]:mapping["raw_byte_end"]]
            assert hashlib.sha256(span).hexdigest() == mapping["raw_line_sha256"]
            assert span.decode().rstrip("\r\n") == c["text"].splitlines()[line - 1]
            excerpts.append({**mapping, "text": c["text"].splitlines()[line - 1]})
        example["products"].append({"source_id": sid, "issued_at": p["issued_at"],
                                    "target_row": matching[0] if matching else None,
                                    "all_valid_times": [r["valid_at"] for r in p["forecasts"]],
                                    "raw_path": raw_relative, "raw_sha256": c["raw_sha256"],
                                    "excerpts": excerpts})
    data = {"counts": scores["counts"], "methods": rows, "paired": paired,
            "attribution_counts": attribution["counts"],
            "error_categories": attribution["primary_error_categories"],
            "source": source, "source_example": example,
            "acceptance_id": acceptance["acceptance_id"],
            "original_job_state": acceptance["model_job_state"],
            "original_worker_all_steps_passed": acceptance["original_worker_all_steps_passed"],
            "scope": "Descriptive figures from accepted P6; no new model calls or scoring changes."}
    dump("evidence/presentation_data.json", data)
    dump("evidence/source_example.json", example)
    for name, records in (("method_results", rows), ("paired_outcomes", paired)):
        with (OUT / "evidence" / f"{name}.csv").open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(records[0]))
            writer.writeheader()
            writer.writerows(records)
    return data


def charts(data):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                         "text.color": INK, "axes.labelcolor": INK,
                         "xtick.color": INK, "ytick.color": INK,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.spines.left": False, "axes.spines.bottom": False,
                         "svg.fonttype": "none", "figure.facecolor": "white"})
    fig, axes = plt.subplots(1, 3, figsize=(16, 5.2), sharey=True)
    specs = (("Checkpoint fully correct", "checkpoint_correct", "checkpoint_total"),
             ("All 5 checkpoints correct", "trajectory_correct", "trajectory_total"),
             ("All 5 correct in BOTH repeats", "both_repeats_correct", "episode_total"))
    for ax, (title, numerator, denominator) in zip(axes, specs):
        x = np.arange(3)
        for idx, condition in enumerate(CONDITIONS):
            rows = [r for r in data["methods"] if r["condition"] == condition]
            values = [100 * r[numerator] / r[denominator] for r in rows]
            bars = ax.bar(x + (idx - 0.5) * 0.36, values, 0.34,
                          color=(TEAL, ORANGE)[idx], label=("Base", "Irrelevant scope L4")[idx])
            ax.bar_label(bars, labels=[f"{v:.1f}" for v in values], fontsize=9, padding=4)
        ax.set_xticks(x, ["Snapshot", "Structured\nstate", "Answer\nhistory"])
        ax.set_ylim(0, 112)
        ax.set_yticks([0, 20, 40, 60, 80, 100])
        ax.yaxis.grid(True, alpha=0.16)
        ax.set_axisbelow(True)
        ax.set_title(f"{title}\nn = {rows[0][denominator]} per method / condition", fontsize=12, pad=14)
    axes[0].set_ylabel("Observed success (%)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False, bbox_to_anchor=(0.5, 0.045))
    fig.suptitle("P6: single-answer accuracy and repeated trajectory reliability", fontsize=18, x=0.5, y=1.015)
    fig.text(0.5, 0.01, "Qwen3-8B | 3 storm source groups | 2 repeats | Descriptive results; panels use different denominators.", ha="center", fontsize=10)
    fig.tight_layout(rect=(0, 0.12, 1, 0.98))
    save(fig, "01_reliability")

    labels = {"status_or_value_mismatch": "Wrong value or status",
              "superseded_same_value": "Superseded source, SAME value",
              "unknown_record_id": "Unknown record ID",
              "wrong_valid_window_or_measurement_kind": "Wrong valid window / measurement kind",
              "out_of_bounds_line": "Line outside source bounds",
              "wrong_entity": "Wrong entity",
              "wrong_variable_or_unit": "Wrong variable / unit",
              "superseded_different_value": "Superseded source, different value"}
    items = sorted(data["error_categories"].items(), key=lambda kv: -kv[1])
    fig, ax = plt.subplots(figsize=(12, 5.5))
    colors = [INK if k == "status_or_value_mismatch" else ORANGE if k == "superseded_same_value" else TEAL for k, _ in items]
    bars = ax.barh([labels[k] for k, _ in items], [v for _, v in items], color=colors, height=0.65)
    ax.bar_label(bars, padding=6)
    ax.invert_yaxis()
    ax.set_xlim(0, 145)
    ax.set_xlabel("Field errors (count)")
    ax.xaxis.grid(True, alpha=0.16)
    ax.set_axisbelow(True)
    ax.set_title("Correct values can still cite an outdated source", loc="left", fontsize=18, pad=18)
    fig.text(0.02, 0.025, "382 field errors / 8,640 field opportunities; 259 citation-only errors.\n116 of 259 citation-only errors cite a superseded source with the same value. Action errors overlap and are excluded here.", fontsize=10)
    fig.tight_layout(rect=(0, 0.105, 1, 1))
    save(fig, "02_error_attribution")

    fig, ax = plt.subplots(figsize=(12, 4.7))
    rows = [p for p in data["paired"] if p["exposure"] == "exposed"]
    left = np.zeros(3)
    segments = (("both_correct", "Both correct", TEAL), ("base_only", "Base only correct", ORANGE),
                ("condition_only", "Scope only correct", "#ddb45c"), ("both_wrong", "Both wrong", GREY))
    for key, label, color in segments:
        vals = np.array([r[key] for r in rows])
        bars = ax.barh(LABELS, vals, left=left, label=label, color=color, height=0.52)
        ax.bar_label(bars, labels=[str(v) for v in vals], label_type="center", color="white" if color == TEAL else INK, fontsize=11)
        left += vals
    ax.invert_yaxis()
    ax.set_xlim(0, 220)
    ax.set_xticks([0, 36, 72, 108, 144, 180, 216])
    ax.set_xlabel("Post-exposure checkpoint pairs (216 per method)")
    ax.set_title("Paired outcomes retain changes in both directions", loc="left", fontsize=18, pad=24)
    fig.legend(*ax.get_legend_handles_labels(), loc="lower center", bbox_to_anchor=(0.5, 0.07), ncol=4, frameon=False, fontsize=10)
    fig.text(0.5, 0.02, "Before exposure: all 432 pairs had identical requests / final texts and were both correct.\nLater checkpoints include effects of prior model outputs on carriers; they are not fixed-carrier interventions.", ha="center", fontsize=10)
    fig.tight_layout(rect=(0, 0.19, 1, 1))
    save(fig, "03_paired_outcomes")

    fig, ax = plt.subplots(figsize=(14, 5.7))
    ax.set(xlim=(0, 1), ylim=(0, 1))
    ax.axis("off")
    ax.text(0, 0.97, "One target valid time, three official advisories", fontsize=20, weight="bold")
    ax.text(0, 0.87, "Francine | Target: 2024-09-10 18:00 UTC | Maximum sustained wind (KT)", fontsize=13)
    for idx, p in enumerate(data["source_example"]["products"]):
        x = 0.01 + idx * 0.337
        color = ORANGE if idx == 1 else TEAL
        ax.add_patch(FancyBboxPatch((x, 0.22), 0.30, 0.51, boxstyle="round,pad=0.008,rounding_size=0.018",
                                   facecolor="#f1f6f5", edgecolor=color, linewidth=1.5))
        ax.text(x + 0.016, 0.665, f"Advisory {idx + 5:03d}", fontsize=16, weight="bold")
        ax.text(x + 0.016, 0.58, p["issued_at"][:16].replace("T", " ") + " UTC", fontsize=11)
        if p["target_row"]:
            row = p["target_row"]
            ax.text(x + 0.016, 0.42, f"{row['max_sustained_wind_kt']} KT", fontsize=29, color=color, weight="bold")
            ax.text(x + 0.016, 0.29, f"Explicit target row\nSource lines {row['forecast_line']} and {row['wind_line']}", fontsize=11)
        else:
            ax.text(x + 0.016, 0.44, "No explicit\ntarget row", fontsize=21, color=color, weight="bold")
            ax.text(x + 0.016, 0.275, "Do not interpolate from nearby times", fontsize=10)
        if idx < 2:
            ax.annotate("", xy=(x + 0.331, 0.48), xytext=(x + 0.306, 0.48), arrowprops={"arrowstyle": "->", "color": INK})
    ax.text(0.01, 0.10, "Proposed task rule: latest visible product with an explicit row for this exact valid time.", fontsize=12)
    ax.text(0.01, 0.025, "Verified source example only: native forecast-task LLM evaluation has not run.\nCanonical line locators were checked against the archived raw HTML bytes. Issuance does not establish historical availability.", fontsize=10)
    save(fig, "04_forecast_example")


if __name__ == "__main__":
    data = extract()
    charts(data)
    checked = verify_source_hashes()
    dump("evidence/validation.json", {"status": "passed", "source_hashes_unchanged": checked,
                                     "accepted_scores_reconciled": True, "raw_excerpt_hashes_checked": True,
                                     "figure_stems": 4, "model_calls": 0,
                                     "scope": "Presentation arithmetic, cited source bytes and selected input preservation; not a rerun of full benchmark acceptance."})
    print(f"Built 4 figures (PNG/SVG/PDF), 2 CSV tables and source excerpts; {checked} input hashes unchanged.")
