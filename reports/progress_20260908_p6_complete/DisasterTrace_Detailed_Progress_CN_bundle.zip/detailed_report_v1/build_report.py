"""Build an explanatory A4 PDF and editable Markdown evidence bundle."""

import hashlib
import json
import re
from pathlib import Path
from xml.sax.saxutils import escape

import markdown
import pymupdf
from bs4 import BeautifulSoup, NavigableString, Tag
from PIL import Image as PILImage, ImageDraw, ImageFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, Frame, Image, KeepTogether, PageBreak,
    PageTemplate, Paragraph, Spacer, Table, TableStyle, XPreformatted,
)
from reportlab.platypus.tableofcontents import TableOfContents


OUT = Path(__file__).resolve().parent
BUNDLE = OUT.parent
ROOT = BUNDLE.parents[1]
REPO = ROOT / "development/disastertrace-next/disastertrace-starter"
FONT_DIR = ROOT / "reports/progress_20260908/fonts"
MD = OUT / "DisasterTrace_Detailed_Progress_CN.md"
PDF = OUT / "DisasterTrace_Detailed_Progress_CN.pdf"
INK, TEAL, MUTED, PALE = "#19313C", "#147D78", "#627077", "#E5EFEB"
PAGE_W, PAGE_H = A4
MARGIN, TOP, BOTTOM = 48, 52, 47
WIDTH = PAGE_W - 2 * MARGIN
EXPECTED_TEXT = []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def facts():
    (OUT / "evidence").mkdir(exist_ok=True)
    p6 = json.loads((BUNDLE / "evidence/presentation_data.json").read_text())
    p7 = json.loads((BUNDLE / "pdf_v2_p7_offline/p7_data.json").read_text())
    history = json.loads((ROOT / "reports/progress_20260908/report_data.json").read_text())
    fields = REPO / "artifacts/p6_live_v1/analysis/fields.jsonl"
    with fields.open() as handle:
        example = next(json.loads(line) for line in handle if '"superseded_same_value"' in line)
    assert example["primary_error"] == "superseded_same_value"
    assert example["expected"]["value"] == example["predicted"]["value"] == 60
    assert example["citation_details"][0]["value_supported"]
    assert not example["citation_details"][0]["current_authority_correct"]
    assert example["expected"]["evidence"] != example["predicted"]["evidence"]
    (OUT / "evidence/p6_actual_error.json").write_text(json.dumps(example, ensure_ascii=False, indent=2) + "\n")
    early = {}
    for name in ("P1", "P2_v1", "P2_v2"):
        rows = history["early_runs"][name]["methods"].values()
        early[name] = {"received": 90 if name == "P1" else 270,
                       "valid": sum(r["counts"]["valid" if name == "P1" else "schema_valid"] for r in rows),
                       "correct": sum(r["counts"]["all_correct"] for r in rows)}
    t6 = history["early_runs"]["T6"]
    early["T6_explicit_8192"] = {
        "received": sum(c["received"] for c in t6["cell_counts"] if c["cell_id"].startswith("explicit_8192")),
        "valid": sum(c["schema_valid"] for c in t6["cell_counts"] if c["cell_id"].startswith("explicit_8192")),
        "correct": sum(v["all_correct_checkpoints"]["numerator"] for k, v in t6["metrics"].items() if k.startswith("explicit_8192")),
    }
    assert early["P1"] == {"received": 90, "valid": 68, "correct": 67}
    assert early["P2_v1"] == {"received": 270, "valid": 264, "correct": 262}
    assert early["P2_v2"]["correct"] == 270 and early["T6_explicit_8192"]["correct"] == 83
    for phase in ("P3", "P4", "revision_chain", "irrelevant_scope", "late_stale_replay"):
        entries = history["measured"][phase]["methods"].values()
        early[phase] = {"received": sum(r["checkpoints"] for r in entries),
                        "valid": sum(r["schema_valid"] for r in entries),
                        "correct": sum(r["all_correct"] for r in entries)}
    assert early["P3"]["correct"] == 193 and early["P4"]["correct"] == 490
    assert sum(early[p]["correct"] for p in ("revision_chain", "irrelevant_scope", "late_stale_replay")) == 1360
    assert p6["counts"]["checkpoints"] == 2160 and p6["counts"]["all_correct"] == 1861
    assert p7["counts"]["included_checkpoints"] == 257 and p7["model_generations"] == 0
    assert (p7["counts"]["statuses"]["DISSIPATED"] + p7["counts"]["statuses"]["not_stated"]) * 6 == 486
    paths = [MD, BUNDLE / "evidence/presentation_data.json", BUNDLE / "pdf_v2_p7_offline/p7_data.json",
             ROOT / "reports/progress_20260908/report_data.json", fields,
             REPO / "artifacts/p7_forecast_task_v1/PROTOCOL.md",
             REPO / "artifacts/p7_forecast_task_v1/FINDINGS.md",
             REPO / "artifacts/p7_forecast_task_v1/NEXT_EXECUTION_PLAN.md",
             REPO / "artifacts/p7_forecast_task_v1/OFFLINE_ACCEPTANCE.json"]
    data = {"scope": "P6 accepted live results and P7 accepted offline milestone",
            "p6": p6, "p7": p7, "historical_results": early,
            "actual_error_selection": "First superseded_same_value field in frozen file order; not selected by method performance.",
            "read_source_hashes": {str(path.relative_to(ROOT)): sha(path) for path in paths},
            "report_creation_model_calls": 0, "report_creation_gpu_jobs": 0}
    (OUT / "evidence/report_facts.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    return data


def figures():
    folder = OUT / "figures"
    folder.mkdir(exist_ok=True)
    p6 = pymupdf.open(BUNDLE / "pdf_v1/DisasterTrace_P6_Presentation_CN.pdf")
    p7 = pymupdf.open(BUNDLE / "pdf_v2_p7_offline/DisasterTrace_P6_P7_Progress_CN.pdf")
    for doc, index, name in ((p6, 6, "p6_reliability"), (p6, 7, "p6_errors"), (p7, 11, "p7_program_controls")):
        doc[index].get_pixmap(matrix=pymupdf.Matrix(1.7, 1.7), clip=pymupdf.Rect(54, 185, 1221, 666), alpha=False).save(folder / f"{name}.png")


def styles():
    base = getSampleStyleSheet()
    result = {}
    result["body"] = ParagraphStyle("CNBody", fontName="NotoRegular", fontSize=10.5, leading=17,
                                     textColor=colors.HexColor(INK), spaceAfter=8, wordWrap="CJK", allowWidows=0, allowOrphans=0)
    result["h1"] = ParagraphStyle("CNChapter", parent=result["body"], fontName="NotoBold", fontSize=18,
                                   leading=25, spaceBefore=20, spaceAfter=12, keepWithNext=True, textColor=colors.HexColor(TEAL))
    result["h2"] = ParagraphStyle("CNSubsection", parent=result["body"], fontName="NotoBold", fontSize=12.3,
                                   leading=18, spaceBefore=11, spaceAfter=7, keepWithNext=True)
    result["caption"] = ParagraphStyle("CNCaption", parent=result["body"], fontSize=9, leading=14,
                                        textColor=colors.HexColor(MUTED), spaceAfter=12)
    result["quote"] = ParagraphStyle("CNQuote", parent=result["body"], backColor=colors.HexColor(PALE),
                                      leftIndent=9, rightIndent=9, borderPadding=8, spaceBefore=6, spaceAfter=12)
    result["code"] = ParagraphStyle("CNCode", parent=result["body"], fontSize=9, leading=13.2,
                                     backColor=colors.HexColor("#F0F3F1"), borderPadding=7, spaceBefore=5, spaceAfter=11)
    result["toc0"] = ParagraphStyle("TocLevel0", parent=result["body"], fontSize=10.5, leading=16,
                                     firstLineIndent=0, leftIndent=0, spaceBefore=6, spaceAfter=3)
    result["toc1"] = ParagraphStyle("TocLevel1", parent=result["body"], fontSize=9.2, leading=13,
                                     firstLineIndent=0, leftIndent=12, spaceBefore=0, spaceAfter=1, textColor=colors.HexColor(MUTED))
    result["cover_title"] = ParagraphStyle("CoverTitle", parent=result["body"], fontName="NotoBold", fontSize=38, leading=53, spaceAfter=16)
    result["cover_subtitle"] = ParagraphStyle("CoverSubtitle", parent=result["body"], fontName="NotoBold", fontSize=23, leading=34, textColor=colors.HexColor(TEAL), spaceAfter=28)
    return result


def inline(node):
    if isinstance(node, NavigableString):
        return escape(str(node))
    if not isinstance(node, Tag):
        return ""
    body = "".join(inline(child) for child in node.children)
    if node.name in ("strong", "b"):
        return f'<font name="NotoBold">{body}</font>'
    if node.name in ("em", "i"):
        return f'<font color="{TEAL}">{body}</font>'
    if node.name == "code":
        return f'<font color="{TEAL}">{body}</font>'
    if node.name == "br":
        return "<br/>"
    if node.name == "a":
        return f'<font color="{TEAL}">{body}</font>'
    return body


def paragraph(node, style, prefix=""):
    text = node.get_text("", strip=False)
    if text.strip():
        EXPECTED_TEXT.append(text.strip())
    return Paragraph(prefix + inline(node), style)


def table(node, sty):
    raw_rows = [row.find_all(["th", "td"], recursive=False) for row in node.find_all("tr")]
    cols = max(len(row) for row in raw_rows)
    size = 8.2 if cols >= 6 else 9.0 if cols >= 4 else 9.4
    cellstyle = ParagraphStyle("Cell", parent=sty["body"], fontSize=size, leading=size*1.5, spaceAfter=0)
    headerstyle = ParagraphStyle("CellHeader", parent=cellstyle, fontName="NotoBold", textColor=colors.white)
    weights = []
    for index in range(cols):
        lengths = [len(row[index].get_text()) for row in raw_rows if index < len(row)]
        mean = sum(lengths) / len(lengths)
        weights.append(max(5, min(32, mean)) ** .68)
    widths = [WIDTH * w / sum(weights) for w in weights]
    if cols == 7:
        widths = [WIDTH * x for x in (.09, .13, .12, .12, .18, .18, .18)]
    result = []
    for i, row in enumerate(raw_rows):
        values = [paragraph(cell, headerstyle if i == 0 else cellstyle) for cell in row]
        result.append(values + [""]*(cols-len(values)))
    output = Table(result, colWidths=widths, repeatRows=1, hAlign="LEFT")
    output.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(INK)),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F0F3F0")]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LINEBELOW", (0, 0), (-1, 0), .6, colors.HexColor(TEAL)),
        ("LINEBELOW", (0, -1), (-1, -1), .5, colors.HexColor("#D7DEDB")),
    ]))
    before = Spacer(1, 4)
    before.keepWithNext = True
    # Leave the table visible to a preceding heading's keepWithNext rule.
    if output.wrap(WIDTH, PAGE_H-TOP-BOTTOM)[1] <= 450:
        output.splitByRow = 0
    return [before, output, Spacer(1, 12)]


def code(node, sty):
    text = node.get_text()
    EXPECTED_TEXT.append(text)
    wrapped = []
    for source_line in text.rstrip().splitlines():
        line = ""
        for char in source_line:
            if line and pdfmetrics.stringWidth(line + char, "NotoRegular", 9) > WIDTH-18:
                wrapped.append(line)
                line = "  " + char
            else:
                line += char
        wrapped.append(line)
    return XPreformatted(escape("\n".join(wrapped)), sty["code"])


class ReportDoc(BaseDocTemplate):
    def afterFlowable(self, flowable):
        if hasattr(flowable, "toc_level"):
            self.canv.bookmarkPage(flowable.toc_key)
            self.canv.addOutlineEntry(flowable.toc_text, flowable.toc_key, flowable.toc_level, closed=True)
            if flowable.toc_level == 0:
                self.notify("TOCEntry", (0, flowable.toc_text, self.page, flowable.toc_key))


def header_footer(c, doc):
    c.saveState()
    if doc.page > 1:
        c.setFont("NotoRegular", 8.3)
        c.setFillColor(colors.HexColor(MUTED))
        c.drawString(MARGIN, PAGE_H-30, "DISASTERTRACE  /  P6 实测与 P7 原生任务离线进展")
        c.setStrokeColor(colors.HexColor("#D7DEDB"))
        c.line(MARGIN, PAGE_H-39, PAGE_W-MARGIN, PAGE_H-39)
    c.setFont("NotoRegular", 8)
    c.setFillColor(colors.HexColor(MUTED))
    c.drawString(MARGIN, 26, "详细理解版 · 2026-09-08 · 模型成绩与程序诊断分别报告")
    c.drawRightString(PAGE_W-MARGIN, 26, str(doc.page))
    c.restoreState()


def build(sty):
    doc = ReportDoc(str(PDF), pagesize=A4, leftMargin=MARGIN, rightMargin=MARGIN,
                    topMargin=TOP, bottomMargin=BOTTOM,
                    title="DisasterTrace 详细进展说明：P6 与 P7", author="DisasterTrace",
                    subject="从任务原理、真实模型结果到原生任务离线验收与后续计划")
    frame = Frame(MARGIN, BOTTOM, WIDTH, PAGE_H-TOP-BOTTOM, leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    doc.addPageTemplates(PageTemplate(id="Report", frames=[frame], onPage=header_footer))
    story = [Spacer(1, 67), Paragraph("DisasterTrace", sty["cover_title"]),
             Paragraph("详细进展说明", sty["cover_subtitle"]),
             Paragraph("从零理解任务原理、已有结果与下一步", sty["h2"]),
             Paragraph("覆盖已验收的 P6 真实模型评测，以及 P7 官方预报原生任务离线验收。适合先通读理解，再精简为研究汇报。", sty["body"]),
             Spacer(1, 22)]
    intro = [
        [Paragraph("<font name='NotoBold'>P6：真实模型结果</font>", sty["body"]), Paragraph("2,160 条回答<br/>1,861 条完整正确 · 86.2%", sty["body"])],
        [Paragraph("<font name='NotoBold'>P7：原生任务离线验收</font>", sty["body"]), Paragraph("46 个目标 · 257 个查询<br/>模型调用为 0", sty["body"])],
        [Paragraph("<font name='NotoBold'>下一步</font>", sty["body"]), Paragraph("原生采集与四 worker 聚合<br/>预检后冻结首次 1,542 机会实测", sty["body"])],
    ]
    box = Table(intro, colWidths=[WIDTH*.47, WIDTH*.53])
    box.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),colors.HexColor(PALE)),("VALIGN",(0,0),(-1,-1),"TOP"),
                             ("TOPPADDING",(0,0),(-1,-1),13),("BOTTOMPADDING",(0,0),(-1,-1),11),
                             ("LEFTPADDING",(0,0),(-1,-1),13),("RIGHTPADDING",(0,0),(-1,-1),13)]))
    story += [box, Spacer(1, 25), Paragraph("本文包含教学示例、真实错误记录、统计单位解释、阶段结果、官方原文案例及实施路线。教学例与真实模型/官方来源案例分别标明。", sty["body"]),
              PageBreak(), Paragraph("目录", sty["cover_subtitle"])]
    toc = TableOfContents()
    toc.levelStyles = [sty["toc0"], sty["toc1"]]
    toc.dotsMinLevel = 0
    story += [Paragraph("目录列出 17 个章节；PDF 书签进一步列出各节，可直接定位术语、结果和实施计划。", sty["caption"]), toc, PageBreak()]
    html = markdown.markdown(MD.read_text(), extensions=["tables", "fenced_code"])
    soup = BeautifulSoup(html, "html.parser")
    heading_index = 0
    grouped_captions = set()
    for node in soup.children:
        if not isinstance(node, Tag) or node.name == "h1" or id(node) in grouped_captions:
            continue
        if node.name in ("h2", "h3"):
            heading_index += 1
            level = 0 if node.name == "h2" else 1
            heading = paragraph(node, sty["h1"] if level == 0 else sty["h2"])
            heading.toc_level, heading.toc_key, heading.toc_text = level, f"section_{heading_index}", node.get_text()
            story.append(heading)
        elif node.name == "p":
            picture = node.find("img")
            if picture:
                path = OUT / picture["src"]
                with PILImage.open(path) as im:
                    height = WIDTH * im.height / im.width
                block = [Spacer(1, 8), Image(str(path), width=WIDTH, height=height), Spacer(1, 6)]
                caption = node.find_next_sibling("p")
                if caption and re.match(r"图\s*\d+[：:]", caption.get_text()):
                    block.append(paragraph(caption, sty["caption"]))
                    grouped_captions.add(id(caption))
                story.append(KeepTogether(block))
            else:
                style = sty["caption"] if re.match(r"图\s*\d+[：:]", node.get_text()) else sty["body"]
                story.append(paragraph(node, style))
        elif node.name in ("ul", "ol"):
            for index, item in enumerate(node.find_all("li", recursive=False), 1):
                prefix = f"{index}. " if node.name == "ol" else "• "
                story.append(paragraph(item, sty["body"], prefix=prefix))
        elif node.name == "table":
            story.extend(table(node, sty))
        elif node.name == "pre":
            story.append(KeepTogether([code(node, sty)]))
        elif node.name == "blockquote":
            for item in node.find_all("p", recursive=False):
                story.append(paragraph(item, sty["quote"]))
        elif node.name == "hr":
            story.append(Spacer(1, 10))
    doc.multiBuild(story)


def validate(data):
    doc = pymupdf.open(PDF)
    compact = lambda s: re.sub(r"\s+", "", s)
    full_text = compact("\n".join(page.get_text() for page in doc))
    missing = [text for text in EXPECTED_TEXT if compact(text) not in full_text]
    # A repeated table header can interrupt a paragraph crossing a page boundary.
    fragments = []
    for text in missing:
        words = compact(text)
        if any(words[i:i+16] not in full_text for i in range(0, len(words), 16)):
            fragments.append(text[:160])
    assert not fragments, fragments[:10]
    clipped = []
    font_names = set()
    for index, page in enumerate(doc, 1):
        assert abs(page.rect.width-PAGE_W)<.1 and abs(page.rect.height-PAGE_H)<.1
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                for span in line["spans"]:
                    box = pymupdf.Rect(span["bbox"])
                    if box.x0 < -.1 or box.y0 < -.1 or box.x1 > PAGE_W+.1 or box.y1 > PAGE_H+.1:
                        clipped.append((index, span["text"]))
                    font_names.add(span["font"])
    assert not clipped, clipped
    fonts = {f for p in doc for f in p.get_fonts() if "Noto" in f[3]}
    assert fonts and all(doc.extract_font(f[0])[3] for f in fonts)
    assert len([item for item in doc.get_toc() if item[0] == 1]) == 17
    preview = OUT / "preview"
    preview.mkdir(exist_ok=True)
    face = ImageFont.truetype(str(FONT_DIR / "NotoSansSC-Regular.ttf"), 18)
    for index, page in enumerate(doc, 1):
        page.get_pixmap(matrix=pymupdf.Matrix(1.5, 1.5), alpha=False).save(preview / f"page_{index:02d}.png")
    for batch, start in enumerate(range(0, len(doc), 8), 1):
        sheet = PILImage.new("RGB", (1240, 924), "#DCE3DF")
        draw = ImageDraw.Draw(sheet)
        for local, index in enumerate(range(start, min(start+8, len(doc)))):
            im = PILImage.open(preview / f"page_{index+1:02d}.png").convert("RGB")
            im.thumbnail((286, 405), PILImage.Resampling.LANCZOS)
            x, y = 12+local%4*308, 10+local//4*456
            sheet.paste(im, (x,y))
            draw.text((x+3,y+414), f"第 {index+1} 页", font=face, fill=INK)
        sheet.save(preview / f"contact_sheet_{batch}.jpg", quality=91)
    for relative, expected in data["read_source_hashes"].items():
        assert sha(ROOT / relative) == expected, relative
    result = {"status": "passed", "pages": len(doc), "chapters": 17, "bookmarks": len(doc.get_toc()),
              "expected_text_blocks": len(EXPECTED_TEXT), "all_text_recovered": True,
              "clipped_text_spans": 0, "embedded_font_subsets": len(fonts), "page_size": "A4",
              "pdf_bytes": PDF.stat().st_size, "pdf_sha256": sha(PDF), "model_calls": 0,
              "visual_review_pending": True, "figures": 3,
              "source_files_unchanged": len(data["read_source_hashes"])}
    (OUT / "evidence/pdf_validation.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    for name in ("Regular", "Bold"):
        pdfmetrics.registerFont(TTFont("Noto"+name, str(FONT_DIR / f"NotoSansSC-{name}.ttf")))
    data = facts()
    figures()
    build(styles())
    validate(data)
