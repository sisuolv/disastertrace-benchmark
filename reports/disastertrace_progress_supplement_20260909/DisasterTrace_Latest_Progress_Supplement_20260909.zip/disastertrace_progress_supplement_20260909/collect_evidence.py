"""Snapshot existing results for a reading supplement; never execute a model."""

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PROJECT = ROOT / "development/disastertrace-next/disastertrace-starter"
BASELINE = ROOT / "reports/disastertrace_paper_narrative_20260908"
METHODS = ("snapshot", "structured_state", "answer_history")
PHASES = {
    "p7": "p7_forecast_live_v1",
    "p8": "p8_carrier_representation_v1",
    "p9": "p9_forecast_model_v1",
    "p10": "p10_forecast_cohort_v1",
    "p11": "p11_cohort_live_v1",
    "p12": "p12_compact_grammar_v1",
    "p13": "p13_prompt_role_v1",
    "p14": "p14_qwen_prompt_role_v1",
}
FILES = {}
CHECKS = []


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def read(path, copy_to=None, parse=True):
    raw = path.read_bytes()
    key = str(path.relative_to(ROOT))
    entry = {"sha256": digest(raw), "bytes": len(raw)}
    if copy_to:
        destination = OUT / copy_to
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
        entry["copy"] = copy_to
    FILES[key] = entry
    return json.loads(raw) if parse else raw


def check(name, result):
    assert result, name
    CHECKS.append(name)


def csv_table(name, rows):
    path = OUT / "tables" / name
    path.parent.mkdir(exist_ok=True)
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    if (OUT / "evidence/snapshot.json").exists():
        raise SystemExit("Snapshot already exists. Create a new version to collect newer evidence.")
    started = datetime.now(timezone.utc).isoformat()
    baseline = read(BASELINE / "evidence/snapshot.json", "baseline/evidence_snapshot.json")
    for name in ("DisasterTrace_Paper_Pre_CN.pdf", "DisasterTrace_Paper_Storyline_CN.md"):
        read(BASELINE / name, "baseline/" + name, parse=False)
    read(BASELINE / "evidence/literature/references.json", "baseline/references.json")
    acceptances = {}
    inventories = {}
    for phase, directory in PHASES.items():
        folder = PROJECT / "artifacts" / directory
        name = "OFFLINE_ACCEPTANCE.json" if phase == "p10" else "COMPLETED_ACCEPTANCE.json"
        path = folder / name
        read(folder / "FINDINGS.md", f"evidence/sources/{phase}_FINDINGS.md", parse=False)
        if path.exists():
            data = read(path)
            inventories[phase] = data["evidence_sha256"]
            excerpt = {k: v for k, v in data.items() if k != "evidence_sha256"}
            excerpt["evidence_inventory_entries"] = len(inventories[phase])
            excerpt["excerpt_not_full_acceptance"] = True
            excerpt["source_sha256"] = FILES[str(path.relative_to(ROOT))]["sha256"]
            write_json(OUT / f"evidence/sources/{phase}_acceptance_excerpt.json", excerpt)
            acceptances[phase] = {k: excerpt.get(k) for k in (
                "acceptance_id", "status", "at", "evidence_inventory_entries", "source_sha256"
            )}
            acceptances[phase]["present_at_snapshot"] = True
        else:
            acceptances[phase] = {"present_at_snapshot": False, "path_checked": str(path.relative_to(ROOT))}
    addon_path = PROJECT / "artifacts/autonomy_10h_v1/p11_review_addendum_v1/COMPLETED_ACCEPTANCE.json"
    addon = read(addon_path, "evidence/sources/p11_review_addendum_acceptance.json")
    inventories["p11_addendum"] = addon["evidence_sha256"]
    acceptances["p11_addendum"] = {
        "acceptance_id": addon["acceptance_id"], "status": addon["status"],
        "evidence_inventory_entries": len(addon["evidence_sha256"]),
        "previously_omitted_files": len(addon["previously_omitted_review_files_sha256"]),
    }
    runs = {}
    for key in ("p7_qwen3", "p8_qwen3", "p9_deepseek_r1", "p11_qwen3",
                "p11_deepseek_r1", "p12_qwen3", "p12_deepseek_r1", "p13_deepseek_r1", "p14_qwen3"):
        phase = key.split("_")[0]
        folder = PROJECT / "artifacts" / PHASES[phase]
        location = None
        if phase in ("p7", "p8", "p9"):
            final = folder / ("finalization_02" if phase == "p9" else "finalization_01")
            analysis_path = folder / "analysis_01.json"
        else:
            location = read(PROJECT / "artifacts/autonomy_10h_v1/reviews_continuation_v2" /
                            f"LOCATION_{key}.json", f"evidence/sources/{key}_LOCATION.json")
            final = PROJECT / location["finalization"]
            analysis_path = PROJECT / location["review_directory"] / f"{key}.json"
        status_path = final / "FINAL_STATUS.json"
        status = read(status_path, f"evidence/sources/{key}_FINAL_STATUS.json")
        report_path = final / "global_report.json"
        report = read(report_path)
        report_sha = FILES[str(report_path.relative_to(ROOT))]["sha256"]
        check(key + ": report SHA bound by final status", report_sha == status["report_sha256"])
        check(key + ": passed report finalization", status["status"] == "passed")
        check(key + ": report identity", report["report_id"] == status["report_id"])
        for filename, hash_key in (("token_replay.json", "token_replay_sha256"),
                                   ("cpu_relocated/receipt.json", "cpu_relocation_sha256")):
            path = final / filename
            receipt = read(path, f"evidence/sources/{key}_{path.name}")
            check(key + ": " + filename, receipt["status"] == "passed" and
                  FILES[str(path.relative_to(ROOT))]["sha256"] == status[hash_key])
        for operation in ("report", "verify_report", "token_replay", "cpu_relocation"):
            path = final / f"{operation}_result.json"
            result = read(path, f"evidence/sources/{key}_{operation}_result.json")
            check(key + ": recorded command " + operation, result["exit_code"] == 0)
        score = report["scores"]["counts"]
        counts = report["counts"]
        check(key + ": opportunity conservation", counts["planned"] == counts["raw_returned"] +
              counts["unattempted"] + counts["unknown_outcomes"])
        check(key + ": disjoint errors conserve denominator", sum(score["errors"].values()) == counts["planned"])
        check(key + ": score/return agreement", score["received"] == counts["raw_returned"])
        excerpt = {k: v for k, v in report.items() if k not in ("scores", "workers", "paired_representation")}
        excerpt["scores"] = {k: v for k, v in report["scores"].items() if k != "records"}
        excerpt["source_sha256"] = report_sha
        excerpt["excerpt_not_full_report"] = True
        if "paired_representation" in report:
            excerpt["paired_representation"] = report["paired_representation"]
        write_json(OUT / f"evidence/sources/{key}_report_excerpt.json", excerpt)
        item = {
            "phase": phase, "counts": counts, "scores": score,
            "methods": report["scores"]["breakdowns"].get("method", {}),
            "breakdowns": report["scores"]["breakdowns"],
            "both_repeats_legacy_field": report["scores"]["both_repeats"],
            "whole_trajectories": report["scores"]["whole_trajectories"],
            "report_id": report["report_id"], "report_sha256": report_sha,
            "execution_id": status["execution_id"], "finalized_at": status["finished_at"],
            "finalization": str(final.relative_to(PROJECT)), "platform_jobs": status["platform_jobs"],
            "collection_complete": counts["raw_returned"] == counts["planned"],
            "strict_percent_planned": 100 * score["all_correct"] / counts["planned"],
            "strict_percent_returned_diagnostic": 100 * score["all_correct"] / counts["raw_returned"],
        }
        if "paired_representation" in report:
            item["paired_representation"] = {k: v for k, v in report["paired_representation"].items() if k != "records"}
        paths_to_bind = [report_path, status_path]
        if analysis_path.exists():
            analysis = read(analysis_path, f"evidence/sources/{key}_analysis.json")
            check(key + ": analysis report identity", analysis.get("report_id", analysis.get("source_report_id")) == report["report_id"])
            item["analysis"] = {k: v for k, v in analysis.items() if k != "records"}
            if location:
                check(key + ": analysis SHA and ID", analysis["analysis_id"] == location["analysis_id"] and
                      FILES[str(analysis_path.relative_to(ROOT))]["sha256"] == location["analysis_sha256"])
                check(key + ": location final-status SHA", FILES[str(status_path.relative_to(ROOT))]["sha256"] == location["final_status_sha256"])
                check(key + ": analysis record denominator", len(analysis["records"]) == counts["planned"])
                check(key + ": analysis record totals", sum(r["score"]["all_correct"] for r in analysis["records"]) == score["all_correct"])
                for operation in ("analyze", "verify"):
                    path = analysis_path.parent / f"{key}_{operation}_result.json"
                    result = read(path, f"evidence/sources/{key}_{operation}_result.json")
                    check(key + ": recorded analysis " + operation, result["exit_code"] == 0)
            paths_to_bind.append(analysis_path)
        bindings = []
        for path in paths_to_bind:
            sha = FILES[str(path.relative_to(ROOT))]["sha256"]
            owners = [name for name in (phase, "p11_addendum" if phase == "p11" else phase)
                      if inventories.get(name, {}).get(str(path.relative_to(PROJECT))) == sha]
            if acceptances[phase]["present_at_snapshot"]:
                check(key + ": acceptance covers " + path.name, bool(owners))
            bindings.append({"source": str(path.relative_to(PROJECT)), "covered_by": sorted(set(owners))})
        item["acceptance_bindings"] = bindings
        runs[key] = item
    auxiliary = {}
    for filename in ("context_censoring_v1.json", "pair_coverage_v1.json"):
        auxiliary[filename[:-5]] = read(PROJECT / "artifacts/autonomy_10h_v1" / filename,
                                        "evidence/sources/" + filename)
    for filename in ("POST_WINDOW_PRIORITIES.md", "ACCEPTANCE_COVERAGE_ADDENDUM.md"):
        read(PROJECT / "artifacts/autonomy_10h_v1" / filename, "evidence/sources/" + filename, parse=False)
    read(PROJECT / "artifacts/p12_compact_grammar_v1/CONTEXT_STOP_WORKER0.md",
         "evidence/sources/CONTEXT_STOP_WORKER0.md", parse=False)
    p10 = read(PROJECT / "artifacts/p10_forecast_cohort_v1/validation_01/FINAL_STATUS.json",
               "evidence/sources/p10_FINAL_STATUS.json")
    snapshot = {
        "schema_version": "disastertrace_presentation_supplement_v1",
        "collection_started_at_utc": started,
        "snapshot_at_utc": datetime.now(timezone.utc).isoformat(),
        "baseline_at_utc": baseline["snapshot_at_utc"],
        "scope": "Frozen reading supplement, not a complete scientific evidence archive or new model execution.",
        "model_calls": 0, "gpu_jobs": 0, "full_underlying_audits_rerun": False,
        "global_archive_closure_verified_here": False,
        "baseline_controlled": baseline["p6"], "runs": runs,
        "acceptances": acceptances, "expanded_offline_status": p10, "auxiliary": auxiliary,
        "sources": FILES, "checks": CHECKS,
    }
    write_json(OUT / "evidence/snapshot.json", snapshot)
    run_rows, method_rows, status_rows, error_rows = [], [], [], []
    for key, run in runs.items():
        c, s = run["counts"], run["scores"]
        run_rows.append({"condition": key, "planned": c["planned"], "returned": c["raw_returned"],
                         "shape_valid": s["shape_valid"], "strict_correct": s["all_correct"],
                         "strict_percent_planned": run["strict_percent_planned"],
                         "unattempted": c["unattempted"], "unknown": c["unknown_outcomes"],
                         "strict_percent_returned_diagnostic": run["strict_percent_returned_diagnostic"],
                         "collection_complete": run["collection_complete"], "report_id": run["report_id"]})
        for method, d in run["methods"].items():
            method_rows.append({"condition": key, "method": method, "planned": d["planned"],
                                "returned": d["received"], "strict_correct": d["all_correct"],
                                "strict_percent_planned": 100*d["all_correct"]/d["planned"]})
        for name, count in s["errors"].items():
            error_rows.append({"condition": key, "disjoint_precedence_category": name, "count": count})
        if key.startswith(("p11_", "p12_", "p13_", "p14_")):
            for group, methods in run["analysis"]["cross_tables"]["status"].items():
                status_rows.append({"condition": key, "reference_status": group,
                                    **{name: sum(m[field] for m in methods.values()) for name, field in
                                       (("planned", "planned"), ("returned", "received"), ("strict_correct", "all_correct"))}})
    csv_table("model_results.csv", run_rows)
    csv_table("method_results.csv", method_rows)
    csv_table("status_results.csv", status_rows)
    csv_table("disjoint_errors.csv", error_rows)
    print(json.dumps({"snapshot_at": snapshot["snapshot_at_utc"], "runs": len(runs),
                      "source_files": len(FILES), "checks": len(CHECKS), "p14_acceptance": acceptances["p14"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
