"""Cross-check supplement tables against preserved, hashed result analyses."""

import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path


OUT = Path(__file__).resolve().parent
CHECKS = []


def load(path):
    return json.loads(path.read_text())


def check(label, result):
    assert result, label
    CHECKS.append(label)


def table(name):
    with (OUT / "tables" / name).open(newline="") as stream:
        return list(csv.DictReader(stream))


def write_table(name, rows):
    with (OUT / "tables" / name).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    snapshot = load(OUT / "evidence/snapshot.json")
    runs = snapshot["runs"]
    for path, entry in snapshot["sources"].items():
        if "copy" in entry:
            check("source copy: " + entry["copy"],
                  hashlib.sha256((OUT / entry["copy"]).read_bytes()).hexdigest() == entry["sha256"])
    for row in table("model_results.csv"):
        r = runs[row["condition"]]
        n, returned, correct = int(row["planned"]), int(row["returned"]), int(row["strict_correct"])
        check("CSV counts: " + row["condition"],
              n == r["counts"]["planned"] and returned == r["counts"]["raw_returned"] and
              correct == r["scores"]["all_correct"] and int(row["shape_valid"]) == r["scores"]["shape_valid"])
        check("CSV coverage: " + row["condition"],
              returned + int(row["unattempted"]) + int(row["unknown"]) == n)
        check("CSV percentages: " + row["condition"],
              abs(float(row["strict_percent_planned"]) - 100*correct/n) < 1e-10 and
              abs(float(row["strict_percent_returned_diagnostic"]) - 100*correct/returned) < 1e-10)
        excerpt = load(OUT / "evidence/sources" / f"{row['condition']}_report_excerpt.json")
        check("report excerpt agreement: " + row["condition"],
              excerpt["source_sha256"] == r["report_sha256"] and excerpt["counts"] == r["counts"] and
              excerpt["scores"]["counts"] == r["scores"])
    for row in table("method_results.csv"):
        d = runs[row["condition"]]["methods"][row["method"]]
        check("CSV method: " + row["condition"] + "/" + row["method"],
              int(row["planned"]) == d["planned"] and int(row["returned"]) == d["received"] and
              int(row["strict_correct"]) == d["all_correct"])
    for row in table("status_results.csv"):
        d = runs[row["condition"]]["analysis"]["cross_tables"]["status"][row["reference_status"]]
        check("CSV status: " + row["condition"] + "/" + row["reference_status"],
              all(int(row[k]) == sum(v[f] for v in d.values()) for k, f in
                  (("planned", "planned"), ("returned", "received"), ("strict_correct", "all_correct"))))
    for row in table("disjoint_errors.csv"):
        check("CSV error: " + row["condition"] + "/" + row["disjoint_precedence_category"],
              int(row["count"]) == runs[row["condition"]]["scores"]["errors"][row["disjoint_precedence_category"]])
    pair_source = load(OUT / "evidence/sources/pair_coverage_v1.json")
    pair_rows = []
    for name, pair in pair_source["comparisons"].items():
        before = load(OUT / "evidence/sources" / f"{pair['before']}_analysis.json")
        after = load(OUT / "evidence/sources" / f"{pair['after']}_analysis.json")
        left = {r["slot_id"]: r["score"] for r in before["records"]}
        right = {r["slot_id"]: r["score"] for r in after["records"]}
        check(name + ": unique matching slots", len(left) == len(before["records"]) == 2412 and set(left) == set(right))
        coverage, strict = Counter(), Counter()
        cell_correct = {c: [0, 0] for c in ("both_returned", "before_only", "after_only", "neither_returned")}
        for slot, l in left.items():
            r = right[slot]
            cell = ("both_returned" if l["received"] and r["received"] else
                    "before_only" if l["received"] else "after_only" if r["received"] else "neither_returned")
            coverage[cell] += 1
            cell_correct[cell][0] += l["all_correct"]
            cell_correct[cell][1] += r["all_correct"]
            if cell == "both_returned":
                strict[("correct" if l["all_correct"] else "wrong") + "_" +
                       ("correct" if r["all_correct"] else "wrong")] += 1
        target = pair["tables"]["all"]
        check(name + ": paired outcomes reconstructed", all(strict[k] == v for k, v in target["both_returned_correctness_pairs"].items()))
        for cell, expected in target["coverage_cells"].items():
            check(name + ": coverage " + cell, coverage[cell] == expected["slots"] and
                  cell_correct[cell] == [expected["before_correct"], expected["after_correct"]])
        pair_rows.append({"comparison": name, "before": pair["before"], "after": pair["after"],
                          "planned": 2412, **{k: coverage[k] for k in cell_correct},
                          "before_correct": target["before_correct"], "after_correct": target["after_correct"],
                          "difference_both_returned": target["difference_on_both_returned_slots"],
                          "difference_one_sided": target["difference_on_one_sided_return_slots"],
                          "not_a_causal_adjustment": True})
    write_table("paired_coverage.csv", pair_rows)
    p8 = load(OUT / "evidence/sources/p8_qwen3_report_excerpt.json")["paired_representation"]
    check("P8: reconstruct 422 pairs", len(p8["records"]) == 422 and
          dict(Counter(r["outcome"] for r in p8["records"])) == p8["counts"])
    token_diffs = [r["prompt_tokens_text_minus_json"] for r in p8["records"]]
    check("P8: token differences", min(token_diffs) == 36 and max(token_diffs) == 54 and
          abs(sum(token_diffs)/len(token_diffs)-p8["captured_pair_prompt_token_difference"]["mean"]) < 1e-10)
    write_table("representation_pairs.csv", [{"outcome": k, "pairs": v} for k, v in p8["counts"].items()])
    context = load(OUT / "evidence/sources/context_censoring_v1.json")
    context_rows = []
    for phase in ("p11", "p12", "p13"):
        cases = [v for k, v in context["cases"].items() if k.startswith(phase+"_")]
        totals = {k: sum(c[k] for c in cases) for k in (
            "unattempted", "pending_on_initially_blocked_trajectories", "pending_on_other_trajectories")}
        check(phase + ": context conservation", len(cases) == 2 and
              totals["unattempted"] == runs[phase+"_deepseek_r1"]["counts"]["unattempted"] ==
              totals["pending_on_initially_blocked_trajectories"] + totals["pending_on_other_trajectories"])
        check(phase + ": next batch fitting requests", all(c["next_batch_requests_that_fit"] == 3 for c in cases))
        context_rows.append({"condition": phase+"_deepseek_r1", **totals,
                             "later_other_requests_not_assumed_to_fit": True})
    write_table("context_censoring.csv", context_rows)
    trajectory_rows = []
    for key, r in runs.items():
        if key.startswith(("p11_", "p12_", "p13_", "p14_")):
            for method, d in r["analysis"]["targets"].items():
                trajectory_rows.append({"condition": key, "method": method, "repeats": 1, **d})
    write_table("single_repeat_targets.csv", trajectory_rows)
    md = (OUT / "DisasterTrace_Latest_Progress_Supplement_CN.md").read_text()
    for phrase in ("1,542／1,542", "527／1,542", "19／276", "118／422", "143／422", "+5.92",
                   "1,060／2,412", "952／2,412", "952／1,628", "+68 − 176＝−108", "7,498", "7,811",
                   "125 个来源文件", "178 项", "02:44:04", "不是两次重复均成功", "没有重新执行全局"):
        check("document critical claim: " + phrase, phrase in md)
    check("P14 acceptance included at snapshot", snapshot["acceptances"]["p14"]["present_at_snapshot"] and
          snapshot["acceptances"]["p14"]["status"] == "passed")
    check("P14 remains incomplete", not runs["p14_qwen3"]["collection_complete"])
    notes = (OUT / "SUPPLEMENT_SPEAKER_NOTES_CN.md").read_text()
    for key in [f"S{i:02d}" for i in range(1, 13)] + [f"A{i}" for i in range(1, 4)]:
        check("speaker notes: " + key, "## " + key + "｜" in notes)
    for path in OUT.glob("*.md"):
        for target in re.findall(r"\]\(([^)]+)\)", path.read_text()):
            if not target.startswith(("https://", "http://", "#")):
                check("local Markdown link: " + path.name + ":" + target, (path.parent/target).exists())
    patterns = (re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"), re.compile(r"-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----"))
    for path in OUT.rglob("*"):
        if path.is_file() and path.suffix in (".md", ".json", ".csv", ".txt"):
            text = path.read_text()
            check("shareable text scan: " + str(path.relative_to(OUT)), not any(p.search(text) for p in patterns))
    receipt = {"status": "passed", "snapshot_at_utc": snapshot["snapshot_at_utc"],
               "checks": len(CHECKS), "check_names": CHECKS,
               "paired_coverage_reconstructed_from_preserved_analyses": True,
               "raw_outputs_rescored": False, "full_research_audits_rerun": False,
               "model_calls": 0, "gpu_jobs": 0}
    (OUT / "evidence/document_validation.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({k: v for k, v in receipt.items() if k != "check_names"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
