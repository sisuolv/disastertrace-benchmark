"""Build the supplementary vector slides from the frozen reporting snapshot."""

import argparse
import hashlib
import json
import re
from importlib.metadata import version
from pathlib import Path

import pymupdf
from PIL import Image, ImageDraw, ImageFont
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PDF = OUT / "DisasterTrace_Latest_Progress_Supplement_CN.pdf"
W, H = 1280, 720
BG, WHITE, INK = "#F5F3ED", "#FFFFFF", "#19313C"
TEAL, RUST, MUTED, RULE, PALE = "#147D78", "#C45F43", "#627077", "#D7DEDB", "#E5EFEB"
SLIDES = []
FACTS = json.loads((OUT / "evidence/snapshot.json").read_text())
RUNS = FACTS["runs"]


def face(bold=False):
    return "NotoBold" if bold else "NotoRegular"


def wrap(content, width, size, bold=False):
    result = []
    for paragraph in str(content).split("\n"):
        line = ""
        for char in paragraph:
            if line and pdfmetrics.stringWidth(line + char, face(bold), size) > width:
                result.append(line.rstrip())
                line = char.lstrip()
            else:
                line += char
        result.append(line.rstrip())
    return result


class Slide:
    def __init__(self, title, subtitle, source, appendix=False):
        self.number, self.title, self.appendix = len(SLIDES) + 1, title, appendix
        self.items = []
        self.rect(0, 0, W, H, BG)
        self.rect(0, 0, 10, H, TEAL)
        self.text(64, 30, 1100, 25, "DISASTERTRACE  /  " + ("备查材料" if appendix else "最新证据补充"), 15, TEAL, True)
        self.text(64, 76, 1152, 54, title, 35, INK, True)
        self.text(64, 139, 1152, 34, subtitle, 20, MUTED)
        self.line(64, 676, 1216, 676)
        self.text(64, 690, 930, 20, source, 12, MUTED)
        self.text(1003, 690, 155, 20, "2026.09.09", 13, MUTED, align="right")
        self.text(1166, 683, 50, 32, f"{self.number:02d}", 22, TEAL, True, "right")
        SLIDES.append(self)

    def rect(self, x, y, w, h, fill, stroke=None):
        assert min(x, y) >= 0 and x + w <= W and y + h <= H
        self.items.append(dict(kind="rect", x=x, y=y, w=w, h=h, fill=fill, stroke=stroke))

    def line(self, x1, y1, x2, y2, color=RULE, width=1):
        self.items.append(dict(kind="line", x1=x1, y1=y1, x2=x2, y2=y2, color=color, width=width))

    def text(self, x, y, w, h, content, size=23, color=INK, bold=False, align="left"):
        lines = wrap(content, w, size, bold)
        leading = size * 1.31
        if len(lines) * leading > h + 0.5:
            raise ValueError(f"Slide {self.number}: overflow {content!r}, {len(lines)} lines, height {h}")
        assert min(x, y) >= 0 and x + w <= W and y + h <= H
        self.items.append(dict(kind="text", x=x, y=y, w=w, h=h, text=str(content), lines=lines,
                               size=size, color=color, bold=bold, align=align, leading=leading))

    def band(self, content, size=21):
        self.rect(64, 622, 1152, 42, PALE)
        self.text(81, 629, 1118, 32, content, size, TEAL, True)

    def table(self, headers, rows, widths, y=211, row_h=76, size=22, x=64, header_size=19):
        assert len(headers) == len(widths) and x + sum(widths) <= 1216
        for i, row in enumerate([headers] + rows):
            xx = x
            for j, (content, width) in enumerate(zip(row, widths)):
                yy = y + i * row_h
                self.rect(xx, yy, width, row_h - 1, INK if i == 0 else (WHITE if i % 2 else "#EBEEE8"))
                self.text(xx + 14, yy + 12, width - 28, row_h - 15, content,
                          header_size if i == 0 else size,
                          WHITE if i == 0 else TEAL if j == 0 else INK, i == 0 or j == 0)
                xx += width


def panel(s, x, y, w, h, heading, body, accent=TEAL, size=22):
    s.rect(x, y, w, h, WHITE)
    s.rect(x, y, w, 5, accent)
    s.text(x + 21, y + 23, w - 42, 76, heading, 26, accent, True)
    s.text(x + 21, y + 111, w - 42, h - 123, body, size, INK)


def arrow(s, x1, y1, x2, y2, color=MUTED):
    s.line(x1, y1, x2, y2, color, 2)
    s.line(x2 - 7, y2 - 5, x2, y2, color, 2)
    s.line(x2 - 7, y2 + 5, x2, y2, color, 2)


def pct(n, d):
    return f"{100*n/d:.2f}%"


def story():
    s = Slide("新增证据延伸了同一个研究问题", "当天气证据持续更新，LLM 能否持续给出目标正确、来源当前的答案？",
              "S01 · 旧版截至 09-08 16:51；本包证据截至 09-09 02:44 UTC")
    panel(s, 64, 211, 368, 377, "受控诊断\n为什么需要分层测量", "2,160 份已有模型回答\n内容正确仍可能引用旧版\n\n解释值、来源与整段可靠性\n为何必须分别评估", size=21)
    panel(s, 456, 211, 368, 377, "官方原文\n现在已有真实模型结果", "两风暴 Qwen 收齐 1,542 份\n严格正确 527 份\n\n再扩六个风暴、36 份原文\n检验事件与状态差异", size=21)
    panel(s, 848, 211, 368, 377, "比较诊断\n进一步解释分数来源", "422 对同前缀表示实验\n第二本地模型与协议对照\n\n历史增长、故障牵连与缺失\n成为后续测量的重点", RUST, 21)
    s.band("当前测量对象：对已发布天气陈述的理解、更新与引用。")


def native():
    r = RUNS["p7_qwen3"]
    s = Slide("官方原文上，结构合法仍远不足以保证正确", "两风暴 · 46 个目标 · 257 个检查点 · 三种历史条件 · 两次重复",
              "S02 · P7 global report / analysis；严格正确要求内容、目标、版本与定位同时满足")
    for x, value, head, note, color in (
        (64, "1,542 / 1,542", "全部返回且结构合法", "目标键、单位字符串也全部正确", TEAL),
        (656, f"527 / 1,542", "严格正确：" + pct(527, 1542), "失败不能统一归因于 JSON 格式", RUST),
    ):
        s.rect(x, 208, 560, 169, WHITE)
        s.text(x + 20, 224, 520, 42, head, 25, color, True)
        s.text(x + 20, 273, 520, 60, value, 42, INK, True)
        s.text(x + 20, 342, 520, 29, note, 18, MUTED)
    errors = r["scores"]["errors"]
    rows = [
        ["值／状态失败", str(errors["wrong_value_status_or_unit"]), "本组中单位实际均正确"],
        ["定位／版本／同值旧版", "223 + 23 + 5 = 251", "引用相关的互斥错误类别"],
    ]
    s.table(["错误分解", "失败检查点数", "口径"], rows, [350, 342, 460], y=401, row_h=62, size=21)
    s.band("互斥失败合计 1,015；不要与允许重叠的组件失败计数相加。", 20)


def reliability():
    s = Slide("局部答对，不等于整个目标持续可靠", "276 条轨迹中，仅 19 条所有检查点都正确；进一步要求两次均成功的目标更少。",
              "S03 · P7：276 条目标×方法×重复轨迹，仅 19 条所有检查点正确")
    s.table(["历史条件", "检查点严格正确", "两次均整段正确"], [
        ["snapshot", "187 / 514  = 36.38%", "1 / 46"],
        ["structured_state", "194 / 514  = 37.74%", "2 / 46"],
        ["answer_history", "146 / 514  = 28.40%", "2 / 46"],
    ], [356, 440, 356], y=210, row_h=82, size=24)
    s.text(64, 566, 1152, 38, "Francine 与 Ida 上，snapshot 和 structured_state 的领先顺序相反。", 22, MUTED)
    s.band("两风暴的描述性结果支持多层测量，尚不足以形成通用方法排名。", 20)


def representation():
    pairs = RUNS["p8_qwen3"]["paired_representation"]
    s = Slide("固定同一历史前缀，再比较载体表示", "422 个非初始前缀，每个分别生成 JSON／文本两个单步分支，共 844 份回答。",
              "S04 · P8 paired_representation；两个风暴；分支结果不串成新的闭环轨迹")
    s.table(["配对结果", "文本正确", "文本错误"], [
        ["JSON 正确", "88", "30"], ["JSON 错误", "55", "249"],
    ], [208, 171, 171], y=211, row_h=93, size=25)
    panel(s, 654, 211, 562, 279, "JSON 27.96% → 文本 33.89%", "118 / 422 → 143 / 422\n增加 25 个正确回答，+5.92 个百分点\n保留相同历史信息与已有错误", size=24)
    mean = pairs["captured_pair_prompt_token_difference"]["mean"]
    s.text(64, 526, 1152, 72, f"文本每个请求多 36—54 token，平均多 {mean:.2f}；没有等长度配对。\n观测的是具体表示方案的差异，包括语法和长度。", 23, MUTED)
    s.band("可解释为这些前缀上的单步差异，不能推广为纯格式效应或完整轨迹收益。", 20)


def expanded():
    s = Slide("扩展真实事件，同时检查常见捷径是否有效", "Dorian、Isaias、Henri、Fiona、Lee、Helene；各取最初六份编号公告。",
              "S05 · P10 offline acceptance / FINDINGS；下面是程序成绩，独立于 LLM 回答")
    for x, value, label in ((64, "36", "原始公告"), (350, "144", "绝对时间目标"),
                            (636, "804", "纳入未来检查点"), (922, "2,412", "每模型／协议回答机会")):
        s.rect(x, 207, 276, 137, WHITE)
        s.text(x + 17, 223, 242, 61, value, 42, TEAL, True)
        s.text(x + 17, 299, 242, 32, label, 19, MUTED)
    s.table(["公开程序策略", "正确／2,412", "说明"], [
        ["latest_explicit", "2,412", "规则可公开求解"],
        ["最新公告 / 同相对时长", "1,434 / 1,020", "两类捷径均不等价于目标时间对齐"],
        ["最后一行", "108", "资料中可见不等于属于当前目标"],
    ], [386, 270, 496], y=365, row_h=58, size=20, header_size=18)
    s.band("六个早期公告队列；有终止状态，但没有终止修订检查点。", 21)


def method_metrics():
    s = Slide("同一组结果，不同指标给出不同的方法排序", "六风暴 Qwen，system／任意空白条件已全部收齐；只有一次重复。",
              "S06 · P11 Qwen analysis；P12 为独立默认空白条件，各自产生历史")
    s.table(["历史条件", "检查点正确／804", "整目标正确／144"], [
        ["snapshot", "356  · 单点最多", "4"],
        ["structured_state", "345", "22  · 整目标最多"],
        ["answer_history", "299", "15"],
    ], [355, 402, 395], y=212, row_h=79, size=25)
    s.text(64, 556, 1152, 61, "默认空白条件：snapshot 与 structured_state 同为 369 / 804；\n整目标成功分别为 6 / 144 与 23 / 144。", 21, MUTED)
    s.band("整目标指标揭示错误分布；这里不能称为“两次重复均成功”。", 21)


def status_mix():
    s = Slide("总分变化，需要回到问题状态构成解释", "六风暴 Qwen 的两个完整 system 条件；每行均使用相同计划分母。",
              "S07 · P11 / P12 Qwen status cross_tables；numeric 指完整数值答案及其来源均正确")
    s.table(["参考状态", "任意空白", "默认空白", "正确数变化"], [
        ["numeric", "485 / 1,794\n27.03%", "502 / 1,794\n27.98%", "+17"],
        ["not_stated", "502 / 588\n85.37%", "545 / 588\n92.69%", "+43"],
        ["DISSIPATED", "13 / 30\n43.33%", "13 / 30\n43.33%", "0"],
    ], [300, 314, 314, 224], y=208, row_h=87, size=22)
    s.text(64, 574, 1152, 35, "总分 41.46% → 43.95%，多出的 60 个正确中，43 个来自 not_stated。", 23, INK)
    s.band("报告总分，同时报告 numeric、缺陈述状态、终止状态与风暴分组。", 20)


def protocol():
    s = Slide("第二个模型揭示了输出协议的适配问题", "本地 DeepSeek-R1-Distill-Qwen-7B；各条件固定计划 2,412，未收齐。",
              "S08 · P11–P13 DeepSeek analysis；与 Qwen 共享架构来源，不是早期 DeepSeek API 模型")
    s.table(["角色／空白", "返回", "结构合法", "严格正确", "length 结束"], [
        ["system／任意", "1,604", "1,514", "3", "90"],
        ["system／默认", "1,994", "1,943", "9", "51"],
        ["user／默认", "2,064", "2,011", "6", "53"],
    ], [350, 183, 211, 201, 207], y=212, row_h=74, size=23)
    s.text(64, 535, 1152, 74, "严格正确的 3、9、6 份回答全部属于 not_stated；numeric 和终止组均为 0。\n单位、目标、数值、引用与长度问题并存；本轮没有归一化或答案修补。", 22, MUTED)
    s.band("默认 JSON 分隔空白减少异常空白，但没有保证历史长度有界。", 20)


def isolation():
    s = Slide("一条历史轨迹超限，会停止整个 worker", "DeepSeek 六风暴条件：旧收集器使一条历史轨迹的失败牵连到其他方法。",
              "S09 · context_censoring_v1 / CONTEXT_STOP_WORKER0；现有停止前缀的 CPU 分析")
    s.text(64, 207, 489, 36, "实际下一批次：1 条超限 + 3 条可容纳", 23, INK, True)
    for i in range(4):
        y = 263 + i * 59
        s.rect(64, y, 346, 48, "#F3E5DD" if i == 0 else WHITE)
        s.text(80, y + 10, 314, 32, "history：超过上下文上限" if i == 0 else f"其他请求 {i}：当前可容纳", 21, RUST if i == 0 else TEAL)
    arrow(s, 427, 348, 493, 348)
    s.text(507, 321, 104, 72, "worker\n整体退出", 22, RUST, True)
    s.table(["角色／空白", "最先超限轨迹", "其他轨迹"], [
        ["system／任意", "5", "803"], ["system／默认", "3", "415"], ["user／默认", "2", "346"],
    ], [224, 204, 155], x=633, y=211, row_h=73, size=23, header_size=17)
    s.text(64, 526, 1152, 80, "右表为未尝试槽位归属；不假设更远的其他请求一定可容纳或会答对。\n极长的引用整数仍能增长到数千位，单独限制空白不足以解决问题。", 22, MUTED)
    s.band("下一版应隔离失败轨迹，让其他轨迹继续；历史失败与分母保持冻结。", 20)


def missingness():
    s = Slide("未收齐的角色对照，必须保留缺失与分母", "Qwen user／默认空白：1,628 返回，780 未尝试，4 结果未知；启动更晚。",
              "S10 · P14 analysis / pair_coverage_v1；原 worker 未留下明确最终 stop_reason")
    s.rect(64, 210, 458, 290, WHITE)
    s.text(85, 229, 414, 36, "主结果：952 / 2,412", 25, TEAL, True)
    s.text(85, 275, 414, 69, "39.47%", 48, TEAL, True)
    s.text(85, 369, 414, 98, "返回子集：952 / 1,628 = 58.48%\n不能直接与完整 system 条件的\n1,060 / 2,412 = 43.95% 比较。", 21, MUTED)
    s.table(["user 返回覆盖", "返回／计划"], [
        ["numeric", "1,053 / 1,794"], ["not_stated", "567 / 588"], ["DISSIPATED", "8 / 30"],
    ], [305, 346], x=565, y=211, row_h=73, size=23)
    s.text(64, 533, 1152, 73, "双方返回部分，user 多答对 68；system 独有的返回部分有 176 个正确。\n全计划正确数差：+68 − 176 = −108。共同返回子集也不是无偏校正。", 22, INK)
    s.band("比较完整任务准确率时给足完成预算；比较固定资源时先统一预算口径。", 20)


def conclusions():
    s = Slide("当前结论回到任务、证据和持续可靠性", "新增结果扩展了整体 benchmark 的论证，并明确了需要补足的证据。",
              "S11 · 详细补充稿第 12 节；相关研究沿用旧版核对记录，本次未新增检索")
    panel(s, 64, 211, 368, 380, "任务定义", "对象 + 绝对目标时间\n可见来源 + 当前明确覆盖\n\n受控诊断与官方原文互补\n当前主要覆盖热带气旋\n预报陈述的使用", size=22)
    panel(s, 456, 211, 368, 380, "已有实证", "内容正确与来源正确可分离\n单点表现与整段成功可分离\n\n相同历史的表示仍可有差异\n状态、协议与缺失影响总分", size=22)
    panel(s, 848, 211, 368, 380, "结论边界", "八个原生开发风暴来源\n两个共享 Qwen 来源的模型\n\n尚缺独立 heldout 结论\n不等时限妨碍角色比较\n不据此建立通用方法排名", RUST, 21)
    s.band("可支持的贡献：可执行、可复核，并能解释失败的动态证据测量框架。", 20)


def next_steps():
    s = Slide("下一步按已发现的问题依次补证据", "先提高比较的可解释性，再扩展模型和独立评测；本包没有启动新实验。",
              "S12 · POST_WINDOW_PRIORITIES / 详细补充稿第 13 节")
    rows = [
        ("01", "逐轨迹故障隔离", "超限与未知结果只停止对应轨迹；先做离线故障注入。"),
        ("02", "冻结共同公共协议", "公开表示边界、提示与评分版本；错误但合法的答案仍可生成。"),
        ("03", "分层扩展真实资料", "补生命周期、真实终止修订和时间依据；保留准入失败。"),
        ("04", "等完成预算开发比较", "先明确准确率或固定资源问题，再加入独立模型与重复。"),
        ("05", "独立 heldout 验证", "协议冻结后确定风暴分组统计与污染边界。"),
    ]
    for i, (n, head, body) in enumerate(rows):
        y = 208 + i * 77
        s.rect(64, y, 1152, 68, WHITE)
        s.text(82, y + 14, 75, 45, n, 28, TEAL, True)
        s.text(172, y + 17, 309, 36, head, 23, INK, True)
        s.text(485, y + 19, 709, 33, body, 19, MUTED)
    s.band("当前失败已经给出明确的工作优先级；单纯增加调用量不能消除这些混杂。", 20)


def appendices():
    s = Slide("附录 A1：六风暴完整模型条件表", "每行计划 2,412；三种方法各 804；一次重复；主分母始终保留未返回项。",
              "A1 · tables/model_results.csv；DS 为 DeepSeek-R1-Distill-Qwen-7B", appendix=True)
    rows = []
    for key, label in (("p11_qwen3", "Qwen system／任意"), ("p12_qwen3", "Qwen system／默认"),
                       ("p14_qwen3", "Qwen user／默认"), ("p11_deepseek_r1", "DS system／任意"),
                       ("p12_deepseek_r1", "DS system／默认"), ("p13_deepseek_r1", "DS user／默认")):
        r = RUNS[key]
        rows.append([label, f"{r['counts']['raw_returned']:,}", f"{r['scores']['shape_valid']:,}",
                     f"{r['scores']['all_correct']:,}", f"{r['strict_percent_planned']:.2f}%",
                     f"{r['counts']['unattempted']} + {r['counts']['unknown_outcomes']}"])
    s.table(["模型／角色／空白", "返回", "合法", "严格正确", "主正确率", "未试＋未知"],
            rows, [351, 135, 135, 178, 166, 187], y=209, row_h=55, size=19, header_size=17)
    s.band("默认空白指 JSON 默认分隔符格式；三种条件各自生成历史，不是完整因子设计。", 19)

    s = Slide("附录 A2：完成状态分三层说明", "快照 2026-09-09 02:44 UTC；全部引用的阶段验收已存在并通过。",
              "A2 · 125 个来源 / 178 项快照一致性检查；没有在本次制作中重跑完整科学审计", appendix=True)
    s.table(["层面", "截至快照的状态", "含义"], [
        ["模型收集", "部分条件收齐；部分停止", "失败和缺失保留在计划分母"],
        ["阶段验收", "P7—P14 相应验收 passed", "包括未收齐运行的可重建前缀"],
        ["全局归档／发布", "本包未核验统一闭合", "不据此声明最新 GitHub 已包含全部结果"],
    ], [255, 426, 471], y=213, row_h=84, size=21)
    s.text(64, 564, 1152, 47, "P11 原清单漏绑 14 个分析／命令文件，另有 30 文件补充；原始模型得分不变。", 21, MUTED)
    s.band("本包是带证据入口的阅读附件；完整科学复查仍需原始研究归档与清单。", 20)

    s = Slide("附录 A3：并入旧汇报时保持论文主线", "旧版解释为什么测、怎样测；补充包更新已有证据、当前结论和下一步。",
              "A3 · PRE_UPDATE_GUIDE_CN / SUPPLEMENT_SPEAKER_NOTES_CN / ChatGPT Pro 复查提示", appendix=True)
    s.table(["旧内容", "合并动作"], [
        ["1—9：问题与设计", "保留结构；更新原生模型结果待采集的过时状态"],
        ["11—14：受控与原文", "接入 S02—S07：原文结果、表示、事件与指标"],
        ["15—18：进展与结论", "用 S09—S12 更新：测量问题、结论与执行优先级"],
    ], [338, 814], y=211, row_h=85, size=23)
    s.text(64, 565, 1152, 39, "阶段编号放附录；任一百分比旁保留分母，未收齐条件保留缺失。", 23, MUTED)
    s.band("动机 → 任务设计 → 互补实证 → 比较边界 → 下一步需要的证据", 22)


def render():
    c = canvas.Canvas(str(PDF), pagesize=(W, H), pageCompression=1)
    c.setTitle("DisasterTrace 最新进展补充：动态天气证据中的 LLM 可靠性")
    c.setAuthor("DisasterTrace")
    c.setSubject("证据快照 2026-09-09 02:44 UTC；论文式整体汇报补充")
    for s in SLIDES:
        key = f"slide_{s.number:02d}"
        c.bookmarkPage(key)
        c.addOutlineEntry(f"{s.number:02d}  {s.title}", key, 0, False)
        for e in s.items:
            if e["kind"] == "rect":
                c.setFillColor(HexColor(e["fill"]))
                c.setStrokeColor(HexColor(e["stroke"] or e["fill"]))
                c.rect(e["x"], H-e["y"]-e["h"], e["w"], e["h"], fill=1, stroke=bool(e["stroke"]))
            elif e["kind"] == "line":
                c.setStrokeColor(HexColor(e["color"]))
                c.setLineWidth(e["width"])
                c.line(e["x1"], H-e["y1"], e["x2"], H-e["y2"])
            else:
                name = face(e["bold"])
                c.setFont(name, e["size"])
                c.setFillColor(HexColor(e["color"]))
                ascent = pdfmetrics.getAscent(name) / 1000 * e["size"]
                for i, line in enumerate(e["lines"]):
                    width = pdfmetrics.stringWidth(line, name, e["size"])
                    x = e["x"] + (e["w"]-width)*{"left": 0, "center": .5, "right": 1}[e["align"]]
                    c.drawString(x, H-e["y"]-ascent-i*e["leading"], line)
        c.showPage()
    c.save()


def validate(fonts):
    preview = OUT / "preview"
    preview.mkdir(exist_ok=True)
    doc = pymupdf.open(PDF)
    assert len(doc) == len(SLIDES) == 15 and len(doc.get_toc()) == 15
    compact = lambda text: re.sub(r"\s+", "", text)
    checks = []
    for index, (page, slide) in enumerate(zip(doc, SLIDES), 1):
        assert page.rect.width == W and page.rect.height == H
        text = compact(page.get_text())
        for e in slide.items:
            if e["kind"] == "text":
                assert compact(e["text"]) in text, (index, e["text"])
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                for span in line["spans"]:
                    x0, y0, x1, y1 = span["bbox"]
                    assert min(x0, y0) >= -0.1 and x1 <= W+.1 and y1 <= H+.1, (index, span)
        assert not page.get_images()
        page.get_pixmap(matrix=pymupdf.Matrix(1, 1), alpha=False).save(preview / f"page_{index:02d}.png")
        checks.append({"page": index, "text_complete": True, "bounds_passed": True})
    embedded = {e for p in doc for e in p.get_fonts() if "Noto" in e[3]}
    assert {e[3].split("+")[-1] for e in embedded} == {"NotoSansSC-Regular", "NotoSansSC-Bold"}
    for e in embedded:
        assert len(doc.extract_font(e[0])[3]) > 1000
    font = ImageFont.truetype(str(fonts / "NotoSansSC-Regular.ttf"), 19)
    for batch, start in enumerate(range(0, len(doc), 9), 1):
        sheet = Image.new("RGB", (1280, 804), "#D7DEDB")
        drawer = ImageDraw.Draw(sheet)
        for local, index in enumerate(range(start, min(start+9, len(doc)))):
            im = Image.open(preview / f"page_{index+1:02d}.png").convert("RGB")
            im.thumbnail((400, 225), Image.Resampling.LANCZOS)
            x, y = 16+local%3*426, 10+local//3*265
            sheet.paste(im, (x, y))
            drawer.text((x+4, y+229), f"{index+1:02d} " + SLIDES[index].title[:18], font=font, fill=INK)
        sheet.save(preview / f"contact_sheet_{batch}.jpg", quality=93)
    receipt = {"status": "passed", "pages": 15, "main_pages": 12, "appendix_pages": 3,
               "aspect_ratio": "16:9", "embedded_chinese_font_faces": 2, "bookmarks": 15,
               "vector_graphics": True, "raster_images_in_pdf": 0, "page_checks": checks,
               "pdf_sha256": hashlib.sha256(PDF.read_bytes()).hexdigest(),
               "pdf_bytes": PDF.stat().st_size, "visual_review_pending": True,
               "model_calls": 0, "gpu_jobs": 0}
    (OUT / "pdf_validation.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({k: v for k, v in receipt.items() if k != "page_checks"}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--font-dir", type=Path, default=ROOT / "reports/progress_20260908/fonts")
    args = parser.parse_args()
    for name in ("Regular", "Bold"):
        pdfmetrics.registerFont(TTFont("Noto"+name, str(args.font_dir / f"NotoSansSC-{name}.ttf")))
    for entry in FACTS["sources"].values():
        if "copy" in entry:
            assert hashlib.sha256((OUT/entry["copy"]).read_bytes()).hexdigest() == entry["sha256"]
    for builder in (story, native, reliability, representation, expanded, method_metrics,
                    status_mix, protocol, isolation, missingness, conclusions, next_steps, appendices):
        builder()
    render()
    (OUT / "slide_manifest.json").write_text(json.dumps([
        {"number": s.number, "title": s.title, "appendix": s.appendix, "items": s.items}
        for s in SLIDES], ensure_ascii=False, indent=2)+"\n")
    inputs = [Path(__file__), OUT / "evidence/snapshot.json", *sorted(OUT.glob("*.md"))]
    (OUT / "evidence/build_inputs.json").write_text(json.dumps({
        "inputs_sha256": {str(p.relative_to(OUT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
        "font_files_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in
                              (args.font_dir/"NotoSansSC-Regular.ttf", args.font_dir/"NotoSansSC-Bold.ttf")},
        "libraries": {name: version(name) for name in ("reportlab", "PyMuPDF", "Pillow")},
        "model_calls": 0, "gpu_jobs": 0,
    }, ensure_ascii=False, indent=2)+"\n")
    validate(args.font_dir)


if __name__ == "__main__":
    main()
