"""Package the reading supplement and verify a temporary extracted copy."""

import hashlib
import json
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path


OUT = Path(__file__).resolve().parent
ZIP = OUT / "DisasterTrace_Latest_Progress_Supplement_20260909.zip"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name):
    return json.loads((OUT / name).read_text())


def write(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def main():
    pdf = load("pdf_validation.json")
    documents = load("evidence/document_validation.json")
    snapshot = load("evidence/snapshot.json")
    assert pdf["status"] == documents["status"] == "passed"
    assert not pdf["visual_review_pending"]
    assert pdf["pdf_sha256"] == sha(OUT / "DisasterTrace_Latest_Progress_Supplement_CN.pdf")
    for name, expected in load("evidence/build_inputs.json")["inputs_sha256"].items():
        assert sha(OUT / name) == expected, name
    write("bundle_validation.json", {
        "status": "passed", "at_utc": datetime.now(timezone.utc).isoformat(),
        "snapshot_at_utc": snapshot["snapshot_at_utc"], "source_files": len(snapshot["sources"]),
        "collection_checks": len(snapshot["checks"]), "document_checks": documents["checks"],
        "pdf_pages": pdf["pages"], "pdf_visual_review_complete": True,
        "pdf_sha256": pdf["pdf_sha256"], "new_model_calls": 0, "new_gpu_jobs": 0,
        "scope": "Reading supplement, not a complete scientific evidence archive.",
        "zip_integrity_receipt": "ZIP_RECEIPT.json is outside the ZIP to avoid a self-referential hash.",
    })
    excluded = {ZIP.name, "ZIP_RECEIPT.json", "MANIFEST.sha256"}
    paths = sorted(p for p in OUT.rglob("*") if p.is_file() and
                   p.name not in excluded and "__pycache__" not in p.parts and p.suffix != ".pyc")
    expected = {str(p.relative_to(OUT)): sha(p) for p in paths}
    manifest = OUT / "MANIFEST.sha256"
    manifest.write_text("".join(f"{value}  {name}\n" for name, value in expected.items()))
    with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in paths + [manifest]:
            archive.write(path, str(Path(OUT.name) / path.relative_to(OUT)))
    with tempfile.TemporaryDirectory(prefix="disastertrace-reading-verify-") as scratch:
        with zipfile.ZipFile(ZIP) as archive:
            assert archive.testzip() is None
            names = archive.namelist()
            assert len(names) == len(set(names)) == len(paths) + 1
            for name in names:
                path = Path(name)
                assert not path.is_absolute() and ".." not in path.parts
            archive.extractall(scratch)
        restored = Path(scratch) / OUT.name
        assert (restored / "MANIFEST.sha256").read_bytes() == manifest.read_bytes()
        for name, value in expected.items():
            assert sha(restored / name) == value, name
    receipt = {
        "status": "passed", "zip_name": ZIP.name, "zip_sha256": sha(ZIP),
        "zip_bytes": ZIP.stat().st_size, "archive_entries": len(paths) + 1,
        "manifest_payload_files": len(paths), "crc_passed": True,
        "temporary_extraction_hashes_passed": True, "manifest_sha256": sha(manifest),
        "snapshot_at_utc": snapshot["snapshot_at_utc"],
        "model_calls": 0, "gpu_jobs": 0,
    }
    write("ZIP_RECEIPT.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
